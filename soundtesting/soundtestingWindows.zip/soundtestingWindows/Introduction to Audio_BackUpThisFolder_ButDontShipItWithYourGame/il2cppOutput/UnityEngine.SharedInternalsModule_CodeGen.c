﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.AssetFileNameExtensionAttribute::.ctor(System.String,System.String[])
extern void AssetFileNameExtensionAttribute__ctor_m49EB0E6BB7D29A0AC5131A6EC007AFBC1DE60390 (void);
// 0x00000002 System.Void UnityEngine.ThreadAndSerializationSafeAttribute::.ctor()
extern void ThreadAndSerializationSafeAttribute__ctor_mCB8D8FEED836D6472A4FB90C69969F0D99C39619 (void);
// 0x00000003 System.Void UnityEngine.WritableAttribute::.ctor()
extern void WritableAttribute__ctor_m58A5D24131EC67D50A7BF2804568DCB607BD97D6 (void);
// 0x00000004 System.Void UnityEngine.UnityEngineModuleAssembly::.ctor()
extern void UnityEngineModuleAssembly__ctor_m791D74EDFEF6B1368540E376C7DCA131C2528993 (void);
// 0x00000005 System.Void UnityEngine.NativeClassAttribute::set_QualifiedNativeName(System.String)
extern void NativeClassAttribute_set_QualifiedNativeName_m4649657DC46E04FAE4BED6D53EBB7C82CEE4FC31 (void);
// 0x00000006 System.Void UnityEngine.NativeClassAttribute::set_Declaration(System.String)
extern void NativeClassAttribute_set_Declaration_m2C630638B2BB58F82CA43663F183761444524F1A (void);
// 0x00000007 System.Void UnityEngine.NativeClassAttribute::.ctor(System.String)
extern void NativeClassAttribute__ctor_m814DCB23A54C2AE01ACDB1930DDF06277CAD9DE8 (void);
// 0x00000008 System.Void UnityEngine.NativeClassAttribute::.ctor(System.String,System.String)
extern void NativeClassAttribute__ctor_mFAF14B283CE2D27EA4A98E118CB5ED55A2232F92 (void);
// 0x00000009 System.String UnityEngine.UnityString::Format(System.String,System.Object[])
extern void UnityString_Format_m415056ECF8DA7B3EC6A8456E299D0C2002177387 (void);
// 0x0000000A System.Void UnityEngine.Bindings.VisibleToOtherModulesAttribute::.ctor()
extern void VisibleToOtherModulesAttribute__ctor_m82D98B6D202548277D803878EB2BE3A82722CC74 (void);
// 0x0000000B System.Void UnityEngine.Bindings.VisibleToOtherModulesAttribute::.ctor(System.String[])
extern void VisibleToOtherModulesAttribute__ctor_mEC52A33ADE6FEA527A467F9F64BF966F2A63A942 (void);
// 0x0000000C System.Void UnityEngine.Bindings.NativeConditionalAttribute::set_Condition(System.String)
extern void NativeConditionalAttribute_set_Condition_m0BD35F77FDBCC278203543FB3CAC35A8227474B5 (void);
// 0x0000000D System.Void UnityEngine.Bindings.NativeConditionalAttribute::set_StubReturnStatement(System.String)
extern void NativeConditionalAttribute_set_StubReturnStatement_m5B9DD02B66D59F5F7D5EA7935C3D111A25AF49ED (void);
// 0x0000000E System.Void UnityEngine.Bindings.NativeConditionalAttribute::set_Enabled(System.Boolean)
extern void NativeConditionalAttribute_set_Enabled_m3584B9F0F4BD7F3F8B8C49595D1900EF01B3C1E0 (void);
// 0x0000000F System.Void UnityEngine.Bindings.NativeConditionalAttribute::.ctor(System.String)
extern void NativeConditionalAttribute__ctor_mBF34AC3E165A50B3BE9F49520DDE1851DC7CFF13 (void);
// 0x00000010 System.Void UnityEngine.Bindings.NativeConditionalAttribute::.ctor(System.String,System.String)
extern void NativeConditionalAttribute__ctor_m346032B5B913E186D2688335FF8A7093555444C9 (void);
// 0x00000011 System.Void UnityEngine.Bindings.NativeHeaderAttribute::set_Header(System.String)
extern void NativeHeaderAttribute_set_Header_m4DBF0E38BD79721921158F6B12B9AF58316C6778 (void);
// 0x00000012 System.Void UnityEngine.Bindings.NativeHeaderAttribute::.ctor(System.String)
extern void NativeHeaderAttribute__ctor_m490124694FDBCB4336CBA29D2E24A27FF3451A0E (void);
// 0x00000013 System.Void UnityEngine.Bindings.NativeNameAttribute::set_Name(System.String)
extern void NativeNameAttribute_set_Name_m8559126FDC09CB14ADF9AF9D03E6102908738FD3 (void);
// 0x00000014 System.Void UnityEngine.Bindings.NativeNameAttribute::.ctor(System.String)
extern void NativeNameAttribute__ctor_m85D49395E6305D8C6CFA8C39A83653F36A8FC9BA (void);
// 0x00000015 System.Void UnityEngine.Bindings.NativeWritableSelfAttribute::set_WritableSelf(System.Boolean)
extern void NativeWritableSelfAttribute_set_WritableSelf_mB6A7EF77A83E5B77DAE7BBA1F8A63BBB44C1529B (void);
// 0x00000016 System.Void UnityEngine.Bindings.NativeWritableSelfAttribute::.ctor()
extern void NativeWritableSelfAttribute__ctor_m827940BA28BA2267BA715EADC657E4638C1FF780 (void);
// 0x00000017 System.Void UnityEngine.Bindings.NativeMethodAttribute::set_Name(System.String)
extern void NativeMethodAttribute_set_Name_mBC4CF088461DE9830E85F6E68B462DE9CC48574C (void);
// 0x00000018 System.Void UnityEngine.Bindings.NativeMethodAttribute::set_IsThreadSafe(System.Boolean)
extern void NativeMethodAttribute_set_IsThreadSafe_m11B322FBC460DD97E27F24B6686F5D8C4077F7E6 (void);
// 0x00000019 System.Void UnityEngine.Bindings.NativeMethodAttribute::set_IsFreeFunction(System.Boolean)
extern void NativeMethodAttribute_set_IsFreeFunction_m4A2C3A5DE2D0CCAC8FFFB6660BAD55A044EFFDDF (void);
// 0x0000001A System.Void UnityEngine.Bindings.NativeMethodAttribute::set_ThrowsException(System.Boolean)
extern void NativeMethodAttribute_set_ThrowsException_m923834F65F9D355EE8E6F8FC760DB6F9C94F22F1 (void);
// 0x0000001B System.Void UnityEngine.Bindings.NativeMethodAttribute::set_HasExplicitThis(System.Boolean)
extern void NativeMethodAttribute_set_HasExplicitThis_mA955027BB50011811A96125CB83F88BB9BD61F1D (void);
// 0x0000001C System.Void UnityEngine.Bindings.NativeMethodAttribute::.ctor()
extern void NativeMethodAttribute__ctor_mE26CCBB6FA1CF524CDF21471D4D513E7DE1C5B43 (void);
// 0x0000001D System.Void UnityEngine.Bindings.NativeMethodAttribute::.ctor(System.String)
extern void NativeMethodAttribute__ctor_m1A8CC57006916ACBBBCB515C26224392E8711A22 (void);
// 0x0000001E System.Void UnityEngine.Bindings.NativeMethodAttribute::.ctor(System.String,System.Boolean)
extern void NativeMethodAttribute__ctor_m34B386D374A17251F14912F04256860E57DF559F (void);
// 0x0000001F System.Void UnityEngine.Bindings.NativeMethodAttribute::.ctor(System.String,System.Boolean,System.Boolean)
extern void NativeMethodAttribute__ctor_m793B5D7530F92DC04173E68EAD8F4A8F9232DD29 (void);
// 0x00000020 System.Void UnityEngine.Bindings.NativePropertyAttribute::set_TargetType(UnityEngine.Bindings.TargetType)
extern void NativePropertyAttribute_set_TargetType_m8705F4754AA0C953CDA6DDCB95B0276F51FE0146 (void);
// 0x00000021 System.Void UnityEngine.Bindings.NativePropertyAttribute::.ctor()
extern void NativePropertyAttribute__ctor_mC9AA5DB9519961A6AA76C71968B7E4F9649235FF (void);
// 0x00000022 System.Void UnityEngine.Bindings.NativePropertyAttribute::.ctor(System.String)
extern void NativePropertyAttribute__ctor_m92618E6DC14A2AD87A9CB3A2BB3DFCDA1A431164 (void);
// 0x00000023 System.Void UnityEngine.Bindings.NativePropertyAttribute::.ctor(System.String,System.Boolean,UnityEngine.Bindings.TargetType)
extern void NativePropertyAttribute__ctor_m2584E9D08E56EFB31AE671E6488046168A3911D3 (void);
// 0x00000024 System.Void UnityEngine.Bindings.NativeAsStructAttribute::.ctor()
extern void NativeAsStructAttribute__ctor_m9886B079ED1A2BC42C0133A3C726ED96D4DEFA34 (void);
// 0x00000025 System.Void UnityEngine.Bindings.NativeTypeAttribute::set_Header(System.String)
extern void NativeTypeAttribute_set_Header_m1CC3A47E66E54E5E7A87C5C5911B8EE9D0E8657B (void);
// 0x00000026 System.Void UnityEngine.Bindings.NativeTypeAttribute::set_IntermediateScriptingStructName(System.String)
extern void NativeTypeAttribute_set_IntermediateScriptingStructName_m6409CEAAEE1D910DE284325904215DAE9104DDFE (void);
// 0x00000027 System.Void UnityEngine.Bindings.NativeTypeAttribute::set_CodegenOptions(UnityEngine.Bindings.CodegenOptions)
extern void NativeTypeAttribute_set_CodegenOptions_m25EC23287090E27AA2344F376BABD52DE4D4A23D (void);
// 0x00000028 System.Void UnityEngine.Bindings.NativeTypeAttribute::.ctor()
extern void NativeTypeAttribute__ctor_mC6578F8A8AD3F4778CCC17248E32746D9BCD7C1F (void);
// 0x00000029 System.Void UnityEngine.Bindings.NativeTypeAttribute::.ctor(UnityEngine.Bindings.CodegenOptions)
extern void NativeTypeAttribute__ctor_m51D3D691AF2587E97E54787810199664922210DE (void);
// 0x0000002A System.Void UnityEngine.Bindings.NativeTypeAttribute::.ctor(System.String)
extern void NativeTypeAttribute__ctor_m7ACA25C054E933120D16DC7BBDE17734194454B6 (void);
// 0x0000002B System.Void UnityEngine.Bindings.NativeTypeAttribute::.ctor(UnityEngine.Bindings.CodegenOptions,System.String)
extern void NativeTypeAttribute__ctor_mF0E347C64A5AAF78A6FDB8EF2FDC39C0753B0211 (void);
// 0x0000002C System.Void UnityEngine.Bindings.NotNullAttribute::.ctor()
extern void NotNullAttribute__ctor_m8F88B3030D52285AA10334E4E117151630BEC045 (void);
// 0x0000002D System.Void UnityEngine.Bindings.UnmarshalledAttribute::.ctor()
extern void UnmarshalledAttribute__ctor_m7E224B875755FD7109EDFB2CBA2A2F7F617A1191 (void);
// 0x0000002E System.Void UnityEngine.Bindings.FreeFunctionAttribute::.ctor()
extern void FreeFunctionAttribute__ctor_m69E4EBDD649729C9473BA68585097AF48D06B83D (void);
// 0x0000002F System.Void UnityEngine.Bindings.FreeFunctionAttribute::.ctor(System.String)
extern void FreeFunctionAttribute__ctor_m18D7DE98494E55663EB23287EE6DB00E6649241F (void);
// 0x00000030 System.Void UnityEngine.Bindings.FreeFunctionAttribute::.ctor(System.String,System.Boolean)
extern void FreeFunctionAttribute__ctor_m54898E27CB62607552A0612FA26165A18CB3F444 (void);
// 0x00000031 System.Void UnityEngine.Bindings.ThreadSafeAttribute::.ctor()
extern void ThreadSafeAttribute__ctor_mC3058002BD52E2EB8475B8115A1AC5FFCA53E1DD (void);
// 0x00000032 System.Void UnityEngine.Bindings.StaticAccessorAttribute::set_Name(System.String)
extern void StaticAccessorAttribute_set_Name_mBFD8EFC09BA63B0CE005B306037E564B530377D0 (void);
// 0x00000033 System.Void UnityEngine.Bindings.StaticAccessorAttribute::set_Type(UnityEngine.Bindings.StaticAccessorType)
extern void StaticAccessorAttribute_set_Type_m85233B66B145700BD66145EB0AA31D0960896AE2 (void);
// 0x00000034 System.Void UnityEngine.Bindings.StaticAccessorAttribute::.ctor(System.String)
extern void StaticAccessorAttribute__ctor_m6698A0204830E258A0D9881AFA7368196C179782 (void);
// 0x00000035 System.Void UnityEngine.Bindings.StaticAccessorAttribute::.ctor(System.String,UnityEngine.Bindings.StaticAccessorType)
extern void StaticAccessorAttribute__ctor_m8F492CF3D710FAE0D63BB8C2640D271264C84448 (void);
// 0x00000036 System.Void UnityEngine.Bindings.NativeThrowsAttribute::set_ThrowsException(System.Boolean)
extern void NativeThrowsAttribute_set_ThrowsException_m563468CF2C9D8B2D745373285B67150C734F363F (void);
// 0x00000037 System.Void UnityEngine.Bindings.NativeThrowsAttribute::.ctor()
extern void NativeThrowsAttribute__ctor_m4EBDA91A1EBCABBD08DF5A91E216578B8CD76EDB (void);
// 0x00000038 System.Void UnityEngine.Bindings.IgnoreAttribute::set_DoesNotContributeToSize(System.Boolean)
extern void IgnoreAttribute_set_DoesNotContributeToSize_mF507E8A0ADF588062014330B44B9BD674D7A75AA (void);
// 0x00000039 System.Void UnityEngine.Bindings.IgnoreAttribute::.ctor()
extern void IgnoreAttribute__ctor_m4B78BE44704DA9040A683AC928187E1DAE6BC885 (void);
// 0x0000003A System.Void UnityEngine.Scripting.UsedByNativeCodeAttribute::.ctor()
extern void UsedByNativeCodeAttribute__ctor_m599B42E9BBC333CDA57CD8154C902AB7594B80AD (void);
// 0x0000003B System.Void UnityEngine.Scripting.UsedByNativeCodeAttribute::.ctor(System.String)
extern void UsedByNativeCodeAttribute__ctor_m55E1FDE70505DB890BD076C78AF986869C3D714F (void);
// 0x0000003C System.Void UnityEngine.Scripting.UsedByNativeCodeAttribute::set_Name(System.String)
extern void UsedByNativeCodeAttribute_set_Name_m5AF6F7B56F5D616F4CA7C5C2AE1E92B5A621A062 (void);
// 0x0000003D System.Void UnityEngine.Scripting.RequiredByNativeCodeAttribute::.ctor()
extern void RequiredByNativeCodeAttribute__ctor_mD8B976753773E00BB7E1E63DF6C23A1EB3054422 (void);
// 0x0000003E System.Void UnityEngine.Scripting.RequiredByNativeCodeAttribute::.ctor(System.String)
extern void RequiredByNativeCodeAttribute__ctor_m761592712F1FA96E5BF7721E9463AE05DC73A306 (void);
// 0x0000003F System.Void UnityEngine.Scripting.RequiredByNativeCodeAttribute::set_Name(System.String)
extern void RequiredByNativeCodeAttribute_set_Name_m756DAF113B75ABD5D869765E6FA6C546ADC85423 (void);
// 0x00000040 System.Void UnityEngine.Scripting.RequiredByNativeCodeAttribute::set_Optional(System.Boolean)
extern void RequiredByNativeCodeAttribute_set_Optional_m995DE99A803BC2D6FE66CCB370AEBE5ACF706955 (void);
// 0x00000041 System.Void UnityEngine.Scripting.RequiredByNativeCodeAttribute::set_GenerateProxy(System.Boolean)
extern void RequiredByNativeCodeAttribute_set_GenerateProxy_m8B647BCD03460AD81F920CEF4CC51B499B5AFE55 (void);
static Il2CppMethodPointer s_methodPointers[65] = 
{
	AssetFileNameExtensionAttribute__ctor_m49EB0E6BB7D29A0AC5131A6EC007AFBC1DE60390,
	ThreadAndSerializationSafeAttribute__ctor_mCB8D8FEED836D6472A4FB90C69969F0D99C39619,
	WritableAttribute__ctor_m58A5D24131EC67D50A7BF2804568DCB607BD97D6,
	UnityEngineModuleAssembly__ctor_m791D74EDFEF6B1368540E376C7DCA131C2528993,
	NativeClassAttribute_set_QualifiedNativeName_m4649657DC46E04FAE4BED6D53EBB7C82CEE4FC31,
	NativeClassAttribute_set_Declaration_m2C630638B2BB58F82CA43663F183761444524F1A,
	NativeClassAttribute__ctor_m814DCB23A54C2AE01ACDB1930DDF06277CAD9DE8,
	NativeClassAttribute__ctor_mFAF14B283CE2D27EA4A98E118CB5ED55A2232F92,
	UnityString_Format_m415056ECF8DA7B3EC6A8456E299D0C2002177387,
	VisibleToOtherModulesAttribute__ctor_m82D98B6D202548277D803878EB2BE3A82722CC74,
	VisibleToOtherModulesAttribute__ctor_mEC52A33ADE6FEA527A467F9F64BF966F2A63A942,
	NativeConditionalAttribute_set_Condition_m0BD35F77FDBCC278203543FB3CAC35A8227474B5,
	NativeConditionalAttribute_set_StubReturnStatement_m5B9DD02B66D59F5F7D5EA7935C3D111A25AF49ED,
	NativeConditionalAttribute_set_Enabled_m3584B9F0F4BD7F3F8B8C49595D1900EF01B3C1E0,
	NativeConditionalAttribute__ctor_mBF34AC3E165A50B3BE9F49520DDE1851DC7CFF13,
	NativeConditionalAttribute__ctor_m346032B5B913E186D2688335FF8A7093555444C9,
	NativeHeaderAttribute_set_Header_m4DBF0E38BD79721921158F6B12B9AF58316C6778,
	NativeHeaderAttribute__ctor_m490124694FDBCB4336CBA29D2E24A27FF3451A0E,
	NativeNameAttribute_set_Name_m8559126FDC09CB14ADF9AF9D03E6102908738FD3,
	NativeNameAttribute__ctor_m85D49395E6305D8C6CFA8C39A83653F36A8FC9BA,
	NativeWritableSelfAttribute_set_WritableSelf_mB6A7EF77A83E5B77DAE7BBA1F8A63BBB44C1529B,
	NativeWritableSelfAttribute__ctor_m827940BA28BA2267BA715EADC657E4638C1FF780,
	NativeMethodAttribute_set_Name_mBC4CF088461DE9830E85F6E68B462DE9CC48574C,
	NativeMethodAttribute_set_IsThreadSafe_m11B322FBC460DD97E27F24B6686F5D8C4077F7E6,
	NativeMethodAttribute_set_IsFreeFunction_m4A2C3A5DE2D0CCAC8FFFB6660BAD55A044EFFDDF,
	NativeMethodAttribute_set_ThrowsException_m923834F65F9D355EE8E6F8FC760DB6F9C94F22F1,
	NativeMethodAttribute_set_HasExplicitThis_mA955027BB50011811A96125CB83F88BB9BD61F1D,
	NativeMethodAttribute__ctor_mE26CCBB6FA1CF524CDF21471D4D513E7DE1C5B43,
	NativeMethodAttribute__ctor_m1A8CC57006916ACBBBCB515C26224392E8711A22,
	NativeMethodAttribute__ctor_m34B386D374A17251F14912F04256860E57DF559F,
	NativeMethodAttribute__ctor_m793B5D7530F92DC04173E68EAD8F4A8F9232DD29,
	NativePropertyAttribute_set_TargetType_m8705F4754AA0C953CDA6DDCB95B0276F51FE0146,
	NativePropertyAttribute__ctor_mC9AA5DB9519961A6AA76C71968B7E4F9649235FF,
	NativePropertyAttribute__ctor_m92618E6DC14A2AD87A9CB3A2BB3DFCDA1A431164,
	NativePropertyAttribute__ctor_m2584E9D08E56EFB31AE671E6488046168A3911D3,
	NativeAsStructAttribute__ctor_m9886B079ED1A2BC42C0133A3C726ED96D4DEFA34,
	NativeTypeAttribute_set_Header_m1CC3A47E66E54E5E7A87C5C5911B8EE9D0E8657B,
	NativeTypeAttribute_set_IntermediateScriptingStructName_m6409CEAAEE1D910DE284325904215DAE9104DDFE,
	NativeTypeAttribute_set_CodegenOptions_m25EC23287090E27AA2344F376BABD52DE4D4A23D,
	NativeTypeAttribute__ctor_mC6578F8A8AD3F4778CCC17248E32746D9BCD7C1F,
	NativeTypeAttribute__ctor_m51D3D691AF2587E97E54787810199664922210DE,
	NativeTypeAttribute__ctor_m7ACA25C054E933120D16DC7BBDE17734194454B6,
	NativeTypeAttribute__ctor_mF0E347C64A5AAF78A6FDB8EF2FDC39C0753B0211,
	NotNullAttribute__ctor_m8F88B3030D52285AA10334E4E117151630BEC045,
	UnmarshalledAttribute__ctor_m7E224B875755FD7109EDFB2CBA2A2F7F617A1191,
	FreeFunctionAttribute__ctor_m69E4EBDD649729C9473BA68585097AF48D06B83D,
	FreeFunctionAttribute__ctor_m18D7DE98494E55663EB23287EE6DB00E6649241F,
	FreeFunctionAttribute__ctor_m54898E27CB62607552A0612FA26165A18CB3F444,
	ThreadSafeAttribute__ctor_mC3058002BD52E2EB8475B8115A1AC5FFCA53E1DD,
	StaticAccessorAttribute_set_Name_mBFD8EFC09BA63B0CE005B306037E564B530377D0,
	StaticAccessorAttribute_set_Type_m85233B66B145700BD66145EB0AA31D0960896AE2,
	StaticAccessorAttribute__ctor_m6698A0204830E258A0D9881AFA7368196C179782,
	StaticAccessorAttribute__ctor_m8F492CF3D710FAE0D63BB8C2640D271264C84448,
	NativeThrowsAttribute_set_ThrowsException_m563468CF2C9D8B2D745373285B67150C734F363F,
	NativeThrowsAttribute__ctor_m4EBDA91A1EBCABBD08DF5A91E216578B8CD76EDB,
	IgnoreAttribute_set_DoesNotContributeToSize_mF507E8A0ADF588062014330B44B9BD674D7A75AA,
	IgnoreAttribute__ctor_m4B78BE44704DA9040A683AC928187E1DAE6BC885,
	UsedByNativeCodeAttribute__ctor_m599B42E9BBC333CDA57CD8154C902AB7594B80AD,
	UsedByNativeCodeAttribute__ctor_m55E1FDE70505DB890BD076C78AF986869C3D714F,
	UsedByNativeCodeAttribute_set_Name_m5AF6F7B56F5D616F4CA7C5C2AE1E92B5A621A062,
	RequiredByNativeCodeAttribute__ctor_mD8B976753773E00BB7E1E63DF6C23A1EB3054422,
	RequiredByNativeCodeAttribute__ctor_m761592712F1FA96E5BF7721E9463AE05DC73A306,
	RequiredByNativeCodeAttribute_set_Name_m756DAF113B75ABD5D869765E6FA6C546ADC85423,
	RequiredByNativeCodeAttribute_set_Optional_m995DE99A803BC2D6FE66CCB370AEBE5ACF706955,
	RequiredByNativeCodeAttribute_set_GenerateProxy_m8B647BCD03460AD81F920CEF4CC51B499B5AFE55,
};
static const int32_t s_InvokerIndices[65] = 
{
	27,
	23,
	23,
	23,
	26,
	26,
	26,
	27,
	1,
	23,
	26,
	26,
	26,
	31,
	26,
	27,
	26,
	26,
	26,
	26,
	31,
	23,
	26,
	31,
	31,
	31,
	31,
	23,
	26,
	406,
	753,
	32,
	23,
	26,
	1036,
	23,
	26,
	26,
	32,
	23,
	32,
	26,
	62,
	23,
	23,
	23,
	26,
	406,
	23,
	26,
	32,
	26,
	140,
	31,
	23,
	31,
	23,
	23,
	26,
	26,
	23,
	26,
	26,
	31,
	31,
};
extern const Il2CppCodeGenModule g_UnityEngine_SharedInternalsModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_SharedInternalsModuleCodeGenModule = 
{
	"UnityEngine.SharedInternalsModule.dll",
	65,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
