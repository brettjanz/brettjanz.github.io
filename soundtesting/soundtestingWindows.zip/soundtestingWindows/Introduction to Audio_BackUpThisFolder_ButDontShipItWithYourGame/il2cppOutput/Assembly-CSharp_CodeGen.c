﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void CarMovement::Start()
extern void CarMovement_Start_m217CE842B1C5D3D43B925116901D04941515E4B1 (void);
// 0x00000002 System.Void CarMovement::Update()
extern void CarMovement_Update_m0CBAC71B32625DE2F65901AD223FB6810FE81405 (void);
// 0x00000003 System.Void CarMovement::.ctor()
extern void CarMovement__ctor_mFBA7B076ADEE9B247A13653A0B863BC50B89F400 (void);
// 0x00000004 Controller Controller::get_Instance()
extern void Controller_get_Instance_m6BCAD4BA1577A35F4A55226A1978D626FBA0AF8B (void);
// 0x00000005 System.Void Controller::set_Instance(Controller)
extern void Controller_set_Instance_m33D59E4DF6D2C3C7071866B679197C663F011DAD (void);
// 0x00000006 System.Single Controller::get_Speed()
extern void Controller_get_Speed_m039BF6957E8E718B7AAFFC194CA30E5C56AA15D8 (void);
// 0x00000007 System.Void Controller::set_Speed(System.Single)
extern void Controller_set_Speed_m592EEC62C9984562B112E878960D45797D15C223 (void);
// 0x00000008 System.Boolean Controller::get_LockControl()
extern void Controller_get_LockControl_mE8D2587C6CAFA7A58C9D394080904CB9E5288A05 (void);
// 0x00000009 System.Void Controller::set_LockControl(System.Boolean)
extern void Controller_set_LockControl_mD84BF3B46EC9D74A92A23137C6D80340A88EDE0A (void);
// 0x0000000A System.Boolean Controller::get_Grounded()
extern void Controller_get_Grounded_m18673DC6949577695271F9A01906C2BBFBCF870A (void);
// 0x0000000B System.Void Controller::Awake()
extern void Controller_Awake_mB79839215154BE499EE8007A461996C2D2108E70 (void);
// 0x0000000C System.Void Controller::Start()
extern void Controller_Start_m677A5649D52F2F489A32241FA0D8A66443028477 (void);
// 0x0000000D System.Void Controller::Update()
extern void Controller_Update_mD451AF27888A2F5E90B85BBAFD1FAC07DEFF355E (void);
// 0x0000000E System.Void Controller::DisplayCursor(System.Boolean)
extern void Controller_DisplayCursor_m410EEADF33DDC72929EE36D32EE55BEF573C96B0 (void);
// 0x0000000F System.Void Controller::.ctor()
extern void Controller__ctor_m991221C6928749BE23FA50995AFB8664ED96D7A0 (void);
// 0x00000010 PoolSystem PoolSystem::get_Instance()
extern void PoolSystem_get_Instance_m8DAFEA00F1CD19DD178E32108E8DD994BD7D4719 (void);
// 0x00000011 System.Void PoolSystem::set_Instance(PoolSystem)
extern void PoolSystem_set_Instance_mF9A271CC3667DA1FB9E24BEA3264A9EB813638AA (void);
// 0x00000012 System.Void PoolSystem::Create()
extern void PoolSystem_Create_m254EFD59752DDDA8252B4C711C9E9A6F3A7F8532 (void);
// 0x00000013 System.Void PoolSystem::InitPool(UnityEngine.Object,System.Int32)
extern void PoolSystem_InitPool_m07E3496D7E06B13D5918ADE2914D186C66B89BB4 (void);
// 0x00000014 T PoolSystem::GetInstance(UnityEngine.Object)
// 0x00000015 System.Void PoolSystem::SetActive(UnityEngine.Object,System.Boolean)
extern void PoolSystem_SetActive_m7F622D0F30E3A8424CB1B781EAA866DD0E67582E (void);
// 0x00000016 System.Void PoolSystem::.ctor()
extern void PoolSystem__ctor_mC2C61C7B9A095C17AF7E03B7600116E94656B7EA (void);
// 0x00000017 System.Void Readme::.ctor()
extern void Readme__ctor_m23AE6143BDABB863B629ADE701E2998AB8651D4C (void);
// 0x00000018 System.Void UnityTemplateProjects.SimpleCameraController::OnEnable()
extern void SimpleCameraController_OnEnable_mE3D6E47455F101F2DEEBC2A58D09A97CF38E80B8 (void);
// 0x00000019 UnityEngine.Vector3 UnityTemplateProjects.SimpleCameraController::GetInputTranslationDirection()
extern void SimpleCameraController_GetInputTranslationDirection_m73C99DB69CEB467834BBA00A62415D1CEEF0CB47 (void);
// 0x0000001A System.Void UnityTemplateProjects.SimpleCameraController::Update()
extern void SimpleCameraController_Update_mBCD24408A4A2C4053F2F98DB808BD6DE88CA998F (void);
// 0x0000001B System.Void UnityTemplateProjects.SimpleCameraController::.ctor()
extern void SimpleCameraController__ctor_m8DE12FC1A6C31D2D60ED78F0B574CE3F864F546E (void);
// 0x0000001C System.Void Readme_Section::.ctor()
extern void Section__ctor_mE73C1D6AE5454B5A67AAB04CAA5144A5CA0B0D96 (void);
// 0x0000001D System.Void UnityTemplateProjects.SimpleCameraController_CameraState::SetFromTransform(UnityEngine.Transform)
extern void CameraState_SetFromTransform_m6467352ED87301E5F4A76456060A765CAB96AF3E (void);
// 0x0000001E System.Void UnityTemplateProjects.SimpleCameraController_CameraState::Translate(UnityEngine.Vector3)
extern void CameraState_Translate_m76BCC104A48EA7F125D5A50D874A2DEEA7967247 (void);
// 0x0000001F System.Void UnityTemplateProjects.SimpleCameraController_CameraState::LerpTowards(UnityTemplateProjects.SimpleCameraController_CameraState,System.Single,System.Single)
extern void CameraState_LerpTowards_m883AAF2D3C7F5045B64CAF655FB84EF0FC98F282 (void);
// 0x00000020 System.Void UnityTemplateProjects.SimpleCameraController_CameraState::UpdateTransform(UnityEngine.Transform)
extern void CameraState_UpdateTransform_mE3349362276789C1617C01276F7DE533BBA22623 (void);
// 0x00000021 System.Void UnityTemplateProjects.SimpleCameraController_CameraState::.ctor()
extern void CameraState__ctor_m4A83DF36C7D280050EA1B101E61B7E345C31A322 (void);
static Il2CppMethodPointer s_methodPointers[33] = 
{
	CarMovement_Start_m217CE842B1C5D3D43B925116901D04941515E4B1,
	CarMovement_Update_m0CBAC71B32625DE2F65901AD223FB6810FE81405,
	CarMovement__ctor_mFBA7B076ADEE9B247A13653A0B863BC50B89F400,
	Controller_get_Instance_m6BCAD4BA1577A35F4A55226A1978D626FBA0AF8B,
	Controller_set_Instance_m33D59E4DF6D2C3C7071866B679197C663F011DAD,
	Controller_get_Speed_m039BF6957E8E718B7AAFFC194CA30E5C56AA15D8,
	Controller_set_Speed_m592EEC62C9984562B112E878960D45797D15C223,
	Controller_get_LockControl_mE8D2587C6CAFA7A58C9D394080904CB9E5288A05,
	Controller_set_LockControl_mD84BF3B46EC9D74A92A23137C6D80340A88EDE0A,
	Controller_get_Grounded_m18673DC6949577695271F9A01906C2BBFBCF870A,
	Controller_Awake_mB79839215154BE499EE8007A461996C2D2108E70,
	Controller_Start_m677A5649D52F2F489A32241FA0D8A66443028477,
	Controller_Update_mD451AF27888A2F5E90B85BBAFD1FAC07DEFF355E,
	Controller_DisplayCursor_m410EEADF33DDC72929EE36D32EE55BEF573C96B0,
	Controller__ctor_m991221C6928749BE23FA50995AFB8664ED96D7A0,
	PoolSystem_get_Instance_m8DAFEA00F1CD19DD178E32108E8DD994BD7D4719,
	PoolSystem_set_Instance_mF9A271CC3667DA1FB9E24BEA3264A9EB813638AA,
	PoolSystem_Create_m254EFD59752DDDA8252B4C711C9E9A6F3A7F8532,
	PoolSystem_InitPool_m07E3496D7E06B13D5918ADE2914D186C66B89BB4,
	NULL,
	PoolSystem_SetActive_m7F622D0F30E3A8424CB1B781EAA866DD0E67582E,
	PoolSystem__ctor_mC2C61C7B9A095C17AF7E03B7600116E94656B7EA,
	Readme__ctor_m23AE6143BDABB863B629ADE701E2998AB8651D4C,
	SimpleCameraController_OnEnable_mE3D6E47455F101F2DEEBC2A58D09A97CF38E80B8,
	SimpleCameraController_GetInputTranslationDirection_m73C99DB69CEB467834BBA00A62415D1CEEF0CB47,
	SimpleCameraController_Update_mBCD24408A4A2C4053F2F98DB808BD6DE88CA998F,
	SimpleCameraController__ctor_m8DE12FC1A6C31D2D60ED78F0B574CE3F864F546E,
	Section__ctor_mE73C1D6AE5454B5A67AAB04CAA5144A5CA0B0D96,
	CameraState_SetFromTransform_m6467352ED87301E5F4A76456060A765CAB96AF3E,
	CameraState_Translate_m76BCC104A48EA7F125D5A50D874A2DEEA7967247,
	CameraState_LerpTowards_m883AAF2D3C7F5045B64CAF655FB84EF0FC98F282,
	CameraState_UpdateTransform_mE3349362276789C1617C01276F7DE533BBA22623,
	CameraState__ctor_m4A83DF36C7D280050EA1B101E61B7E345C31A322,
};
static const int32_t s_InvokerIndices[33] = 
{
	23,
	23,
	23,
	4,
	122,
	684,
	296,
	114,
	31,
	114,
	23,
	23,
	23,
	31,
	23,
	4,
	122,
	3,
	140,
	-1,
	568,
	23,
	23,
	23,
	1126,
	23,
	23,
	23,
	26,
	1127,
	1293,
	26,
	23,
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x06000014, { 0, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[1] = 
{
	{ (Il2CppRGCTXDataType)2, 20824 },
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	33,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	1,
	s_rgctxIndices,
	1,
	s_rgctxValues,
	NULL,
};
