﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.Playables.PlayableDirector::SendOnPlayableDirectorPlay()
extern void PlayableDirector_SendOnPlayableDirectorPlay_m4E9920374473D4726C270EF6ECACA93303C7BA87 (void);
// 0x00000002 System.Void UnityEngine.Playables.PlayableDirector::SendOnPlayableDirectorPause()
extern void PlayableDirector_SendOnPlayableDirectorPause_m4E43A08D82CCE58DE75A1D9605A716BD85837F81 (void);
// 0x00000003 System.Void UnityEngine.Playables.PlayableDirector::SendOnPlayableDirectorStop()
extern void PlayableDirector_SendOnPlayableDirectorStop_mB1699B938518B0D2CBB70B6A7678FBA8A83839A8 (void);
static Il2CppMethodPointer s_methodPointers[3] = 
{
	PlayableDirector_SendOnPlayableDirectorPlay_m4E9920374473D4726C270EF6ECACA93303C7BA87,
	PlayableDirector_SendOnPlayableDirectorPause_m4E43A08D82CCE58DE75A1D9605A716BD85837F81,
	PlayableDirector_SendOnPlayableDirectorStop_mB1699B938518B0D2CBB70B6A7678FBA8A83839A8,
};
static const int32_t s_InvokerIndices[3] = 
{
	23,
	23,
	23,
};
extern const Il2CppCodeGenModule g_UnityEngine_DirectorModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_DirectorModuleCodeGenModule = 
{
	"UnityEngine.DirectorModule.dll",
	3,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
