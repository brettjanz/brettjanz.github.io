﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngineInternal.MathfInternal::.cctor()
extern void MathfInternal__cctor_m885D4921B8E928763E7ABB4466659665780F860F (void);
// 0x00000002 System.Void UnityEngineInternal.TypeInferenceRuleAttribute::.ctor(UnityEngineInternal.TypeInferenceRules)
extern void TypeInferenceRuleAttribute__ctor_m389751AED6740F401AC8DFACD5914C13AB24D8A6 (void);
// 0x00000003 System.Void UnityEngineInternal.TypeInferenceRuleAttribute::.ctor(System.String)
extern void TypeInferenceRuleAttribute__ctor_m34920F979AA071F4973CEEEF6F91B5B6A53E5765 (void);
// 0x00000004 System.String UnityEngineInternal.TypeInferenceRuleAttribute::ToString()
extern void TypeInferenceRuleAttribute_ToString_m49343B52ED0F3E75B3E56E37CF523F63E5A746F6 (void);
// 0x00000005 System.Void UnityEngineInternal.GenericStack::.ctor()
extern void GenericStack__ctor_m0659B84DB6B093AF1F01F566686C510DDEEAE848 (void);
// 0x00000006 System.Void Unity.Profiling.ProfilerMarker::.ctor(System.String)
extern void ProfilerMarker__ctor_mF9F9BDCB1E4618F9533D83D47EAD7325A32FDC2A_AdjustorThunk (void);
// 0x00000007 Unity.Profiling.ProfilerMarker_AutoScope Unity.Profiling.ProfilerMarker::Auto()
extern void ProfilerMarker_Auto_m27C8BA4E46F26F3005760C48C4B92EBC284A5D02_AdjustorThunk (void);
// 0x00000008 System.IntPtr Unity.Profiling.ProfilerMarker::Internal_Create(System.String,System.UInt16)
extern void ProfilerMarker_Internal_Create_m92F2A7651D4BF3F3D0CB62078DD79B71839FA370 (void);
// 0x00000009 System.Void Unity.Profiling.ProfilerMarker::Internal_Begin(System.IntPtr)
extern void ProfilerMarker_Internal_Begin_m79272E72708A53AFDEEEB81CF66C7D62920AC5B5 (void);
// 0x0000000A System.Void Unity.Profiling.ProfilerMarker::Internal_End(System.IntPtr)
extern void ProfilerMarker_Internal_End_mE25FE55A23DF111614CE890359972D96A65B499A (void);
// 0x0000000B System.Void Unity.Profiling.ProfilerMarker_AutoScope::.ctor(System.IntPtr)
extern void AutoScope__ctor_mDB99051F3C5C2BFFF71574AC515AB523F04E3320_AdjustorThunk (void);
// 0x0000000C System.Void Unity.Profiling.ProfilerMarker_AutoScope::Dispose()
extern void AutoScope_Dispose_m3663B79F5E62F2FA39FAAB5956A5EA141BA98AF2_AdjustorThunk (void);
// 0x0000000D System.Void Unity.Jobs.JobHandle::ScheduleBatchedJobs()
extern void JobHandle_ScheduleBatchedJobs_mE52469B0B3D765B57BC658E82815840C83A6A4D0 (void);
// 0x0000000E System.Void Unity.Collections.NativeLeakDetection::Initialize()
extern void NativeLeakDetection_Initialize_m70E48965BE4B399698C8034015B4F0EBD8D4C6E7 (void);
// 0x0000000F System.Void Unity.Collections.NativeArray`1::.ctor(System.Int32,Unity.Collections.Allocator,Unity.Collections.NativeArrayOptions)
// 0x00000010 System.Void Unity.Collections.NativeArray`1::Allocate(System.Int32,Unity.Collections.Allocator,Unity.Collections.NativeArray`1<T>&)
// 0x00000011 System.Int32 Unity.Collections.NativeArray`1::get_Length()
// 0x00000012 T Unity.Collections.NativeArray`1::get_Item(System.Int32)
// 0x00000013 System.Void Unity.Collections.NativeArray`1::set_Item(System.Int32,T)
// 0x00000014 System.Void Unity.Collections.NativeArray`1::Deallocate()
// 0x00000015 System.Void Unity.Collections.NativeArray`1::Dispose()
// 0x00000016 Unity.Collections.NativeArray`1_Enumerator<T> Unity.Collections.NativeArray`1::GetEnumerator()
// 0x00000017 System.Collections.Generic.IEnumerator`1<T> Unity.Collections.NativeArray`1::System.Collections.Generic.IEnumerable<T>.GetEnumerator()
// 0x00000018 System.Collections.IEnumerator Unity.Collections.NativeArray`1::System.Collections.IEnumerable.GetEnumerator()
// 0x00000019 System.Boolean Unity.Collections.NativeArray`1::Equals(Unity.Collections.NativeArray`1<T>)
// 0x0000001A System.Boolean Unity.Collections.NativeArray`1::Equals(System.Object)
// 0x0000001B System.Int32 Unity.Collections.NativeArray`1::GetHashCode()
// 0x0000001C System.Void Unity.Collections.NativeArray`1_Enumerator::.ctor(Unity.Collections.NativeArray`1<T>&)
// 0x0000001D System.Void Unity.Collections.NativeArray`1_Enumerator::Dispose()
// 0x0000001E System.Boolean Unity.Collections.NativeArray`1_Enumerator::MoveNext()
// 0x0000001F System.Void Unity.Collections.NativeArray`1_Enumerator::Reset()
// 0x00000020 T Unity.Collections.NativeArray`1_Enumerator::get_Current()
// 0x00000021 System.Object Unity.Collections.NativeArray`1_Enumerator::System.Collections.IEnumerator.get_Current()
// 0x00000022 System.Void Unity.Collections.LowLevel.Unsafe.NativeContainerAttribute::.ctor()
extern void NativeContainerAttribute__ctor_mD22697FA575BA0404B981921B295C1A4B89C9F42 (void);
// 0x00000023 System.Void Unity.Collections.LowLevel.Unsafe.NativeContainerSupportsMinMaxWriteRestrictionAttribute::.ctor()
extern void NativeContainerSupportsMinMaxWriteRestrictionAttribute__ctor_m3D87D41F66CB34605B2C23D12BD04E9546AF321D (void);
// 0x00000024 System.Void Unity.Collections.LowLevel.Unsafe.NativeContainerSupportsDeallocateOnJobCompletionAttribute::.ctor()
extern void NativeContainerSupportsDeallocateOnJobCompletionAttribute__ctor_m56D5D2E8D7FE0BF8368167A7139204F4740A875B (void);
// 0x00000025 System.Void Unity.Collections.LowLevel.Unsafe.NativeContainerSupportsDeferredConvertListToArray::.ctor()
extern void NativeContainerSupportsDeferredConvertListToArray__ctor_m81D3D40F97FDB1675D128ACD785A9658E5E9DBB2 (void);
// 0x00000026 System.Void Unity.Collections.LowLevel.Unsafe.WriteAccessRequiredAttribute::.ctor()
extern void WriteAccessRequiredAttribute__ctor_mBB72625FD2C0CE5081BCEBF5C6122581723574B5 (void);
// 0x00000027 System.Void Unity.Collections.LowLevel.Unsafe.NativeDisableUnsafePtrRestrictionAttribute::.ctor()
extern void NativeDisableUnsafePtrRestrictionAttribute__ctor_m25F3A64C3715BB3C92C7150DB1F46BC88091B653 (void);
// 0x00000028 Unity.Collections.NativeArray`1<T> Unity.Collections.LowLevel.Unsafe.NativeArrayUnsafeUtility::ConvertExistingDataToNativeArray(System.Void*,System.Int32,Unity.Collections.Allocator)
// 0x00000029 System.Void* Unity.Collections.LowLevel.Unsafe.NativeArrayUnsafeUtility::GetUnsafePtr(Unity.Collections.NativeArray`1<T>)
// 0x0000002A System.Void* Unity.Collections.LowLevel.Unsafe.NativeArrayUnsafeUtility::GetUnsafeReadOnlyPtr(Unity.Collections.NativeArray`1<T>)
// 0x0000002B System.Boolean Unity.Collections.LowLevel.Unsafe.UnsafeUtility::IsBlittable()
// 0x0000002C System.Void* Unity.Collections.LowLevel.Unsafe.UnsafeUtility::Malloc(System.Int64,System.Int32,Unity.Collections.Allocator)
extern void UnsafeUtility_Malloc_m43BC7C9BE1437A70DD9A236418B0906CD3617331 (void);
// 0x0000002D System.Void Unity.Collections.LowLevel.Unsafe.UnsafeUtility::Free(System.Void*,Unity.Collections.Allocator)
extern void UnsafeUtility_Free_mAC082BB03B10D20CA9E5AD7FBA33164DF2B52E89 (void);
// 0x0000002E System.Void Unity.Collections.LowLevel.Unsafe.UnsafeUtility::MemCpy(System.Void*,System.Void*,System.Int64)
extern void UnsafeUtility_MemCpy_mA675903DD7350CC5EC22947C0899B18944E3578C (void);
// 0x0000002F System.Void Unity.Collections.LowLevel.Unsafe.UnsafeUtility::MemSet(System.Void*,System.Byte,System.Int64)
extern void UnsafeUtility_MemSet_m2877A4878CEB99D6B13B8F6A49FDA1C0C924AE24 (void);
// 0x00000030 System.Void Unity.Collections.LowLevel.Unsafe.UnsafeUtility::MemClear(System.Void*,System.Int64)
extern void UnsafeUtility_MemClear_m288BC0ABEB3E1A7B941FB28033D391E661887545 (void);
// 0x00000031 System.Boolean Unity.Collections.LowLevel.Unsafe.UnsafeUtility::IsBlittable(System.Type)
extern void UnsafeUtility_IsBlittable_m4FE85090DA275D2B489A8E57BCD2DAA1859B5A8E (void);
// 0x00000032 System.Boolean Unity.Collections.LowLevel.Unsafe.UnsafeUtility::IsBlittableValueType(System.Type)
extern void UnsafeUtility_IsBlittableValueType_mF403D8551AA7A8503B5D1587941B7DB248EA5637 (void);
// 0x00000033 System.String Unity.Collections.LowLevel.Unsafe.UnsafeUtility::GetReasonForTypeNonBlittableImpl(System.Type,System.String)
extern void UnsafeUtility_GetReasonForTypeNonBlittableImpl_m8ED27B0E929F764C6A75971117783802277AE5C2 (void);
// 0x00000034 System.Boolean Unity.Collections.LowLevel.Unsafe.UnsafeUtility::IsGenericListBlittable()
// 0x00000035 System.String Unity.Collections.LowLevel.Unsafe.UnsafeUtility::GetReasonForGenericListNonBlittable()
// 0x00000036 System.Int32 Unity.Collections.LowLevel.Unsafe.UnsafeUtility::AlignOf()
// 0x00000037 T Unity.Collections.LowLevel.Unsafe.UnsafeUtility::ReadArrayElement(System.Void*,System.Int32)
// 0x00000038 System.Void Unity.Collections.LowLevel.Unsafe.UnsafeUtility::WriteArrayElement(System.Void*,System.Int32,T)
// 0x00000039 System.Int32 Unity.Collections.LowLevel.Unsafe.UnsafeUtility::SizeOf()
// 0x0000003A System.Int32 Unity.Collections.LowLevel.Unsafe.UnsafeUtility::EnumToInt(T)
// 0x0000003B System.Void Unity.Collections.LowLevel.Unsafe.UnsafeUtility::InternalEnumToInt(T&,System.Int32&)
// 0x0000003C System.Int32 UnityEngine.SortingLayer::get_id()
extern void SortingLayer_get_id_mC93B809F988E70775D746B1BEA41FCC97D0DAA51_AdjustorThunk (void);
// 0x0000003D System.Int32 UnityEngine.SortingLayer::get_value()
extern void SortingLayer_get_value_mAA4CF694CCFF3EB7ACD26B95319C2DC2DDDB77F7_AdjustorThunk (void);
// 0x0000003E UnityEngine.SortingLayer[] UnityEngine.SortingLayer::get_layers()
extern void SortingLayer_get_layers_m5F1CE882A1DC669B4A3E3233817577419FFFEC56 (void);
// 0x0000003F System.Int32[] UnityEngine.SortingLayer::GetSortingLayerIDsInternal()
extern void SortingLayer_GetSortingLayerIDsInternal_mC6BE877C3F2F1C09A3E07BD11632CED281D616C1 (void);
// 0x00000040 System.Int32 UnityEngine.SortingLayer::GetLayerValueFromID(System.Int32)
extern void SortingLayer_GetLayerValueFromID_m564F9C83200E5EC3E9578A75854CB943CE5546F8 (void);
// 0x00000041 System.String UnityEngine.SortingLayer::IDToName(System.Int32)
extern void SortingLayer_IDToName_m5D8BC7962C906483BC1A544B157026E30568F1BC (void);
// 0x00000042 System.Void UnityEngine.Keyframe::.ctor(System.Single,System.Single,System.Single,System.Single)
extern void Keyframe__ctor_m10FFFE5FE1213C3AE88359375398F213B24F18D5_AdjustorThunk (void);
// 0x00000043 System.Single UnityEngine.Keyframe::get_time()
extern void Keyframe_get_time_m5A49381A903E63DD63EF8A381BA26C1A2DEF935D_AdjustorThunk (void);
// 0x00000044 System.Void UnityEngine.Keyframe::set_time(System.Single)
extern void Keyframe_set_time_mAD4CA2282CD1B7C1D330C3EE75F79AD636C7FC83_AdjustorThunk (void);
// 0x00000045 System.Void UnityEngine.AnimationCurve::Internal_Destroy(System.IntPtr)
extern void AnimationCurve_Internal_Destroy_m295BAECEF97D64ACFE55D7EA91B9E9C077DB6A7C (void);
// 0x00000046 System.IntPtr UnityEngine.AnimationCurve::Internal_Create(UnityEngine.Keyframe[])
extern void AnimationCurve_Internal_Create_mA7A2A0191C4AAE7BD5B18F0DCC05AD4290D1691B (void);
// 0x00000047 System.Boolean UnityEngine.AnimationCurve::Internal_Equals(System.IntPtr)
extern void AnimationCurve_Internal_Equals_m7ACF09175F2DC61D95006ABB5BBE1CF7434B2D1D (void);
// 0x00000048 System.Void UnityEngine.AnimationCurve::Finalize()
extern void AnimationCurve_Finalize_mDF0DECA505DA883A56B2E3FCE1EF19CC3959F11D (void);
// 0x00000049 System.Single UnityEngine.AnimationCurve::Evaluate(System.Single)
extern void AnimationCurve_Evaluate_m51CAA6B1C54B7EF44FE4D74B422C1DA1FA6F8776 (void);
// 0x0000004A UnityEngine.Keyframe[] UnityEngine.AnimationCurve::get_keys()
extern void AnimationCurve_get_keys_m88E1848D255C2893F379E855A522DA9B0E0F78FB (void);
// 0x0000004B System.Void UnityEngine.AnimationCurve::set_keys(UnityEngine.Keyframe[])
extern void AnimationCurve_set_keys_m3AA5ED7D9B0D9BCBCD349355160810B2DF939096 (void);
// 0x0000004C System.Int32 UnityEngine.AnimationCurve::AddKey(System.Single,System.Single)
extern void AnimationCurve_AddKey_m67EF6AFE4C0083D8B08926D5CA2B32A907DBB216 (void);
// 0x0000004D System.Int32 UnityEngine.AnimationCurve::AddKey(UnityEngine.Keyframe)
extern void AnimationCurve_AddKey_mBF33163D92DCC0BC0A10D2308038A8D49750E961 (void);
// 0x0000004E System.Int32 UnityEngine.AnimationCurve::AddKey_Internal(UnityEngine.Keyframe)
extern void AnimationCurve_AddKey_Internal_mC89C6E030F40FE6586C3D1609DB24F075EDE9B64 (void);
// 0x0000004F System.Int32 UnityEngine.AnimationCurve::MoveKey(System.Int32,UnityEngine.Keyframe)
extern void AnimationCurve_MoveKey_m20405AA535659CAAC9BC1B100301C5BD76201735 (void);
// 0x00000050 System.Void UnityEngine.AnimationCurve::RemoveKey(System.Int32)
extern void AnimationCurve_RemoveKey_m25D7337353EE1BE94799C156BEDC8D971B1A1F13 (void);
// 0x00000051 UnityEngine.Keyframe UnityEngine.AnimationCurve::get_Item(System.Int32)
extern void AnimationCurve_get_Item_m303DEF117A2702D57F8F5D55D422EC395E4388FC (void);
// 0x00000052 System.Int32 UnityEngine.AnimationCurve::get_length()
extern void AnimationCurve_get_length_m36B9D49BCB7D677C38A7963FF00313A2E48E7B26 (void);
// 0x00000053 System.Void UnityEngine.AnimationCurve::SetKeys(UnityEngine.Keyframe[])
extern void AnimationCurve_SetKeys_mDC9E9E871BEED0B5C3F25A991F1BEF18F23602FC (void);
// 0x00000054 UnityEngine.Keyframe UnityEngine.AnimationCurve::GetKey(System.Int32)
extern void AnimationCurve_GetKey_m2FD7B7AB3633B9C353FA59FC3927BC7EB904691F (void);
// 0x00000055 UnityEngine.Keyframe[] UnityEngine.AnimationCurve::GetKeys()
extern void AnimationCurve_GetKeys_mC61A3A3E0D17E5849768B3AB3698F2139CF70EBE (void);
// 0x00000056 System.Void UnityEngine.AnimationCurve::SmoothTangents(System.Int32,System.Single)
extern void AnimationCurve_SmoothTangents_mEC6BDF7315345A949E35C4D34B0314DDC8DAFD76 (void);
// 0x00000057 System.Void UnityEngine.AnimationCurve::.ctor(UnityEngine.Keyframe[])
extern void AnimationCurve__ctor_mE9462D171C06A2A746B9DA1B0A6B0F4FC7DB94CF (void);
// 0x00000058 System.Void UnityEngine.AnimationCurve::.ctor()
extern void AnimationCurve__ctor_mA12B39D1FD275B9A8150227B24805C7B218CDF2C (void);
// 0x00000059 System.Boolean UnityEngine.AnimationCurve::Equals(System.Object)
extern void AnimationCurve_Equals_m5E3528A0595AC6714584CAD54549D756C9B3DDD5 (void);
// 0x0000005A System.Boolean UnityEngine.AnimationCurve::Equals(UnityEngine.AnimationCurve)
extern void AnimationCurve_Equals_m60310C21F9B109BAC9BA4FACE9BEF88931B22DED (void);
// 0x0000005B System.Int32 UnityEngine.AnimationCurve::GetHashCode()
extern void AnimationCurve_GetHashCode_m22EEE795E7C76841C40A1563E3E90CBB089B19A6 (void);
// 0x0000005C System.Int32 UnityEngine.AnimationCurve::AddKey_Internal_Injected(UnityEngine.Keyframe&)
extern void AnimationCurve_AddKey_Internal_Injected_mD23B51D3B53AF2181150952AC124A5889C4B1B02 (void);
// 0x0000005D System.Int32 UnityEngine.AnimationCurve::MoveKey_Injected(System.Int32,UnityEngine.Keyframe&)
extern void AnimationCurve_MoveKey_Injected_m8BA9D6C6BB0BB094BEBAB730F4443C282CDE2E32 (void);
// 0x0000005E System.Void UnityEngine.AnimationCurve::GetKey_Injected(System.Int32,UnityEngine.Keyframe&)
extern void AnimationCurve_GetKey_Injected_m01C24E74FE72837D5E6A59BBB1BACAEC308454EA (void);
// 0x0000005F System.Void UnityEngine.Application::Quit(System.Int32)
extern void Application_Quit_m514D6F92E1A06D53D1BCA2F2A646ABA6678717B2 (void);
// 0x00000060 System.Void UnityEngine.Application::Quit()
extern void Application_Quit_mA005EB22CB989AC3794334754F15E1C0D2FF1C95 (void);
// 0x00000061 System.Boolean UnityEngine.Application::get_isPlaying()
extern void Application_get_isPlaying_mF43B519662E7433DD90D883E5AE22EC3CFB65CA5 (void);
// 0x00000062 UnityEngine.RuntimePlatform UnityEngine.Application::get_platform()
extern void Application_get_platform_m6AFFFF3B077F4D5CA1F71CF14ABA86A83FC71672 (void);
// 0x00000063 System.Boolean UnityEngine.Application::get_isMobilePlatform()
extern void Application_get_isMobilePlatform_m11B260E344378D2A3CE53FCCA64DAC70F0B783E7 (void);
// 0x00000064 System.Void UnityEngine.Application::CallLowMemory()
extern void Application_CallLowMemory_m4C6693BD717D61DB33C2FB061FDA8CE055966E75 (void);
// 0x00000065 System.Void UnityEngine.Application::CallLogCallback(System.String,System.String,UnityEngine.LogType,System.Boolean)
extern void Application_CallLogCallback_mCA351E4FBE7397C3D09A7FBD8A9B074A4745ED89 (void);
// 0x00000066 System.Boolean UnityEngine.Application::Internal_ApplicationWantsToQuit()
extern void Application_Internal_ApplicationWantsToQuit_mDF35192EF816ECD73F0BD4AFBCDE1460EF06442A (void);
// 0x00000067 System.Void UnityEngine.Application::Internal_ApplicationQuit()
extern void Application_Internal_ApplicationQuit_mC9ACAA5CB0800C837DBD9925E1E389FB918F3DED (void);
// 0x00000068 System.Void UnityEngine.Application::InvokeOnBeforeRender()
extern void Application_InvokeOnBeforeRender_mF2E1F3E67C1D160AD1209C1DBC1EC91E8FB88C97 (void);
// 0x00000069 System.Void UnityEngine.Application::InvokeFocusChanged(System.Boolean)
extern void Application_InvokeFocusChanged_m61786C9688D01809FAC41250B371CE13C9DBBD6F (void);
// 0x0000006A System.Void UnityEngine.Application::InvokeDeepLinkActivated(System.String)
extern void Application_InvokeDeepLinkActivated_m473D851836BD708C896850AA1DAE2B56A4B01176 (void);
// 0x0000006B System.Boolean UnityEngine.Application::get_isEditor()
extern void Application_get_isEditor_m347E6EE16E5109EF613C83ED98DB1EC6E3EF5E26 (void);
// 0x0000006C System.Void UnityEngine.Application_LowMemoryCallback::.ctor(System.Object,System.IntPtr)
extern void LowMemoryCallback__ctor_m9A428FDE023342AE31B3749FC821B078AEDA2290 (void);
// 0x0000006D System.Void UnityEngine.Application_LowMemoryCallback::Invoke()
extern void LowMemoryCallback_Invoke_m3082D6F2046585D3504696B94A59A4CBC43262F8 (void);
// 0x0000006E System.IAsyncResult UnityEngine.Application_LowMemoryCallback::BeginInvoke(System.AsyncCallback,System.Object)
extern void LowMemoryCallback_BeginInvoke_m4686E95B4CF6EDE103DB0448FC54354BAE5F1745 (void);
// 0x0000006F System.Void UnityEngine.Application_LowMemoryCallback::EndInvoke(System.IAsyncResult)
extern void LowMemoryCallback_EndInvoke_mB8843171E51584D380B62D3B79BC4F4930A22D0C (void);
// 0x00000070 System.Void UnityEngine.Application_LogCallback::.ctor(System.Object,System.IntPtr)
extern void LogCallback__ctor_mF61E7CECD9E360B0B8A992720860F9816E165731 (void);
// 0x00000071 System.Void UnityEngine.Application_LogCallback::Invoke(System.String,System.String,UnityEngine.LogType)
extern void LogCallback_Invoke_mCB0C38C44CBF8BBE88690BE6C0382011C5D5B61F (void);
// 0x00000072 System.IAsyncResult UnityEngine.Application_LogCallback::BeginInvoke(System.String,System.String,UnityEngine.LogType,System.AsyncCallback,System.Object)
extern void LogCallback_BeginInvoke_mECA20C96EB7E35915BC9202F833685D0ED5F66A7 (void);
// 0x00000073 System.Void UnityEngine.Application_LogCallback::EndInvoke(System.IAsyncResult)
extern void LogCallback_EndInvoke_m03CD6E28DACBF36E7A756F8CC653E546CBF3FD54 (void);
// 0x00000074 UnityEngine.BootConfigData UnityEngine.BootConfigData::WrapBootConfigData(System.IntPtr)
extern void BootConfigData_WrapBootConfigData_m7C2DCB60E1456C2B7748ECFAAEB492611A5D7690 (void);
// 0x00000075 System.Void UnityEngine.BootConfigData::.ctor(System.IntPtr)
extern void BootConfigData__ctor_m6C109EB48CAE91C89BB6C4BFD10C77EA6723E5AE (void);
// 0x00000076 System.Single UnityEngine.Camera::get_nearClipPlane()
extern void Camera_get_nearClipPlane_mD9D3E3D27186BBAC2CC354CE3609E6118A5BF66C (void);
// 0x00000077 System.Single UnityEngine.Camera::get_farClipPlane()
extern void Camera_get_farClipPlane_mF51F1FF5BE87719CFAC293E272B1138DC1EFFD4B (void);
// 0x00000078 System.Single UnityEngine.Camera::get_fieldOfView()
extern void Camera_get_fieldOfView_m065A50B70AC3661337ACA482DDEFA29CCBD249D6 (void);
// 0x00000079 System.Boolean UnityEngine.Camera::get_allowHDR()
extern void Camera_get_allowHDR_m665C9AE59920BD6FD436C85EA3517D4914477759 (void);
// 0x0000007A System.Boolean UnityEngine.Camera::get_allowMSAA()
extern void Camera_get_allowMSAA_m857F27DB6C26C843A9F4A65D05C12E5E1BFA097F (void);
// 0x0000007B System.Boolean UnityEngine.Camera::get_allowDynamicResolution()
extern void Camera_get_allowDynamicResolution_m914F4649B78C663DC318AFA9C8488F1E1272194D (void);
// 0x0000007C System.Single UnityEngine.Camera::get_orthographicSize()
extern void Camera_get_orthographicSize_m700FCD8CF48BC59A0415A624328B4A627B88D958 (void);
// 0x0000007D System.Void UnityEngine.Camera::set_orthographicSize(System.Single)
extern void Camera_set_orthographicSize_mF15F37A294A7AA2ADD9519728A495DFA0A836428 (void);
// 0x0000007E System.Boolean UnityEngine.Camera::get_orthographic()
extern void Camera_get_orthographic_m801883D15C8D9816091F6B9C742CA5FA3650C8E6 (void);
// 0x0000007F UnityEngine.Rendering.OpaqueSortMode UnityEngine.Camera::get_opaqueSortMode()
extern void Camera_get_opaqueSortMode_m44EA1DE8FAB7C81906D992A95EFA6C1309241A1A (void);
// 0x00000080 UnityEngine.TransparencySortMode UnityEngine.Camera::get_transparencySortMode()
extern void Camera_get_transparencySortMode_m5AFD99D6A373C9ECE90803BBA6C4C0F3E74C5AE4 (void);
// 0x00000081 System.Single UnityEngine.Camera::get_depth()
extern void Camera_get_depth_m436C49A1C7669E4AD5665A1F1107BDFBA38742CD (void);
// 0x00000082 System.Int32 UnityEngine.Camera::get_cullingMask()
extern void Camera_get_cullingMask_m0992E96D87A4221E38746EBD882780CEFF7C2BCD (void);
// 0x00000083 System.Int32 UnityEngine.Camera::get_eventMask()
extern void Camera_get_eventMask_m1D85900090AF34244340C69B53A42CDE5E9669D3 (void);
// 0x00000084 UnityEngine.CameraType UnityEngine.Camera::get_cameraType()
extern void Camera_get_cameraType_m8AE222219696578F70EA285D5AF182630089F21C (void);
// 0x00000085 UnityEngine.Color UnityEngine.Camera::get_backgroundColor()
extern void Camera_get_backgroundColor_m14496C5DC24582D7227277AF71DBE96F8E9E64FF (void);
// 0x00000086 UnityEngine.CameraClearFlags UnityEngine.Camera::get_clearFlags()
extern void Camera_get_clearFlags_m1D02BA1ABD7310269F6121C58AF41DCDEF1E0266 (void);
// 0x00000087 UnityEngine.Rect UnityEngine.Camera::get_rect()
extern void Camera_get_rect_m3570AA056526AB01C7733B4E7BE69F332E128A08 (void);
// 0x00000088 System.Void UnityEngine.Camera::set_rect(UnityEngine.Rect)
extern void Camera_set_rect_m6DB9964EA6E519E2B07561C8CE6AA423980FEC11 (void);
// 0x00000089 UnityEngine.Rect UnityEngine.Camera::get_pixelRect()
extern void Camera_get_pixelRect_mBA87D6C23FD7A5E1A7F3CE0E8F9B86A9318B5317 (void);
// 0x0000008A System.Void UnityEngine.Camera::set_pixelRect(UnityEngine.Rect)
extern void Camera_set_pixelRect_m9380482EFA5D7912988D585E9538A58988C8E0E9 (void);
// 0x0000008B System.Int32 UnityEngine.Camera::get_pixelWidth()
extern void Camera_get_pixelWidth_m67EC53853580E35527F32D6EA002FE21C234172E (void);
// 0x0000008C System.Int32 UnityEngine.Camera::get_pixelHeight()
extern void Camera_get_pixelHeight_m38879ACBA6B21C25E83AB07FA37A8E5EB7A51B05 (void);
// 0x0000008D UnityEngine.RenderTexture UnityEngine.Camera::get_targetTexture()
extern void Camera_get_targetTexture_m1E776560FAC888D8210D49CEE310BB39D34A3FDC (void);
// 0x0000008E System.Int32 UnityEngine.Camera::get_targetDisplay()
extern void Camera_get_targetDisplay_m2C318D2EB9A016FEC76B13F7F7AE382F443FB731 (void);
// 0x0000008F UnityEngine.Matrix4x4 UnityEngine.Camera::get_worldToCameraMatrix()
extern void Camera_get_worldToCameraMatrix_mDE5C634A92CD1303D6B1ADC65E4ED852108FBECE (void);
// 0x00000090 System.Void UnityEngine.Camera::set_worldToCameraMatrix(UnityEngine.Matrix4x4)
extern void Camera_set_worldToCameraMatrix_m1B6A7FCD4185E771264938CA68FF999B22238B6F (void);
// 0x00000091 UnityEngine.Matrix4x4 UnityEngine.Camera::get_projectionMatrix()
extern void Camera_get_projectionMatrix_m50964A6A11D1E3F8857A0B6E60BBB9C208BE473A (void);
// 0x00000092 UnityEngine.Matrix4x4 UnityEngine.Camera::get_nonJitteredProjectionMatrix()
extern void Camera_get_nonJitteredProjectionMatrix_mE4E183D92A45925D9C26D1D781ED9639903788BE (void);
// 0x00000093 System.Void UnityEngine.Camera::ResetWorldToCameraMatrix()
extern void Camera_ResetWorldToCameraMatrix_m2B62CFBE1575C53DC43501F4FDAF8B6DEE10E607 (void);
// 0x00000094 UnityEngine.Vector3 UnityEngine.Camera::WorldToScreenPoint(UnityEngine.Vector3,UnityEngine.Camera_MonoOrStereoscopicEye)
extern void Camera_WorldToScreenPoint_m315B44D111E92F6C81C39B7B0927622289C1BC52 (void);
// 0x00000095 UnityEngine.Vector3 UnityEngine.Camera::WorldToScreenPoint(UnityEngine.Vector3)
extern void Camera_WorldToScreenPoint_m880F9611E4848C11F21FDF1A1D307B401C61B1BF (void);
// 0x00000096 UnityEngine.Vector3 UnityEngine.Camera::ScreenToViewportPoint(UnityEngine.Vector3)
extern void Camera_ScreenToViewportPoint_m52ABFA35ADAA0B4FF3A7EE675F92F8F483E821FD (void);
// 0x00000097 UnityEngine.Ray UnityEngine.Camera::ScreenPointToRay(UnityEngine.Vector2,UnityEngine.Camera_MonoOrStereoscopicEye)
extern void Camera_ScreenPointToRay_m84C3D8E0A4E8390A353C2361A0900372742065A0 (void);
// 0x00000098 UnityEngine.Ray UnityEngine.Camera::ScreenPointToRay(UnityEngine.Vector3,UnityEngine.Camera_MonoOrStereoscopicEye)
extern void Camera_ScreenPointToRay_m7069BC09C3D802595AC1FBAEFB3C59C8F1FE5FE2 (void);
// 0x00000099 UnityEngine.Ray UnityEngine.Camera::ScreenPointToRay(UnityEngine.Vector3)
extern void Camera_ScreenPointToRay_m27638E78502DB6D6D7113F81AF7C210773B828F3 (void);
// 0x0000009A UnityEngine.Camera UnityEngine.Camera::get_main()
extern void Camera_get_main_m9256A9F84F92D7ED73F3E6C4E2694030AD8B61FA (void);
// 0x0000009B System.Boolean UnityEngine.Camera::get_stereoEnabled()
extern void Camera_get_stereoEnabled_m24FC636CCDA9B771F2A975C4F5DB561454357856 (void);
// 0x0000009C UnityEngine.StereoTargetEyeMask UnityEngine.Camera::get_stereoTargetEye()
extern void Camera_get_stereoTargetEye_mC9A7C0AB7FE7858D2CD9B7B09DAD4FCA7BE16D21 (void);
// 0x0000009D System.Int32 UnityEngine.Camera::GetAllCamerasCount()
extern void Camera_GetAllCamerasCount_mBA721F43F94AA5DB555461DE11351CBAF8267662 (void);
// 0x0000009E System.Int32 UnityEngine.Camera::GetAllCamerasImpl(UnityEngine.Camera[])
extern void Camera_GetAllCamerasImpl_mC93829FFC53391EA6C5012E5FA3817BA20DBEA89 (void);
// 0x0000009F System.Int32 UnityEngine.Camera::get_allCamerasCount()
extern void Camera_get_allCamerasCount_mF6CDC46D6F61B1F1A0337A9AD7DFA485E408E6A1 (void);
// 0x000000A0 System.Int32 UnityEngine.Camera::GetAllCameras(UnityEngine.Camera[])
extern void Camera_GetAllCameras_m500A4F27E7BE1C259E9EAA0AEBB1E1B35893059C (void);
// 0x000000A1 System.Void UnityEngine.Camera::FireOnPreCull(UnityEngine.Camera)
extern void Camera_FireOnPreCull_m7E8B65875444B1DE75170805AE22908ADE52301E (void);
// 0x000000A2 System.Void UnityEngine.Camera::FireOnPreRender(UnityEngine.Camera)
extern void Camera_FireOnPreRender_m996699B5D50FC3D0AB05EED9F9CE581CCDC2FF67 (void);
// 0x000000A3 System.Void UnityEngine.Camera::FireOnPostRender(UnityEngine.Camera)
extern void Camera_FireOnPostRender_m17457A692D59CBDDDBBE0E4C441D393DAD58654B (void);
// 0x000000A4 System.Boolean UnityEngine.Camera::TryGetCullingParameters(System.Boolean,UnityEngine.Rendering.ScriptableCullingParameters&)
extern void Camera_TryGetCullingParameters_mCCA2EAAEFB8C8DA2C81B51BA5111A0C1F6BB064C (void);
// 0x000000A5 System.Boolean UnityEngine.Camera::GetCullingParameters_Internal(UnityEngine.Camera,System.Boolean,UnityEngine.Rendering.ScriptableCullingParameters&,System.Int32)
extern void Camera_GetCullingParameters_Internal_m97DCDFD9FC11DFE1024ACDDB2E6233079883F774 (void);
// 0x000000A6 System.Void UnityEngine.Camera::.ctor()
extern void Camera__ctor_mD07AB17467A910BC7A4EE32BB9DD546748E31254 (void);
// 0x000000A7 System.Void UnityEngine.Camera::get_backgroundColor_Injected(UnityEngine.Color&)
extern void Camera_get_backgroundColor_Injected_m35D7092E021C199D24A3457297EEEAA520CAC999 (void);
// 0x000000A8 System.Void UnityEngine.Camera::get_rect_Injected(UnityEngine.Rect&)
extern void Camera_get_rect_Injected_m88F10E0BE4F27E638C97010D4616DBB14338EEED (void);
// 0x000000A9 System.Void UnityEngine.Camera::set_rect_Injected(UnityEngine.Rect&)
extern void Camera_set_rect_Injected_m62EE0CFFE15C612C226DEAB0ADB3D3B81ABE0C4E (void);
// 0x000000AA System.Void UnityEngine.Camera::get_pixelRect_Injected(UnityEngine.Rect&)
extern void Camera_get_pixelRect_Injected_mDE6A7F125BC1DD2BCFEA3CB03DFA948E5635E631 (void);
// 0x000000AB System.Void UnityEngine.Camera::set_pixelRect_Injected(UnityEngine.Rect&)
extern void Camera_set_pixelRect_Injected_mBE9F9ED0BC921A91C9E1B85075E8E7F8ECD61D45 (void);
// 0x000000AC System.Void UnityEngine.Camera::get_worldToCameraMatrix_Injected(UnityEngine.Matrix4x4&)
extern void Camera_get_worldToCameraMatrix_Injected_mF75446D0941E2CBEC1DDFE4FCFBE13E7ACAD0025 (void);
// 0x000000AD System.Void UnityEngine.Camera::set_worldToCameraMatrix_Injected(UnityEngine.Matrix4x4&)
extern void Camera_set_worldToCameraMatrix_Injected_mA848604C2BE1736B773F75FD83D39C4EF8E68EFA (void);
// 0x000000AE System.Void UnityEngine.Camera::get_projectionMatrix_Injected(UnityEngine.Matrix4x4&)
extern void Camera_get_projectionMatrix_Injected_mB52990E81F3B593935C384045A72611A1E160E30 (void);
// 0x000000AF System.Void UnityEngine.Camera::get_nonJitteredProjectionMatrix_Injected(UnityEngine.Matrix4x4&)
extern void Camera_get_nonJitteredProjectionMatrix_Injected_m0D047D1DFCAA06176DA978B02E5522EDB12DF23A (void);
// 0x000000B0 System.Void UnityEngine.Camera::WorldToScreenPoint_Injected(UnityEngine.Vector3&,UnityEngine.Camera_MonoOrStereoscopicEye,UnityEngine.Vector3&)
extern void Camera_WorldToScreenPoint_Injected_m640C6AFA68F6C2AD25AFD9E06C1AEFEAC5B48B01 (void);
// 0x000000B1 System.Void UnityEngine.Camera::ScreenToViewportPoint_Injected(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void Camera_ScreenToViewportPoint_Injected_m407A30EDD4AC317DE3DD0B4361664F438E5A6639 (void);
// 0x000000B2 System.Void UnityEngine.Camera::ScreenPointToRay_Injected(UnityEngine.Vector2&,UnityEngine.Camera_MonoOrStereoscopicEye,UnityEngine.Ray&)
extern void Camera_ScreenPointToRay_Injected_m1135D2C450C7DED657837BEFE5AD7FAFB9B99387 (void);
// 0x000000B3 System.Void UnityEngine.Camera_CameraCallback::.ctor(System.Object,System.IntPtr)
extern void CameraCallback__ctor_m7CAE962B355F00AB2868577DC302A1FA80939C50 (void);
// 0x000000B4 System.Void UnityEngine.Camera_CameraCallback::Invoke(UnityEngine.Camera)
extern void CameraCallback_Invoke_m2B4F10A7BF2620A9BBF1C071D5B4EE828FFE821F (void);
// 0x000000B5 System.IAsyncResult UnityEngine.Camera_CameraCallback::BeginInvoke(UnityEngine.Camera,System.AsyncCallback,System.Object)
extern void CameraCallback_BeginInvoke_m46CF0E3E7E6A18868CBEBEA62D012713B20A8B14 (void);
// 0x000000B6 System.Void UnityEngine.Camera_CameraCallback::EndInvoke(System.IAsyncResult)
extern void CameraCallback_EndInvoke_m3B1E210D6A4F41F0FF74B187B3D7CB64C302D146 (void);
// 0x000000B7 System.Void UnityEngine.CullingGroup::.ctor()
extern void CullingGroup__ctor_m9930683B9FE5B8B3409C4C60476D592863306EC5 (void);
// 0x000000B8 System.Void UnityEngine.CullingGroup::Finalize()
extern void CullingGroup_Finalize_m67D1F84462EC91AACBB9899B859D26CAD5BE24AB (void);
// 0x000000B9 System.Void UnityEngine.CullingGroup::DisposeInternal()
extern void CullingGroup_DisposeInternal_m50A7ADA8944DDE68D1D10A7CFFEB37EE2FB4EB19 (void);
// 0x000000BA System.Void UnityEngine.CullingGroup::Dispose()
extern void CullingGroup_Dispose_mBB6749664C63EA7289A5AB405A479DFEAD90A2EF (void);
// 0x000000BB System.Void UnityEngine.CullingGroup::set_targetCamera(UnityEngine.Camera)
extern void CullingGroup_set_targetCamera_m5FC653577169438F41E58DA5DF9D006FCFF0FF18 (void);
// 0x000000BC System.Void UnityEngine.CullingGroup::SetBoundingSpheres(UnityEngine.BoundingSphere[])
extern void CullingGroup_SetBoundingSpheres_m23F40B24D0A5DFF2CBA61444FD491B0D23225974 (void);
// 0x000000BD System.Void UnityEngine.CullingGroup::SetBoundingSphereCount(System.Int32)
extern void CullingGroup_SetBoundingSphereCount_m0BA4EA985BFEC46C6D6F8703D5EB947647002CCA (void);
// 0x000000BE System.Boolean UnityEngine.CullingGroup::IsVisible(System.Int32)
extern void CullingGroup_IsVisible_mDF6806EB7EE918F7919377D0CE00AF44DDD31F7B (void);
// 0x000000BF System.Void UnityEngine.CullingGroup::SendEvents(UnityEngine.CullingGroup,System.IntPtr,System.Int32)
extern void CullingGroup_SendEvents_m08EBF10EEFF49CF9894BA940FD969C8F53F807E7 (void);
// 0x000000C0 System.IntPtr UnityEngine.CullingGroup::Init(System.Object)
extern void CullingGroup_Init_m1F9C9FAFDD0D2B89FF7C8DC662886734450021FE (void);
// 0x000000C1 System.Void UnityEngine.CullingGroup::FinalizerFailure()
extern void CullingGroup_FinalizerFailure_mB9C9DC09F2124724B22C0726B6B1EA2957D87973 (void);
// 0x000000C2 System.Void UnityEngine.CullingGroup_StateChanged::.ctor(System.Object,System.IntPtr)
extern void StateChanged__ctor_m8DCC0DCE42D5257F92FEA1F2B4DA2EF4558006F9 (void);
// 0x000000C3 System.Void UnityEngine.CullingGroup_StateChanged::Invoke(UnityEngine.CullingGroupEvent)
extern void StateChanged_Invoke_m2E371D6B1AD1F23F20038D0DEEEFED15D76BC545 (void);
// 0x000000C4 System.IAsyncResult UnityEngine.CullingGroup_StateChanged::BeginInvoke(UnityEngine.CullingGroupEvent,System.AsyncCallback,System.Object)
extern void StateChanged_BeginInvoke_m5BD458B36BF2E71F4FB19444B0FAAA1B87BF8912 (void);
// 0x000000C5 System.Void UnityEngine.CullingGroup_StateChanged::EndInvoke(System.IAsyncResult)
extern void StateChanged_EndInvoke_mBC050D5602C1F3EC3F8137908D81894E646F5212 (void);
// 0x000000C6 System.Void UnityEngine.ReflectionProbe::CallReflectionProbeEvent(UnityEngine.ReflectionProbe,UnityEngine.ReflectionProbe_ReflectionProbeEvent)
extern void ReflectionProbe_CallReflectionProbeEvent_mA6273CE84793FD3CC7AA0506C525EED4F4935B62 (void);
// 0x000000C7 System.Void UnityEngine.ReflectionProbe::CallSetDefaultReflection(UnityEngine.Cubemap)
extern void ReflectionProbe_CallSetDefaultReflection_m97EFBE5F8A57BB7C8CA65C65FF4BD9889060325D (void);
// 0x000000C8 System.Void UnityEngine.DebugLogHandler::Internal_Log(UnityEngine.LogType,UnityEngine.LogOption,System.String,UnityEngine.Object)
extern void DebugLogHandler_Internal_Log_m2B637FD9089DEAA9D9FDE458DF5415CDF97424C3 (void);
// 0x000000C9 System.Void UnityEngine.DebugLogHandler::Internal_LogException(System.Exception,UnityEngine.Object)
extern void DebugLogHandler_Internal_LogException_m8400B0D97B8D4A155A449BD28A32C68373A1A856 (void);
// 0x000000CA System.Void UnityEngine.DebugLogHandler::LogFormat(UnityEngine.LogType,UnityEngine.Object,System.String,System.Object[])
extern void DebugLogHandler_LogFormat_m3C9B0AD4B5CDFF5AF195F9AA9FCBA908053BA41D (void);
// 0x000000CB System.Void UnityEngine.DebugLogHandler::LogException(System.Exception,UnityEngine.Object)
extern void DebugLogHandler_LogException_m816CF2DDA84DFC1D1715B24F9626BD623FF05416 (void);
// 0x000000CC System.Void UnityEngine.DebugLogHandler::.ctor()
extern void DebugLogHandler__ctor_mE9664BE5E6020FB88C6A301465811C80DEDFA392 (void);
// 0x000000CD UnityEngine.ILogger UnityEngine.Debug::get_unityLogger()
extern void Debug_get_unityLogger_mFA75EC397E067D09FD66D56B4E7692C3FCC3E960 (void);
// 0x000000CE System.Void UnityEngine.Debug::Log(System.Object)
extern void Debug_Log_m4B7C70BAFD477C6BDB59C88A0934F0B018D03708 (void);
// 0x000000CF System.Void UnityEngine.Debug::LogError(System.Object)
extern void Debug_LogError_m3BCF9B78263152261565DCA9DB7D55F0C391ED29 (void);
// 0x000000D0 System.Void UnityEngine.Debug::LogError(System.Object,UnityEngine.Object)
extern void Debug_LogError_m97139CB2EE76D5CD8308C1AD0499A5F163FC7F51 (void);
// 0x000000D1 System.Void UnityEngine.Debug::LogErrorFormat(System.String,System.Object[])
extern void Debug_LogErrorFormat_mB54A656B267CF936439D50348FC828921AEDA8A9 (void);
// 0x000000D2 System.Void UnityEngine.Debug::LogErrorFormat(UnityEngine.Object,System.String,System.Object[])
extern void Debug_LogErrorFormat_m994E4759C25BF0E9DD4179C10E3979558137CCF0 (void);
// 0x000000D3 System.Void UnityEngine.Debug::LogException(System.Exception)
extern void Debug_LogException_mBAA6702C240E37B2A834AA74E4FDC15A3A5589A9 (void);
// 0x000000D4 System.Void UnityEngine.Debug::LogException(System.Exception,UnityEngine.Object)
extern void Debug_LogException_m3CC9A37CD398E5B7F2305896F0969939F1BD1E3E (void);
// 0x000000D5 System.Void UnityEngine.Debug::LogWarning(System.Object)
extern void Debug_LogWarning_m37338644DC81F640CCDFEAE35A223F0E965F0568 (void);
// 0x000000D6 System.Void UnityEngine.Debug::LogWarning(System.Object,UnityEngine.Object)
extern void Debug_LogWarning_mD417697331190AC1D21C463F412C475103A7256E (void);
// 0x000000D7 System.Void UnityEngine.Debug::LogWarningFormat(UnityEngine.Object,System.String,System.Object[])
extern void Debug_LogWarningFormat_m4A02CCF91F3A9392F4AA93576DCE2222267E5945 (void);
// 0x000000D8 System.Void UnityEngine.Debug::Assert(System.Boolean)
extern void Debug_Assert_m0283DD85C5E5F5029793C17A335DB16BC307E62E (void);
// 0x000000D9 System.Void UnityEngine.Debug::Assert(System.Boolean,System.String)
extern void Debug_Assert_m84EE43ACFD01E8C0CEC0160C494B2CE77338F7BC (void);
// 0x000000DA System.Void UnityEngine.Debug::LogAssertion(System.Object)
extern void Debug_LogAssertion_m2A8940871EC1BD01A405103429F2FCE2AFB12506 (void);
// 0x000000DB System.Boolean UnityEngine.Debug::get_isDebugBuild()
extern void Debug_get_isDebugBuild_mED5A7963C7B055A9ACC5565862BBBA6F3D86EDE8 (void);
// 0x000000DC System.Boolean UnityEngine.Debug::CallOverridenDebugHandler(System.Exception,UnityEngine.Object)
extern void Debug_CallOverridenDebugHandler_m5F5FC22445A9C957A655734DA5B661A5E256BEBE (void);
// 0x000000DD System.Void UnityEngine.Debug::.cctor()
extern void Debug__cctor_m9BFDFB65B30AA2962FDACD15F36FC666471D1C5E (void);
// 0x000000DE System.Void UnityEngine.Bounds::.ctor(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Bounds__ctor_m294E77A20EC1A3E96985FE1A925CB271D1B5266D_AdjustorThunk (void);
// 0x000000DF System.Int32 UnityEngine.Bounds::GetHashCode()
extern void Bounds_GetHashCode_m9F5F751E9D52F99FCC3DC07407410078451F06AC_AdjustorThunk (void);
// 0x000000E0 System.Boolean UnityEngine.Bounds::Equals(System.Object)
extern void Bounds_Equals_m1ECFAEFE19BAFB61FFECA5C0B8AE068483A39C61_AdjustorThunk (void);
// 0x000000E1 System.Boolean UnityEngine.Bounds::Equals(UnityEngine.Bounds)
extern void Bounds_Equals_mC2E2B04AB16455E2C17CD0B3C1497835DEA39859_AdjustorThunk (void);
// 0x000000E2 UnityEngine.Vector3 UnityEngine.Bounds::get_center()
extern void Bounds_get_center_m4FB6E99F0533EE2D432988B08474D6DC9B8B744B_AdjustorThunk (void);
// 0x000000E3 System.Void UnityEngine.Bounds::set_center(UnityEngine.Vector3)
extern void Bounds_set_center_mAD29DD80FD631F83AF4E7558BB27A0398E8FD841_AdjustorThunk (void);
// 0x000000E4 UnityEngine.Vector3 UnityEngine.Bounds::get_size()
extern void Bounds_get_size_m0739F2686AE2D3416A33AEF892653091347FD4A6_AdjustorThunk (void);
// 0x000000E5 System.Void UnityEngine.Bounds::set_size(UnityEngine.Vector3)
extern void Bounds_set_size_m70855AC67A54062D676174B416FB06019226B39A_AdjustorThunk (void);
// 0x000000E6 UnityEngine.Vector3 UnityEngine.Bounds::get_extents()
extern void Bounds_get_extents_mBA4B2196036DD5A858BDAD53BC71A778B41841C9_AdjustorThunk (void);
// 0x000000E7 System.Void UnityEngine.Bounds::set_extents(UnityEngine.Vector3)
extern void Bounds_set_extents_mC83719146B06D0575A160CDDE9997202A1192B35_AdjustorThunk (void);
// 0x000000E8 UnityEngine.Vector3 UnityEngine.Bounds::get_min()
extern void Bounds_get_min_m2D48F74D29BF904D1AF19C562932E34ACAE2467C_AdjustorThunk (void);
// 0x000000E9 System.Void UnityEngine.Bounds::set_min(UnityEngine.Vector3)
extern void Bounds_set_min_m5933955F04FCC8E3B372EA72ECCD398BB057C844_AdjustorThunk (void);
// 0x000000EA UnityEngine.Vector3 UnityEngine.Bounds::get_max()
extern void Bounds_get_max_mC3BE43C2A865BAC138D117684BC01E289892549B_AdjustorThunk (void);
// 0x000000EB System.Void UnityEngine.Bounds::set_max(UnityEngine.Vector3)
extern void Bounds_set_max_m12B864B082A4A188C7624C1ABEFA34028DD5A603_AdjustorThunk (void);
// 0x000000EC System.Boolean UnityEngine.Bounds::op_Equality(UnityEngine.Bounds,UnityEngine.Bounds)
extern void Bounds_op_Equality_m8168B65BF71D8E5B2F0181677ED79957DD754FF4 (void);
// 0x000000ED System.Boolean UnityEngine.Bounds::op_Inequality(UnityEngine.Bounds,UnityEngine.Bounds)
extern void Bounds_op_Inequality_mA6EBEDD980A41D5E206CBE009731EB1CA0B25502 (void);
// 0x000000EE System.Void UnityEngine.Bounds::SetMinMax(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Bounds_SetMinMax_m04969DE5CBC7F9843C12926ADD5F591159C86CA6_AdjustorThunk (void);
// 0x000000EF System.Void UnityEngine.Bounds::Encapsulate(UnityEngine.Vector3)
extern void Bounds_Encapsulate_mD1F1DAC416D7147E07BF54D87CA7FF84C1088D8D_AdjustorThunk (void);
// 0x000000F0 System.String UnityEngine.Bounds::ToString()
extern void Bounds_ToString_m4637EA7C58B9C75651A040182471E9BAB9295666_AdjustorThunk (void);
// 0x000000F1 System.Void UnityEngine.Plane::.ctor(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Plane__ctor_m6535EAD5E675627C2533962F1F7890CBFA2BA44A_AdjustorThunk (void);
// 0x000000F2 System.Boolean UnityEngine.Plane::Raycast(UnityEngine.Ray,System.Single&)
extern void Plane_Raycast_m04E61D7C78A5DA70F4F73F9805ABB54177B799A9_AdjustorThunk (void);
// 0x000000F3 System.String UnityEngine.Plane::ToString()
extern void Plane_ToString_mF92ABB5136759C7DFBC26FD3957532B3C26F2099_AdjustorThunk (void);
// 0x000000F4 System.Void UnityEngine.Ray::.ctor(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Ray__ctor_m695D219349B8AA4C82F96C55A27D384C07736F6B_AdjustorThunk (void);
// 0x000000F5 UnityEngine.Vector3 UnityEngine.Ray::get_origin()
extern void Ray_get_origin_m3773CA7B1E2F26F6F1447652B485D86C0BEC5187_AdjustorThunk (void);
// 0x000000F6 UnityEngine.Vector3 UnityEngine.Ray::get_direction()
extern void Ray_get_direction_m9E6468CD87844B437FC4B93491E63D388322F76E_AdjustorThunk (void);
// 0x000000F7 UnityEngine.Vector3 UnityEngine.Ray::GetPoint(System.Single)
extern void Ray_GetPoint_mE8830D3BA68A184AD70514428B75F5664105ED08_AdjustorThunk (void);
// 0x000000F8 System.String UnityEngine.Ray::ToString()
extern void Ray_ToString_m73B5291E29C9C691773B44590C467A0D4FBE0EC1_AdjustorThunk (void);
// 0x000000F9 System.Void UnityEngine.Rect::.ctor(System.Single,System.Single,System.Single,System.Single)
extern void Rect__ctor_m50B92C75005C9C5A0D05E6E0EBB43AFAF7C66280_AdjustorThunk (void);
// 0x000000FA System.Void UnityEngine.Rect::.ctor(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Rect__ctor_m027E778E437FED8E6DBCE0C01C854ADF54986ECE_AdjustorThunk (void);
// 0x000000FB UnityEngine.Rect UnityEngine.Rect::get_zero()
extern void Rect_get_zero_m4CF0F9AD904132829A6EFCA85A1BF52794E7E56B (void);
// 0x000000FC UnityEngine.Rect UnityEngine.Rect::MinMaxRect(System.Single,System.Single,System.Single,System.Single)
extern void Rect_MinMaxRect_m9513FDB332B24FB8B49202C7350FF7223477F54F (void);
// 0x000000FD System.Single UnityEngine.Rect::get_x()
extern void Rect_get_x_mC51A461F546D14832EB96B11A7198DADDE2597B7_AdjustorThunk (void);
// 0x000000FE System.Void UnityEngine.Rect::set_x(System.Single)
extern void Rect_set_x_m49EFE25263C03A48D52499C3E9C097298E0EA3A6_AdjustorThunk (void);
// 0x000000FF System.Single UnityEngine.Rect::get_y()
extern void Rect_get_y_m53E3E4F62D9840FBEA751A66293038F1F5D1D45C_AdjustorThunk (void);
// 0x00000100 System.Void UnityEngine.Rect::set_y(System.Single)
extern void Rect_set_y_mCFDB9BD77334EF9CD896F64BE63C755777D7CCD5_AdjustorThunk (void);
// 0x00000101 UnityEngine.Vector2 UnityEngine.Rect::get_position()
extern void Rect_get_position_m54A2ACD2F97988561D6C83FCEF7D082BC5226D4C_AdjustorThunk (void);
// 0x00000102 System.Void UnityEngine.Rect::set_position(UnityEngine.Vector2)
extern void Rect_set_position_mD92DFF591D9C96CDD6AF22EA2052BB3D468D68ED_AdjustorThunk (void);
// 0x00000103 UnityEngine.Vector2 UnityEngine.Rect::get_center()
extern void Rect_get_center_mA6E659EAAACC32132022AB199793BF641B3068CB_AdjustorThunk (void);
// 0x00000104 UnityEngine.Vector2 UnityEngine.Rect::get_min()
extern void Rect_get_min_m17345668569CF57C5F1D2B2DADD05DD4220A5950_AdjustorThunk (void);
// 0x00000105 UnityEngine.Vector2 UnityEngine.Rect::get_max()
extern void Rect_get_max_m3BFB033D741F205FB04EF163A9D5785E7E020756_AdjustorThunk (void);
// 0x00000106 System.Single UnityEngine.Rect::get_width()
extern void Rect_get_width_m54FF69FC2C086E2DC349ED091FD0D6576BFB1484_AdjustorThunk (void);
// 0x00000107 System.Void UnityEngine.Rect::set_width(System.Single)
extern void Rect_set_width_mC81EF602AC91E0C615C12FCE060254A461A152B8_AdjustorThunk (void);
// 0x00000108 System.Single UnityEngine.Rect::get_height()
extern void Rect_get_height_m088C36990E0A255C5D7DCE36575DCE23ABB364B5_AdjustorThunk (void);
// 0x00000109 System.Void UnityEngine.Rect::set_height(System.Single)
extern void Rect_set_height_mF4CB5A97D4706696F1C9EA31A5D8C466E48050D6_AdjustorThunk (void);
// 0x0000010A UnityEngine.Vector2 UnityEngine.Rect::get_size()
extern void Rect_get_size_m731642B8F03F6CE372A2C9E2E4A925450630606C_AdjustorThunk (void);
// 0x0000010B System.Void UnityEngine.Rect::set_size(UnityEngine.Vector2)
extern void Rect_set_size_m4618056983660063A74F40CCFF9A683933CB4C93_AdjustorThunk (void);
// 0x0000010C System.Single UnityEngine.Rect::get_xMin()
extern void Rect_get_xMin_mFDFA74F66595FD2B8CE360183D1A92B575F0A76E_AdjustorThunk (void);
// 0x0000010D System.Void UnityEngine.Rect::set_xMin(System.Single)
extern void Rect_set_xMin_mD8F9BF59F4F33F9C3AB2FEFF32D8C16756B51E34_AdjustorThunk (void);
// 0x0000010E System.Single UnityEngine.Rect::get_yMin()
extern void Rect_get_yMin_m31EDC3262BE39D2F6464B15397F882237E6158C3_AdjustorThunk (void);
// 0x0000010F System.Void UnityEngine.Rect::set_yMin(System.Single)
extern void Rect_set_yMin_m58C137C81F3D098CF81498964E1B5987882883A7_AdjustorThunk (void);
// 0x00000110 System.Single UnityEngine.Rect::get_xMax()
extern void Rect_get_xMax_mA16D7C3C2F30F8608719073ED79028C11CE90983_AdjustorThunk (void);
// 0x00000111 System.Void UnityEngine.Rect::set_xMax(System.Single)
extern void Rect_set_xMax_m1775041FCD5CA22C77D75CC780D158CD2B31CEAF_AdjustorThunk (void);
// 0x00000112 System.Single UnityEngine.Rect::get_yMax()
extern void Rect_get_yMax_m8AA5E92C322AF3FF571330F00579DA864F33341B_AdjustorThunk (void);
// 0x00000113 System.Void UnityEngine.Rect::set_yMax(System.Single)
extern void Rect_set_yMax_m4F1C5632CD4836853A22E979C810C279FBB20B95_AdjustorThunk (void);
// 0x00000114 System.Boolean UnityEngine.Rect::Contains(UnityEngine.Vector2)
extern void Rect_Contains_mAD3D41C88795960F177088F847509C9DDA23B682_AdjustorThunk (void);
// 0x00000115 System.Boolean UnityEngine.Rect::Contains(UnityEngine.Vector3)
extern void Rect_Contains_m5072228CE6251E7C754F227BA330F9ADA95C1495_AdjustorThunk (void);
// 0x00000116 UnityEngine.Rect UnityEngine.Rect::OrderMinMax(UnityEngine.Rect)
extern void Rect_OrderMinMax_m1BE37D433FE6B7FB0FB73652E166A4FB887214CD (void);
// 0x00000117 System.Boolean UnityEngine.Rect::Overlaps(UnityEngine.Rect)
extern void Rect_Overlaps_m2FE484659899E54C13772AB7D9E202239A637559_AdjustorThunk (void);
// 0x00000118 System.Boolean UnityEngine.Rect::Overlaps(UnityEngine.Rect,System.Boolean)
extern void Rect_Overlaps_m4FFECCEAB3FBF23ED5A51B2E26220F035B942B4B_AdjustorThunk (void);
// 0x00000119 System.Boolean UnityEngine.Rect::op_Inequality(UnityEngine.Rect,UnityEngine.Rect)
extern void Rect_op_Inequality_mAF9DC03779A7C3E1B430D7FFA797F2C4CEAD1FC7 (void);
// 0x0000011A System.Boolean UnityEngine.Rect::op_Equality(UnityEngine.Rect,UnityEngine.Rect)
extern void Rect_op_Equality_mFBE3505CEDD6B73F66276E782C1B02E0E5633563 (void);
// 0x0000011B System.Int32 UnityEngine.Rect::GetHashCode()
extern void Rect_GetHashCode_mA23F5D7C299F7E05A0390DF2FA663F5A003799C6_AdjustorThunk (void);
// 0x0000011C System.Boolean UnityEngine.Rect::Equals(System.Object)
extern void Rect_Equals_m76E3B7E2E5CC43299C4BF4CB2EA9EF6E989E23E3_AdjustorThunk (void);
// 0x0000011D System.Boolean UnityEngine.Rect::Equals(UnityEngine.Rect)
extern void Rect_Equals_mC8430F80283016D0783FB6C4E7461BEED4B55C82_AdjustorThunk (void);
// 0x0000011E System.String UnityEngine.Rect::ToString()
extern void Rect_ToString_m045E7857658F27052323E301FBA3867AD13A6FE5_AdjustorThunk (void);
// 0x0000011F System.Int32 UnityEngine.RectInt::get_x()
extern void RectInt_get_x_mF20D556E7923C4CFD7BB968287E81EEFC777E1AE_AdjustorThunk (void);
// 0x00000120 System.Void UnityEngine.RectInt::set_x(System.Int32)
extern void RectInt_set_x_m789BBF9F6936E14405F20C659F103F23E8BE108E_AdjustorThunk (void);
// 0x00000121 System.Int32 UnityEngine.RectInt::get_y()
extern void RectInt_get_y_m25B8B729B867E3A3B095763A9D44B4ACD82FA3FC_AdjustorThunk (void);
// 0x00000122 System.Void UnityEngine.RectInt::set_y(System.Int32)
extern void RectInt_set_y_mB44F87E3B83ABA670CA1F8AF175B3C18F23E222A_AdjustorThunk (void);
// 0x00000123 System.Int32 UnityEngine.RectInt::get_width()
extern void RectInt_get_width_mDA704D3EB9595731CBD251E57AADD56264D4A63A_AdjustorThunk (void);
// 0x00000124 System.Void UnityEngine.RectInt::set_width(System.Int32)
extern void RectInt_set_width_m26A0E2678960FBCD030AF849842D6179B0D694C7_AdjustorThunk (void);
// 0x00000125 System.Int32 UnityEngine.RectInt::get_height()
extern void RectInt_get_height_m72A9DC291C6C2B36646646FFCC9FBE5018DAC2BC_AdjustorThunk (void);
// 0x00000126 System.Void UnityEngine.RectInt::set_height(System.Int32)
extern void RectInt_set_height_mEE6F6F740F5F0BC97D81EB8D707434517FD8E389_AdjustorThunk (void);
// 0x00000127 System.Void UnityEngine.RectInt::.ctor(System.Int32,System.Int32,System.Int32,System.Int32)
extern void RectInt__ctor_mF85AFBAF60C3270995656D8A05A002304D57B8E4_AdjustorThunk (void);
// 0x00000128 System.String UnityEngine.RectInt::ToString()
extern void RectInt_ToString_m8EB8256D9DD212E3949E2C3ED629B710731C89DA_AdjustorThunk (void);
// 0x00000129 System.Boolean UnityEngine.RectInt::Equals(UnityEngine.RectInt)
extern void RectInt_Equals_m653C25536C79F1002A12DC2D8F69C714BEF3926F_AdjustorThunk (void);
// 0x0000012A System.Void UnityEngine.RectOffset::.ctor()
extern void RectOffset__ctor_m4A29807F411591FC06BE9367167B8F417EF73828 (void);
// 0x0000012B System.Void UnityEngine.RectOffset::.ctor(System.Object,System.IntPtr)
extern void RectOffset__ctor_m23620FE61AAF476219462230C6839B86736B80BA (void);
// 0x0000012C System.Void UnityEngine.RectOffset::Finalize()
extern void RectOffset_Finalize_m69453D37706F46DD3A2A6F39A018D371A5E7072C (void);
// 0x0000012D System.String UnityEngine.RectOffset::ToString()
extern void RectOffset_ToString_m6852E54822C1FACE624F3306DD9DC71628E91F93 (void);
// 0x0000012E System.Void UnityEngine.RectOffset::Destroy()
extern void RectOffset_Destroy_mE1A6BDB23EC0B1A51AD5365CEF0055F7856AA533 (void);
// 0x0000012F System.IntPtr UnityEngine.RectOffset::InternalCreate()
extern void RectOffset_InternalCreate_m6638B085A0DA1CB1DA37B7C91CAC98DCF2CF7A16 (void);
// 0x00000130 System.Void UnityEngine.RectOffset::InternalDestroy(System.IntPtr)
extern void RectOffset_InternalDestroy_m4FAB64D6AECF15082E19BDC4F22913152D5C6FA1 (void);
// 0x00000131 System.Int32 UnityEngine.RectOffset::get_left()
extern void RectOffset_get_left_mA86EC00866C1940134873E3A1565A1F700DE67AD (void);
// 0x00000132 System.Int32 UnityEngine.RectOffset::get_right()
extern void RectOffset_get_right_m9B05958C3C1B31F1FAB8675834A492C7208F6C96 (void);
// 0x00000133 System.Int32 UnityEngine.RectOffset::get_top()
extern void RectOffset_get_top_mBA813D4147BFBC079933054018437F411B6B41E1 (void);
// 0x00000134 System.Int32 UnityEngine.RectOffset::get_bottom()
extern void RectOffset_get_bottom_mE5162CADD266B59539E3EE1967EE9A74705E5632 (void);
// 0x00000135 System.Int32 UnityEngine.RectOffset::get_horizontal()
extern void RectOffset_get_horizontal_m9274B965D5D388F6F750D127B3E57F70DF0D89C1 (void);
// 0x00000136 System.Int32 UnityEngine.RectOffset::get_vertical()
extern void RectOffset_get_vertical_m89ED337C8D303C8994B2B056C05368E4286CFC5E (void);
// 0x00000137 System.Void UnityEngine.Gizmos::DrawIcon(UnityEngine.Vector3,System.String,System.Boolean,UnityEngine.Color)
extern void Gizmos_DrawIcon_m68377BABAC05C0DA18A2678D3B3AD6F574326275 (void);
// 0x00000138 System.Void UnityEngine.Gizmos::DrawIcon_Injected(UnityEngine.Vector3&,System.String,System.Boolean,UnityEngine.Color&)
extern void Gizmos_DrawIcon_Injected_m4D9D38623FBCF115DC08EC5B3135CA16B04E8B5C (void);
// 0x00000139 System.Void UnityEngine.BeforeRenderHelper::Invoke()
extern void BeforeRenderHelper_Invoke_m5CADC9F58196CF3F11CB1203AEAF40003C7D4ADD (void);
// 0x0000013A System.Void UnityEngine.BeforeRenderHelper::.cctor()
extern void BeforeRenderHelper__cctor_mAF1DF30E8F7C2CE586303CAA41303230FE2DEB0D (void);
// 0x0000013B System.Void UnityEngine.Display::.ctor()
extern void Display__ctor_m1E66361E430C3698C98D242CEB6820E9B4FC7EB8 (void);
// 0x0000013C System.Void UnityEngine.Display::.ctor(System.IntPtr)
extern void Display__ctor_mE84D2B0874035D8A772F4BAE78E0B8A2C7008E46 (void);
// 0x0000013D System.Int32 UnityEngine.Display::get_renderingWidth()
extern void Display_get_renderingWidth_mA02F65BF724686D7A0CD0C192954CA22592C3B12 (void);
// 0x0000013E System.Int32 UnityEngine.Display::get_renderingHeight()
extern void Display_get_renderingHeight_m1496BF9D66501280B4F75A31A515D8CF416838B0 (void);
// 0x0000013F System.Int32 UnityEngine.Display::get_systemWidth()
extern void Display_get_systemWidth_mA14AF2D3B017CF4BA2C2990DC2398E528AF83413 (void);
// 0x00000140 System.Int32 UnityEngine.Display::get_systemHeight()
extern void Display_get_systemHeight_m0D7950CB39015167C175634EF8A5E0C52FBF5EC7 (void);
// 0x00000141 System.Boolean UnityEngine.Display::get_requiresBlitToBackbuffer()
extern void Display_get_requiresBlitToBackbuffer_m18F968721D2394EA154886F0F7F8429171DE3415 (void);
// 0x00000142 System.Boolean UnityEngine.Display::get_requiresSrgbBlitToBackbuffer()
extern void Display_get_requiresSrgbBlitToBackbuffer_mC06CB63E2F9E0B46C765E4024AB934D6799F5062 (void);
// 0x00000143 UnityEngine.Vector3 UnityEngine.Display::RelativeMouseAt(UnityEngine.Vector3)
extern void Display_RelativeMouseAt_mABDA4BAC2C1B328A2C6A205D552AA5488BFFAA93 (void);
// 0x00000144 UnityEngine.Display UnityEngine.Display::get_main()
extern void Display_get_main_mDC0ED8AD60BF5BC3C83384E9C5131403E7033AFA (void);
// 0x00000145 System.Void UnityEngine.Display::RecreateDisplayList(System.IntPtr[])
extern void Display_RecreateDisplayList_mA7E2B69AF4BD88A0C45B9A0BB7E1FFDDA5C60FE8 (void);
// 0x00000146 System.Void UnityEngine.Display::FireDisplaysUpdated()
extern void Display_FireDisplaysUpdated_m1655DF7464EA901E47BCDD6C3BBB9AFF52757D86 (void);
// 0x00000147 System.Void UnityEngine.Display::GetSystemExtImpl(System.IntPtr,System.Int32&,System.Int32&)
extern void Display_GetSystemExtImpl_m946E5A2D11FC99291208F123B660978106C0B5C6 (void);
// 0x00000148 System.Void UnityEngine.Display::GetRenderingExtImpl(System.IntPtr,System.Int32&,System.Int32&)
extern void Display_GetRenderingExtImpl_m14405A2EC3C99F90D5CD080F3262BB7B4AC2BA49 (void);
// 0x00000149 System.Int32 UnityEngine.Display::RelativeMouseAtImpl(System.Int32,System.Int32,System.Int32&,System.Int32&)
extern void Display_RelativeMouseAtImpl_mDC1A8A011C9B7FF7BC9A53A10FEDE8D817D68CDB (void);
// 0x0000014A System.Boolean UnityEngine.Display::RequiresBlitToBackbufferImpl(System.IntPtr)
extern void Display_RequiresBlitToBackbufferImpl_mBB4242A691C1957869352322174800929B4465A5 (void);
// 0x0000014B System.Boolean UnityEngine.Display::RequiresSrgbBlitToBackbufferImpl(System.IntPtr)
extern void Display_RequiresSrgbBlitToBackbufferImpl_m238B00D35DE436ED16E3E0412C31E9C0136527F3 (void);
// 0x0000014C System.Void UnityEngine.Display::.cctor()
extern void Display__cctor_mC1A1851D26DD51ECF2C09DBB1147A7CF05EEEC9D (void);
// 0x0000014D System.Void UnityEngine.Display_DisplaysUpdatedDelegate::.ctor(System.Object,System.IntPtr)
extern void DisplaysUpdatedDelegate__ctor_m976C17F642CEF8A7F95FA4C414B17BF0EC025197 (void);
// 0x0000014E System.Void UnityEngine.Display_DisplaysUpdatedDelegate::Invoke()
extern void DisplaysUpdatedDelegate_Invoke_mBCC82165E169B27958A8FD4E5A90B83A108DAE89 (void);
// 0x0000014F System.IAsyncResult UnityEngine.Display_DisplaysUpdatedDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void DisplaysUpdatedDelegate_BeginInvoke_m5DA06B0A901673F809EA597946702A73F9436BFF (void);
// 0x00000150 System.Void UnityEngine.Display_DisplaysUpdatedDelegate::EndInvoke(System.IAsyncResult)
extern void DisplaysUpdatedDelegate_EndInvoke_m470B70745AF2631D69A51A3883D774E9B49DD2E2 (void);
// 0x00000151 System.Int32 UnityEngine.Screen::get_width()
extern void Screen_get_width_m8ECCEF7FF17395D1237BC0193D7A6640A3FEEAD3 (void);
// 0x00000152 System.Int32 UnityEngine.Screen::get_height()
extern void Screen_get_height_mF5B64EBC4CDE0EAAA5713C1452ED2CE475F25150 (void);
// 0x00000153 System.Single UnityEngine.Screen::get_dpi()
extern void Screen_get_dpi_m92A755DE9E23ABA717B5594F4F52AFB0FBEAC1D3 (void);
// 0x00000154 UnityEngine.FullScreenMode UnityEngine.Screen::get_fullScreenMode()
extern void Screen_get_fullScreenMode_m89BD87B3D0CB7D42B845E3DE1D36EFC5B3577115 (void);
// 0x00000155 System.Int32 UnityEngine.Graphics::Internal_GetMaxDrawMeshInstanceCount()
extern void Graphics_Internal_GetMaxDrawMeshInstanceCount_mB5F6508A9AB7DBEBC192C6C7BDEF872295FB9801 (void);
// 0x00000156 UnityEngine.Rendering.GraphicsTier UnityEngine.Graphics::get_activeTier()
extern void Graphics_get_activeTier_mC69EEB666BDB6DD90E0DD89D18179DBB54C25141 (void);
// 0x00000157 System.Boolean UnityEngine.Graphics::GetPreserveFramebufferAlpha()
extern void Graphics_GetPreserveFramebufferAlpha_mF3E90C35ECADF153C649949335E8B6CE215B1CC3 (void);
// 0x00000158 System.Boolean UnityEngine.Graphics::get_preserveFramebufferAlpha()
extern void Graphics_get_preserveFramebufferAlpha_m39E2A13F37D33E13828A727957AFBBBEBB3C9CF6 (void);
// 0x00000159 System.Void UnityEngine.Graphics::CopyTexture_Slice(UnityEngine.Texture,System.Int32,System.Int32,UnityEngine.Texture,System.Int32,System.Int32)
extern void Graphics_CopyTexture_Slice_m8633121E05B15579BA27F1E0892CDFED06EAAFBE (void);
// 0x0000015A System.Void UnityEngine.Graphics::CopyTexture(UnityEngine.Texture,System.Int32,System.Int32,UnityEngine.Texture,System.Int32,System.Int32)
extern void Graphics_CopyTexture_m9328A3205B2969652666FDA6054DF8395BC7355B (void);
// 0x0000015B System.Void UnityEngine.Graphics::.cctor()
extern void Graphics__cctor_m87F7D324CC82B1B70ADFEC237B2BBEDC1767F1FF (void);
// 0x0000015C UnityEngine.Matrix4x4 UnityEngine.GL::GetGPUProjectionMatrix(UnityEngine.Matrix4x4,System.Boolean)
extern void GL_GetGPUProjectionMatrix_mE662E5FB0439D4794169BA587BA480960AFADD3E (void);
// 0x0000015D System.Void UnityEngine.GL::GetGPUProjectionMatrix_Injected(UnityEngine.Matrix4x4&,System.Boolean,UnityEngine.Matrix4x4&)
extern void GL_GetGPUProjectionMatrix_Injected_mA3C07257B2C404BE78FC6E36CF0794414C70446E (void);
// 0x0000015E System.Single UnityEngine.ScalableBufferManager::get_widthScaleFactor()
extern void ScalableBufferManager_get_widthScaleFactor_mABF8DAEDB2E92B657CF2CA67118E4B77A21EEBCC (void);
// 0x0000015F System.Single UnityEngine.ScalableBufferManager::get_heightScaleFactor()
extern void ScalableBufferManager_get_heightScaleFactor_m7E3D9F0A90F159C41231FC60DC47CC696FC93C96 (void);
// 0x00000160 System.Void UnityEngine.ScalableBufferManager::ResizeBuffers(System.Single,System.Single)
extern void ScalableBufferManager_ResizeBuffers_m11AEC8322CFB1490B64F242438DE125D43B43FDF (void);
// 0x00000161 System.String UnityEngine.Resolution::ToString()
extern void Resolution_ToString_m42289CE0FC4ED41A9DC62B398F46F7954BC52F04_AdjustorThunk (void);
// 0x00000162 System.Int32 UnityEngine.QualitySettings::get_antiAliasing()
extern void QualitySettings_get_antiAliasing_m28EE8A60C753C1D160BB393D92D98CC0E1776B16 (void);
// 0x00000163 System.Void UnityEngine.QualitySettings::set_antiAliasing(System.Int32)
extern void QualitySettings_set_antiAliasing_m0D256DE219D099724FADED02DA8ED7563412F3A5 (void);
// 0x00000164 UnityEngine.ColorSpace UnityEngine.QualitySettings::get_activeColorSpace()
extern void QualitySettings_get_activeColorSpace_m13DBB3B679AA5D5CEA05C2B4517A1FDE1B2CF9B0 (void);
// 0x00000165 System.Void UnityEngine.ImageEffectAllowedInSceneView::.ctor()
extern void ImageEffectAllowedInSceneView__ctor_m7A0019F3F3121A17776CF2E017375BD003E5816C (void);
// 0x00000166 System.IntPtr UnityEngine.MaterialPropertyBlock::CreateImpl()
extern void MaterialPropertyBlock_CreateImpl_m24B31B00E85647888CE23025A887F670066C167A (void);
// 0x00000167 System.Void UnityEngine.MaterialPropertyBlock::DestroyImpl(System.IntPtr)
extern void MaterialPropertyBlock_DestroyImpl_m8BE5B07A016787E1B841496630E77F31243EF109 (void);
// 0x00000168 System.Void UnityEngine.MaterialPropertyBlock::Clear(System.Boolean)
extern void MaterialPropertyBlock_Clear_mEE49CDB81EC589B9797128CF99068C45AEF0532D (void);
// 0x00000169 System.Void UnityEngine.MaterialPropertyBlock::Clear()
extern void MaterialPropertyBlock_Clear_m6082C33086704A4A407BBEFD6E5C465E55BEE315 (void);
// 0x0000016A System.Void UnityEngine.MaterialPropertyBlock::.ctor()
extern void MaterialPropertyBlock__ctor_m9055A333A5DA8CC70CC3D837BD59B54C313D39F3 (void);
// 0x0000016B System.Void UnityEngine.MaterialPropertyBlock::Finalize()
extern void MaterialPropertyBlock_Finalize_m26F82696BBE81EC8910C0991AD7CFD9B4B26DA3D (void);
// 0x0000016C System.Void UnityEngine.MaterialPropertyBlock::Dispose()
extern void MaterialPropertyBlock_Dispose_m3DED1CD5B678C080B844E4B8CB9F32FDC50041ED (void);
// 0x0000016D UnityEngine.Bounds UnityEngine.Renderer::get_bounds()
extern void Renderer_get_bounds_mB29E41E26DD95939C09F3EC67F5B2793A438BDB5 (void);
// 0x0000016E System.Int32 UnityEngine.Renderer::get_sortingLayerID()
extern void Renderer_get_sortingLayerID_m2E204E68869EDA3176C334AE1C62219F380A5D85 (void);
// 0x0000016F System.Int32 UnityEngine.Renderer::get_sortingOrder()
extern void Renderer_get_sortingOrder_m33DD50ED293AA672FDAD862B4A4865666B5FEBAF (void);
// 0x00000170 System.Void UnityEngine.Renderer::get_bounds_Injected(UnityEngine.Bounds&)
extern void Renderer_get_bounds_Injected_mDC960C9F758AFCA774D4359860F9D188E00EA027 (void);
// 0x00000171 UnityEngine.Color UnityEngine.RenderSettings::get_subtractiveShadowColor()
extern void RenderSettings_get_subtractiveShadowColor_mB8C271901D1295E64E36C1627D6450CD2DBA14C5 (void);
// 0x00000172 UnityEngine.Material UnityEngine.RenderSettings::get_skybox()
extern void RenderSettings_get_skybox_mB18548A547E6D62BBD82B0049BC9BA82E784EDF6 (void);
// 0x00000173 UnityEngine.Light UnityEngine.RenderSettings::get_sun()
extern void RenderSettings_get_sun_m6CF6A8CC535CB1EC64D85EF8BB7A31FDD6B0A349 (void);
// 0x00000174 UnityEngine.Rendering.SphericalHarmonicsL2 UnityEngine.RenderSettings::get_ambientProbe()
extern void RenderSettings_get_ambientProbe_mA0894D3DD7B43D3F52A6078E68EA5E57831C512E (void);
// 0x00000175 System.Single UnityEngine.RenderSettings::get_reflectionIntensity()
extern void RenderSettings_get_reflectionIntensity_m8340055281B6CEFF02994D4A8572302BCD59C214 (void);
// 0x00000176 System.Void UnityEngine.RenderSettings::get_subtractiveShadowColor_Injected(UnityEngine.Color&)
extern void RenderSettings_get_subtractiveShadowColor_Injected_m7351BE1097E219178C3173F571F7951BE87959F7 (void);
// 0x00000177 System.Void UnityEngine.RenderSettings::get_ambientProbe_Injected(UnityEngine.Rendering.SphericalHarmonicsL2&)
extern void RenderSettings_get_ambientProbe_Injected_mDB78986D41A558628706617FA52A6E44FDBF5972 (void);
// 0x00000178 UnityEngine.Shader UnityEngine.Shader::Find(System.String)
extern void Shader_Find_m755654AA68D1C663A3E20A10E00CDC10F96C962B (void);
// 0x00000179 System.Boolean UnityEngine.Shader::get_isSupported()
extern void Shader_get_isSupported_m3660681289CDFE742D399C3030A6CF5C4D8B030D (void);
// 0x0000017A System.Void UnityEngine.Shader::set_globalRenderPipeline(System.String)
extern void Shader_set_globalRenderPipeline_mDD57BC9253ECF13404F987D52A55A288817F3B21 (void);
// 0x0000017B System.Void UnityEngine.Shader::EnableKeyword(System.String)
extern void Shader_EnableKeyword_m600614EB1D434CA8ECFC8DAA5BC6E2ED4E55CD9F (void);
// 0x0000017C System.Void UnityEngine.Shader::DisableKeyword(System.String)
extern void Shader_DisableKeyword_m2D15FB4C26535D9AF45445B4149EADD4BF68C701 (void);
// 0x0000017D System.Int32 UnityEngine.Shader::TagToID(System.String)
extern void Shader_TagToID_m0597E33DAA0FD822B2E10881E7740E42222A8392 (void);
// 0x0000017E System.Int32 UnityEngine.Shader::PropertyToID(System.String)
extern void Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45 (void);
// 0x0000017F System.Void UnityEngine.Shader::SetGlobalVectorImpl(System.Int32,UnityEngine.Vector4)
extern void Shader_SetGlobalVectorImpl_m2741D71F920CDE4F2416EFA61A3B44CA258348B7 (void);
// 0x00000180 System.Void UnityEngine.Shader::SetGlobalMatrixImpl(System.Int32,UnityEngine.Matrix4x4)
extern void Shader_SetGlobalMatrixImpl_mA5166FA119796B15645170AF95169C532C75B967 (void);
// 0x00000181 System.Void UnityEngine.Shader::SetGlobalVector(System.Int32,UnityEngine.Vector4)
extern void Shader_SetGlobalVector_m95C42CE1CC56A5BD792C48C60EDD1DF220046566 (void);
// 0x00000182 System.Void UnityEngine.Shader::SetGlobalMatrix(System.Int32,UnityEngine.Matrix4x4)
extern void Shader_SetGlobalMatrix_mE9F00E107B245DEFB3210F00228F72F2BF2B8112 (void);
// 0x00000183 System.Void UnityEngine.Shader::.ctor()
extern void Shader__ctor_m6D011DE6D578D5F19FBF7EAED326C7209C419E21 (void);
// 0x00000184 System.Void UnityEngine.Shader::SetGlobalVectorImpl_Injected(System.Int32,UnityEngine.Vector4&)
extern void Shader_SetGlobalVectorImpl_Injected_m163EB9DAE823DD5F7AD16969CA24DA6C2F130D1A (void);
// 0x00000185 System.Void UnityEngine.Shader::SetGlobalMatrixImpl_Injected(System.Int32,UnityEngine.Matrix4x4&)
extern void Shader_SetGlobalMatrixImpl_Injected_m52914EC8C70103DF40621F04ACD8975DCEBE3E67 (void);
// 0x00000186 System.Void UnityEngine.Material::CreateWithShader(UnityEngine.Material,UnityEngine.Shader)
extern void Material_CreateWithShader_m41F159D25DC785C3BB43E6908057BB2BD1D2CB7F (void);
// 0x00000187 System.Void UnityEngine.Material::CreateWithMaterial(UnityEngine.Material,UnityEngine.Material)
extern void Material_CreateWithMaterial_mD3140BCB57EBB406D063C7A7B0B9D1A4C74DA3F2 (void);
// 0x00000188 System.Void UnityEngine.Material::CreateWithString(UnityEngine.Material)
extern void Material_CreateWithString_mCF4047522DD7D38087CF9AF121766E0D69B9BB55 (void);
// 0x00000189 System.Void UnityEngine.Material::.ctor(UnityEngine.Shader)
extern void Material__ctor_m81E76B5C1316004F25D4FE9CEC0E78A7428DABA8 (void);
// 0x0000018A System.Void UnityEngine.Material::.ctor(UnityEngine.Material)
extern void Material__ctor_m0171C6D4D3FD04D58C70808F255DBA67D0ED2BDE (void);
// 0x0000018B System.Void UnityEngine.Material::.ctor(System.String)
extern void Material__ctor_m02F4232D67F46B1EE84441089306E867B1788924 (void);
// 0x0000018C UnityEngine.Texture UnityEngine.Material::get_mainTexture()
extern void Material_get_mainTexture_mE85CF647728AD145D7E03A172EFD5930773E514E (void);
// 0x0000018D System.Int32 UnityEngine.Material::GetFirstPropertyNameIdByAttribute(UnityEngine.Rendering.ShaderPropertyFlags)
extern void Material_GetFirstPropertyNameIdByAttribute_m34991F73A65FE72151842050D18EB3EC8969A8C2 (void);
// 0x0000018E System.Boolean UnityEngine.Material::HasProperty(System.Int32)
extern void Material_HasProperty_m901DE6C516A0D2C986B849C7B44F679AE21B8927 (void);
// 0x0000018F System.Boolean UnityEngine.Material::HasProperty(System.String)
extern void Material_HasProperty_m8611FACA6F9D9B2B5C3E92B6D93D2D514B443512 (void);
// 0x00000190 System.Void UnityEngine.Material::EnableKeyword(System.String)
extern void Material_EnableKeyword_m7466758182CBBC40134C9048CDF682DF46F32FA9 (void);
// 0x00000191 System.Void UnityEngine.Material::DisableKeyword(System.String)
extern void Material_DisableKeyword_m2ACBFC5D28ED46FF2CF5532F00D702FF62C02ED3 (void);
// 0x00000192 System.Void UnityEngine.Material::SetShaderKeywords(System.String[])
extern void Material_SetShaderKeywords_m32714E17C5D17AAE15927F89624416E14B044A82 (void);
// 0x00000193 System.Void UnityEngine.Material::set_shaderKeywords(System.String[])
extern void Material_set_shaderKeywords_m336EBA03D542BE657FEBDD62C7546568CD3081C9 (void);
// 0x00000194 System.Void UnityEngine.Material::SetFloatImpl(System.Int32,System.Single)
extern void Material_SetFloatImpl_mFD6022220F625E704EC4F27691F496166E590094 (void);
// 0x00000195 System.Void UnityEngine.Material::SetColorImpl(System.Int32,UnityEngine.Color)
extern void Material_SetColorImpl_m0779CF8FCCFC298AAF42A9E9FF6503C9FDC43CFE (void);
// 0x00000196 System.Void UnityEngine.Material::SetMatrixImpl(System.Int32,UnityEngine.Matrix4x4)
extern void Material_SetMatrixImpl_mAC50A1E655FF577F6AEB3C67F14DAE7D1AA60C4B (void);
// 0x00000197 System.Void UnityEngine.Material::SetTextureImpl(System.Int32,UnityEngine.Texture)
extern void Material_SetTextureImpl_mBCF204C1FAD811B00DBAE98847D6D533EE05B135 (void);
// 0x00000198 UnityEngine.Texture UnityEngine.Material::GetTextureImpl(System.Int32)
extern void Material_GetTextureImpl_m19D8CE6C5701AC4B69A6D5354E08240DF6C036D2 (void);
// 0x00000199 System.Void UnityEngine.Material::SetFloat(System.String,System.Single)
extern void Material_SetFloat_m4B7D3FAA00D20BCB3C487E72B7E4B2691D5ECAD2 (void);
// 0x0000019A System.Void UnityEngine.Material::SetFloat(System.Int32,System.Single)
extern void Material_SetFloat_mC2FDDF0798373DEE6BBA9B9FFFE03EC3CFB9BF47 (void);
// 0x0000019B System.Void UnityEngine.Material::SetInt(System.String,System.Int32)
extern void Material_SetInt_m1FCBDBB985E6A299AE11C3D8AF29BB4D7C7DF278 (void);
// 0x0000019C System.Void UnityEngine.Material::SetInt(System.Int32,System.Int32)
extern void Material_SetInt_m8D3776E4EF0DFA2A278B456F40741E07D83508CD (void);
// 0x0000019D System.Void UnityEngine.Material::SetVector(System.Int32,UnityEngine.Vector4)
extern void Material_SetVector_m95B7CB07B91F004B4DD9DB5DFA5146472737B8EA (void);
// 0x0000019E System.Void UnityEngine.Material::SetMatrix(System.String,UnityEngine.Matrix4x4)
extern void Material_SetMatrix_mE3D3FA75DA02FED1B97E2BECA258F45399715764 (void);
// 0x0000019F System.Void UnityEngine.Material::SetTexture(System.Int32,UnityEngine.Texture)
extern void Material_SetTexture_m4FFF0B403A64253B83534701104F017840142ACA (void);
// 0x000001A0 UnityEngine.Texture UnityEngine.Material::GetTexture(System.String)
extern void Material_GetTexture_mCD6B822EA19773B8D39368FF1A285E7B69043896 (void);
// 0x000001A1 UnityEngine.Texture UnityEngine.Material::GetTexture(System.Int32)
extern void Material_GetTexture_mDB1B89D76D44AD07BD214224C59A6FE0B62F6477 (void);
// 0x000001A2 System.Void UnityEngine.Material::SetColorImpl_Injected(System.Int32,UnityEngine.Color&)
extern void Material_SetColorImpl_Injected_mEE762DBD0B37ACA313061179B3CB767B59E4B0FB (void);
// 0x000001A3 System.Void UnityEngine.Material::SetMatrixImpl_Injected(System.Int32,UnityEngine.Matrix4x4&)
extern void Material_SetMatrixImpl_Injected_mD2486E408D7547B08CC36A2DE70520F97A68529C (void);
// 0x000001A4 UnityEngine.LightType UnityEngine.Light::get_type()
extern void Light_get_type_m24F8A5EFB5D0B0B5F4820623132D1EAA327D06E3 (void);
// 0x000001A5 System.Single UnityEngine.Light::get_spotAngle()
extern void Light_get_spotAngle_m1EAB341E449675D41E86A63F047BF3ABE2B99C3B (void);
// 0x000001A6 System.Single UnityEngine.Light::get_innerSpotAngle()
extern void Light_get_innerSpotAngle_m663952080C39817A16E86C1E8FD9F4A4538B6B7C (void);
// 0x000001A7 UnityEngine.Color UnityEngine.Light::get_color()
extern void Light_get_color_m7A83B30FE716A1A931D450A6035A0069A2DD7698 (void);
// 0x000001A8 System.Single UnityEngine.Light::get_intensity()
extern void Light_get_intensity_m4E9152844D85D03FEDA5AE4599AFAFC3C66EFF23 (void);
// 0x000001A9 System.Single UnityEngine.Light::get_bounceIntensity()
extern void Light_get_bounceIntensity_m9185F30A7DED7FB480B1026B2CC6DBA357FAE9A7 (void);
// 0x000001AA System.Single UnityEngine.Light::get_shadowBias()
extern void Light_get_shadowBias_mFB01780F645A252821DA6F126E2F72384E18F140 (void);
// 0x000001AB System.Single UnityEngine.Light::get_shadowNormalBias()
extern void Light_get_shadowNormalBias_m021AD7A43D53CE417DC4EB7E647D84CBCB6E17EB (void);
// 0x000001AC System.Single UnityEngine.Light::get_shadowNearPlane()
extern void Light_get_shadowNearPlane_m4AA787C5BCB1A12A7E512D5FB2CFEA81C78D6EE0 (void);
// 0x000001AD System.Single UnityEngine.Light::get_range()
extern void Light_get_range_m3AA5F21DB9441E888A0E89C465F928445150061A (void);
// 0x000001AE UnityEngine.LightBakingOutput UnityEngine.Light::get_bakingOutput()
extern void Light_get_bakingOutput_mE447036D9B09ADED8D4244DF0155092D5BB32917 (void);
// 0x000001AF UnityEngine.LightShadows UnityEngine.Light::get_shadows()
extern void Light_get_shadows_m8FBBEDB8C442B0426E5D3E457330AA81D764C8F2 (void);
// 0x000001B0 System.Single UnityEngine.Light::get_shadowStrength()
extern void Light_get_shadowStrength_mB46E58530AF939421D198670434F15D331BFB672 (void);
// 0x000001B1 System.Void UnityEngine.Light::.ctor()
extern void Light__ctor_m23741EFAFF3A57B788747187A39CDA35A57A913E (void);
// 0x000001B2 System.Void UnityEngine.Light::get_color_Injected(UnityEngine.Color&)
extern void Light_get_color_Injected_m266FA6B59B6A43AE5C2717FE58D91E93626D48DE (void);
// 0x000001B3 System.Void UnityEngine.Light::get_bakingOutput_Injected(UnityEngine.LightBakingOutput&)
extern void Light_get_bakingOutput_Injected_m376A3C0E44091FC917D7A44B9905AAC8D2789C15 (void);
// 0x000001B4 System.Void UnityEngine.MeshFilter::DontStripMeshFilter()
extern void MeshFilter_DontStripMeshFilter_m7FBA33F8214DB646F74E00F7CEFFDF2D0018004C (void);
// 0x000001B5 System.Void UnityEngine.MeshRenderer::DontStripMeshRenderer()
extern void MeshRenderer_DontStripMeshRenderer_mC5359CA39BA768EBDB3C90D4FAE999F4EB1B6B24 (void);
// 0x000001B6 System.Void UnityEngine.Mesh::Internal_Create(UnityEngine.Mesh)
extern void Mesh_Internal_Create_mF1F8E9F726EAC9A087D49C81E2F1609E8266649E (void);
// 0x000001B7 System.Void UnityEngine.Mesh::.ctor()
extern void Mesh__ctor_m3AEBC82AB71D4F9498F6E254174BEBA8372834B4 (void);
// 0x000001B8 System.Int32[] UnityEngine.Mesh::GetIndicesImpl(System.Int32,System.Boolean)
extern void Mesh_GetIndicesImpl_m2118C6CA196093FD19BB05E5258C0DCE06FEAD30 (void);
// 0x000001B9 System.Void UnityEngine.Mesh::SetIndicesImpl(System.Int32,UnityEngine.MeshTopology,UnityEngine.Rendering.IndexFormat,System.Array,System.Int32,System.Int32,System.Boolean,System.Int32)
extern void Mesh_SetIndicesImpl_m05B1C648F5E02990B89D1FFF002F5D5672779D8B (void);
// 0x000001BA System.Void UnityEngine.Mesh::PrintErrorCantAccessChannel(UnityEngine.Rendering.VertexAttribute)
extern void Mesh_PrintErrorCantAccessChannel_m2E8A25959739B006557A94F7E460E8BE0B3ABB19 (void);
// 0x000001BB System.Boolean UnityEngine.Mesh::HasVertexAttribute(UnityEngine.Rendering.VertexAttribute)
extern void Mesh_HasVertexAttribute_m87C57B859ECB5224EEB77ED9BD3B6FF30F5A9B1C (void);
// 0x000001BC System.Void UnityEngine.Mesh::SetArrayForChannelImpl(UnityEngine.Rendering.VertexAttribute,UnityEngine.Rendering.VertexAttributeFormat,System.Int32,System.Array,System.Int32,System.Int32,System.Int32)
extern void Mesh_SetArrayForChannelImpl_m6FDE8B55C37DC1828C0041DDA3AD1E6D2C028E6C (void);
// 0x000001BD System.Array UnityEngine.Mesh::GetAllocArrayFromChannelImpl(UnityEngine.Rendering.VertexAttribute,UnityEngine.Rendering.VertexAttributeFormat,System.Int32)
extern void Mesh_GetAllocArrayFromChannelImpl_mFDE324953466F6DBAC14CD4B48105B62181CC399 (void);
// 0x000001BE System.Boolean UnityEngine.Mesh::get_canAccess()
extern void Mesh_get_canAccess_m1E0020EA7961227FBC0D90D851A49BCF7EB1E194 (void);
// 0x000001BF System.Int32 UnityEngine.Mesh::get_subMeshCount()
extern void Mesh_get_subMeshCount_m6BE7CFB52CE84AEE45B4E5A704E865954397F52F (void);
// 0x000001C0 System.Void UnityEngine.Mesh::ClearImpl(System.Boolean)
extern void Mesh_ClearImpl_mFFD3A4748AF067B75DBD646B4A64B3D9A2F3EE14 (void);
// 0x000001C1 System.Void UnityEngine.Mesh::RecalculateBoundsImpl()
extern void Mesh_RecalculateBoundsImpl_m43DE3DEFC2DADC090DC6FD2C27F44D6DBB88CEF6 (void);
// 0x000001C2 System.Void UnityEngine.Mesh::UploadMeshDataImpl(System.Boolean)
extern void Mesh_UploadMeshDataImpl_m1D48BFFC3E32EAD6D206C1DBFD8E2D23B63425D7 (void);
// 0x000001C3 UnityEngine.Rendering.VertexAttribute UnityEngine.Mesh::GetUVChannel(System.Int32)
extern void Mesh_GetUVChannel_m15BB0A6CC8E32867621A78627CD5FF2CAEA163CC (void);
// 0x000001C4 System.Int32 UnityEngine.Mesh::DefaultDimensionForChannel(UnityEngine.Rendering.VertexAttribute)
extern void Mesh_DefaultDimensionForChannel_mF943AF434BB9F54DBB3B3DE65F7B816E617A89C9 (void);
// 0x000001C5 T[] UnityEngine.Mesh::GetAllocArrayFromChannel(UnityEngine.Rendering.VertexAttribute,UnityEngine.Rendering.VertexAttributeFormat,System.Int32)
// 0x000001C6 T[] UnityEngine.Mesh::GetAllocArrayFromChannel(UnityEngine.Rendering.VertexAttribute)
// 0x000001C7 System.Void UnityEngine.Mesh::SetSizedArrayForChannel(UnityEngine.Rendering.VertexAttribute,UnityEngine.Rendering.VertexAttributeFormat,System.Int32,System.Array,System.Int32,System.Int32,System.Int32)
extern void Mesh_SetSizedArrayForChannel_mBBB7F5AE4D5A5A6D5794742745385B02B13E082D (void);
// 0x000001C8 System.Void UnityEngine.Mesh::SetArrayForChannel(UnityEngine.Rendering.VertexAttribute,T[])
// 0x000001C9 System.Void UnityEngine.Mesh::SetListForChannel(UnityEngine.Rendering.VertexAttribute,UnityEngine.Rendering.VertexAttributeFormat,System.Int32,System.Collections.Generic.List`1<T>,System.Int32,System.Int32)
// 0x000001CA System.Void UnityEngine.Mesh::SetListForChannel(UnityEngine.Rendering.VertexAttribute,System.Collections.Generic.List`1<T>,System.Int32,System.Int32)
// 0x000001CB UnityEngine.Vector3[] UnityEngine.Mesh::get_vertices()
extern void Mesh_get_vertices_m7D07DC0F071C142B87F675B148FC0F7A243238B9 (void);
// 0x000001CC System.Void UnityEngine.Mesh::set_vertices(UnityEngine.Vector3[])
extern void Mesh_set_vertices_mC1406AE08BC3495F3B0E29B53BACC9FD7BA685C6 (void);
// 0x000001CD UnityEngine.Vector3[] UnityEngine.Mesh::get_normals()
extern void Mesh_get_normals_m3CE4668899836CBD17C3F85EB24261CBCEB3EABB (void);
// 0x000001CE System.Void UnityEngine.Mesh::set_normals(UnityEngine.Vector3[])
extern void Mesh_set_normals_m4054D319A67DAAA25A794D67AD37278A84406589 (void);
// 0x000001CF UnityEngine.Vector4[] UnityEngine.Mesh::get_tangents()
extern void Mesh_get_tangents_mFF92BD7D6EBA8C7EB8340E1529B1CB98006F44DD (void);
// 0x000001D0 System.Void UnityEngine.Mesh::set_tangents(UnityEngine.Vector4[])
extern void Mesh_set_tangents_mE66D8020B76E43A5CA3C4E60DB61CD962D7D3C57 (void);
// 0x000001D1 UnityEngine.Vector2[] UnityEngine.Mesh::get_uv()
extern void Mesh_get_uv_m0EBA5CA4644C9D5F1B2125AF3FE3873EFC8A4616 (void);
// 0x000001D2 System.Void UnityEngine.Mesh::set_uv(UnityEngine.Vector2[])
extern void Mesh_set_uv_m56E4B52315669FBDA89DC9C550AC89EEE8A4E7C8 (void);
// 0x000001D3 UnityEngine.Vector2[] UnityEngine.Mesh::get_uv2()
extern void Mesh_get_uv2_m3E70D5DD7A5C6910A074A78296269EBF2CBAE97F (void);
// 0x000001D4 UnityEngine.Vector2[] UnityEngine.Mesh::get_uv3()
extern void Mesh_get_uv3_mC56484D8B69A65DA948C7F23B06ED490BCFBE8B0 (void);
// 0x000001D5 UnityEngine.Vector2[] UnityEngine.Mesh::get_uv4()
extern void Mesh_get_uv4_m1C5734938A443D8004339E8D8DDDC33B3E0935F6 (void);
// 0x000001D6 System.Void UnityEngine.Mesh::set_colors(UnityEngine.Color[])
extern void Mesh_set_colors_m704D0EF58B7AED0D64AE4763EA375638FB08E026 (void);
// 0x000001D7 UnityEngine.Color32[] UnityEngine.Mesh::get_colors32()
extern void Mesh_get_colors32_m24C6C6BC1A40B7F09FF390F304A96728A4C99246 (void);
// 0x000001D8 System.Void UnityEngine.Mesh::SetVertices(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void Mesh_SetVertices_m5F487FC255C9CAF4005B75CFE67A88C8C0E7BB06 (void);
// 0x000001D9 System.Void UnityEngine.Mesh::SetVertices(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Int32,System.Int32)
extern void Mesh_SetVertices_mCFFD77B857B3041D407D4EB6BEA3F4FC8F258655 (void);
// 0x000001DA System.Void UnityEngine.Mesh::SetNormals(System.Collections.Generic.List`1<UnityEngine.Vector3>)
extern void Mesh_SetNormals_m76D71A949B9288FA8ED17DDADC530365307B9797 (void);
// 0x000001DB System.Void UnityEngine.Mesh::SetNormals(System.Collections.Generic.List`1<UnityEngine.Vector3>,System.Int32,System.Int32)
extern void Mesh_SetNormals_m2D6A6379F1C1E974C155DFD0E59812316B17F6B2 (void);
// 0x000001DC System.Void UnityEngine.Mesh::SetTangents(System.Collections.Generic.List`1<UnityEngine.Vector4>)
extern void Mesh_SetTangents_m6EEAB861C9286B1DA4935B87A883045ADD3955E5 (void);
// 0x000001DD System.Void UnityEngine.Mesh::SetTangents(System.Collections.Generic.List`1<UnityEngine.Vector4>,System.Int32,System.Int32)
extern void Mesh_SetTangents_m2C28E9ED06F035D4F726DA8F8782F75B81AF1BF9 (void);
// 0x000001DE System.Void UnityEngine.Mesh::SetColors(System.Collections.Generic.List`1<UnityEngine.Color32>)
extern void Mesh_SetColors_m237E41213E82D4BB882ED96FD81A17D9366590CF (void);
// 0x000001DF System.Void UnityEngine.Mesh::SetColors(System.Collections.Generic.List`1<UnityEngine.Color32>,System.Int32,System.Int32)
extern void Mesh_SetColors_m7F5D50EA329435A03C41DCF4A6CFAB57504FAAAF (void);
// 0x000001E0 System.Void UnityEngine.Mesh::SetUvsImpl(System.Int32,System.Int32,System.Collections.Generic.List`1<T>,System.Int32,System.Int32)
// 0x000001E1 System.Void UnityEngine.Mesh::SetUVs(System.Int32,System.Collections.Generic.List`1<UnityEngine.Vector2>)
extern void Mesh_SetUVs_m0210150B0387289B823488D421BDF9CBF9769116 (void);
// 0x000001E2 System.Void UnityEngine.Mesh::SetUVs(System.Int32,System.Collections.Generic.List`1<UnityEngine.Vector2>,System.Int32,System.Int32)
extern void Mesh_SetUVs_m5E152C09C814455B8A8FB6672ACD15C0D6804EC5 (void);
// 0x000001E3 System.Void UnityEngine.Mesh::PrintErrorCantAccessIndices()
extern void Mesh_PrintErrorCantAccessIndices_mA45D3609288655A328AEB0F2F436403B1ECE5077 (void);
// 0x000001E4 System.Boolean UnityEngine.Mesh::CheckCanAccessSubmesh(System.Int32,System.Boolean)
extern void Mesh_CheckCanAccessSubmesh_mF86EBD1C9EC3FE557880FA138510F7761585D227 (void);
// 0x000001E5 System.Boolean UnityEngine.Mesh::CheckCanAccessSubmeshTriangles(System.Int32)
extern void Mesh_CheckCanAccessSubmeshTriangles_m214B5F30F7461C620D03F10F6CF1CAF53DBEE509 (void);
// 0x000001E6 System.Boolean UnityEngine.Mesh::CheckCanAccessSubmeshIndices(System.Int32)
extern void Mesh_CheckCanAccessSubmeshIndices_m81DF83B1676084AF0B70A36BC7621ADB08430722 (void);
// 0x000001E7 System.Void UnityEngine.Mesh::set_triangles(System.Int32[])
extern void Mesh_set_triangles_m143A1C262BADCFACE43587EBA2CDC6EBEB5DFAED (void);
// 0x000001E8 System.Int32[] UnityEngine.Mesh::GetIndices(System.Int32)
extern void Mesh_GetIndices_m2FD8417547E7595F590CE55D381E0D13A8D72AA5 (void);
// 0x000001E9 System.Int32[] UnityEngine.Mesh::GetIndices(System.Int32,System.Boolean)
extern void Mesh_GetIndices_m4260DCF1026449C4E8C4C40229D12AF8CAB26EAF (void);
// 0x000001EA System.Void UnityEngine.Mesh::CheckIndicesArrayRange(System.Int32,System.Int32,System.Int32)
extern void Mesh_CheckIndicesArrayRange_m6DEDA2715437F79DAC8BD7F818B5B2DBAD9BFEBE (void);
// 0x000001EB System.Void UnityEngine.Mesh::SetTrianglesImpl(System.Int32,UnityEngine.Rendering.IndexFormat,System.Array,System.Int32,System.Int32,System.Int32,System.Boolean,System.Int32)
extern void Mesh_SetTrianglesImpl_m0AD2B3D12113B5E82AC9E29D2C6308E7410E2B98 (void);
// 0x000001EC System.Void UnityEngine.Mesh::SetTriangles(System.Collections.Generic.List`1<System.Int32>,System.Int32)
extern void Mesh_SetTriangles_m6A43D705DE751C622CCF88EC31C4EF1B53578BE5 (void);
// 0x000001ED System.Void UnityEngine.Mesh::SetTriangles(System.Collections.Generic.List`1<System.Int32>,System.Int32,System.Boolean,System.Int32)
extern void Mesh_SetTriangles_m39FB983B90F36D724CC1C21BA7821C9697F86116 (void);
// 0x000001EE System.Void UnityEngine.Mesh::SetTriangles(System.Collections.Generic.List`1<System.Int32>,System.Int32,System.Int32,System.Int32,System.Boolean,System.Int32)
extern void Mesh_SetTriangles_mBD39F430A044A27A171AD8FD80F2B9DDFDB4A469 (void);
// 0x000001EF System.Void UnityEngine.Mesh::SetIndices(System.Int32[],UnityEngine.MeshTopology,System.Int32)
extern void Mesh_SetIndices_m18C0006CF36C43FF16B1917099E2970C2D4145BD (void);
// 0x000001F0 System.Void UnityEngine.Mesh::SetIndices(System.Int32[],UnityEngine.MeshTopology,System.Int32,System.Boolean)
extern void Mesh_SetIndices_m84F3CDB60B5C8FA4374B83E3F77C9DAA4C946BCF (void);
// 0x000001F1 System.Void UnityEngine.Mesh::SetIndices(System.Int32[],UnityEngine.MeshTopology,System.Int32,System.Boolean,System.Int32)
extern void Mesh_SetIndices_mFE6F2769EF170F0CD84C739E96976A15052B7024 (void);
// 0x000001F2 System.Void UnityEngine.Mesh::SetIndices(System.Int32[],System.Int32,System.Int32,UnityEngine.MeshTopology,System.Int32,System.Boolean,System.Int32)
extern void Mesh_SetIndices_m5E72EA4BED8BA7B0732E80227199026B1CD9B6C5 (void);
// 0x000001F3 System.Void UnityEngine.Mesh::Clear()
extern void Mesh_Clear_mB750E1DCAB658124AAD81A02B93DED7601047B60 (void);
// 0x000001F4 System.Void UnityEngine.Mesh::RecalculateBounds()
extern void Mesh_RecalculateBounds_m1BF701FE2CEA4E8E1183FF878B812808ED1EBA49 (void);
// 0x000001F5 System.Void UnityEngine.Mesh::UploadMeshData(System.Boolean)
extern void Mesh_UploadMeshData_m809A98624475785C493269B72EC6C41B556759A1 (void);
// 0x000001F6 System.Void UnityEngine.Texture::.ctor()
extern void Texture__ctor_m19850F4654F76731DD82B99217AD5A2EB6974C6C (void);
// 0x000001F7 UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Texture::get_graphicsFormat()
extern void Texture_get_graphicsFormat_m4169EBAA431C6A3FFF2CA66C83B4659E2CAA4194 (void);
// 0x000001F8 System.Int32 UnityEngine.Texture::GetDataWidth()
extern void Texture_GetDataWidth_m862817D573E6B1BAE31E9412DB1F1C9B3A15B21D (void);
// 0x000001F9 System.Int32 UnityEngine.Texture::GetDataHeight()
extern void Texture_GetDataHeight_m3E5739F25B967D6AF703541F236F0B1F3F8F939E (void);
// 0x000001FA UnityEngine.Rendering.TextureDimension UnityEngine.Texture::GetDimension()
extern void Texture_GetDimension_m823F205A9A9A8416E745A322D0C86851BF4C85C3 (void);
// 0x000001FB System.Int32 UnityEngine.Texture::get_width()
extern void Texture_get_width_mEF9D208720B8FB3E7A29F3A5A5C381B56E657ED2 (void);
// 0x000001FC System.Void UnityEngine.Texture::set_width(System.Int32)
extern void Texture_set_width_m9E42C8B8ED703644B85F54D8DCFB51BF954F56DA (void);
// 0x000001FD System.Int32 UnityEngine.Texture::get_height()
extern void Texture_get_height_m3A004CD1FA238B3D0B32FE7030634B9038EC4AA0 (void);
// 0x000001FE System.Void UnityEngine.Texture::set_height(System.Int32)
extern void Texture_set_height_m601E103C6E803353701370B161F992A5B0C89AB6 (void);
// 0x000001FF UnityEngine.Rendering.TextureDimension UnityEngine.Texture::get_dimension()
extern void Texture_get_dimension_m9BFA811A908673794B77310CADF1FF86B388A5FF (void);
// 0x00000200 System.Void UnityEngine.Texture::set_dimension(UnityEngine.Rendering.TextureDimension)
extern void Texture_set_dimension_mC2221B460AB7728D06B94DCE6B83FFA93ACF68E9 (void);
// 0x00000201 System.Boolean UnityEngine.Texture::get_isReadable()
extern void Texture_get_isReadable_mFB3D8E8799AC5EFD9E1AB68386DA16F3607631BD (void);
// 0x00000202 UnityEngine.TextureWrapMode UnityEngine.Texture::get_wrapMode()
extern void Texture_get_wrapMode_mC21054C7BC6E958937B7459DAF1D17654284B07A (void);
// 0x00000203 System.Void UnityEngine.Texture::set_wrapMode(UnityEngine.TextureWrapMode)
extern void Texture_set_wrapMode_m85E9A995D5947B59FE13A7311E891F3DEDEBBCEC (void);
// 0x00000204 System.Void UnityEngine.Texture::set_filterMode(UnityEngine.FilterMode)
extern void Texture_set_filterMode_mB9AC927A527EFE95771B9B438E2CFB9EDA84AF01 (void);
// 0x00000205 System.Void UnityEngine.Texture::set_anisoLevel(System.Int32)
extern void Texture_set_anisoLevel_mD2F6FE80CC33E408368734983EBA1463BB2D5712 (void);
// 0x00000206 System.Void UnityEngine.Texture::set_mipMapBias(System.Single)
extern void Texture_set_mipMapBias_m38BD81110AE2AA28186242FF551691BC83AB8354 (void);
// 0x00000207 UnityEngine.Vector2 UnityEngine.Texture::get_texelSize()
extern void Texture_get_texelSize_m89BA9E4CF5276F4FDBAAD6B497809F3E6DB1E30C (void);
// 0x00000208 System.Boolean UnityEngine.Texture::ValidateFormat(UnityEngine.TextureFormat)
extern void Texture_ValidateFormat_m23ED49E24864EE9D1C4EF775002A91EE049561B1 (void);
// 0x00000209 System.Boolean UnityEngine.Texture::ValidateFormat(UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.FormatUsage)
extern void Texture_ValidateFormat_mA62E75B693BFABECB7CB732C165139B8492DE0ED (void);
// 0x0000020A UnityEngine.UnityException UnityEngine.Texture::CreateNonReadableException(UnityEngine.Texture)
extern void Texture_CreateNonReadableException_m66E69BE853119A5A9FE2C27EA788B62BF7CFE34D (void);
// 0x0000020B System.Void UnityEngine.Texture::.cctor()
extern void Texture__cctor_m63D3A3E79E62355737DCF71786623D516FAA07E1 (void);
// 0x0000020C System.Void UnityEngine.Texture::get_texelSize_Injected(UnityEngine.Vector2&)
extern void Texture_get_texelSize_Injected_m812BEA61C30039FF16BE6A2E174C81DCB40000DE (void);
// 0x0000020D UnityEngine.TextureFormat UnityEngine.Texture2D::get_format()
extern void Texture2D_get_format_mF0EE5CEB9F84280D4E722B71546BBBA577101E9F (void);
// 0x0000020E UnityEngine.Texture2D UnityEngine.Texture2D::get_whiteTexture()
extern void Texture2D_get_whiteTexture_mF447523DE8957109355641ECE0DD3D3C8D2F6C41 (void);
// 0x0000020F UnityEngine.Texture2D UnityEngine.Texture2D::get_blackTexture()
extern void Texture2D_get_blackTexture_mCF4F978DF9B6066794E7130E0C14618216ED0956 (void);
// 0x00000210 System.Boolean UnityEngine.Texture2D::Internal_CreateImpl(UnityEngine.Texture2D,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags,System.IntPtr)
extern void Texture2D_Internal_CreateImpl_mE77AB26318BC128ABD08D138FD3EF3A9954F8A5C (void);
// 0x00000211 System.Void UnityEngine.Texture2D::Internal_Create(UnityEngine.Texture2D,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags,System.IntPtr)
extern void Texture2D_Internal_Create_mC33D3C13F046ADDAF417534E99A741FCF96538B1 (void);
// 0x00000212 System.Boolean UnityEngine.Texture2D::get_isReadable()
extern void Texture2D_get_isReadable_mCF446A169E1D8BF244235F4E9B35DDC4F5E696AD (void);
// 0x00000213 System.Void UnityEngine.Texture2D::ApplyImpl(System.Boolean,System.Boolean)
extern void Texture2D_ApplyImpl_mEFE072AD63B1B7B317225DAEDDB1FF9012DB398B (void);
// 0x00000214 System.Void UnityEngine.Texture2D::SetPixelImpl(System.Int32,System.Int32,System.Int32,UnityEngine.Color)
extern void Texture2D_SetPixelImpl_m62B6A2252516D1D5E09701BA550D72ACB79E328B (void);
// 0x00000215 UnityEngine.Color UnityEngine.Texture2D::GetPixelBilinearImpl(System.Int32,System.Single,System.Single)
extern void Texture2D_GetPixelBilinearImpl_m950AB40E4151F10B6AA6C5759903BA07348114FB (void);
// 0x00000216 System.Void UnityEngine.Texture2D::SetPixelsImpl(System.Int32,System.Int32,System.Int32,System.Int32,UnityEngine.Color[],System.Int32,System.Int32)
extern void Texture2D_SetPixelsImpl_m8102FB784092E318608E2BC2BB92A82D1C0C9AD1 (void);
// 0x00000217 System.Void UnityEngine.Texture2D::.ctor(System.Int32,System.Int32,UnityEngine.TextureFormat,System.Int32,System.Boolean,System.IntPtr)
extern void Texture2D__ctor_mB33D5D6E83136BF8A42D2628405B10BE0889F439 (void);
// 0x00000218 System.Void UnityEngine.Texture2D::.ctor(System.Int32,System.Int32,UnityEngine.TextureFormat,System.Boolean,System.Boolean)
extern void Texture2D__ctor_m01B7AF7873AA43495B8216926C1768FEDDF4CE64 (void);
// 0x00000219 System.Void UnityEngine.Texture2D::.ctor(System.Int32,System.Int32,UnityEngine.TextureFormat,System.Boolean)
extern void Texture2D__ctor_m22561E039BC96019757E6B2427BE09734AE2C44A (void);
// 0x0000021A System.Void UnityEngine.Texture2D::SetPixel(System.Int32,System.Int32,UnityEngine.Color)
extern void Texture2D_SetPixel_m8BE87C152447B812D06CB894B3570269CC2DE7C3 (void);
// 0x0000021B System.Void UnityEngine.Texture2D::SetPixels(System.Int32,System.Int32,System.Int32,System.Int32,UnityEngine.Color[],System.Int32)
extern void Texture2D_SetPixels_mC768DC908606FE162BF77A8761AD3ED7BAC1612C (void);
// 0x0000021C System.Void UnityEngine.Texture2D::SetPixels(UnityEngine.Color[])
extern void Texture2D_SetPixels_mDE50229135F49F323D265340C415D680CCB2FB92 (void);
// 0x0000021D UnityEngine.Color UnityEngine.Texture2D::GetPixelBilinear(System.Single,System.Single)
extern void Texture2D_GetPixelBilinear_m3E0E9A22A0989E99A7295BC6FE6999728F290A78 (void);
// 0x0000021E System.Void UnityEngine.Texture2D::Apply(System.Boolean,System.Boolean)
extern void Texture2D_Apply_mCC17B1895AEB420CF75B1A50A62AB623C225A6C1 (void);
// 0x0000021F System.Void UnityEngine.Texture2D::Apply()
extern void Texture2D_Apply_m0F3B4A4B1B89E44E2AF60ABDEFAA18D93735B5CA (void);
// 0x00000220 System.Void UnityEngine.Texture2D::SetPixelImpl_Injected(System.Int32,System.Int32,System.Int32,UnityEngine.Color&)
extern void Texture2D_SetPixelImpl_Injected_m21934648C4DE2227463F16A67EFA3DC740682ACC (void);
// 0x00000221 System.Void UnityEngine.Texture2D::GetPixelBilinearImpl_Injected(System.Int32,System.Single,System.Single,UnityEngine.Color&)
extern void Texture2D_GetPixelBilinearImpl_Injected_m120BD9810D176C39E874FFDAF53AD3AC3B6ADF85 (void);
// 0x00000222 System.Boolean UnityEngine.Cubemap::Internal_CreateImpl(UnityEngine.Cubemap,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags,System.IntPtr)
extern void Cubemap_Internal_CreateImpl_m2E42502B311D4511987453F591F469EFD3D46C7E (void);
// 0x00000223 System.Void UnityEngine.Cubemap::Internal_Create(UnityEngine.Cubemap,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags,System.IntPtr)
extern void Cubemap_Internal_Create_m7D1672F9247A6CA2578874A69C901311B6196289 (void);
// 0x00000224 System.Void UnityEngine.Cubemap::ApplyImpl(System.Boolean,System.Boolean)
extern void Cubemap_ApplyImpl_m685B04A32C22E02263439BCAB68D1485427874F6 (void);
// 0x00000225 System.Boolean UnityEngine.Cubemap::get_isReadable()
extern void Cubemap_get_isReadable_m97956094F4DBC9C67A86AEC8CCE73AB237694121 (void);
// 0x00000226 System.Void UnityEngine.Cubemap::SetPixelImpl(System.Int32,System.Int32,System.Int32,UnityEngine.Color)
extern void Cubemap_SetPixelImpl_mE574550B3ED1AAD204EA189CDF534B3B2BC17671 (void);
// 0x00000227 System.Void UnityEngine.Cubemap::.ctor(System.Int32,UnityEngine.Experimental.Rendering.DefaultFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Cubemap__ctor_mA198007748E1B40309793BFD41C6DA8506BFC36E (void);
// 0x00000228 System.Void UnityEngine.Cubemap::.ctor(System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Cubemap__ctor_mC713C6EC5AA4BB7091AF19FC75E1A5D3A133550B (void);
// 0x00000229 System.Void UnityEngine.Cubemap::.ctor(System.Int32,UnityEngine.TextureFormat,System.Int32)
extern void Cubemap__ctor_m823CBFD84E8497FEEDE6858F1781ADECB0C6CFBF (void);
// 0x0000022A System.Void UnityEngine.Cubemap::.ctor(System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags,System.Int32)
extern void Cubemap__ctor_mDEAB11F63268FC5F1115D928499AC270F21FB249 (void);
// 0x0000022B System.Void UnityEngine.Cubemap::.ctor(System.Int32,UnityEngine.TextureFormat,System.Int32,System.IntPtr)
extern void Cubemap__ctor_mFC82AF58FF4875D6750838AF47A05D5B203523A8 (void);
// 0x0000022C System.Void UnityEngine.Cubemap::.ctor(System.Int32,UnityEngine.TextureFormat,System.Boolean,System.IntPtr)
extern void Cubemap__ctor_m619C9524BF966423D2DE66E878C824113616C371 (void);
// 0x0000022D System.Void UnityEngine.Cubemap::.ctor(System.Int32,UnityEngine.TextureFormat,System.Boolean)
extern void Cubemap__ctor_mB0430DC19209C90736915B41A670C7AC65698D71 (void);
// 0x0000022E System.Void UnityEngine.Cubemap::SetPixel(UnityEngine.CubemapFace,System.Int32,System.Int32,UnityEngine.Color)
extern void Cubemap_SetPixel_m84EC07CAB35F83FF229C83E4FCE5257EC64D131A (void);
// 0x0000022F System.Void UnityEngine.Cubemap::Apply(System.Boolean,System.Boolean)
extern void Cubemap_Apply_mEED93FB138644F26274EC7A9E91E996178E5492B (void);
// 0x00000230 System.Void UnityEngine.Cubemap::Apply()
extern void Cubemap_Apply_mDC3AC8509F8B673A1D3B4D05A1C2BBAA78848446 (void);
// 0x00000231 System.Void UnityEngine.Cubemap::SetPixelImpl_Injected(System.Int32,System.Int32,System.Int32,UnityEngine.Color&)
extern void Cubemap_SetPixelImpl_Injected_mDB88DCC7521A128F118EA17598E3FFC92143A62C (void);
// 0x00000232 System.Boolean UnityEngine.Texture3D::get_isReadable()
extern void Texture3D_get_isReadable_m2793D34A645AA2A88B903D7C0CBC05BC180A489F (void);
// 0x00000233 System.Boolean UnityEngine.Texture3D::Internal_CreateImpl(UnityEngine.Texture3D,System.Int32,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Texture3D_Internal_CreateImpl_m6B7F1E0A4F0A8DF201C84B8F5EBE88F5BC2D0ED5 (void);
// 0x00000234 System.Void UnityEngine.Texture3D::Internal_Create(UnityEngine.Texture3D,System.Int32,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Texture3D_Internal_Create_mCE8880719B54D2E8426234438DF2BA893B16CAA5 (void);
// 0x00000235 System.Void UnityEngine.Texture3D::ApplyImpl(System.Boolean,System.Boolean)
extern void Texture3D_ApplyImpl_mF64D926DEC8B3F84C5D45679455C0535723CF51A (void);
// 0x00000236 System.Void UnityEngine.Texture3D::SetPixels(UnityEngine.Color[],System.Int32)
extern void Texture3D_SetPixels_m800F0485825F86CBABB48AB5C0F5B178DDCDB4AE (void);
// 0x00000237 System.Void UnityEngine.Texture3D::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.DefaultFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Texture3D__ctor_m3819CE6527C761C3514E46566BAE8D09CEE6C6C0 (void);
// 0x00000238 System.Void UnityEngine.Texture3D::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Texture3D__ctor_m080D4201C72C73ECB718F44491858309CDCCBF40 (void);
// 0x00000239 System.Void UnityEngine.Texture3D::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags,System.Int32)
extern void Texture3D__ctor_m9FB382B0BC5C568B195C9E27E7BCA34C108F5FF7 (void);
// 0x0000023A System.Void UnityEngine.Texture3D::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.TextureFormat,System.Int32)
extern void Texture3D__ctor_m13ADB707E9EA6970AE5D6A5DDF8A5DAAD88DD2B0 (void);
// 0x0000023B System.Void UnityEngine.Texture3D::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.TextureFormat,System.Boolean)
extern void Texture3D__ctor_m7086160504490544C327FF1C7823830B44441466 (void);
// 0x0000023C System.Void UnityEngine.Texture3D::Apply(System.Boolean,System.Boolean)
extern void Texture3D_Apply_m7E14DDF5C1A548E55424048088F9FD2283A314F0 (void);
// 0x0000023D System.Void UnityEngine.Texture3D::Apply()
extern void Texture3D_Apply_m9EF036FDBCD9DC9DE056689D47FF5D4224D86074 (void);
// 0x0000023E System.Int32 UnityEngine.Texture2DArray::get_allSlices()
extern void Texture2DArray_get_allSlices_mF7A27FED8FB4B534155070AF350A8DB4DB1E50CC (void);
// 0x0000023F System.Boolean UnityEngine.Texture2DArray::get_isReadable()
extern void Texture2DArray_get_isReadable_mB2E454ED94BB334E77B42E6CD9DABC0B1D679C1A (void);
// 0x00000240 System.Boolean UnityEngine.Texture2DArray::Internal_CreateImpl(UnityEngine.Texture2DArray,System.Int32,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Texture2DArray_Internal_CreateImpl_mF6D0DD31CE06DB61D0E3C8D875F20692B33C776E (void);
// 0x00000241 System.Void UnityEngine.Texture2DArray::Internal_Create(UnityEngine.Texture2DArray,System.Int32,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Texture2DArray_Internal_Create_m53A30DE93DCDA75588C999A967F8004AB0EE113F (void);
// 0x00000242 System.Void UnityEngine.Texture2DArray::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.DefaultFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Texture2DArray__ctor_m92A39957ECC1DBE79437D3849A1FA7A98615A9F0 (void);
// 0x00000243 System.Void UnityEngine.Texture2DArray::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void Texture2DArray__ctor_mD92521FF6DA05FF47471B741DDC7E4D5B3C3F4E2 (void);
// 0x00000244 System.Void UnityEngine.Texture2DArray::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags,System.Int32)
extern void Texture2DArray__ctor_mF94531ED3A27A6583DCACE742D6D6A56C3B1CB76 (void);
// 0x00000245 System.Void UnityEngine.Texture2DArray::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.TextureFormat,System.Int32,System.Boolean)
extern void Texture2DArray__ctor_m982669D0408998D2038575A421440A8D537D67E6 (void);
// 0x00000246 System.Void UnityEngine.Texture2DArray::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.TextureFormat,System.Boolean,System.Boolean)
extern void Texture2DArray__ctor_mEDE73B65A89EACA4B487FFBA92B155ED5B09970F (void);
// 0x00000247 System.Void UnityEngine.Texture2DArray::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.TextureFormat,System.Boolean)
extern void Texture2DArray__ctor_mE0F6B7F60470C479258E1CC295456BCA103E66BF (void);
// 0x00000248 System.Boolean UnityEngine.CubemapArray::get_isReadable()
extern void CubemapArray_get_isReadable_mBE24F088422FA9FE007086C36C7D16A6D6377919 (void);
// 0x00000249 System.Boolean UnityEngine.CubemapArray::Internal_CreateImpl(UnityEngine.CubemapArray,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void CubemapArray_Internal_CreateImpl_mDA1FF7D490A441C86198448B72B62C2D38B9A046 (void);
// 0x0000024A System.Void UnityEngine.CubemapArray::Internal_Create(UnityEngine.CubemapArray,System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void CubemapArray_Internal_Create_m2503EFCE0A71CBCCCA87C93E15B9F83709274A58 (void);
// 0x0000024B System.Void UnityEngine.CubemapArray::ApplyImpl(System.Boolean,System.Boolean)
extern void CubemapArray_ApplyImpl_mBA3A00B7915C7E6E8CA85D7B39FD9D145E12E383 (void);
// 0x0000024C System.Void UnityEngine.CubemapArray::SetPixels(UnityEngine.Color[],UnityEngine.CubemapFace,System.Int32,System.Int32)
extern void CubemapArray_SetPixels_m68601785D408414D206F01EBB351F0A0361DF503 (void);
// 0x0000024D System.Void UnityEngine.CubemapArray::SetPixels(UnityEngine.Color[],UnityEngine.CubemapFace,System.Int32)
extern void CubemapArray_SetPixels_m614E9EADABB21CCA01EECA6FE0D38713D279A27F (void);
// 0x0000024E System.Void UnityEngine.CubemapArray::.ctor(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.DefaultFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void CubemapArray__ctor_m44E378D2D09F711CF0AEF479DC7D12426C449CF6 (void);
// 0x0000024F System.Void UnityEngine.CubemapArray::.ctor(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags)
extern void CubemapArray__ctor_m390539598EAAEE1AAE0B89D2241A60EE6BD1B219 (void);
// 0x00000250 System.Void UnityEngine.CubemapArray::.ctor(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.TextureCreationFlags,System.Int32)
extern void CubemapArray__ctor_m88D0AB083EEF112A636EE307337BAFAF036E0A2B (void);
// 0x00000251 System.Void UnityEngine.CubemapArray::.ctor(System.Int32,System.Int32,UnityEngine.TextureFormat,System.Int32,System.Boolean)
extern void CubemapArray__ctor_m1FC2738B93636229EC645E15D36C9A3F67FE0E54 (void);
// 0x00000252 System.Void UnityEngine.CubemapArray::.ctor(System.Int32,System.Int32,UnityEngine.TextureFormat,System.Boolean,System.Boolean)
extern void CubemapArray__ctor_mE9E5A417064CB9CF4283C8A82F4AE5C463C4014E (void);
// 0x00000253 System.Void UnityEngine.CubemapArray::.ctor(System.Int32,System.Int32,UnityEngine.TextureFormat,System.Boolean)
extern void CubemapArray__ctor_mD52A7D884A01A8DF05B40D820584C1F3869317AC (void);
// 0x00000254 System.Void UnityEngine.CubemapArray::Apply(System.Boolean,System.Boolean)
extern void CubemapArray_Apply_mAA584F103CAA850A51C0099E34633337116BF919 (void);
// 0x00000255 System.Void UnityEngine.CubemapArray::Apply()
extern void CubemapArray_Apply_m37532D4ADC2C693BED0B279303B0C316A2BBE7BF (void);
// 0x00000256 System.Int32 UnityEngine.RenderTexture::get_width()
extern void RenderTexture_get_width_m246F1304B26711BE9D18EE186F130590B9EDADDB (void);
// 0x00000257 System.Void UnityEngine.RenderTexture::set_width(System.Int32)
extern void RenderTexture_set_width_m10EF29F6167493A1C5826869ACB10EA9C7A5BDCE (void);
// 0x00000258 System.Int32 UnityEngine.RenderTexture::get_height()
extern void RenderTexture_get_height_m26FBCCE11E1C6C9A47566CC4421258BAF5F35CE6 (void);
// 0x00000259 System.Void UnityEngine.RenderTexture::set_height(System.Int32)
extern void RenderTexture_set_height_m4402FEFDF6D35ABE3FBA485FE9A144FB4204B561 (void);
// 0x0000025A UnityEngine.Rendering.TextureDimension UnityEngine.RenderTexture::get_dimension()
extern void RenderTexture_get_dimension_m63E0A3DC2C36BF788682CA938338EE88AAEA68DB (void);
// 0x0000025B System.Void UnityEngine.RenderTexture::set_dimension(UnityEngine.Rendering.TextureDimension)
extern void RenderTexture_set_dimension_m946594E580FC4E1D4D07050C981350FDF1ACFECB (void);
// 0x0000025C UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.RenderTexture::get_graphicsFormat()
extern void RenderTexture_get_graphicsFormat_mE0A181AB88D5E381CD945440A67187929328382E (void);
// 0x0000025D System.Void UnityEngine.RenderTexture::set_graphicsFormat(UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void RenderTexture_set_graphicsFormat_mF60798F07D5994C46C53826F8A8F2E553B8F85CF (void);
// 0x0000025E System.Boolean UnityEngine.RenderTexture::get_useMipMap()
extern void RenderTexture_get_useMipMap_mF9C82146D1CC2D08645CA990FC8D533F9D9D73AE (void);
// 0x0000025F System.Void UnityEngine.RenderTexture::set_useMipMap(System.Boolean)
extern void RenderTexture_set_useMipMap_m5C5D90A9CA6125C21536E945890A84B7B7560D51 (void);
// 0x00000260 System.Boolean UnityEngine.RenderTexture::get_sRGB()
extern void RenderTexture_get_sRGB_m73E0F48DF924CBD308CD2B34E2B410E299F47B6A (void);
// 0x00000261 System.Void UnityEngine.RenderTexture::set_memorylessMode(UnityEngine.RenderTextureMemoryless)
extern void RenderTexture_set_memorylessMode_m9C1C6EB31B28619D92243DD865BD8C9DC0D0546A (void);
// 0x00000262 UnityEngine.RenderTextureFormat UnityEngine.RenderTexture::get_format()
extern void RenderTexture_get_format_mC500BCC10B2A6D6808645B505DB510056516D1FF (void);
// 0x00000263 System.Void UnityEngine.RenderTexture::set_stencilFormat(UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void RenderTexture_set_stencilFormat_m1879238C289901C8C8A818FF70005104145CE54C (void);
// 0x00000264 System.Void UnityEngine.RenderTexture::set_autoGenerateMips(System.Boolean)
extern void RenderTexture_set_autoGenerateMips_mD2592BAF6AB49EB936DF81BB118E5324F3C18085 (void);
// 0x00000265 System.Int32 UnityEngine.RenderTexture::get_volumeDepth()
extern void RenderTexture_get_volumeDepth_m8F15924EC6BAA5B422E44AEA6C385F5ADA2A0C51 (void);
// 0x00000266 System.Void UnityEngine.RenderTexture::set_volumeDepth(System.Int32)
extern void RenderTexture_set_volumeDepth_mF0FE016DC6C99C4901BE79291E15DB8415406672 (void);
// 0x00000267 System.Int32 UnityEngine.RenderTexture::get_antiAliasing()
extern void RenderTexture_get_antiAliasing_mD49E94DED64C07E6855967E5B04A77F06AC9EEEF (void);
// 0x00000268 System.Void UnityEngine.RenderTexture::set_antiAliasing(System.Int32)
extern void RenderTexture_set_antiAliasing_mBE37447FA23E0D57731C1456165E03303EC9B559 (void);
// 0x00000269 System.Void UnityEngine.RenderTexture::set_bindTextureMS(System.Boolean)
extern void RenderTexture_set_bindTextureMS_mCEE784272C9FB149DB3E3FEBCE3E98900B26E975 (void);
// 0x0000026A System.Void UnityEngine.RenderTexture::set_enableRandomWrite(System.Boolean)
extern void RenderTexture_set_enableRandomWrite_mFD4FF62C1DFC56BDAB62D86ACDCAA61030DAB2FD (void);
// 0x0000026B System.Void UnityEngine.RenderTexture::set_useDynamicScale(System.Boolean)
extern void RenderTexture_set_useDynamicScale_mF64047DE064AC493C6F178198B022FD2AD728A4E (void);
// 0x0000026C System.Boolean UnityEngine.RenderTexture::Create()
extern void RenderTexture_Create_mD0960B8843B57D80B9B956D6D36E3338C46B9F41 (void);
// 0x0000026D System.Void UnityEngine.RenderTexture::Release()
extern void RenderTexture_Release_m8CB0AC4A96E59F351807F2011EC2E8EC8C933FC5 (void);
// 0x0000026E System.Void UnityEngine.RenderTexture::SetSRGBReadWrite(System.Boolean)
extern void RenderTexture_SetSRGBReadWrite_mD553522060790CB4984886D2508B79897C3DC2DE (void);
// 0x0000026F System.Void UnityEngine.RenderTexture::Internal_Create(UnityEngine.RenderTexture)
extern void RenderTexture_Internal_Create_m924B30E7AFD36150F0279057C3A3869D94D7646A (void);
// 0x00000270 System.Void UnityEngine.RenderTexture::SetRenderTextureDescriptor(UnityEngine.RenderTextureDescriptor)
extern void RenderTexture_SetRenderTextureDescriptor_mF584353E0834F202C955EAC6499CBD0C6A571527 (void);
// 0x00000271 UnityEngine.RenderTextureDescriptor UnityEngine.RenderTexture::GetDescriptor()
extern void RenderTexture_GetDescriptor_mBDAE7C44038663205A31293B7C4C5AE763CD1128 (void);
// 0x00000272 UnityEngine.RenderTexture UnityEngine.RenderTexture::GetTemporary_Internal(UnityEngine.RenderTextureDescriptor)
extern void RenderTexture_GetTemporary_Internal_mCEA100492B9216DC823FB449EBFB71B15126E026 (void);
// 0x00000273 System.Void UnityEngine.RenderTexture::ReleaseTemporary(UnityEngine.RenderTexture)
extern void RenderTexture_ReleaseTemporary_mFBA6F18138965049AA901D62A0080B1A087A38EA (void);
// 0x00000274 System.Void UnityEngine.RenderTexture::set_depth(System.Int32)
extern void RenderTexture_set_depth_mD4BCB0A9251B7FCF570459A705E03FFFEA4DB3B0 (void);
// 0x00000275 System.Void UnityEngine.RenderTexture::.ctor()
extern void RenderTexture__ctor_mFB50DBD262C99B38016F518AA0FBF753FE22D13A (void);
// 0x00000276 System.Void UnityEngine.RenderTexture::.ctor(UnityEngine.RenderTextureDescriptor)
extern void RenderTexture__ctor_mEC30DF610263D5A16EC16E34BD86AD4BC0C87A9B (void);
// 0x00000277 System.Void UnityEngine.RenderTexture::.ctor(UnityEngine.RenderTexture)
extern void RenderTexture__ctor_m3B3534A6C9696C5CB12ADC78F922237F69CEA33A (void);
// 0x00000278 System.Void UnityEngine.RenderTexture::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.DefaultFormat)
extern void RenderTexture__ctor_mBAE127BF530990C9C8DBF5E155BA05A068777129 (void);
// 0x00000279 System.Void UnityEngine.RenderTexture::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void RenderTexture__ctor_m7C2F727F747019FC14CF7FB5FF5C29A349F9FCD9 (void);
// 0x0000027A System.Void UnityEngine.RenderTexture::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,System.Int32)
extern void RenderTexture__ctor_m2DD279268931EC6E725CAB584DC7D499E4BDCB82 (void);
// 0x0000027B System.Void UnityEngine.RenderTexture::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.RenderTextureFormat,UnityEngine.RenderTextureReadWrite)
extern void RenderTexture__ctor_m32060CA5A5C306C485DB6AF9B9050B2FF2AB3A4C (void);
// 0x0000027C System.Void UnityEngine.RenderTexture::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.RenderTextureFormat)
extern void RenderTexture__ctor_m0FF5DDAB599ED301091CF23D4C76691D8EC70CA5 (void);
// 0x0000027D System.Void UnityEngine.RenderTexture::.ctor(System.Int32,System.Int32,System.Int32)
extern void RenderTexture__ctor_mB54A3ABBD56D38AB762D0AB8B789E2771BC42A7D (void);
// 0x0000027E System.Void UnityEngine.RenderTexture::.ctor(System.Int32,System.Int32,System.Int32,UnityEngine.RenderTextureFormat,System.Int32)
extern void RenderTexture__ctor_mDB3D67FD662C79D27F0C42C6DBA1A7EFF80C2D1E (void);
// 0x0000027F UnityEngine.RenderTextureDescriptor UnityEngine.RenderTexture::get_descriptor()
extern void RenderTexture_get_descriptor_m67E7BCFA6A50634F6E3863E2F5BA1D4923E4DD00 (void);
// 0x00000280 System.Void UnityEngine.RenderTexture::set_descriptor(UnityEngine.RenderTextureDescriptor)
extern void RenderTexture_set_descriptor_m88048ECD2E447B3549D59032F5F9B52D4CA3D528 (void);
// 0x00000281 System.Void UnityEngine.RenderTexture::ValidateRenderTextureDesc(UnityEngine.RenderTextureDescriptor)
extern void RenderTexture_ValidateRenderTextureDesc_mE4BA319BF91FCA90B517EF080E84EE395A4EAD01 (void);
// 0x00000282 UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.RenderTexture::GetCompatibleFormat(UnityEngine.RenderTextureFormat,UnityEngine.RenderTextureReadWrite)
extern void RenderTexture_GetCompatibleFormat_m1C84A2875CC17182DEB4CC7EF277E7089B160095 (void);
// 0x00000283 UnityEngine.RenderTexture UnityEngine.RenderTexture::GetTemporary(UnityEngine.RenderTextureDescriptor)
extern void RenderTexture_GetTemporary_m8E85E142DCF332F8F7250E7B6495964D0BF35D25 (void);
// 0x00000284 UnityEngine.RenderTexture UnityEngine.RenderTexture::GetTemporaryImpl(System.Int32,System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,System.Int32,UnityEngine.RenderTextureMemoryless,UnityEngine.VRTextureUsage,System.Boolean)
extern void RenderTexture_GetTemporaryImpl_mEBD2063A0B8EBB410018015230D7C40458575F18 (void);
// 0x00000285 UnityEngine.RenderTexture UnityEngine.RenderTexture::GetTemporary(System.Int32,System.Int32,System.Int32,UnityEngine.RenderTextureFormat)
extern void RenderTexture_GetTemporary_m6E0EF85D2DEC0626DE5BB5D008A659F1CD66D9F8 (void);
// 0x00000286 System.Void UnityEngine.RenderTexture::SetRenderTextureDescriptor_Injected(UnityEngine.RenderTextureDescriptor&)
extern void RenderTexture_SetRenderTextureDescriptor_Injected_m72AC0A28D6BF9041721D95E43BAC302A56C99019 (void);
// 0x00000287 System.Void UnityEngine.RenderTexture::GetDescriptor_Injected(UnityEngine.RenderTextureDescriptor&)
extern void RenderTexture_GetDescriptor_Injected_m9A137437A3EAD31E2AE4BC123329BF3945B22A64 (void);
// 0x00000288 UnityEngine.RenderTexture UnityEngine.RenderTexture::GetTemporary_Internal_Injected(UnityEngine.RenderTextureDescriptor&)
extern void RenderTexture_GetTemporary_Internal_Injected_m120A90D9E06335E3DED4581D48BC18F0E9F1006A (void);
// 0x00000289 System.Int32 UnityEngine.RenderTextureDescriptor::get_width()
extern void RenderTextureDescriptor_get_width_m225FBFD7C33BD02D6879A93F1D57997BC251F3F5_AdjustorThunk (void);
// 0x0000028A System.Void UnityEngine.RenderTextureDescriptor::set_width(System.Int32)
extern void RenderTextureDescriptor_set_width_m48ADD4AB04E8DBEEC5CA8CC96F86D2674F4FE55F_AdjustorThunk (void);
// 0x0000028B System.Int32 UnityEngine.RenderTextureDescriptor::get_height()
extern void RenderTextureDescriptor_get_height_m947A620B3D28090A57A5DC0D6A126CBBF818B97F_AdjustorThunk (void);
// 0x0000028C System.Void UnityEngine.RenderTextureDescriptor::set_height(System.Int32)
extern void RenderTextureDescriptor_set_height_mD19D74EC9679250F63489CF1950351EFA83A1A45_AdjustorThunk (void);
// 0x0000028D System.Int32 UnityEngine.RenderTextureDescriptor::get_msaaSamples()
extern void RenderTextureDescriptor_get_msaaSamples_mEBE0D743E17068D1898DAE2D281C913E39A33616_AdjustorThunk (void);
// 0x0000028E System.Void UnityEngine.RenderTextureDescriptor::set_msaaSamples(System.Int32)
extern void RenderTextureDescriptor_set_msaaSamples_m5856FC43DAD667D4462B6BCA938B70E42068D24C_AdjustorThunk (void);
// 0x0000028F System.Int32 UnityEngine.RenderTextureDescriptor::get_volumeDepth()
extern void RenderTextureDescriptor_get_volumeDepth_mBC82F4621E4158E3D2F2457487D1C220AA782AC6_AdjustorThunk (void);
// 0x00000290 System.Void UnityEngine.RenderTextureDescriptor::set_volumeDepth(System.Int32)
extern void RenderTextureDescriptor_set_volumeDepth_mDC402E6967166BE8CADDA690B32136A1E0AB8583_AdjustorThunk (void);
// 0x00000291 System.Void UnityEngine.RenderTextureDescriptor::set_mipCount(System.Int32)
extern void RenderTextureDescriptor_set_mipCount_m98C1CE257A8152D8B23EC27D68D0C4C35683DEE5_AdjustorThunk (void);
// 0x00000292 UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.RenderTextureDescriptor::get_graphicsFormat()
extern void RenderTextureDescriptor_get_graphicsFormat_mD2DD8AC2E1324779F8D497697E725FB93341A14D_AdjustorThunk (void);
// 0x00000293 System.Void UnityEngine.RenderTextureDescriptor::set_graphicsFormat(UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void RenderTextureDescriptor_set_graphicsFormat_mF24C183BA9C9C42923CEC3ED353661D54AA741CA_AdjustorThunk (void);
// 0x00000294 UnityEngine.RenderTextureFormat UnityEngine.RenderTextureDescriptor::get_colorFormat()
extern void RenderTextureDescriptor_get_colorFormat_m5BC2FC0A958FA5B820C82DA8E166BAEF20C481D6_AdjustorThunk (void);
// 0x00000295 System.Void UnityEngine.RenderTextureDescriptor::set_colorFormat(UnityEngine.RenderTextureFormat)
extern void RenderTextureDescriptor_set_colorFormat_m26BBE54C0CD58DE267331FED099D449D47801858_AdjustorThunk (void);
// 0x00000296 System.Boolean UnityEngine.RenderTextureDescriptor::get_sRGB()
extern void RenderTextureDescriptor_get_sRGB_mB06940B9BE55946E7E8CCEF912EBA1888FA93B3D_AdjustorThunk (void);
// 0x00000297 System.Void UnityEngine.RenderTextureDescriptor::set_sRGB(System.Boolean)
extern void RenderTextureDescriptor_set_sRGB_m19974099678BC320DA80ED60E71E1F46DAE5426F_AdjustorThunk (void);
// 0x00000298 System.Int32 UnityEngine.RenderTextureDescriptor::get_depthBufferBits()
extern void RenderTextureDescriptor_get_depthBufferBits_m51E82C47A0CA0BD8B20F90D43169C956C4F24996_AdjustorThunk (void);
// 0x00000299 System.Void UnityEngine.RenderTextureDescriptor::set_depthBufferBits(System.Int32)
extern void RenderTextureDescriptor_set_depthBufferBits_mED58A8D9643740713597B0244BF76D0395C1C479_AdjustorThunk (void);
// 0x0000029A UnityEngine.Rendering.TextureDimension UnityEngine.RenderTextureDescriptor::get_dimension()
extern void RenderTextureDescriptor_get_dimension_mCFB2C2CD795A0C0482F4A5B9E3F9E52D42027B5C_AdjustorThunk (void);
// 0x0000029B System.Void UnityEngine.RenderTextureDescriptor::set_dimension(UnityEngine.Rendering.TextureDimension)
extern void RenderTextureDescriptor_set_dimension_mBC3C8793345AC5E627BDD932B46A5F93568ACCE5_AdjustorThunk (void);
// 0x0000029C System.Void UnityEngine.RenderTextureDescriptor::set_shadowSamplingMode(UnityEngine.Rendering.ShadowSamplingMode)
extern void RenderTextureDescriptor_set_shadowSamplingMode_m0AC43F8A8BE0755567EED4DDFADBE207739E1ECF_AdjustorThunk (void);
// 0x0000029D System.Void UnityEngine.RenderTextureDescriptor::set_vrUsage(UnityEngine.VRTextureUsage)
extern void RenderTextureDescriptor_set_vrUsage_mC591604135749B0BD156865141E114F51812E502_AdjustorThunk (void);
// 0x0000029E System.Void UnityEngine.RenderTextureDescriptor::set_memoryless(UnityEngine.RenderTextureMemoryless)
extern void RenderTextureDescriptor_set_memoryless_m1FB3F7E8B482C71BDB549AD71D762BCF337D8185_AdjustorThunk (void);
// 0x0000029F System.Void UnityEngine.RenderTextureDescriptor::.ctor(System.Int32,System.Int32)
extern void RenderTextureDescriptor__ctor_m8F804E105E65451663825D24C55B3660AC598696_AdjustorThunk (void);
// 0x000002A0 System.Void UnityEngine.RenderTextureDescriptor::.ctor(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,System.Int32)
extern void RenderTextureDescriptor__ctor_mC2F88C9BE0407671CD463877068A9194158ACBFB_AdjustorThunk (void);
// 0x000002A1 System.Void UnityEngine.RenderTextureDescriptor::.ctor(System.Int32,System.Int32,UnityEngine.Experimental.Rendering.GraphicsFormat,System.Int32,System.Int32)
extern void RenderTextureDescriptor__ctor_m227EBED323830B1059806874C69E1426DDC16B85_AdjustorThunk (void);
// 0x000002A2 System.Void UnityEngine.RenderTextureDescriptor::SetOrClearRenderTextureCreationFlag(System.Boolean,UnityEngine.RenderTextureCreationFlags)
extern void RenderTextureDescriptor_SetOrClearRenderTextureCreationFlag_m387E338D17ED601B0587EF4E5CEB10DDFC42CC05_AdjustorThunk (void);
// 0x000002A3 System.Void UnityEngine.RenderTextureDescriptor::set_useMipMap(System.Boolean)
extern void RenderTextureDescriptor_set_useMipMap_m6945F823439A1355129CD99358F5CD2514823D8E_AdjustorThunk (void);
// 0x000002A4 System.Void UnityEngine.RenderTextureDescriptor::set_autoGenerateMips(System.Boolean)
extern void RenderTextureDescriptor_set_autoGenerateMips_m65E46C31C8A8F4942AFD3605111D19367E6B52E5_AdjustorThunk (void);
// 0x000002A5 System.Void UnityEngine.RenderTextureDescriptor::set_enableRandomWrite(System.Boolean)
extern void RenderTextureDescriptor_set_enableRandomWrite_m40E4833717B6D9AB1E4DABD4F5AD31C31077055E_AdjustorThunk (void);
// 0x000002A6 System.Void UnityEngine.RenderTextureDescriptor::set_bindMS(System.Boolean)
extern void RenderTextureDescriptor_set_bindMS_m7585E1C1850022AE4B139C6DB5FB59913F7D8B9D_AdjustorThunk (void);
// 0x000002A7 System.Void UnityEngine.RenderTextureDescriptor::set_createdFromScript(System.Boolean)
extern void RenderTextureDescriptor_set_createdFromScript_m1AD9EEA1A2C28F445C710EF281970A180FF5EDA2_AdjustorThunk (void);
// 0x000002A8 System.Void UnityEngine.RenderTextureDescriptor::set_useDynamicScale(System.Boolean)
extern void RenderTextureDescriptor_set_useDynamicScale_m7DA7110A51900A67962FB0839833928B20F64BE7_AdjustorThunk (void);
// 0x000002A9 System.Void UnityEngine.RenderTextureDescriptor::.cctor()
extern void RenderTextureDescriptor__cctor_mA5675E6684E1E8C26E848D2390FB2ABE8E3C11FD (void);
// 0x000002AA System.Void UnityEngine.Hash128::.ctor(System.UInt64,System.UInt64)
extern void Hash128__ctor_m600462667D7BE3F6E017E8ECDF6242A525F3FD8E_AdjustorThunk (void);
// 0x000002AB System.UInt64 UnityEngine.Hash128::get_u64_0()
extern void Hash128_get_u64_0_m5EA1CF70752F0A303C01B0F9CE819FC8490390DB_AdjustorThunk (void);
// 0x000002AC System.UInt64 UnityEngine.Hash128::get_u64_1()
extern void Hash128_get_u64_1_m163DB2AB90204E672FB6F09DD8F5A28FBAE15036_AdjustorThunk (void);
// 0x000002AD System.Int32 UnityEngine.Hash128::CompareTo(UnityEngine.Hash128)
extern void Hash128_CompareTo_m0BC4F8F4228CF2B48C615E39CD3CE260386CC5BC_AdjustorThunk (void);
// 0x000002AE System.String UnityEngine.Hash128::ToString()
extern void Hash128_ToString_mD81890597BCFD67BE47646DA5366347C545EB5E8_AdjustorThunk (void);
// 0x000002AF System.String UnityEngine.Hash128::Internal_Hash128ToString(UnityEngine.Hash128)
extern void Hash128_Internal_Hash128ToString_m0C8F22C98723DA1488DC4FC86886662AC030E798 (void);
// 0x000002B0 System.Boolean UnityEngine.Hash128::Equals(System.Object)
extern void Hash128_Equals_m4701FDD64B5C5F81B1E494D5586C5CB4519BC007_AdjustorThunk (void);
// 0x000002B1 System.Boolean UnityEngine.Hash128::Equals(UnityEngine.Hash128)
extern void Hash128_Equals_m85BCDD87EB2A629FB8BB72FD63244787BC47E52D_AdjustorThunk (void);
// 0x000002B2 System.Int32 UnityEngine.Hash128::GetHashCode()
extern void Hash128_GetHashCode_m65DA1711C64E83AB514A3D498C568CB10EAA0D69_AdjustorThunk (void);
// 0x000002B3 System.Int32 UnityEngine.Hash128::CompareTo(System.Object)
extern void Hash128_CompareTo_m3595697B0FC7ACAED77C03FEC7FF80A073A4F6AE_AdjustorThunk (void);
// 0x000002B4 System.Boolean UnityEngine.Hash128::op_Equality(UnityEngine.Hash128,UnityEngine.Hash128)
extern void Hash128_op_Equality_m77950F7840A081CBFE1D01A2B72DA521A4AF5065 (void);
// 0x000002B5 System.Boolean UnityEngine.Hash128::op_LessThan(UnityEngine.Hash128,UnityEngine.Hash128)
extern void Hash128_op_LessThan_m2F98815644822762B642B483F79A72CFB4BADB39 (void);
// 0x000002B6 System.Boolean UnityEngine.Hash128::op_GreaterThan(UnityEngine.Hash128,UnityEngine.Hash128)
extern void Hash128_op_GreaterThan_m1B6A95E0C9A75EE36E33D0E75ADB0D1872B843A1 (void);
// 0x000002B7 System.String UnityEngine.Hash128::Internal_Hash128ToString_Injected(UnityEngine.Hash128&)
extern void Hash128_Internal_Hash128ToString_Injected_m6B07AAF4C1F86D9B7E482FD030AFB9CB15527583 (void);
// 0x000002B8 System.Void UnityEngine.HashUtilities::AppendHash(UnityEngine.Hash128&,UnityEngine.Hash128&)
extern void HashUtilities_AppendHash_m925038D55CA5EDF96EEE6C3F4F7A7495C45BBB9B (void);
// 0x000002B9 System.Void UnityEngine.HashUnsafeUtilities::ComputeHash128(System.Void*,System.UInt64,System.UInt64*,System.UInt64*)
extern void HashUnsafeUtilities_ComputeHash128_m87F6E52DA65D183D96B903F2A8B5D0DDC9513042 (void);
// 0x000002BA System.Void UnityEngine.HashUnsafeUtilities::ComputeHash128(System.Void*,System.UInt64,UnityEngine.Hash128*)
extern void HashUnsafeUtilities_ComputeHash128_mFD8128869575343C3B3D61E6D9D387065F2FEC50 (void);
// 0x000002BB System.Boolean UnityEngine.SpookyHash::AttemptDetectAllowUnalignedRead()
extern void SpookyHash_AttemptDetectAllowUnalignedRead_m16DAF389E8D6613FEFD72496B7EA1F816502D01E (void);
// 0x000002BC System.Void UnityEngine.SpookyHash::Hash(System.Void*,System.UInt64,System.UInt64*,System.UInt64*)
extern void SpookyHash_Hash_m412D286990E0C1CF2C53709BF8D195FB75C027AE (void);
// 0x000002BD System.Void UnityEngine.SpookyHash::End(System.UInt64*,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&)
extern void SpookyHash_End_m3965A09BB1DDE0E6DA8154A0F3DC5331BB9B1791 (void);
// 0x000002BE System.Void UnityEngine.SpookyHash::EndPartial(System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&)
extern void SpookyHash_EndPartial_mCF833335448A20FC7BD032F684BC8CCEDA2CF263 (void);
// 0x000002BF System.Void UnityEngine.SpookyHash::Rot64(System.UInt64&,System.Int32)
extern void SpookyHash_Rot64_mF3D9A87021715ED95DA32FCDBFB009111F8E4C33 (void);
// 0x000002C0 System.Void UnityEngine.SpookyHash::Short(System.Void*,System.UInt64,System.UInt64*,System.UInt64*)
extern void SpookyHash_Short_m6DD9B8A72AD13F6CA1A273A959C9B9844F9F0B22 (void);
// 0x000002C1 System.Void UnityEngine.SpookyHash::ShortMix(System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&)
extern void SpookyHash_ShortMix_m30CA9B50F80B2A28C41E1778AE673150B8A1EE12 (void);
// 0x000002C2 System.Void UnityEngine.SpookyHash::ShortEnd(System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&)
extern void SpookyHash_ShortEnd_m0A83C3EDC139579B3CE4E899263237EB6CD45F14 (void);
// 0x000002C3 System.Void UnityEngine.SpookyHash::Mix(System.UInt64*,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&,System.UInt64&)
extern void SpookyHash_Mix_mC591F4B57A475E0BDA906AA873A6C3611EE07213 (void);
// 0x000002C4 System.Void UnityEngine.SpookyHash::memset(System.Void*,System.Int32,System.UInt64)
extern void SpookyHash_memset_m3D0988877733DBBE392E56D257C6BFCFF1277316 (void);
// 0x000002C5 System.Void UnityEngine.SpookyHash::.cctor()
extern void SpookyHash__cctor_m846879BD0451CCED57A97386509A49F9A78236BC (void);
// 0x000002C6 System.Void UnityEngine.SpookyHash_U::.ctor(System.UInt16*)
extern void U__ctor_mA51EB7CBBF4D6A6B4F2687CD280D0DEC08D3BA6F_AdjustorThunk (void);
// 0x000002C7 System.Void UnityEngine.Cursor::set_visible(System.Boolean)
extern void Cursor_set_visible_mDB51E60B3D7B14873A6F5FBE5E0A432D4A46C431 (void);
// 0x000002C8 UnityEngine.CursorLockMode UnityEngine.Cursor::get_lockState()
extern void Cursor_get_lockState_mE0C93F496E3AA120AD168ED30371C35ED79C9DF1 (void);
// 0x000002C9 System.Void UnityEngine.Cursor::set_lockState(UnityEngine.CursorLockMode)
extern void Cursor_set_lockState_m019E27A0FE021A28A1C672801416ACA5E770933F (void);
// 0x000002CA UnityEngine.ILogHandler UnityEngine.ILogger::get_logHandler()
// 0x000002CB System.Void UnityEngine.ILogger::Log(UnityEngine.LogType,System.Object)
// 0x000002CC System.Void UnityEngine.ILogger::Log(UnityEngine.LogType,System.Object,UnityEngine.Object)
// 0x000002CD System.Void UnityEngine.ILogger::LogFormat(UnityEngine.LogType,System.String,System.Object[])
// 0x000002CE System.Void UnityEngine.ILogHandler::LogFormat(UnityEngine.LogType,UnityEngine.Object,System.String,System.Object[])
// 0x000002CF System.Void UnityEngine.ILogHandler::LogException(System.Exception,UnityEngine.Object)
// 0x000002D0 System.Void UnityEngine.Logger::.ctor(UnityEngine.ILogHandler)
extern void Logger__ctor_m447215F90AA8D1508924BFB1CD1E49AFCCE04FFE (void);
// 0x000002D1 UnityEngine.ILogHandler UnityEngine.Logger::get_logHandler()
extern void Logger_get_logHandler_m0C450B6FE86FA1B07422A1359CF278D1F5945CCD (void);
// 0x000002D2 System.Void UnityEngine.Logger::set_logHandler(UnityEngine.ILogHandler)
extern void Logger_set_logHandler_m891099050CB8C36A01ECA861E4820441B7080C73 (void);
// 0x000002D3 System.Boolean UnityEngine.Logger::get_logEnabled()
extern void Logger_get_logEnabled_m5AE50375671516B8E1171838E34C63C3A326E927 (void);
// 0x000002D4 System.Void UnityEngine.Logger::set_logEnabled(System.Boolean)
extern void Logger_set_logEnabled_m3CEBD8A4B6DC548168EC38CFC5CB982222DB655F (void);
// 0x000002D5 UnityEngine.LogType UnityEngine.Logger::get_filterLogType()
extern void Logger_get_filterLogType_mD850DE3FD8CC67E4B076FCC6B05F8FA603B5B38B (void);
// 0x000002D6 System.Void UnityEngine.Logger::set_filterLogType(UnityEngine.LogType)
extern void Logger_set_filterLogType_m1829D8E1B8350B8CFCE881598BABB2AA1826EE72 (void);
// 0x000002D7 System.Boolean UnityEngine.Logger::IsLogTypeAllowed(UnityEngine.LogType)
extern void Logger_IsLogTypeAllowed_m7B2A793443A642C8CA0759D1DD0FBDFAED4E1FCB (void);
// 0x000002D8 System.String UnityEngine.Logger::GetString(System.Object)
extern void Logger_GetString_m0078CBA4ADAE877152C264A4BEA5408BAB1DC514 (void);
// 0x000002D9 System.Void UnityEngine.Logger::Log(UnityEngine.LogType,System.Object)
extern void Logger_Log_m653FDC5B68CB933887D8886762C7BBA75243A9AF (void);
// 0x000002DA System.Void UnityEngine.Logger::Log(UnityEngine.LogType,System.Object,UnityEngine.Object)
extern void Logger_Log_mE06FF98F674C73E4BB67302E1EEDEA72F7655FF0 (void);
// 0x000002DB System.Void UnityEngine.Logger::LogFormat(UnityEngine.LogType,System.String,System.Object[])
extern void Logger_LogFormat_m7F6CBF8AF6A60EF05CF9EE795502036CBAC847A7 (void);
// 0x000002DC System.Void UnityEngine.Logger::LogFormat(UnityEngine.LogType,UnityEngine.Object,System.String,System.Object[])
extern void Logger_LogFormat_m549605E9E6499650E70B0A168E047727490F31B7 (void);
// 0x000002DD System.Void UnityEngine.Logger::LogException(System.Exception,UnityEngine.Object)
extern void Logger_LogException_m362D3434D3B275B0B98E434BFBFBF52C76BBC9C3 (void);
// 0x000002DE System.Void UnityEngine.UnityLogWriter::WriteStringToUnityLog(System.String)
extern void UnityLogWriter_WriteStringToUnityLog_m0036CA8A9FB1FE3CFF460CA0212B6377B09E6504 (void);
// 0x000002DF System.Void UnityEngine.UnityLogWriter::WriteStringToUnityLogImpl(System.String)
extern void UnityLogWriter_WriteStringToUnityLogImpl_mA39CCE94FF5BD2ABD4A8C8D78A00E366C64B4985 (void);
// 0x000002E0 System.Void UnityEngine.UnityLogWriter::Init()
extern void UnityLogWriter_Init_mAD1F3BFE2183E39CFA1E7BEFB948B368547D9E99 (void);
// 0x000002E1 System.Void UnityEngine.UnityLogWriter::Write(System.Char)
extern void UnityLogWriter_Write_mB1200B0B26545C48E178BFE952BEE14BDE53D2A7 (void);
// 0x000002E2 System.Void UnityEngine.UnityLogWriter::Write(System.String)
extern void UnityLogWriter_Write_mE3A4616A06A79B87512C3B0C8100EB508BB85C52 (void);
// 0x000002E3 System.Void UnityEngine.UnityLogWriter::Write(System.Char[],System.Int32,System.Int32)
extern void UnityLogWriter_Write_mE21873E7757E51C3771C58321E995DEBB2ADF750 (void);
// 0x000002E4 System.Void UnityEngine.UnityLogWriter::.ctor()
extern void UnityLogWriter__ctor_mE8DC0EAD466C5F290F6D32CC07F0F70590688833 (void);
// 0x000002E5 System.Void UnityEngine.Color::.ctor(System.Single,System.Single,System.Single,System.Single)
extern void Color__ctor_m20DF490CEB364C4FC36D7EE392640DF5B7420D7C_AdjustorThunk (void);
// 0x000002E6 System.Void UnityEngine.Color::.ctor(System.Single,System.Single,System.Single)
extern void Color__ctor_mC9AEEB3931D5B8C37483A884DD8EB40DC8946369_AdjustorThunk (void);
// 0x000002E7 System.String UnityEngine.Color::ToString()
extern void Color_ToString_m17A27E0CFB20D9946D130DAEDB5BDCACA5A4473F_AdjustorThunk (void);
// 0x000002E8 System.Int32 UnityEngine.Color::GetHashCode()
extern void Color_GetHashCode_m88317C719D2DAA18E293B3F5CD17B9FB80E26CF1_AdjustorThunk (void);
// 0x000002E9 System.Boolean UnityEngine.Color::Equals(System.Object)
extern void Color_Equals_m63ECBA87A0F27CD7D09EEA36BCB697652E076F4E_AdjustorThunk (void);
// 0x000002EA System.Boolean UnityEngine.Color::Equals(UnityEngine.Color)
extern void Color_Equals_mA81EEDDC4250DE67C2F43BC88A102EA32A138052_AdjustorThunk (void);
// 0x000002EB UnityEngine.Color UnityEngine.Color::op_Multiply(UnityEngine.Color,System.Single)
extern void Color_op_Multiply_mF36917AD6235221537542FD079817CAB06CB1934 (void);
// 0x000002EC UnityEngine.Color UnityEngine.Color::op_Multiply(System.Single,UnityEngine.Color)
extern void Color_op_Multiply_m2A972C4CDC2883F4225CC2E431D7808ECBAC3567 (void);
// 0x000002ED System.Boolean UnityEngine.Color::op_Equality(UnityEngine.Color,UnityEngine.Color)
extern void Color_op_Equality_m71B1A2F64AD6228F10E20149EF6440460D2C748E (void);
// 0x000002EE System.Boolean UnityEngine.Color::op_Inequality(UnityEngine.Color,UnityEngine.Color)
extern void Color_op_Inequality_m9C3EFC058BB205C298A2D3166173342303E660B9 (void);
// 0x000002EF UnityEngine.Color UnityEngine.Color::Lerp(UnityEngine.Color,UnityEngine.Color,System.Single)
extern void Color_Lerp_mD37EF718F1BAC65A7416655F0BC902CE76559C46 (void);
// 0x000002F0 UnityEngine.Color UnityEngine.Color::RGBMultiplied(System.Single)
extern void Color_RGBMultiplied_m41914B23903491843FAA3B0C02027EF8B70F34CF_AdjustorThunk (void);
// 0x000002F1 UnityEngine.Color UnityEngine.Color::get_red()
extern void Color_get_red_m5562DD438931CF0D1FBBBB29BF7F8B752AF38957 (void);
// 0x000002F2 UnityEngine.Color UnityEngine.Color::get_white()
extern void Color_get_white_mE7F3AC4FF0D6F35E48049C73116A222CBE96D905 (void);
// 0x000002F3 UnityEngine.Color UnityEngine.Color::get_black()
extern void Color_get_black_mEB3C91F45F8AA7E4842238DFCC578BB322723DAF (void);
// 0x000002F4 UnityEngine.Color UnityEngine.Color::get_magenta()
extern void Color_get_magenta_m04E2DDB63AA6288C701A93E248643A06EBD2D7AD (void);
// 0x000002F5 UnityEngine.Color UnityEngine.Color::get_grey()
extern void Color_get_grey_mC37E72622FEB89E52EBCB5245D42DBF63E4FE3B7 (void);
// 0x000002F6 UnityEngine.Color UnityEngine.Color::get_clear()
extern void Color_get_clear_m419239BDAEB3D3C4B4291BF2C6EF09A7D7D81360 (void);
// 0x000002F7 UnityEngine.Color UnityEngine.Color::get_linear()
extern void Color_get_linear_mB10CD29D56ADE2C811AD74A605BA11F6656E9D1A_AdjustorThunk (void);
// 0x000002F8 UnityEngine.Color UnityEngine.Color::get_gamma()
extern void Color_get_gamma_m38A0BB5A9A0A7F860BEEB3BD9F69F72CFA926A79_AdjustorThunk (void);
// 0x000002F9 System.Single UnityEngine.Color::get_maxColorComponent()
extern void Color_get_maxColorComponent_mBA8595CB2790747F42145CB696C10E64C9BBD76D_AdjustorThunk (void);
// 0x000002FA UnityEngine.Vector4 UnityEngine.Color::op_Implicit(UnityEngine.Color)
extern void Color_op_Implicit_m653C1CE2391B0A04114B9132C37E41AC92B33AFE (void);
// 0x000002FB UnityEngine.Color UnityEngine.Color::op_Implicit(UnityEngine.Vector4)
extern void Color_op_Implicit_m51CEC50D37ABC484073AECE7EB958B414F2B6E7B (void);
// 0x000002FC System.Void UnityEngine.Color32::.ctor(System.Byte,System.Byte,System.Byte,System.Byte)
extern void Color32__ctor_m1AEF46FBBBE4B522E6984D081A3D158198E10AA2_AdjustorThunk (void);
// 0x000002FD UnityEngine.Color32 UnityEngine.Color32::op_Implicit(UnityEngine.Color)
extern void Color32_op_Implicit_m52B034473369A651C8952BD916A2AB193E0E5B30 (void);
// 0x000002FE UnityEngine.Color UnityEngine.Color32::op_Implicit(UnityEngine.Color32)
extern void Color32_op_Implicit_mA89CAD76E78975F51DF7374A67D18A5F6EF8DA61 (void);
// 0x000002FF System.String UnityEngine.Color32::ToString()
extern void Color32_ToString_m217F2AD5C02E630E37BE5CFB0933630F6D0C3555_AdjustorThunk (void);
// 0x00000300 System.IntPtr UnityEngine.Gradient::Init()
extern void Gradient_Init_m56D09BE88E111535F8D2278E03BE81C9D70EFAAD (void);
// 0x00000301 System.Void UnityEngine.Gradient::Cleanup()
extern void Gradient_Cleanup_mD38D8100E8FAAC7FBD5047380555802E638DF718 (void);
// 0x00000302 System.Boolean UnityEngine.Gradient::Internal_Equals(System.IntPtr)
extern void Gradient_Internal_Equals_m210D28E9843DBA28E2F60FDBB366FE2B5B739B1A (void);
// 0x00000303 System.Void UnityEngine.Gradient::.ctor()
extern void Gradient__ctor_m297B6B928FDA6BD99A142736017F5C0E2B30BE7F (void);
// 0x00000304 System.Void UnityEngine.Gradient::Finalize()
extern void Gradient_Finalize_mB8CB38D86D7935F98000B5F4A0EBF419BD859210 (void);
// 0x00000305 System.Boolean UnityEngine.Gradient::Equals(System.Object)
extern void Gradient_Equals_m0A13AD7938F81F21CC380609A506A39B37CF2097 (void);
// 0x00000306 System.Boolean UnityEngine.Gradient::Equals(UnityEngine.Gradient)
extern void Gradient_Equals_m7F23C7692189DDD94FC31758493D4C99C2F3FB1E (void);
// 0x00000307 System.Int32 UnityEngine.Gradient::GetHashCode()
extern void Gradient_GetHashCode_m2596E6672ACDAD829961AB1FBD3EB649A908DE64 (void);
// 0x00000308 UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::TRS(UnityEngine.Vector3,UnityEngine.Quaternion,UnityEngine.Vector3)
extern void Matrix4x4_TRS_m5BB2EBA1152301BAC92FDC7F33ECA732BAE57990 (void);
// 0x00000309 UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::Inverse(UnityEngine.Matrix4x4)
extern void Matrix4x4_Inverse_mECB7765A8E71D8D2DAF064F94AAD33DE8976A85D (void);
// 0x0000030A UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::get_inverse()
extern void Matrix4x4_get_inverse_mBD3145C0D7977962E18C8B3BF63DD671F7917166_AdjustorThunk (void);
// 0x0000030B UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::Perspective(System.Single,System.Single,System.Single,System.Single)
extern void Matrix4x4_Perspective_mCFA40C620EE4661CBEA269EF57F44A7D29425EA2 (void);
// 0x0000030C System.Void UnityEngine.Matrix4x4::.ctor(UnityEngine.Vector4,UnityEngine.Vector4,UnityEngine.Vector4,UnityEngine.Vector4)
extern void Matrix4x4__ctor_mC7C5A4F0791B2A3ADAFE1E6C491B7705B6492B12_AdjustorThunk (void);
// 0x0000030D System.Void UnityEngine.Matrix4x4::set_Item(System.Int32,System.Int32,System.Single)
extern void Matrix4x4_set_Item_mDD63AFD70962132EC5468F486A641B560234CB63_AdjustorThunk (void);
// 0x0000030E System.Void UnityEngine.Matrix4x4::set_Item(System.Int32,System.Single)
extern void Matrix4x4_set_Item_m63E67A0D3E7C3CFEA191C2E73D4380A07C9046AE_AdjustorThunk (void);
// 0x0000030F System.Int32 UnityEngine.Matrix4x4::GetHashCode()
extern void Matrix4x4_GetHashCode_m6627C82FBE2092AE4711ABA909D0E2C3C182028F_AdjustorThunk (void);
// 0x00000310 System.Boolean UnityEngine.Matrix4x4::Equals(System.Object)
extern void Matrix4x4_Equals_m7FB9C1A249956C6CDE761838B92097C525596D31_AdjustorThunk (void);
// 0x00000311 System.Boolean UnityEngine.Matrix4x4::Equals(UnityEngine.Matrix4x4)
extern void Matrix4x4_Equals_mF8358F488D95A9C2E5A9F69F31EC7EA0F4640E51_AdjustorThunk (void);
// 0x00000312 UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::op_Multiply(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4)
extern void Matrix4x4_op_Multiply_mF6693A950E1917204E356366892C3CCB0553436E (void);
// 0x00000313 UnityEngine.Vector4 UnityEngine.Matrix4x4::GetColumn(System.Int32)
extern void Matrix4x4_GetColumn_m34D9081FB464BB7CF124C50BB5BE4C22E2DBFA9E_AdjustorThunk (void);
// 0x00000314 System.Void UnityEngine.Matrix4x4::SetColumn(System.Int32,UnityEngine.Vector4)
extern void Matrix4x4_SetColumn_m8AFBFEE401780B02DC32B58BF8FCE9AAA34C7F88_AdjustorThunk (void);
// 0x00000315 UnityEngine.Vector3 UnityEngine.Matrix4x4::MultiplyPoint(UnityEngine.Vector3)
extern void Matrix4x4_MultiplyPoint_mD5D082585C5B3564A5EFC90A3C5CAFFE47E45B65_AdjustorThunk (void);
// 0x00000316 UnityEngine.Vector3 UnityEngine.Matrix4x4::MultiplyPoint3x4(UnityEngine.Vector3)
extern void Matrix4x4_MultiplyPoint3x4_m7C872FDCC9E3378E00A40977F641A45A24994E9A_AdjustorThunk (void);
// 0x00000317 UnityEngine.Vector3 UnityEngine.Matrix4x4::MultiplyVector(UnityEngine.Vector3)
extern void Matrix4x4_MultiplyVector_mFED70C58FB201633483463CE64DBF0D0BE081863_AdjustorThunk (void);
// 0x00000318 UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::Translate(UnityEngine.Vector3)
extern void Matrix4x4_Translate_m73101FF77DD95B0B88F06EF9E58992F7B7CD2B36 (void);
// 0x00000319 UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::get_zero()
extern void Matrix4x4_get_zero_m0998BBFF9505014951817FEDB16FAED8C5791A39 (void);
// 0x0000031A UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::get_identity()
extern void Matrix4x4_get_identity_mA0CECDE2A5E85CF014375084624F3770B5B7B79B (void);
// 0x0000031B System.String UnityEngine.Matrix4x4::ToString()
extern void Matrix4x4_ToString_m7E29D2447E2FC1EAB3D8565B7DCAFB9037C69E1D_AdjustorThunk (void);
// 0x0000031C System.Void UnityEngine.Matrix4x4::.cctor()
extern void Matrix4x4__cctor_mC5A7950045F0C8DBAD83A45D08812BEDBC6E159E (void);
// 0x0000031D System.Void UnityEngine.Matrix4x4::TRS_Injected(UnityEngine.Vector3&,UnityEngine.Quaternion&,UnityEngine.Vector3&,UnityEngine.Matrix4x4&)
extern void Matrix4x4_TRS_Injected_mADF67489B3C6715B6BA35E22B0BA6713784100CC (void);
// 0x0000031E System.Void UnityEngine.Matrix4x4::Inverse_Injected(UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&)
extern void Matrix4x4_Inverse_Injected_m7849F11A4307E901FDBAD8FBC9FB9606B6827673 (void);
// 0x0000031F System.Void UnityEngine.Matrix4x4::Perspective_Injected(System.Single,System.Single,System.Single,System.Single,UnityEngine.Matrix4x4&)
extern void Matrix4x4_Perspective_Injected_mF2D589F7B16B6874134AEF870BAA466CE65E0C45 (void);
// 0x00000320 UnityEngine.Vector3 UnityEngine.Vector3::Lerp(UnityEngine.Vector3,UnityEngine.Vector3,System.Single)
extern void Vector3_Lerp_m5BA75496B803820CC64079383956D73C6FD4A8A1 (void);
// 0x00000321 System.Single UnityEngine.Vector3::get_Item(System.Int32)
extern void Vector3_get_Item_mC3B9D35C070A91D7CA5C5B47280BD0EA3E148AC6_AdjustorThunk (void);
// 0x00000322 System.Void UnityEngine.Vector3::set_Item(System.Int32,System.Single)
extern void Vector3_set_Item_m89FF112CEC0D9ED43F1C4FE01522C75394B30AE6_AdjustorThunk (void);
// 0x00000323 System.Void UnityEngine.Vector3::.ctor(System.Single,System.Single,System.Single)
extern void Vector3__ctor_m08F61F548AA5836D8789843ACB4A81E4963D2EE1_AdjustorThunk (void);
// 0x00000324 System.Void UnityEngine.Vector3::.ctor(System.Single,System.Single)
extern void Vector3__ctor_m6AD8F21FFCC7723C6F507CCF2E4E2EFFC4871584_AdjustorThunk (void);
// 0x00000325 UnityEngine.Vector3 UnityEngine.Vector3::Cross(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_Cross_m3E9DBC445228FDB850BDBB4B01D6F61AC0111887 (void);
// 0x00000326 System.Int32 UnityEngine.Vector3::GetHashCode()
extern void Vector3_GetHashCode_m6C42B4F413A489535D180E8A99BE0298AD078B0B_AdjustorThunk (void);
// 0x00000327 System.Boolean UnityEngine.Vector3::Equals(System.Object)
extern void Vector3_Equals_m1F74B1FB7EE51589FFFA61D894F616B8F258C056_AdjustorThunk (void);
// 0x00000328 System.Boolean UnityEngine.Vector3::Equals(UnityEngine.Vector3)
extern void Vector3_Equals_m6B991540378DB8541CEB9472F7ED2BF5FF72B5DB_AdjustorThunk (void);
// 0x00000329 UnityEngine.Vector3 UnityEngine.Vector3::Normalize(UnityEngine.Vector3)
extern void Vector3_Normalize_mDEA51D0C131125535DA2B49B7281E0086ED583DC (void);
// 0x0000032A System.Void UnityEngine.Vector3::Normalize()
extern void Vector3_Normalize_m174460238EC6322B9095A378AA8624B1DD9000F3_AdjustorThunk (void);
// 0x0000032B UnityEngine.Vector3 UnityEngine.Vector3::get_normalized()
extern void Vector3_get_normalized_mE20796F1D2D36244FACD4D14DADB245BE579849B_AdjustorThunk (void);
// 0x0000032C System.Single UnityEngine.Vector3::Dot(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_Dot_m0C530E1C51278DE28B77906D56356506232272C1 (void);
// 0x0000032D System.Single UnityEngine.Vector3::Distance(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_Distance_mE316E10B9B319A5C2A29F86E028740FD528149E7 (void);
// 0x0000032E System.Single UnityEngine.Vector3::Magnitude(UnityEngine.Vector3)
extern void Vector3_Magnitude_m3958BE20951093E6B035C5F90493027063B39437 (void);
// 0x0000032F System.Single UnityEngine.Vector3::get_magnitude()
extern void Vector3_get_magnitude_m9A750659B60C5FE0C30438A7F9681775D5DB1274_AdjustorThunk (void);
// 0x00000330 System.Single UnityEngine.Vector3::get_sqrMagnitude()
extern void Vector3_get_sqrMagnitude_m1C6E190B4A933A183B308736DEC0DD64B0588968_AdjustorThunk (void);
// 0x00000331 UnityEngine.Vector3 UnityEngine.Vector3::Min(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_Min_m0D0997E6CDFF77E5177C8D4E0A21C592C63F747E (void);
// 0x00000332 UnityEngine.Vector3 UnityEngine.Vector3::Max(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_Max_m78495079CA1E29B0658699B856AFF22E23180F36 (void);
// 0x00000333 UnityEngine.Vector3 UnityEngine.Vector3::get_zero()
extern void Vector3_get_zero_m3CDDCAE94581DF3BB16C4B40A100E28E9C6649C2 (void);
// 0x00000334 UnityEngine.Vector3 UnityEngine.Vector3::get_one()
extern void Vector3_get_one_mA11B83037CB269C6076CBCF754E24C8F3ACEC2AB (void);
// 0x00000335 UnityEngine.Vector3 UnityEngine.Vector3::get_forward()
extern void Vector3_get_forward_m3E2E192B3302130098738C308FA1EE1439449D0D (void);
// 0x00000336 UnityEngine.Vector3 UnityEngine.Vector3::get_back()
extern void Vector3_get_back_mE7EF8625637E6F8B9E6B42A6AE140777C51E02F7 (void);
// 0x00000337 UnityEngine.Vector3 UnityEngine.Vector3::get_up()
extern void Vector3_get_up_m6309EBC4E42D6D0B3D28056BD23D0331275306F7 (void);
// 0x00000338 UnityEngine.Vector3 UnityEngine.Vector3::get_down()
extern void Vector3_get_down_m3F76A48E5B7C82B35EE047375538AFD91A305F55 (void);
// 0x00000339 UnityEngine.Vector3 UnityEngine.Vector3::get_left()
extern void Vector3_get_left_m74B52D8CFD8C62138067B2EB6846B6E9E51B7C20 (void);
// 0x0000033A UnityEngine.Vector3 UnityEngine.Vector3::get_right()
extern void Vector3_get_right_m6DD9559CA0C75BBA42D9140021C4C2A9AAA9B3F5 (void);
// 0x0000033B UnityEngine.Vector3 UnityEngine.Vector3::op_Addition(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_op_Addition_m929F9C17E5D11B94D50B4AFF1D730B70CB59B50E (void);
// 0x0000033C UnityEngine.Vector3 UnityEngine.Vector3::op_Subtraction(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_op_Subtraction_mF9846B723A5034F8B9F5F5DCB78E3D67649143D3 (void);
// 0x0000033D UnityEngine.Vector3 UnityEngine.Vector3::op_UnaryNegation(UnityEngine.Vector3)
extern void Vector3_op_UnaryNegation_m2AFBBF22801F9BCA5A4EBE642A29F433FE1339C2 (void);
// 0x0000033E UnityEngine.Vector3 UnityEngine.Vector3::op_Multiply(UnityEngine.Vector3,System.Single)
extern void Vector3_op_Multiply_m1C5F07723615156ACF035D88A1280A9E8F35A04E (void);
// 0x0000033F UnityEngine.Vector3 UnityEngine.Vector3::op_Multiply(System.Single,UnityEngine.Vector3)
extern void Vector3_op_Multiply_mC7A8D6FD19E58DBF98E30D454F59F142F7BF8839 (void);
// 0x00000340 UnityEngine.Vector3 UnityEngine.Vector3::op_Division(UnityEngine.Vector3,System.Single)
extern void Vector3_op_Division_mDF34F1CC445981B4D1137765BC6277419E561624 (void);
// 0x00000341 System.Boolean UnityEngine.Vector3::op_Equality(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_op_Equality_mA9E2F96E98E71AE7ACCE74766D700D41F0404806 (void);
// 0x00000342 System.Boolean UnityEngine.Vector3::op_Inequality(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Vector3_op_Inequality_mFEEAA4C4BF743FB5B8A47FF4967A5E2C73273D6E (void);
// 0x00000343 System.String UnityEngine.Vector3::ToString()
extern void Vector3_ToString_m2682D27AB50CD1CE4677C38D0720A302D582348D_AdjustorThunk (void);
// 0x00000344 System.Void UnityEngine.Vector3::.cctor()
extern void Vector3__cctor_m83F3F89A8A8AFDBB54273660ABCA2E5AE1EAFDBD (void);
// 0x00000345 UnityEngine.Quaternion UnityEngine.Quaternion::Inverse(UnityEngine.Quaternion)
extern void Quaternion_Inverse_mC3A78571A826F05CE179637E675BD25F8B203E0C (void);
// 0x00000346 UnityEngine.Quaternion UnityEngine.Quaternion::Internal_FromEulerRad(UnityEngine.Vector3)
extern void Quaternion_Internal_FromEulerRad_mC6AB58E2F3C37DFE2089A38D578E862B3430E755 (void);
// 0x00000347 UnityEngine.Vector3 UnityEngine.Quaternion::Internal_ToEulerRad(UnityEngine.Quaternion)
extern void Quaternion_Internal_ToEulerRad_m5F7B68953CC22DCE9EC246396B02F0ADC0B1C470 (void);
// 0x00000348 UnityEngine.Quaternion UnityEngine.Quaternion::LookRotation(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Quaternion_LookRotation_m7BED8FBB457FF073F183AC7962264E5110794672 (void);
// 0x00000349 System.Void UnityEngine.Quaternion::.ctor(System.Single,System.Single,System.Single,System.Single)
extern void Quaternion__ctor_m7502F0C38E04C6DE24C965D1CAF278DDD02B9D61_AdjustorThunk (void);
// 0x0000034A UnityEngine.Quaternion UnityEngine.Quaternion::get_identity()
extern void Quaternion_get_identity_m548B37D80F2DEE60E41D1F09BF6889B557BE1A64 (void);
// 0x0000034B UnityEngine.Vector3 UnityEngine.Quaternion::op_Multiply(UnityEngine.Quaternion,UnityEngine.Vector3)
extern void Quaternion_op_Multiply_mD5999DE317D808808B72E58E7A978C4C0995879C (void);
// 0x0000034C System.Boolean UnityEngine.Quaternion::IsEqualUsingDot(System.Single)
extern void Quaternion_IsEqualUsingDot_mA5E0CF75CBB488E3EC55BE9397FC3C92439A0BEF (void);
// 0x0000034D System.Boolean UnityEngine.Quaternion::op_Equality(UnityEngine.Quaternion,UnityEngine.Quaternion)
extern void Quaternion_op_Equality_m0DBCE8FE48EEF2D7C79741E498BFFB984DF4956F (void);
// 0x0000034E System.Boolean UnityEngine.Quaternion::op_Inequality(UnityEngine.Quaternion,UnityEngine.Quaternion)
extern void Quaternion_op_Inequality_mDA6D2E63A498C8A9AB9A11DD7EA3B96567390C70 (void);
// 0x0000034F System.Single UnityEngine.Quaternion::Dot(UnityEngine.Quaternion,UnityEngine.Quaternion)
extern void Quaternion_Dot_m0C931CC8127C5461E5B8A857BDE2CE09297E468B (void);
// 0x00000350 System.Void UnityEngine.Quaternion::SetLookRotation(UnityEngine.Vector3,UnityEngine.Vector3)
extern void Quaternion_SetLookRotation_mDB3D5A8083E5AB5881FA9CC1EACFC196F61B8204_AdjustorThunk (void);
// 0x00000351 UnityEngine.Vector3 UnityEngine.Quaternion::Internal_MakePositive(UnityEngine.Vector3)
extern void Quaternion_Internal_MakePositive_mC458BD7036703798B11C6C46675814B57E236597 (void);
// 0x00000352 UnityEngine.Vector3 UnityEngine.Quaternion::get_eulerAngles()
extern void Quaternion_get_eulerAngles_mF8ABA8EB77CD682017E92F0F457374E54BC943F9_AdjustorThunk (void);
// 0x00000353 UnityEngine.Quaternion UnityEngine.Quaternion::Euler(System.Single,System.Single,System.Single)
extern void Quaternion_Euler_m537DD6CEAE0AD4274D8A84414C24C30730427D05 (void);
// 0x00000354 UnityEngine.Quaternion UnityEngine.Quaternion::Euler(UnityEngine.Vector3)
extern void Quaternion_Euler_m55C96FCD397CC69109261572710608D12A4CBD2B (void);
// 0x00000355 System.Int32 UnityEngine.Quaternion::GetHashCode()
extern void Quaternion_GetHashCode_m43BDCF3A72E31FA4063C1DEB770890FF47033458_AdjustorThunk (void);
// 0x00000356 System.Boolean UnityEngine.Quaternion::Equals(System.Object)
extern void Quaternion_Equals_m099618C36B86DC63B2E7C89673C8566B18E5996E_AdjustorThunk (void);
// 0x00000357 System.Boolean UnityEngine.Quaternion::Equals(UnityEngine.Quaternion)
extern void Quaternion_Equals_m0A269A9B77E915469801463C8BBEF7A06EF94A09_AdjustorThunk (void);
// 0x00000358 System.String UnityEngine.Quaternion::ToString()
extern void Quaternion_ToString_m38DF4A1C05A91331D0A208F45CE74AF005AB463D_AdjustorThunk (void);
// 0x00000359 System.Void UnityEngine.Quaternion::.cctor()
extern void Quaternion__cctor_m026361EBBB33BB651A59FC7BC6128195AEDCF935 (void);
// 0x0000035A System.Void UnityEngine.Quaternion::Inverse_Injected(UnityEngine.Quaternion&,UnityEngine.Quaternion&)
extern void Quaternion_Inverse_Injected_m1CD79ADF97C60D5645C15C5F04219021EE4654DD (void);
// 0x0000035B System.Void UnityEngine.Quaternion::Internal_FromEulerRad_Injected(UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void Quaternion_Internal_FromEulerRad_Injected_m2197C7F75B2DB8B99C1947CD7C92714FE8D0099D (void);
// 0x0000035C System.Void UnityEngine.Quaternion::Internal_ToEulerRad_Injected(UnityEngine.Quaternion&,UnityEngine.Vector3&)
extern void Quaternion_Internal_ToEulerRad_Injected_mE55FFD02837E4FFFFFF8689E63B4EAF4F3B7396D (void);
// 0x0000035D System.Void UnityEngine.Quaternion::LookRotation_Injected(UnityEngine.Vector3&,UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void Quaternion_LookRotation_Injected_m59A46014572ACB8F5C8A377B773D12EACCB53D4A (void);
// 0x0000035E System.Single UnityEngine.Mathf::GammaToLinearSpace(System.Single)
extern void Mathf_GammaToLinearSpace_m537DFDE30A58265FDA50F4D245B9599BBA8A4772 (void);
// 0x0000035F System.Single UnityEngine.Mathf::LinearToGammaSpace(System.Single)
extern void Mathf_LinearToGammaSpace_m2E1C2A97C0D476FB5659601D09500CC8DDE09F61 (void);
// 0x00000360 System.Single UnityEngine.Mathf::Sin(System.Single)
extern void Mathf_Sin_m5275643192EFB3BD27A722901C6A4228A0DB8BB6 (void);
// 0x00000361 System.Single UnityEngine.Mathf::Cos(System.Single)
extern void Mathf_Cos_mC5ECAE74D1FE9AF6F6EFF50AD3CD6BA1941B267A (void);
// 0x00000362 System.Single UnityEngine.Mathf::Tan(System.Single)
extern void Mathf_Tan_m436F7A034334BCB42BD46ABC94D1200C70E81A49 (void);
// 0x00000363 System.Single UnityEngine.Mathf::Acos(System.Single)
extern void Mathf_Acos_mF3B88F0C8A5AE43F4C4A42676C8D3DE67B3EAF82 (void);
// 0x00000364 System.Single UnityEngine.Mathf::Atan(System.Single)
extern void Mathf_Atan_m1FF47E958C869FCB8BADF804011E04736E23C6F9 (void);
// 0x00000365 System.Single UnityEngine.Mathf::Sqrt(System.Single)
extern void Mathf_Sqrt_mF1FBD3142F5A3BCC5C35DFB922A14765BC0A8E2B (void);
// 0x00000366 System.Single UnityEngine.Mathf::Abs(System.Single)
extern void Mathf_Abs_mD852D98E3D4846B45F57D0AD4A8C6E00EF272662 (void);
// 0x00000367 System.Single UnityEngine.Mathf::Min(System.Single,System.Single)
extern void Mathf_Min_mCF9BE0E9CAC9F18D207692BB2DAC7F3E1D4E1CB7 (void);
// 0x00000368 System.Int32 UnityEngine.Mathf::Min(System.Int32,System.Int32)
extern void Mathf_Min_m1A2CC204E361AE13C329B6535165179798D3313A (void);
// 0x00000369 System.Single UnityEngine.Mathf::Max(System.Single,System.Single)
extern void Mathf_Max_m670AE0EC1B09ED1A56FF9606B0F954670319CB65 (void);
// 0x0000036A System.Int32 UnityEngine.Mathf::Max(System.Int32,System.Int32)
extern void Mathf_Max_mBDE4C6F1883EE3215CD7AE62550B2AC90592BC3F (void);
// 0x0000036B System.Single UnityEngine.Mathf::Pow(System.Single,System.Single)
extern void Mathf_Pow_mC1BFA8F6235567CBB31F3D9507A6275635A38B5F (void);
// 0x0000036C System.Single UnityEngine.Mathf::Exp(System.Single)
extern void Mathf_Exp_m7C92A75E0245B9FAEE93683523C22910C0877693 (void);
// 0x0000036D System.Single UnityEngine.Mathf::Log(System.Single,System.Single)
extern void Mathf_Log_mD0CFD1242805BD697B5156AA46FBB43E7636A19B (void);
// 0x0000036E System.Single UnityEngine.Mathf::Log(System.Single)
extern void Mathf_Log_m3D3FFA950CF7BC75C2C13E3F22950FF3314CAB61 (void);
// 0x0000036F System.Single UnityEngine.Mathf::Ceil(System.Single)
extern void Mathf_Ceil_m4FC7645E3D0F8FEDC33FE507E3D913108DD94E94 (void);
// 0x00000370 System.Single UnityEngine.Mathf::Floor(System.Single)
extern void Mathf_Floor_mD447D35DE1D81DE09C2EFE21A75F0444E2AEF9E1 (void);
// 0x00000371 System.Single UnityEngine.Mathf::Round(System.Single)
extern void Mathf_Round_mC8FAD403F9E68B0339CF65C8F63BFA3107DB3FC9 (void);
// 0x00000372 System.Int32 UnityEngine.Mathf::CeilToInt(System.Single)
extern void Mathf_CeilToInt_m0230CCC7CC9266F18125D9425C38A25D1CA4275B (void);
// 0x00000373 System.Int32 UnityEngine.Mathf::FloorToInt(System.Single)
extern void Mathf_FloorToInt_m0C42B64571CE92A738AD7BB82388CE12FBE7457C (void);
// 0x00000374 System.Int32 UnityEngine.Mathf::RoundToInt(System.Single)
extern void Mathf_RoundToInt_m0EAD8BD38FCB72FA1D8A04E96337C820EC83F041 (void);
// 0x00000375 System.Single UnityEngine.Mathf::Sign(System.Single)
extern void Mathf_Sign_m6FA1D12786BEE0419D4B9426E5E4955F286BC8D3 (void);
// 0x00000376 System.Single UnityEngine.Mathf::Clamp(System.Single,System.Single,System.Single)
extern void Mathf_Clamp_m033DD894F89E6DCCDAFC580091053059C86A4507 (void);
// 0x00000377 System.Int32 UnityEngine.Mathf::Clamp(System.Int32,System.Int32,System.Int32)
extern void Mathf_Clamp_mE1EA15D719BF2F632741D42DF96F0BC797A20389 (void);
// 0x00000378 System.Single UnityEngine.Mathf::Clamp01(System.Single)
extern void Mathf_Clamp01_m1E5F736941A7E6DC4DBCA88A1E38FE9FBFE0C42B (void);
// 0x00000379 System.Single UnityEngine.Mathf::Lerp(System.Single,System.Single,System.Single)
extern void Mathf_Lerp_m9A74C5A0C37D0CDF45EE66E7774D12A9B93B1364 (void);
// 0x0000037A System.Boolean UnityEngine.Mathf::Approximately(System.Single,System.Single)
extern void Mathf_Approximately_m91AF00403E0D2DEA1AAE68601AD218CFAD70DF7E (void);
// 0x0000037B System.Single UnityEngine.Mathf::SmoothDamp(System.Single,System.Single,System.Single&,System.Single,System.Single,System.Single)
extern void Mathf_SmoothDamp_m00F6830F4979901CACDE66A7CEECD8AA467342C8 (void);
// 0x0000037C System.Single UnityEngine.Mathf::Repeat(System.Single,System.Single)
extern void Mathf_Repeat_m8459F4AAFF92DB770CC892BF71EE9438D9D0F779 (void);
// 0x0000037D System.Single UnityEngine.Mathf::InverseLerp(System.Single,System.Single,System.Single)
extern void Mathf_InverseLerp_m7054CDF25056E9B27D2467F91C95D628508F1F31 (void);
// 0x0000037E System.Void UnityEngine.Mathf::.cctor()
extern void Mathf__cctor_m4855BF06F66120E2029CFA4F3E82FBDB197A86EC (void);
// 0x0000037F System.Single UnityEngine.Vector2::get_Item(System.Int32)
extern void Vector2_get_Item_m67344A67120E48C32D9419E24BA7AED29F063379_AdjustorThunk (void);
// 0x00000380 System.Void UnityEngine.Vector2::set_Item(System.Int32,System.Single)
extern void Vector2_set_Item_m2335DC41E2BB7E64C21CDF0EEDE64FFB56E7ABD1_AdjustorThunk (void);
// 0x00000381 System.Void UnityEngine.Vector2::.ctor(System.Single,System.Single)
extern void Vector2__ctor_mEE8FB117AB1F8DB746FB8B3EB4C0DA3BF2A230D0_AdjustorThunk (void);
// 0x00000382 UnityEngine.Vector2 UnityEngine.Vector2::Scale(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_Scale_m7AA97B65C683CB3B0BCBC61270A7F1A6350355A2 (void);
// 0x00000383 System.Void UnityEngine.Vector2::Normalize()
extern void Vector2_Normalize_m99A2CC6E4CB65C1B9231F898D5B7A12B6D72E722_AdjustorThunk (void);
// 0x00000384 UnityEngine.Vector2 UnityEngine.Vector2::get_normalized()
extern void Vector2_get_normalized_m058E75C38C6FC66E178D7C8EF1B6298DE8F0E14B_AdjustorThunk (void);
// 0x00000385 System.String UnityEngine.Vector2::ToString()
extern void Vector2_ToString_m83C7C331834382748956B053E252AE3BD21807C4_AdjustorThunk (void);
// 0x00000386 System.Int32 UnityEngine.Vector2::GetHashCode()
extern void Vector2_GetHashCode_m028AB6B14EBC6D668CFA45BF6EDEF17E2C44EA54_AdjustorThunk (void);
// 0x00000387 System.Boolean UnityEngine.Vector2::Equals(System.Object)
extern void Vector2_Equals_m4A2A75BC3D09933321220BCEF21219B38AF643AE_AdjustorThunk (void);
// 0x00000388 System.Boolean UnityEngine.Vector2::Equals(UnityEngine.Vector2)
extern void Vector2_Equals_mD6BF1A738E3CAF57BB46E604B030C072728F4EEB_AdjustorThunk (void);
// 0x00000389 System.Single UnityEngine.Vector2::Dot(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_Dot_m34F6A75BE3FC6F728233811943AC4406C7D905BA (void);
// 0x0000038A System.Single UnityEngine.Vector2::get_magnitude()
extern void Vector2_get_magnitude_m66097AFDF9696BD3E88467D4398D4F82B8A4C7DF_AdjustorThunk (void);
// 0x0000038B System.Single UnityEngine.Vector2::get_sqrMagnitude()
extern void Vector2_get_sqrMagnitude_mAEE10A8ECE7D5754E10727BA8C9068A759AD7002_AdjustorThunk (void);
// 0x0000038C System.Single UnityEngine.Vector2::Distance(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_Distance_mB07492BC42EC582754AD11554BE5B7F8D0E93CF4 (void);
// 0x0000038D UnityEngine.Vector2 UnityEngine.Vector2::op_Addition(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_op_Addition_m81A4D928B8E399DA3A4E3ACD8937EDFDCB014682 (void);
// 0x0000038E UnityEngine.Vector2 UnityEngine.Vector2::op_Subtraction(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_op_Subtraction_m2B347E4311EDBBBF27573E34899D2492E6B063C0 (void);
// 0x0000038F UnityEngine.Vector2 UnityEngine.Vector2::op_Multiply(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_op_Multiply_mEDF9FDDF3BFFAEC997FBCDE5FA34871F2955E7C4 (void);
// 0x00000390 UnityEngine.Vector2 UnityEngine.Vector2::op_Division(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_op_Division_mEF4FA1379564288637A7CF5E73BA30CA2259E591 (void);
// 0x00000391 UnityEngine.Vector2 UnityEngine.Vector2::op_UnaryNegation(UnityEngine.Vector2)
extern void Vector2_op_UnaryNegation_m3FA0AE2F9B031765EFA566B25F5453C3B001FF4D (void);
// 0x00000392 UnityEngine.Vector2 UnityEngine.Vector2::op_Multiply(UnityEngine.Vector2,System.Single)
extern void Vector2_op_Multiply_m8A843A37F2F3199EBE99DC7BDABC1DC2EE01AF56 (void);
// 0x00000393 UnityEngine.Vector2 UnityEngine.Vector2::op_Division(UnityEngine.Vector2,System.Single)
extern void Vector2_op_Division_m0961A935168EE6701E098E2B37013DFFF46A5077 (void);
// 0x00000394 System.Boolean UnityEngine.Vector2::op_Equality(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_op_Equality_m0E86E1B1038DDB8554A8A0D58729A7788D989588 (void);
// 0x00000395 System.Boolean UnityEngine.Vector2::op_Inequality(UnityEngine.Vector2,UnityEngine.Vector2)
extern void Vector2_op_Inequality_mC16161C640C89D98A00800924F83FF09FD7C100E (void);
// 0x00000396 UnityEngine.Vector2 UnityEngine.Vector2::op_Implicit(UnityEngine.Vector3)
extern void Vector2_op_Implicit_mEA1F75961E3D368418BA8CEB9C40E55C25BA3C28 (void);
// 0x00000397 UnityEngine.Vector3 UnityEngine.Vector2::op_Implicit(UnityEngine.Vector2)
extern void Vector2_op_Implicit_mD152B6A34B4DB7FFECC2844D74718568FE867D6F (void);
// 0x00000398 UnityEngine.Vector2 UnityEngine.Vector2::get_zero()
extern void Vector2_get_zero_mFE0C3213BB698130D6C5247AB4B887A59074D0A8 (void);
// 0x00000399 UnityEngine.Vector2 UnityEngine.Vector2::get_one()
extern void Vector2_get_one_m6E01BE09CEA40781CB12CCB6AF33BBDA0F60CEED (void);
// 0x0000039A UnityEngine.Vector2 UnityEngine.Vector2::get_up()
extern void Vector2_get_up_mC4548731D5E7C71164D18C390A1AC32501DAE441 (void);
// 0x0000039B UnityEngine.Vector2 UnityEngine.Vector2::get_down()
extern void Vector2_get_down_mCB2BC667A6C70DCA1B522DEA470F9C9DDA3D2F0F (void);
// 0x0000039C UnityEngine.Vector2 UnityEngine.Vector2::get_right()
extern void Vector2_get_right_mB4BD67462D579461853F297C0DE85D81E07E911E (void);
// 0x0000039D UnityEngine.Vector2 UnityEngine.Vector2::get_negativeInfinity()
extern void Vector2_get_negativeInfinity_mCD1BFAFDD738F768ACF2A6C712689D6C8956597F (void);
// 0x0000039E System.Void UnityEngine.Vector2::.cctor()
extern void Vector2__cctor_m13D18E02B3AC28597F5049D2F54830C9E4BDBE84 (void);
// 0x0000039F System.Int32 UnityEngine.Vector2Int::get_x()
extern void Vector2Int_get_x_m300C7C05CD66D24EE62D91CDC0C557A6C0ABF25E_AdjustorThunk (void);
// 0x000003A0 System.Void UnityEngine.Vector2Int::set_x(System.Int32)
extern void Vector2Int_set_x_mC6F9F1E43668A7F8E8C44CEFB427BA97389F1420_AdjustorThunk (void);
// 0x000003A1 System.Int32 UnityEngine.Vector2Int::get_y()
extern void Vector2Int_get_y_m0D6E131AB5FA4AD532DEC377F981AADA189E680B_AdjustorThunk (void);
// 0x000003A2 System.Void UnityEngine.Vector2Int::set_y(System.Int32)
extern void Vector2Int_set_y_mF79CD7FACF0A9A1CC12678E2E24BD43C5E836D88_AdjustorThunk (void);
// 0x000003A3 System.Void UnityEngine.Vector2Int::.ctor(System.Int32,System.Int32)
extern void Vector2Int__ctor_m501C34762BA7ECDDCFC25C19A4B9C93BC15004E1_AdjustorThunk (void);
// 0x000003A4 UnityEngine.Vector2Int UnityEngine.Vector2Int::Max(UnityEngine.Vector2Int,UnityEngine.Vector2Int)
extern void Vector2Int_Max_m8B01A60534D0D8D91735C92E359B729DE81FBFD0 (void);
// 0x000003A5 UnityEngine.Vector2 UnityEngine.Vector2Int::op_Implicit(UnityEngine.Vector2Int)
extern void Vector2Int_op_Implicit_m05B84E680DA5408143C51CB664F97AC4702DC200 (void);
// 0x000003A6 System.Boolean UnityEngine.Vector2Int::op_Equality(UnityEngine.Vector2Int,UnityEngine.Vector2Int)
extern void Vector2Int_op_Equality_m7EDB885618BE7B785798F96DDDDA70E53461BB4B (void);
// 0x000003A7 System.Boolean UnityEngine.Vector2Int::op_Inequality(UnityEngine.Vector2Int,UnityEngine.Vector2Int)
extern void Vector2Int_op_Inequality_mAC8212BEC016167196A2EF04A381D3439070ECAE (void);
// 0x000003A8 System.Boolean UnityEngine.Vector2Int::Equals(System.Object)
extern void Vector2Int_Equals_mF7D7EFBC0286224832BA76701801C28530D40479_AdjustorThunk (void);
// 0x000003A9 System.Boolean UnityEngine.Vector2Int::Equals(UnityEngine.Vector2Int)
extern void Vector2Int_Equals_m65420C995F326F5C340E4825EA5E16BDE68F5A9C_AdjustorThunk (void);
// 0x000003AA System.Int32 UnityEngine.Vector2Int::GetHashCode()
extern void Vector2Int_GetHashCode_m73E874F4E94DF3D2603035E2E892873B139A7A9E_AdjustorThunk (void);
// 0x000003AB System.String UnityEngine.Vector2Int::ToString()
extern void Vector2Int_ToString_mB0D67C1885311767BA89D4C4A6E3A5A515194BF3_AdjustorThunk (void);
// 0x000003AC UnityEngine.Vector2Int UnityEngine.Vector2Int::get_zero()
extern void Vector2Int_get_zero_m40CBB0090688CF55366641596C62128561AA659C (void);
// 0x000003AD UnityEngine.Vector2Int UnityEngine.Vector2Int::get_one()
extern void Vector2Int_get_one_mD4B8C3B5B30E367C52D89BAD69B1026520737CC0 (void);
// 0x000003AE System.Void UnityEngine.Vector2Int::.cctor()
extern void Vector2Int__cctor_mCCA5D2394D22AB700421D56C1EB6998F4E3C810A (void);
// 0x000003AF System.Int32 UnityEngine.Vector3Int::get_x()
extern void Vector3Int_get_x_m23CB00F1579FD4CE86291940E2E75FB13405D53A_AdjustorThunk (void);
// 0x000003B0 System.Int32 UnityEngine.Vector3Int::get_y()
extern void Vector3Int_get_y_m1C2F0AB641A167DF22F9C3C57092EC05AEF8CA26_AdjustorThunk (void);
// 0x000003B1 System.Int32 UnityEngine.Vector3Int::get_z()
extern void Vector3Int_get_z_m9A88DC2346FD1838EC611CC8AB2FC29951E94183_AdjustorThunk (void);
// 0x000003B2 System.Void UnityEngine.Vector3Int::.ctor(System.Int32,System.Int32,System.Int32)
extern void Vector3Int__ctor_m171D642C38B163B353DAE9CCE90ACFE0894C1156_AdjustorThunk (void);
// 0x000003B3 System.Boolean UnityEngine.Vector3Int::op_Equality(UnityEngine.Vector3Int,UnityEngine.Vector3Int)
extern void Vector3Int_op_Equality_mC2E3A3395AC3E18397283F3CBEA7167B2E463DFC (void);
// 0x000003B4 System.Boolean UnityEngine.Vector3Int::Equals(System.Object)
extern void Vector3Int_Equals_m704D204F83B9C64C7AF06152F98B542C5C400DC7_AdjustorThunk (void);
// 0x000003B5 System.Boolean UnityEngine.Vector3Int::Equals(UnityEngine.Vector3Int)
extern void Vector3Int_Equals_m9F98F28666ADF5AD0575C4CABAF6881F1317D4C1_AdjustorThunk (void);
// 0x000003B6 System.Int32 UnityEngine.Vector3Int::GetHashCode()
extern void Vector3Int_GetHashCode_m6CDE2FEC995180949111253817BD0E4ECE7EAE3D_AdjustorThunk (void);
// 0x000003B7 System.String UnityEngine.Vector3Int::ToString()
extern void Vector3Int_ToString_m08AB1BE6A674B2669839B1C44ACCF6D85EBCFB91_AdjustorThunk (void);
// 0x000003B8 System.Void UnityEngine.Vector3Int::.cctor()
extern void Vector3Int__cctor_m0EE114B6FDC7C783EF7B206D4E25F5CE900003C9 (void);
// 0x000003B9 System.Single UnityEngine.Vector4::get_Item(System.Int32)
extern void Vector4_get_Item_m39878FDA732B20347BB37CD1485560E9267EDC98_AdjustorThunk (void);
// 0x000003BA System.Void UnityEngine.Vector4::set_Item(System.Int32,System.Single)
extern void Vector4_set_Item_m56FB3A149299FEF1C0CF638CFAF71C7F0685EE45_AdjustorThunk (void);
// 0x000003BB System.Void UnityEngine.Vector4::.ctor(System.Single,System.Single,System.Single,System.Single)
extern void Vector4__ctor_m545458525879607A5392A10B175D0C19B2BC715D_AdjustorThunk (void);
// 0x000003BC System.Void UnityEngine.Vector4::.ctor(System.Single,System.Single)
extern void Vector4__ctor_mFADAC87CAF1F57AD3FE715E6930D78BF7D303D81_AdjustorThunk (void);
// 0x000003BD System.Int32 UnityEngine.Vector4::GetHashCode()
extern void Vector4_GetHashCode_m7329FEA2E90CDBDBF4F09F51D92C87E08F5DC92E_AdjustorThunk (void);
// 0x000003BE System.Boolean UnityEngine.Vector4::Equals(System.Object)
extern void Vector4_Equals_m552ECA9ECD220D6526D8ECC9902016B6FC6D49B5_AdjustorThunk (void);
// 0x000003BF System.Boolean UnityEngine.Vector4::Equals(UnityEngine.Vector4)
extern void Vector4_Equals_mB9894C2D4EE56C6E8FDF6CC40DCE0CE16BA4F7BF_AdjustorThunk (void);
// 0x000003C0 System.Single UnityEngine.Vector4::Dot(UnityEngine.Vector4,UnityEngine.Vector4)
extern void Vector4_Dot_m9FAE8FE89CF99841AD8D2113DFCDB8764F9FBB18 (void);
// 0x000003C1 System.Single UnityEngine.Vector4::get_sqrMagnitude()
extern void Vector4_get_sqrMagnitude_m6B2707CBD31D237605D066A5925E6419D28B5397_AdjustorThunk (void);
// 0x000003C2 UnityEngine.Vector4 UnityEngine.Vector4::get_zero()
extern void Vector4_get_zero_m42821248DDFA4F9A3E0B2E84CBCB737BE9DCE3E9 (void);
// 0x000003C3 UnityEngine.Vector4 UnityEngine.Vector4::op_Addition(UnityEngine.Vector4,UnityEngine.Vector4)
extern void Vector4_op_Addition_m2079975CEB29719BDECFA861B53E499C70AA7015 (void);
// 0x000003C4 UnityEngine.Vector4 UnityEngine.Vector4::op_UnaryNegation(UnityEngine.Vector4)
extern void Vector4_op_UnaryNegation_m80D997A3F98FA21070490720343B60F22144B447 (void);
// 0x000003C5 UnityEngine.Vector4 UnityEngine.Vector4::op_Multiply(System.Single,UnityEngine.Vector4)
extern void Vector4_op_Multiply_mC2CF8F5A9CA3041B34527E66770AEBA5E58B84F0 (void);
// 0x000003C6 UnityEngine.Vector4 UnityEngine.Vector4::op_Division(UnityEngine.Vector4,System.Single)
extern void Vector4_op_Division_m1D1BD7FFEF0CDBB7CE063CA139C22210A0B76689 (void);
// 0x000003C7 System.Boolean UnityEngine.Vector4::op_Equality(UnityEngine.Vector4,UnityEngine.Vector4)
extern void Vector4_op_Equality_m9AE0D09EC7E02201F94AE469ADE9F416D0E20441 (void);
// 0x000003C8 UnityEngine.Vector4 UnityEngine.Vector4::op_Implicit(UnityEngine.Vector3)
extern void Vector4_op_Implicit_m5BFA8D95F88CB2AEA6E02B200A61B718314A8495 (void);
// 0x000003C9 UnityEngine.Vector3 UnityEngine.Vector4::op_Implicit(UnityEngine.Vector4)
extern void Vector4_op_Implicit_mEAB05A77FF8B3EE79C31499F0CF0A0D621A6496C (void);
// 0x000003CA UnityEngine.Vector4 UnityEngine.Vector4::op_Implicit(UnityEngine.Vector2)
extern void Vector4_op_Implicit_m3CB789809FDA1B5598EC3C928B173C62FC152656 (void);
// 0x000003CB System.String UnityEngine.Vector4::ToString()
extern void Vector4_ToString_m769402E3F7CBD6C92464D916527CC87BBBA53EF9_AdjustorThunk (void);
// 0x000003CC System.Void UnityEngine.Vector4::.cctor()
extern void Vector4__cctor_m478FA6A83B8E23F8323F150FF90B1FB934B1C251 (void);
// 0x000003CD System.Void UnityEngine.IPlayerEditorConnectionNative::Initialize()
// 0x000003CE System.Void UnityEngine.IPlayerEditorConnectionNative::DisconnectAll()
// 0x000003CF System.Void UnityEngine.IPlayerEditorConnectionNative::SendMessage(System.Guid,System.Byte[],System.Int32)
// 0x000003D0 System.Boolean UnityEngine.IPlayerEditorConnectionNative::TrySendMessage(System.Guid,System.Byte[],System.Int32)
// 0x000003D1 System.Void UnityEngine.IPlayerEditorConnectionNative::Poll()
// 0x000003D2 System.Void UnityEngine.IPlayerEditorConnectionNative::RegisterInternal(System.Guid)
// 0x000003D3 System.Void UnityEngine.IPlayerEditorConnectionNative::UnregisterInternal(System.Guid)
// 0x000003D4 System.Boolean UnityEngine.IPlayerEditorConnectionNative::IsConnected()
// 0x000003D5 System.Void UnityEngine.PlayerConnectionInternal::UnityEngine.IPlayerEditorConnectionNative.SendMessage(System.Guid,System.Byte[],System.Int32)
extern void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_SendMessage_m00395F263B4C7FD7F10C32B1F4C4C1F00503D4BB (void);
// 0x000003D6 System.Boolean UnityEngine.PlayerConnectionInternal::UnityEngine.IPlayerEditorConnectionNative.TrySendMessage(System.Guid,System.Byte[],System.Int32)
extern void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_TrySendMessage_m950332D66588946F8699A64E5B8DBA8956A45303 (void);
// 0x000003D7 System.Void UnityEngine.PlayerConnectionInternal::UnityEngine.IPlayerEditorConnectionNative.Poll()
extern void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_Poll_mEAAE7671B5D8E0360BFE50E61E89FFF65DB825E4 (void);
// 0x000003D8 System.Void UnityEngine.PlayerConnectionInternal::UnityEngine.IPlayerEditorConnectionNative.RegisterInternal(System.Guid)
extern void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_RegisterInternal_m991A5281F58D94FA0F095A538BD91CA72B864965 (void);
// 0x000003D9 System.Void UnityEngine.PlayerConnectionInternal::UnityEngine.IPlayerEditorConnectionNative.UnregisterInternal(System.Guid)
extern void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_UnregisterInternal_mAF6931079473185968AFCD40A23A610F7D6CC3A0 (void);
// 0x000003DA System.Void UnityEngine.PlayerConnectionInternal::UnityEngine.IPlayerEditorConnectionNative.Initialize()
extern void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_Initialize_mBC677B0244B87A53875C8C3A3A716DC09A8D541F (void);
// 0x000003DB System.Boolean UnityEngine.PlayerConnectionInternal::UnityEngine.IPlayerEditorConnectionNative.IsConnected()
extern void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_IsConnected_m08B0A552BE45CC80F911E22D990B8FE6C82B53DD (void);
// 0x000003DC System.Void UnityEngine.PlayerConnectionInternal::UnityEngine.IPlayerEditorConnectionNative.DisconnectAll()
extern void PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_DisconnectAll_m5849A206AC5D274115B352114BD5F4B72900F651 (void);
// 0x000003DD System.Boolean UnityEngine.PlayerConnectionInternal::IsConnected()
extern void PlayerConnectionInternal_IsConnected_m4AD0EABFF2FCE8DE9DE1A6B520C707F300721FB2 (void);
// 0x000003DE System.Void UnityEngine.PlayerConnectionInternal::Initialize()
extern void PlayerConnectionInternal_Initialize_mB0E05590ED32D5DCD074FD6CB60064F8A96BB4FD (void);
// 0x000003DF System.Void UnityEngine.PlayerConnectionInternal::RegisterInternal(System.String)
extern void PlayerConnectionInternal_RegisterInternal_mC3FB67053C4C7DB1AABAB7E78E1F1345720ED84F (void);
// 0x000003E0 System.Void UnityEngine.PlayerConnectionInternal::UnregisterInternal(System.String)
extern void PlayerConnectionInternal_UnregisterInternal_m675B2C87E01FCBBF5CB1A205375A2E95A8F150B2 (void);
// 0x000003E1 System.Void UnityEngine.PlayerConnectionInternal::SendMessage(System.String,System.Byte[],System.Int32)
extern void PlayerConnectionInternal_SendMessage_m83801DCA5BBCC8116F1C7898FB6A755CCAF6F928 (void);
// 0x000003E2 System.Boolean UnityEngine.PlayerConnectionInternal::TrySendMessage(System.String,System.Byte[],System.Int32)
extern void PlayerConnectionInternal_TrySendMessage_mE31F212ED59D69FD01FC2B6B4503A5AF97C1948D (void);
// 0x000003E3 System.Void UnityEngine.PlayerConnectionInternal::PollInternal()
extern void PlayerConnectionInternal_PollInternal_m46079D478471FAB04EE8E613CAE8F6E79822472E (void);
// 0x000003E4 System.Void UnityEngine.PlayerConnectionInternal::DisconnectAll()
extern void PlayerConnectionInternal_DisconnectAll_m58AFB71131F174149D6AA98C312D9026C15C6090 (void);
// 0x000003E5 System.Void UnityEngine.PlayerConnectionInternal::.ctor()
extern void PlayerConnectionInternal__ctor_m882227F7C855BCF5CE1B0D44752124106BE31389 (void);
// 0x000003E6 System.Void UnityEngine.PropertyAttribute::.ctor()
extern void PropertyAttribute__ctor_m7F5C473F39D5601486C1127DA0D52F2DC293FC35 (void);
// 0x000003E7 System.Void UnityEngine.TooltipAttribute::.ctor(System.String)
extern void TooltipAttribute__ctor_m13242D6EEE484B1CCA7B3A8FA720C5BCC44AF5DF (void);
// 0x000003E8 System.Void UnityEngine.SpaceAttribute::.ctor()
extern void SpaceAttribute__ctor_m645A0DE9B507F2AFD8C67853D788F5F419D547C7 (void);
// 0x000003E9 System.Void UnityEngine.SpaceAttribute::.ctor(System.Single)
extern void SpaceAttribute__ctor_mA70DC7F5FDC5474223B45E0F71A9003BBED1EFD0 (void);
// 0x000003EA System.Void UnityEngine.HeaderAttribute::.ctor(System.String)
extern void HeaderAttribute__ctor_m0E05B3623D1742E60908E9E5E73CB6CE9C12A4DD (void);
// 0x000003EB System.Void UnityEngine.RangeAttribute::.ctor(System.Single,System.Single)
extern void RangeAttribute__ctor_mB9CC43849A074C59DD99F154215A755131D47D89 (void);
// 0x000003EC System.Void UnityEngine.TextAreaAttribute::.ctor(System.Int32,System.Int32)
extern void TextAreaAttribute__ctor_m6134ACE5D232B16A9433AA1F47081FAA9BAC1BA1 (void);
// 0x000003ED System.Void UnityEngine.ColorUsageAttribute::.ctor(System.Boolean)
extern void ColorUsageAttribute__ctor_m356D0BA237E55A0B1B843D3891A774E74F41D11A (void);
// 0x000003EE UnityEngine.PropertyName UnityEngine.PropertyNameUtils::PropertyNameFromString(System.String)
extern void PropertyNameUtils_PropertyNameFromString_m38F9FC2E83C99C0723DAC4BBC5A2A7EA87752174 (void);
// 0x000003EF System.Void UnityEngine.PropertyNameUtils::PropertyNameFromString_Injected(System.String,UnityEngine.PropertyName&)
extern void PropertyNameUtils_PropertyNameFromString_Injected_mB89F8191FB9B39ADA1F0C627AD130E4F6E37DB38 (void);
// 0x000003F0 System.Void UnityEngine.PropertyName::.ctor(System.String)
extern void PropertyName__ctor_mE0853FF14F978FFAF3EEE0B98DA973E17C962B37_AdjustorThunk (void);
// 0x000003F1 System.Void UnityEngine.PropertyName::.ctor(UnityEngine.PropertyName)
extern void PropertyName__ctor_mF8DCC97F6EC552F9313CE85ACC9D3357F45FA16D_AdjustorThunk (void);
// 0x000003F2 System.Boolean UnityEngine.PropertyName::op_Equality(UnityEngine.PropertyName,UnityEngine.PropertyName)
extern void PropertyName_op_Equality_m15312EA01DB9104A41667A1F7CFF6841E31DBD68 (void);
// 0x000003F3 System.Int32 UnityEngine.PropertyName::GetHashCode()
extern void PropertyName_GetHashCode_mBFB70A344042610A7EC9532BFBD83BB6623B128F_AdjustorThunk (void);
// 0x000003F4 System.Boolean UnityEngine.PropertyName::Equals(System.Object)
extern void PropertyName_Equals_mD2B2AD96A94DAFFAC506CF7E89C3493E5BA90CB1_AdjustorThunk (void);
// 0x000003F5 System.Boolean UnityEngine.PropertyName::Equals(UnityEngine.PropertyName)
extern void PropertyName_Equals_m1CA96DE357EEF70D3171B14B4836F121DA3B09A6_AdjustorThunk (void);
// 0x000003F6 System.String UnityEngine.PropertyName::ToString()
extern void PropertyName_ToString_mBB9266CFD39F9DDF58BECC30B5C85467C55E21C8_AdjustorThunk (void);
// 0x000003F7 System.Single UnityEngine.Random::get_value()
extern void Random_get_value_mC998749E08291DD42CF31C026FAC4F14F746831C (void);
// 0x000003F8 T UnityEngine.Resources::Load(System.String)
// 0x000003F9 UnityEngine.Object UnityEngine.Resources::Load(System.String,System.Type)
extern void Resources_Load_mF0FA033BF566CDDA6A0E69BB97283B44C40726E7 (void);
// 0x000003FA UnityEngine.Object UnityEngine.Resources::GetBuiltinResource(System.Type,System.String)
extern void Resources_GetBuiltinResource_m73DDAC485E1E06C925628AA7285AC63D0797BD0A (void);
// 0x000003FB T UnityEngine.Resources::GetBuiltinResource(System.String)
// 0x000003FC System.Void UnityEngine.AsyncOperation::InvokeCompletionEvent()
extern void AsyncOperation_InvokeCompletionEvent_m5F86FF01A5143016630C9CFADF6AA01DBBBD73A5 (void);
// 0x000003FD System.Type UnityEngine.AttributeHelperEngine::GetParentTypeDisallowingMultipleInclusion(System.Type)
extern void AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m716999F8F469E9398A275432AA5C68E81DD8DB24 (void);
// 0x000003FE System.Type[] UnityEngine.AttributeHelperEngine::GetRequiredComponents(System.Type)
extern void AttributeHelperEngine_GetRequiredComponents_m869E1FF24FE124874E0723E11C12A906E57E3007 (void);
// 0x000003FF System.Int32 UnityEngine.AttributeHelperEngine::GetExecuteMode(System.Type)
extern void AttributeHelperEngine_GetExecuteMode_mDE99262C53FA67B470B8668A13F968B4D5A8E0A1 (void);
// 0x00000400 System.Int32 UnityEngine.AttributeHelperEngine::CheckIsEditorScript(System.Type)
extern void AttributeHelperEngine_CheckIsEditorScript_m95CEEF4147D16BC2985EAADD300905AB736F857E (void);
// 0x00000401 System.Int32 UnityEngine.AttributeHelperEngine::GetDefaultExecutionOrderFor(System.Type)
extern void AttributeHelperEngine_GetDefaultExecutionOrderFor_m0972E47FA03C9CEF196B1E7B2E708E30DF4AD063 (void);
// 0x00000402 T UnityEngine.AttributeHelperEngine::GetCustomAttributeOfType(System.Type)
// 0x00000403 System.Void UnityEngine.AttributeHelperEngine::.cctor()
extern void AttributeHelperEngine__cctor_mAE0863DCF7EF9C1806BDC1D4DF64573464674964 (void);
// 0x00000404 System.Void UnityEngine.DisallowMultipleComponent::.ctor()
extern void DisallowMultipleComponent__ctor_m108E5D8C0DB938F0A747C6D2BA481B4FA9CDECB3 (void);
// 0x00000405 System.Void UnityEngine.RequireComponent::.ctor(System.Type)
extern void RequireComponent__ctor_m27819B55F8BD1517378CEFECA00FB183A13D9397 (void);
// 0x00000406 System.Void UnityEngine.AddComponentMenu::.ctor(System.String)
extern void AddComponentMenu__ctor_m33A9DE8FEE9BC9C12F67CF58BFEBECA372C236A3 (void);
// 0x00000407 System.Void UnityEngine.AddComponentMenu::.ctor(System.String,System.Int32)
extern void AddComponentMenu__ctor_m78D1D62B91D88424AE2175501B17E4609EF645EA (void);
// 0x00000408 System.Void UnityEngine.ExecuteInEditMode::.ctor()
extern void ExecuteInEditMode__ctor_m9A67409D4A11562F23F928655D9A3EFB7A69BB81 (void);
// 0x00000409 System.Void UnityEngine.ExecuteAlways::.ctor()
extern void ExecuteAlways__ctor_m6199E1FB2E787ABEE85C19153D3C90B815572092 (void);
// 0x0000040A System.Void UnityEngine.HideInInspector::.ctor()
extern void HideInInspector__ctor_mED96F804290F203756C1EDDE57F47C0E5A8FF4B4 (void);
// 0x0000040B System.Void UnityEngine.HelpURLAttribute::.ctor(System.String)
extern void HelpURLAttribute__ctor_mE8D73F64B451D3746E3427E74D332B7731D9D3AB (void);
// 0x0000040C System.Int32 UnityEngine.DefaultExecutionOrder::get_order()
extern void DefaultExecutionOrder_get_order_mFD2CD99AEF550E218FAFC6CB3DDA3CE8D78614A9 (void);
// 0x0000040D System.Void UnityEngine.ExcludeFromPresetAttribute::.ctor()
extern void ExcludeFromPresetAttribute__ctor_mB8BE49E17E4360DDB485784D219AE49847A85FB2 (void);
// 0x0000040E System.Boolean UnityEngine.Behaviour::get_enabled()
extern void Behaviour_get_enabled_mAA0C9ED5A3D1589C1C8AA22636543528DB353CFB (void);
// 0x0000040F System.Void UnityEngine.Behaviour::set_enabled(System.Boolean)
extern void Behaviour_set_enabled_m9755D3B17D7022D23D1E4C618BD9A6B66A5ADC6B (void);
// 0x00000410 System.Boolean UnityEngine.Behaviour::get_isActiveAndEnabled()
extern void Behaviour_get_isActiveAndEnabled_mC42DFCC1ECC2C94D52928FFE446CE7E266CA8B61 (void);
// 0x00000411 System.Void UnityEngine.Behaviour::.ctor()
extern void Behaviour__ctor_m409AEC21511ACF9A4CC0654DF4B8253E0D81D22C (void);
// 0x00000412 System.Void UnityEngine.ClassLibraryInitializer::Init()
extern void ClassLibraryInitializer_Init_mB8588C1A9DD9CB6B5CE77DB1F79AE301C46E0CE7 (void);
// 0x00000413 UnityEngine.Transform UnityEngine.Component::get_transform()
extern void Component_get_transform_m00F05BD782F920C301A7EBA480F3B7A904C07EC9 (void);
// 0x00000414 UnityEngine.GameObject UnityEngine.Component::get_gameObject()
extern void Component_get_gameObject_m0B0570BA8DDD3CD78A9DB568EA18D7317686603C (void);
// 0x00000415 UnityEngine.Component UnityEngine.Component::GetComponent(System.Type)
extern void Component_GetComponent_m5E75925F29811EEC97BD17CDC7D4BD8460F3090F (void);
// 0x00000416 System.Void UnityEngine.Component::GetComponentFastPath(System.Type,System.IntPtr)
extern void Component_GetComponentFastPath_mDEB49C6B56084E436C7FC3D555339FA16949937E (void);
// 0x00000417 T UnityEngine.Component::GetComponent()
// 0x00000418 System.Boolean UnityEngine.Component::TryGetComponent(T&)
// 0x00000419 UnityEngine.Component UnityEngine.Component::GetComponentInChildren(System.Type,System.Boolean)
extern void Component_GetComponentInChildren_mEF7890FAC10EA2F776464285B0DCC58B8C373D34 (void);
// 0x0000041A T UnityEngine.Component::GetComponentInChildren(System.Boolean)
// 0x0000041B T UnityEngine.Component::GetComponentInChildren()
// 0x0000041C T[] UnityEngine.Component::GetComponentsInChildren(System.Boolean)
// 0x0000041D System.Void UnityEngine.Component::GetComponentsInChildren(System.Boolean,System.Collections.Generic.List`1<T>)
// 0x0000041E T[] UnityEngine.Component::GetComponentsInChildren()
// 0x0000041F System.Void UnityEngine.Component::GetComponentsInChildren(System.Collections.Generic.List`1<T>)
// 0x00000420 UnityEngine.Component UnityEngine.Component::GetComponentInParent(System.Type)
extern void Component_GetComponentInParent_mFD9A8F6311ABAF986CA0DA556662F89FD9234E7D (void);
// 0x00000421 T UnityEngine.Component::GetComponentInParent()
// 0x00000422 T[] UnityEngine.Component::GetComponentsInParent(System.Boolean)
// 0x00000423 System.Void UnityEngine.Component::GetComponentsInParent(System.Boolean,System.Collections.Generic.List`1<T>)
// 0x00000424 T[] UnityEngine.Component::GetComponentsInParent()
// 0x00000425 System.Void UnityEngine.Component::GetComponentsForListInternal(System.Type,System.Object)
extern void Component_GetComponentsForListInternal_m469B4C3A883942213BEA0EAAA54629219A042480 (void);
// 0x00000426 System.Void UnityEngine.Component::GetComponents(System.Type,System.Collections.Generic.List`1<UnityEngine.Component>)
extern void Component_GetComponents_m1ACBE6B9A75ECC898BA3B21D59AA7B3339D7735A (void);
// 0x00000427 System.Void UnityEngine.Component::GetComponents(System.Collections.Generic.List`1<T>)
// 0x00000428 T[] UnityEngine.Component::GetComponents()
// 0x00000429 System.Void UnityEngine.Component::.ctor()
extern void Component__ctor_m5E2740C0ACA4B368BC460315FAA2EDBFEAC0B8EF (void);
// 0x0000042A System.Void UnityEngine.Coroutine::.ctor()
extern void Coroutine__ctor_mCA679040DA81B31D1E341400E98F6CF569269201 (void);
// 0x0000042B System.Void UnityEngine.Coroutine::Finalize()
extern void Coroutine_Finalize_mACCDC3AFBA7F1D247231AA875B5099200AF9ECC5 (void);
// 0x0000042C System.Void UnityEngine.Coroutine::ReleaseCoroutine(System.IntPtr)
extern void Coroutine_ReleaseCoroutine_mD33DD220788EEA099B98DD1258D6332A46D3D571 (void);
// 0x0000042D System.Void UnityEngine.SetupCoroutine::InvokeMoveNext(System.Collections.IEnumerator,System.IntPtr)
extern void SetupCoroutine_InvokeMoveNext_m9106BA4E8AE0E794B17F184F1021A53F1D071F31 (void);
// 0x0000042E System.Object UnityEngine.SetupCoroutine::InvokeMember(System.Object,System.String,System.Object)
extern void SetupCoroutine_InvokeMember_m0F2AD1D817B8E221C0DCAB9A81DA8359B20A8EFB (void);
// 0x0000042F System.Boolean UnityEngine.CustomYieldInstruction::get_keepWaiting()
// 0x00000430 System.Object UnityEngine.CustomYieldInstruction::get_Current()
extern void CustomYieldInstruction_get_Current_m9B2B482ED92A58E85B4D90A5AC7C89DFF87E33DC (void);
// 0x00000431 System.Boolean UnityEngine.CustomYieldInstruction::MoveNext()
extern void CustomYieldInstruction_MoveNext_m7EA6BAAEF6A01DC791D0B013D5AB5C377F9A6990 (void);
// 0x00000432 System.Void UnityEngine.CustomYieldInstruction::Reset()
extern void CustomYieldInstruction_Reset_m9B3349022DFDDA3A059F14D199F2408725727290 (void);
// 0x00000433 System.Void UnityEngine.CustomYieldInstruction::.ctor()
extern void CustomYieldInstruction__ctor_m06E2B5BC73763FE2E734FAA600D567701EA21EC5 (void);
// 0x00000434 System.Void UnityEngine.ExcludeFromObjectFactoryAttribute::.ctor()
extern void ExcludeFromObjectFactoryAttribute__ctor_mE0437C73993AD36DCB7A002D70AC988340742CD0 (void);
// 0x00000435 System.Void UnityEngine.ExtensionOfNativeClassAttribute::.ctor()
extern void ExtensionOfNativeClassAttribute__ctor_m2D759F6D70D6FE632D8872A7D7C3E7ECFF83EE46 (void);
// 0x00000436 T UnityEngine.GameObject::GetComponent()
// 0x00000437 UnityEngine.Component UnityEngine.GameObject::GetComponent(System.Type)
extern void GameObject_GetComponent_mECB756C7EB39F6BB79F8C065AB0013354763B151 (void);
// 0x00000438 System.Void UnityEngine.GameObject::GetComponentFastPath(System.Type,System.IntPtr)
extern void GameObject_GetComponentFastPath_m5B276335DD94F6B307E604272A26C15B997C3CD4 (void);
// 0x00000439 UnityEngine.Component UnityEngine.GameObject::GetComponentInChildren(System.Type,System.Boolean)
extern void GameObject_GetComponentInChildren_mBC5C12CDA1749A827D136DABBF10498B1096A086 (void);
// 0x0000043A T UnityEngine.GameObject::GetComponentInChildren()
// 0x0000043B T UnityEngine.GameObject::GetComponentInChildren(System.Boolean)
// 0x0000043C UnityEngine.Component UnityEngine.GameObject::GetComponentInParent(System.Type)
extern void GameObject_GetComponentInParent_mA5BF9DFCA90C9003EB8F392CD64C45DFCB80F988 (void);
// 0x0000043D System.Array UnityEngine.GameObject::GetComponentsInternal(System.Type,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.Object)
extern void GameObject_GetComponentsInternal_mAB759217A3AD0831ABD9387163126D391459E1B8 (void);
// 0x0000043E T[] UnityEngine.GameObject::GetComponents()
// 0x0000043F System.Void UnityEngine.GameObject::GetComponents(System.Collections.Generic.List`1<T>)
// 0x00000440 T[] UnityEngine.GameObject::GetComponentsInChildren(System.Boolean)
// 0x00000441 System.Void UnityEngine.GameObject::GetComponentsInChildren(System.Boolean,System.Collections.Generic.List`1<T>)
// 0x00000442 System.Void UnityEngine.GameObject::GetComponentsInParent(System.Boolean,System.Collections.Generic.List`1<T>)
// 0x00000443 T[] UnityEngine.GameObject::GetComponentsInParent(System.Boolean)
// 0x00000444 System.Boolean UnityEngine.GameObject::TryGetComponent(T&)
// 0x00000445 System.Void UnityEngine.GameObject::TryGetComponentFastPath(System.Type,System.IntPtr)
extern void GameObject_TryGetComponentFastPath_mBCE2196B5F774DB34EAE23EA89FDAFB427A04AC2 (void);
// 0x00000446 UnityEngine.Component UnityEngine.GameObject::Internal_AddComponentWithType(System.Type)
extern void GameObject_Internal_AddComponentWithType_m452B72618245B846503E5CA7DEA4662A77FB9896 (void);
// 0x00000447 UnityEngine.Component UnityEngine.GameObject::AddComponent(System.Type)
extern void GameObject_AddComponent_m489C9D5426F2050795FA696CD478BB49AAE4BD70 (void);
// 0x00000448 T UnityEngine.GameObject::AddComponent()
// 0x00000449 UnityEngine.Transform UnityEngine.GameObject::get_transform()
extern void GameObject_get_transform_mA5C38857137F137CB96C69FAA624199EB1C2FB2C (void);
// 0x0000044A System.Int32 UnityEngine.GameObject::get_layer()
extern void GameObject_get_layer_m0DE90D8A3D3AA80497A3A80FBEAC2D207C16B9C8 (void);
// 0x0000044B System.Void UnityEngine.GameObject::set_layer(System.Int32)
extern void GameObject_set_layer_mDAC8037FCFD0CE62DB66004C4342EA20CF604907 (void);
// 0x0000044C System.Void UnityEngine.GameObject::SetActive(System.Boolean)
extern void GameObject_SetActive_m25A39F6D9FB68C51F13313F9804E85ACC937BC04 (void);
// 0x0000044D System.Boolean UnityEngine.GameObject::get_activeSelf()
extern void GameObject_get_activeSelf_mFE1834886CAE59884AC2BE707A3B821A1DB61F44 (void);
// 0x0000044E System.Boolean UnityEngine.GameObject::get_activeInHierarchy()
extern void GameObject_get_activeInHierarchy_mDEE60F1B28281974BA9880EC448682F3DAABB1EF (void);
// 0x0000044F System.Void UnityEngine.GameObject::SendMessage(System.String,System.Object,UnityEngine.SendMessageOptions)
extern void GameObject_SendMessage_mB9147E503F1F55C4F3BC2816C0BDA8C21EA22E95 (void);
// 0x00000450 System.Void UnityEngine.GameObject::.ctor(System.String)
extern void GameObject__ctor_mBB454E679AD9CF0B84D3609A01E6A9753ACF4686 (void);
// 0x00000451 System.Void UnityEngine.GameObject::.ctor()
extern void GameObject__ctor_mA4DFA8F4471418C248E95B55070665EF344B4B2D (void);
// 0x00000452 System.Void UnityEngine.GameObject::.ctor(System.String,System.Type[])
extern void GameObject__ctor_m20BE06980A232E1D64016957059A9DD834173F68 (void);
// 0x00000453 System.Void UnityEngine.GameObject::Internal_CreateGameObject(UnityEngine.GameObject,System.String)
extern void GameObject_Internal_CreateGameObject_m9DC9E92BD086A7ADD9ABCE858646A951FA77F437 (void);
// 0x00000454 System.Int32 UnityEngine.LayerMask::op_Implicit(UnityEngine.LayerMask)
extern void LayerMask_op_Implicit_m2AFFC7F931005437E8F356C953F439829AF4CFA5 (void);
// 0x00000455 UnityEngine.LayerMask UnityEngine.LayerMask::op_Implicit(System.Int32)
extern void LayerMask_op_Implicit_m3F256A7D96C66548F5B62C4621B9725301850300 (void);
// 0x00000456 System.Int32 UnityEngine.LayerMask::get_value()
extern void LayerMask_get_value_m682288E860BBE36F5668DCDBC59245DE6319E537_AdjustorThunk (void);
// 0x00000457 System.Void UnityEngine.ManagedStreamHelpers::ValidateLoadFromStream(System.IO.Stream)
extern void ManagedStreamHelpers_ValidateLoadFromStream_m550BE5DED66EC83AF331265B81084185B35FD846 (void);
// 0x00000458 System.Void UnityEngine.ManagedStreamHelpers::ManagedStreamRead(System.Byte[],System.Int32,System.Int32,System.IO.Stream,System.IntPtr)
extern void ManagedStreamHelpers_ManagedStreamRead_mC0BDD6B226BBF621F6DAC184E3FC798D6BB0D47B (void);
// 0x00000459 System.Void UnityEngine.ManagedStreamHelpers::ManagedStreamSeek(System.Int64,System.UInt32,System.IO.Stream,System.IntPtr)
extern void ManagedStreamHelpers_ManagedStreamSeek_m450DB930DD5085114F382A6FE05CF15C5CB21168 (void);
// 0x0000045A System.Void UnityEngine.ManagedStreamHelpers::ManagedStreamLength(System.IO.Stream,System.IntPtr)
extern void ManagedStreamHelpers_ManagedStreamLength_mB518EF67FCBA5080CA4C45F34496C05041E07B98 (void);
// 0x0000045B System.Boolean UnityEngine.MonoBehaviour::IsInvoking()
extern void MonoBehaviour_IsInvoking_mD0C27BE34FB97F408191450A702FA016E19997E5 (void);
// 0x0000045C System.Void UnityEngine.MonoBehaviour::CancelInvoke()
extern void MonoBehaviour_CancelInvoke_m6ACF5FC83F8FE5A6E744CE1E83A94CB3B0A8B7EF (void);
// 0x0000045D System.Void UnityEngine.MonoBehaviour::Invoke(System.String,System.Single)
extern void MonoBehaviour_Invoke_m979EDEF812D4630882E2E8346776B6CA5A9176BF (void);
// 0x0000045E System.Void UnityEngine.MonoBehaviour::InvokeRepeating(System.String,System.Single,System.Single)
extern void MonoBehaviour_InvokeRepeating_m99F21547D281B3F835745B681E5472F070E7E593 (void);
// 0x0000045F System.Void UnityEngine.MonoBehaviour::CancelInvoke(System.String)
extern void MonoBehaviour_CancelInvoke_mDD95225EF4DFBB8C00B865468DE8AFEB5D30490F (void);
// 0x00000460 System.Boolean UnityEngine.MonoBehaviour::IsInvoking(System.String)
extern void MonoBehaviour_IsInvoking_mCA9E133D28B55AE0CE0E8EDBB183081DEEE57FBC (void);
// 0x00000461 UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine(System.String)
extern void MonoBehaviour_StartCoroutine_m590A0A7F161D579C18E678B4C5ACCE77B1B318DD (void);
// 0x00000462 UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine(System.String,System.Object)
extern void MonoBehaviour_StartCoroutine_mCD250A96284E3C39D579CEC447432681DE8D1E44 (void);
// 0x00000463 UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine(System.Collections.IEnumerator)
extern void MonoBehaviour_StartCoroutine_mBF8044CE06A35D76A69669ADD8977D05956616B7 (void);
// 0x00000464 UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutine_Auto(System.Collections.IEnumerator)
extern void MonoBehaviour_StartCoroutine_Auto_m5002506E1DE4625F7FEACC4D7F0ED8595E3B3AB5 (void);
// 0x00000465 System.Void UnityEngine.MonoBehaviour::StopCoroutine(System.Collections.IEnumerator)
extern void MonoBehaviour_StopCoroutine_m3CDD6C046CC660D4CD6583FCE97F88A9735FD5FA (void);
// 0x00000466 System.Void UnityEngine.MonoBehaviour::StopCoroutine(UnityEngine.Coroutine)
extern void MonoBehaviour_StopCoroutine_mC465FFA3C386BA22384F7AFA5495FF2286510562 (void);
// 0x00000467 System.Void UnityEngine.MonoBehaviour::StopCoroutine(System.String)
extern void MonoBehaviour_StopCoroutine_mC2C29B39556BFC68657F27343602BCC57AA6604F (void);
// 0x00000468 System.Void UnityEngine.MonoBehaviour::StopAllCoroutines()
extern void MonoBehaviour_StopAllCoroutines_mA5469BB7BBB59B8A94BB86590B051E0DFACC12DD (void);
// 0x00000469 System.Boolean UnityEngine.MonoBehaviour::get_useGUILayout()
extern void MonoBehaviour_get_useGUILayout_m468C9F5A4D7F37643D26EEF41E5BA521CD81C267 (void);
// 0x0000046A System.Void UnityEngine.MonoBehaviour::set_useGUILayout(System.Boolean)
extern void MonoBehaviour_set_useGUILayout_m00327593C0DC39787FB9310328489F802FF63167 (void);
// 0x0000046B System.Void UnityEngine.MonoBehaviour::print(System.Object)
extern void MonoBehaviour_print_m171D860AF3370C46648FE8F3EE3E0E6535E1C774 (void);
// 0x0000046C System.Void UnityEngine.MonoBehaviour::Internal_CancelInvokeAll(UnityEngine.MonoBehaviour)
extern void MonoBehaviour_Internal_CancelInvokeAll_m11071D9A8C6743C4FA754C1A079CFF5171638AB1 (void);
// 0x0000046D System.Boolean UnityEngine.MonoBehaviour::Internal_IsInvokingAll(UnityEngine.MonoBehaviour)
extern void MonoBehaviour_Internal_IsInvokingAll_m44707A3C084E2CABC98FBCAF3531E547C6D59644 (void);
// 0x0000046E System.Void UnityEngine.MonoBehaviour::InvokeDelayed(UnityEngine.MonoBehaviour,System.String,System.Single,System.Single)
extern void MonoBehaviour_InvokeDelayed_mB70D589B53A55251F47641C6D3A51DA59F973D63 (void);
// 0x0000046F System.Void UnityEngine.MonoBehaviour::CancelInvoke(UnityEngine.MonoBehaviour,System.String)
extern void MonoBehaviour_CancelInvoke_m38D5CC0BF3FFDD89DD5F5A47E852B1E04BAAC5BB (void);
// 0x00000470 System.Boolean UnityEngine.MonoBehaviour::IsInvoking(UnityEngine.MonoBehaviour,System.String)
extern void MonoBehaviour_IsInvoking_mA209C7787032B92CEC40A5C571CB257D7A87457E (void);
// 0x00000471 System.Boolean UnityEngine.MonoBehaviour::IsObjectMonoBehaviour(UnityEngine.Object)
extern void MonoBehaviour_IsObjectMonoBehaviour_mCB948905029893B860CCD5D852878660A1CEF0D7 (void);
// 0x00000472 UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutineManaged(System.String,System.Object)
extern void MonoBehaviour_StartCoroutineManaged_m53873D1C040DB245BF13B74D2781072015B1EB66 (void);
// 0x00000473 UnityEngine.Coroutine UnityEngine.MonoBehaviour::StartCoroutineManaged2(System.Collections.IEnumerator)
extern void MonoBehaviour_StartCoroutineManaged2_m114327BBBA9F208E8BA2F8BBF71FA0E8E996F7B8 (void);
// 0x00000474 System.Void UnityEngine.MonoBehaviour::StopCoroutineManaged(UnityEngine.Coroutine)
extern void MonoBehaviour_StopCoroutineManaged_mB9F1DBC3C5CCF4F64D5277B87518A54DEF7509C2 (void);
// 0x00000475 System.Void UnityEngine.MonoBehaviour::StopCoroutineFromEnumeratorManaged(System.Collections.IEnumerator)
extern void MonoBehaviour_StopCoroutineFromEnumeratorManaged_mA0D7F798094DF352E354304A50E8D97D9AB6900B (void);
// 0x00000476 System.String UnityEngine.MonoBehaviour::GetScriptClassName()
extern void MonoBehaviour_GetScriptClassName_mB38B7D00E1629DF772709F844EDB4C20074A208F (void);
// 0x00000477 System.Void UnityEngine.MonoBehaviour::.ctor()
extern void MonoBehaviour__ctor_mEAEC84B222C60319D593E456D769B3311DFCEF97 (void);
// 0x00000478 System.Int32 UnityEngine.NoAllocHelpers::SafeLength(System.Array)
extern void NoAllocHelpers_SafeLength_m85E794F370BFE9D3954E72480AE6ED358AF5102C (void);
// 0x00000479 System.Int32 UnityEngine.NoAllocHelpers::SafeLength(System.Collections.Generic.List`1<T>)
// 0x0000047A System.Array UnityEngine.NoAllocHelpers::ExtractArrayFromList(System.Object)
extern void NoAllocHelpers_ExtractArrayFromList_mB4B8B76B4F160975C949FB3E15C1D497DBAE8EDC (void);
// 0x0000047B System.Int32 UnityEngine.RangeInt::get_end()
extern void RangeInt_get_end_m7A5182161CC5454E1C200E0173668572BA7FAAFD_AdjustorThunk (void);
// 0x0000047C System.Void UnityEngine.RangeInt::.ctor(System.Int32,System.Int32)
extern void RangeInt__ctor_mACFE54DF73DE3F62053F851423525DB5AC1B100E_AdjustorThunk (void);
// 0x0000047D System.Void UnityEngine.RuntimeInitializeOnLoadMethodAttribute::.ctor()
extern void RuntimeInitializeOnLoadMethodAttribute__ctor_mF7E0CAAF0DA4A1F5BAD4CF4C02C4C3A5AB2515D0 (void);
// 0x0000047E System.Void UnityEngine.RuntimeInitializeOnLoadMethodAttribute::.ctor(UnityEngine.RuntimeInitializeLoadType)
extern void RuntimeInitializeOnLoadMethodAttribute__ctor_mB64D0D2B5788BC105D3640A22A70FCD5183CB413 (void);
// 0x0000047F System.Void UnityEngine.RuntimeInitializeOnLoadMethodAttribute::set_loadType(UnityEngine.RuntimeInitializeLoadType)
extern void RuntimeInitializeOnLoadMethodAttribute_set_loadType_m99C91FFBB561C344A90B86F6AF9ED8642CB87532 (void);
// 0x00000480 System.Void UnityEngine.ScriptableObject::.ctor()
extern void ScriptableObject__ctor_m6E2B3821A4A361556FC12E9B1C71E1D5DC002C5B (void);
// 0x00000481 UnityEngine.ScriptableObject UnityEngine.ScriptableObject::CreateInstance(System.Type)
extern void ScriptableObject_CreateInstance_mDC77B7257A5E276CB272D3475B9B473B23A7128D (void);
// 0x00000482 T UnityEngine.ScriptableObject::CreateInstance()
// 0x00000483 System.Void UnityEngine.ScriptableObject::CreateScriptableObject(UnityEngine.ScriptableObject)
extern void ScriptableObject_CreateScriptableObject_m0DEEBEC415354F586C010E7863AEA64D2F628D0B (void);
// 0x00000484 UnityEngine.ScriptableObject UnityEngine.ScriptableObject::CreateScriptableObjectInstanceFromType(System.Type,System.Boolean)
extern void ScriptableObject_CreateScriptableObjectInstanceFromType_m251F32A1C8B865FBED309AA24B8EAB3A35E2E25C (void);
// 0x00000485 System.Boolean UnityEngine.ScriptingUtility::IsManagedCodeWorking()
extern void ScriptingUtility_IsManagedCodeWorking_m4E53313183C7CB038C14545B933F81E249E707F3 (void);
// 0x00000486 System.Void UnityEngine.SelectionBaseAttribute::.ctor()
extern void SelectionBaseAttribute__ctor_mD7E83E67AFD9920E70551A353A33CC94D0584E8E (void);
// 0x00000487 System.Void UnityEngine.StackTraceUtility::SetProjectFolder(System.String)
extern void StackTraceUtility_SetProjectFolder_m05FBBB2FF161F2F9F8551EB67D44B50F7CC98E21 (void);
// 0x00000488 System.String UnityEngine.StackTraceUtility::ExtractStackTrace()
extern void StackTraceUtility_ExtractStackTrace_mEDFB4ECA329B87BC7DF2AA3EF7F9A31DAC052DC0 (void);
// 0x00000489 System.Void UnityEngine.StackTraceUtility::ExtractStringFromExceptionInternal(System.Object,System.String&,System.String&)
extern void StackTraceUtility_ExtractStringFromExceptionInternal_m1FB3D6414E31C313AC633A24653DA4B1FB59C975 (void);
// 0x0000048A System.String UnityEngine.StackTraceUtility::ExtractFormattedStackTrace(System.Diagnostics.StackTrace)
extern void StackTraceUtility_ExtractFormattedStackTrace_m02A2ACEEF753617FAAA08B4EA840A49263901660 (void);
// 0x0000048B System.Void UnityEngine.StackTraceUtility::.cctor()
extern void StackTraceUtility__cctor_mDDEE2A2B6EBEDB75E0C28C81AFEDB1E9C372A165 (void);
// 0x0000048C System.Void UnityEngine.UnityException::.ctor()
extern void UnityException__ctor_m68C827240B217197615D8DA06FD3A443127D81DE (void);
// 0x0000048D System.Void UnityEngine.UnityException::.ctor(System.String)
extern void UnityException__ctor_mE42363D886E6DD7F075A6AEA689434C8E96722D9 (void);
// 0x0000048E System.Void UnityEngine.UnityException::.ctor(System.Runtime.Serialization.SerializationInfo,System.Runtime.Serialization.StreamingContext)
extern void UnityException__ctor_m27B11548FE152B9AB9402E54CB6A50A2EE6FFE31 (void);
// 0x0000048F System.String UnityEngine.TextAsset::get_text()
extern void TextAsset_get_text_mD3FBCD974CF552C7F7C7CD9A07BACAE51A2C5D42 (void);
// 0x00000490 System.String UnityEngine.TextAsset::ToString()
extern void TextAsset_ToString_m8C7ED5DD80E20B3A16A2100F62319811BE5DC830 (void);
// 0x00000491 System.Void UnityEngine.UnhandledExceptionHandler::RegisterUECatcher()
extern void UnhandledExceptionHandler_RegisterUECatcher_mE45C6A0301C35F6193F5774B7683683EF78D21DA (void);
// 0x00000492 System.Void UnityEngine.UnhandledExceptionHandler_<>c::.cctor()
extern void U3CU3Ec__cctor_m64F27758792E69C7BFBBDB0705955F951E2F162B (void);
// 0x00000493 System.Void UnityEngine.UnhandledExceptionHandler_<>c::.ctor()
extern void U3CU3Ec__ctor_mAE51BB926802D8ED0E892556F421B0E93398FE96 (void);
// 0x00000494 System.Void UnityEngine.UnhandledExceptionHandler_<>c::<RegisterUECatcher>b__0_0(System.Object,System.UnhandledExceptionEventArgs)
extern void U3CU3Ec_U3CRegisterUECatcherU3Eb__0_0_m55F5FA1A6235A1DF6306D232C25ACE1883E494D0 (void);
// 0x00000495 System.Int32 UnityEngine.Object::GetInstanceID()
extern void Object_GetInstanceID_m33A817CEE904B3362C8BAAF02DB45976575CBEF4 (void);
// 0x00000496 System.Int32 UnityEngine.Object::GetHashCode()
extern void Object_GetHashCode_mCF9141C6640C2989CD354118673711D5F3741984 (void);
// 0x00000497 System.Boolean UnityEngine.Object::Equals(System.Object)
extern void Object_Equals_m813F5A9FF65C9BC0D6907570C2A9913507D58F32 (void);
// 0x00000498 System.Boolean UnityEngine.Object::op_Implicit(UnityEngine.Object)
extern void Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534 (void);
// 0x00000499 System.Boolean UnityEngine.Object::CompareBaseObjects(UnityEngine.Object,UnityEngine.Object)
extern void Object_CompareBaseObjects_mE918232D595FB366CE5FAD4411C5FBD86809CC04 (void);
// 0x0000049A System.Boolean UnityEngine.Object::IsNativeObjectAlive(UnityEngine.Object)
extern void Object_IsNativeObjectAlive_m683A8A1607CB2FF5E56EC09C5D150A8DA7D3FF08 (void);
// 0x0000049B System.IntPtr UnityEngine.Object::GetCachedPtr()
extern void Object_GetCachedPtr_m8CCFA6D419ADFBA8F9EF83CB45DFD75C2704C4A0 (void);
// 0x0000049C System.String UnityEngine.Object::get_name()
extern void Object_get_name_mA2D400141CB3C991C87A2556429781DE961A83CE (void);
// 0x0000049D System.Void UnityEngine.Object::set_name(System.String)
extern void Object_set_name_m538711B144CDE30F929376BCF72D0DC8F85D0826 (void);
// 0x0000049E UnityEngine.Object UnityEngine.Object::Instantiate(UnityEngine.Object)
extern void Object_Instantiate_m17AA3123A55239124BC54A907AEEE509034F0830 (void);
// 0x0000049F UnityEngine.Object UnityEngine.Object::Instantiate(UnityEngine.Object,UnityEngine.Transform,System.Boolean)
extern void Object_Instantiate_m674B3934708548332899CE953CA56BB696C1C887 (void);
// 0x000004A0 T UnityEngine.Object::Instantiate(T)
// 0x000004A1 T UnityEngine.Object::Instantiate(T,UnityEngine.Transform)
// 0x000004A2 T UnityEngine.Object::Instantiate(T,UnityEngine.Transform,System.Boolean)
// 0x000004A3 System.Void UnityEngine.Object::Destroy(UnityEngine.Object,System.Single)
extern void Object_Destroy_m09F51D8BDECFD2E8C618498EF7377029B669030D (void);
// 0x000004A4 System.Void UnityEngine.Object::Destroy(UnityEngine.Object)
extern void Object_Destroy_m23B4562495BA35A74266D4372D45368F8C05109A (void);
// 0x000004A5 System.Void UnityEngine.Object::DestroyImmediate(UnityEngine.Object,System.Boolean)
extern void Object_DestroyImmediate_mFCE7947857C832BCBB366FCCE50072ACAD9A4C51 (void);
// 0x000004A6 System.Void UnityEngine.Object::DestroyImmediate(UnityEngine.Object)
extern void Object_DestroyImmediate_mF6F4415EF22249D6E650FAA40E403283F19B7446 (void);
// 0x000004A7 UnityEngine.Object[] UnityEngine.Object::FindObjectsOfType(System.Type)
extern void Object_FindObjectsOfType_m3FC26FB3B36525BFBFCCCD1AEEE8A86712A12203 (void);
// 0x000004A8 System.Void UnityEngine.Object::DontDestroyOnLoad(UnityEngine.Object)
extern void Object_DontDestroyOnLoad_m4DC90770AD6084E4B1B8489C6B41205DC020C207 (void);
// 0x000004A9 System.Void UnityEngine.Object::set_hideFlags(UnityEngine.HideFlags)
extern void Object_set_hideFlags_mB0B45A19A5871EF407D7B09E0EB76003496BA4F0 (void);
// 0x000004AA T UnityEngine.Object::FindObjectOfType()
// 0x000004AB System.Void UnityEngine.Object::CheckNullArgument(System.Object,System.String)
extern void Object_CheckNullArgument_m8D42F516655D770DFEEAA13CF86A2612214AAA9B (void);
// 0x000004AC UnityEngine.Object UnityEngine.Object::FindObjectOfType(System.Type)
extern void Object_FindObjectOfType_mCDF38E1667CF4502F60C59709D70B60EF7E408DA (void);
// 0x000004AD System.String UnityEngine.Object::ToString()
extern void Object_ToString_m4EBF621C98D5BFA9C0522C27953BB45AB2430FE1 (void);
// 0x000004AE System.Boolean UnityEngine.Object::op_Equality(UnityEngine.Object,UnityEngine.Object)
extern void Object_op_Equality_mBC2401774F3BE33E8CF6F0A8148E66C95D6CFF1C (void);
// 0x000004AF System.Boolean UnityEngine.Object::op_Inequality(UnityEngine.Object,UnityEngine.Object)
extern void Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1 (void);
// 0x000004B0 System.Int32 UnityEngine.Object::GetOffsetOfInstanceIDInCPlusPlusObject()
extern void Object_GetOffsetOfInstanceIDInCPlusPlusObject_m7C7130E8611F32F6CC9A47400AC5BDC2BA5E6D23 (void);
// 0x000004B1 UnityEngine.Object UnityEngine.Object::Internal_CloneSingle(UnityEngine.Object)
extern void Object_Internal_CloneSingle_m4231A0B9138AC40B76655B772F687CC7E6160C06 (void);
// 0x000004B2 UnityEngine.Object UnityEngine.Object::Internal_CloneSingleWithParent(UnityEngine.Object,UnityEngine.Transform,System.Boolean)
extern void Object_Internal_CloneSingleWithParent_m32F1D681010B51B98CDBC82E3510FC260D2D1E17 (void);
// 0x000004B3 System.String UnityEngine.Object::ToString(UnityEngine.Object)
extern void Object_ToString_m7A4BBACD14901DD0181038A25BED62520D273EDC (void);
// 0x000004B4 System.String UnityEngine.Object::GetName(UnityEngine.Object)
extern void Object_GetName_m1691C0D50AEBC1C86229AEAC2FBC1EE2DC6B67AF (void);
// 0x000004B5 System.Void UnityEngine.Object::SetName(UnityEngine.Object,System.String)
extern void Object_SetName_m2CBABC30BA2B93EFF6A39B3295A7AB85901E60E8 (void);
// 0x000004B6 UnityEngine.Object UnityEngine.Object::FindObjectFromInstanceID(System.Int32)
extern void Object_FindObjectFromInstanceID_m7594ED98F525AAE38FEC80052729ECAF3E821350 (void);
// 0x000004B7 System.Void UnityEngine.Object::.ctor()
extern void Object__ctor_m091EBAEBC7919B0391ABDAFB7389ADC12206525B (void);
// 0x000004B8 System.Void UnityEngine.Object::.cctor()
extern void Object__cctor_m14515D6A9B514D3A8590E2CAE4372A0956E8976C (void);
// 0x000004B9 System.Void UnityEngine.UnitySynchronizationContext::.ctor(System.Int32)
extern void UnitySynchronizationContext__ctor_mCABD0C784640450930DF24FAD73E8AD6D1B52037 (void);
// 0x000004BA System.Void UnityEngine.UnitySynchronizationContext::.ctor(System.Collections.Generic.List`1<UnityEngine.UnitySynchronizationContext_WorkRequest>,System.Int32)
extern void UnitySynchronizationContext__ctor_m9D104656F4EAE96CB3A40DDA6EDCEBA752664612 (void);
// 0x000004BB System.Void UnityEngine.UnitySynchronizationContext::Send(System.Threading.SendOrPostCallback,System.Object)
extern void UnitySynchronizationContext_Send_m25CDC5B5ABF8D55B70EB314AA46923E3CF2AD4B9 (void);
// 0x000004BC System.Void UnityEngine.UnitySynchronizationContext::Post(System.Threading.SendOrPostCallback,System.Object)
extern void UnitySynchronizationContext_Post_mB4E900B6E9350E8E944011B6BF3D16C0657375FE (void);
// 0x000004BD System.Threading.SynchronizationContext UnityEngine.UnitySynchronizationContext::CreateCopy()
extern void UnitySynchronizationContext_CreateCopy_mC20AC170E7947120E65ED75D71889CDAC957A5CD (void);
// 0x000004BE System.Void UnityEngine.UnitySynchronizationContext::Exec()
extern void UnitySynchronizationContext_Exec_m07342201E337E047B73C8B3259710820EFF75A9C (void);
// 0x000004BF System.Boolean UnityEngine.UnitySynchronizationContext::HasPendingTasks()
extern void UnitySynchronizationContext_HasPendingTasks_mBFCAC1697C6B71584E72079A6EDB83D52EC1700A (void);
// 0x000004C0 System.Void UnityEngine.UnitySynchronizationContext::InitializeSynchronizationContext()
extern void UnitySynchronizationContext_InitializeSynchronizationContext_m0F2A055040D6848FAD84A08DBC410E56B2D9E6A3 (void);
// 0x000004C1 System.Void UnityEngine.UnitySynchronizationContext::ExecuteTasks()
extern void UnitySynchronizationContext_ExecuteTasks_m027AF329D90D6451B83A2EAF3528C9021800A962 (void);
// 0x000004C2 System.Boolean UnityEngine.UnitySynchronizationContext::ExecutePendingTasks(System.Int64)
extern void UnitySynchronizationContext_ExecutePendingTasks_m74DCC56A938FEECD533CFE58CAC4B8B9ED001122 (void);
// 0x000004C3 System.Void UnityEngine.UnitySynchronizationContext_WorkRequest::.ctor(System.Threading.SendOrPostCallback,System.Object,System.Threading.ManualResetEvent)
extern void WorkRequest__ctor_mE19AE1779B544378C8CB488F1576BDE618548599_AdjustorThunk (void);
// 0x000004C4 System.Void UnityEngine.UnitySynchronizationContext_WorkRequest::Invoke()
extern void WorkRequest_Invoke_m67D71A48794EEBB6B9793E6F1E015DE90C03C1ED_AdjustorThunk (void);
// 0x000004C5 System.Void UnityEngine.WaitForEndOfFrame::.ctor()
extern void WaitForEndOfFrame__ctor_m6CDB79476A4A84CEC62947D36ADED96E907BA20B (void);
// 0x000004C6 System.Single UnityEngine.WaitForSecondsRealtime::get_waitTime()
extern void WaitForSecondsRealtime_get_waitTime_m6D1B0EDEAFA3DBBBFE1A0CC2D372BAB8EA82E2FB (void);
// 0x000004C7 System.Void UnityEngine.WaitForSecondsRealtime::set_waitTime(System.Single)
extern void WaitForSecondsRealtime_set_waitTime_m867F4482BEE354E33A6FD9191344D74B9CC8C790 (void);
// 0x000004C8 System.Boolean UnityEngine.WaitForSecondsRealtime::get_keepWaiting()
extern void WaitForSecondsRealtime_get_keepWaiting_mC257FFC53D5734250B919A8B6BE460A6D8A7CD99 (void);
// 0x000004C9 System.Void UnityEngine.WaitForSecondsRealtime::.ctor(System.Single)
extern void WaitForSecondsRealtime__ctor_m775503EC1F4963D8E5BBDD7989B40F6A000E0525 (void);
// 0x000004CA System.Void UnityEngine.YieldInstruction::.ctor()
extern void YieldInstruction__ctor_mA72AD367FB081E0C2493649C6E8F7CFC592AB620 (void);
// 0x000004CB System.Void UnityEngine.SerializeField::.ctor()
extern void SerializeField__ctor_mEE7F6BB7A9643562D8CEF189848925B74F87DA27 (void);
// 0x000004CC System.Void UnityEngine.ISerializationCallbackReceiver::OnBeforeSerialize()
// 0x000004CD System.Void UnityEngine.ISerializationCallbackReceiver::OnAfterDeserialize()
// 0x000004CE System.Void UnityEngine.ComputeBuffer::Finalize()
extern void ComputeBuffer_Finalize_m1656E84A6F9AA3DFFF24F62A89EC378DAAE6A012 (void);
// 0x000004CF System.Void UnityEngine.ComputeBuffer::Dispose()
extern void ComputeBuffer_Dispose_m002F431B0EBF0B24DF20C7EB8FC2F44B596A6FFE (void);
// 0x000004D0 System.Void UnityEngine.ComputeBuffer::Dispose(System.Boolean)
extern void ComputeBuffer_Dispose_mCD0266359E7566AE532568FC801D2883B9AE04F2 (void);
// 0x000004D1 System.IntPtr UnityEngine.ComputeBuffer::InitBuffer(System.Int32,System.Int32,UnityEngine.ComputeBufferType,UnityEngine.ComputeBufferMode)
extern void ComputeBuffer_InitBuffer_m4EA013B54E8B195654CFCAE9E6FD92ACD15B73DD (void);
// 0x000004D2 System.Void UnityEngine.ComputeBuffer::DestroyBuffer(UnityEngine.ComputeBuffer)
extern void ComputeBuffer_DestroyBuffer_m506890E60C1B0B63CAD39EB38C5821F8C415C537 (void);
// 0x000004D3 System.Void UnityEngine.ComputeBuffer::.ctor(System.Int32,System.Int32)
extern void ComputeBuffer__ctor_mDB6AADE63A5BF60A472D9FF9E533AF38D15C6B1E (void);
// 0x000004D4 System.Void UnityEngine.ComputeBuffer::.ctor(System.Int32,System.Int32,UnityEngine.ComputeBufferType,UnityEngine.ComputeBufferMode,System.Int32)
extern void ComputeBuffer__ctor_m908F94257168ACBAFCA674B2B5EFACC4C84BFE22 (void);
// 0x000004D5 System.Void UnityEngine.ComputeBuffer::Release()
extern void ComputeBuffer_Release_m7DCC16A68F5C00C9C1EA70EE9AFC016AC47F6386 (void);
// 0x000004D6 System.Int32 UnityEngine.ComputeBuffer::get_count()
extern void ComputeBuffer_get_count_m2D80EF2880723F6627924C0ABC642D8DB538D04D (void);
// 0x000004D7 System.Void UnityEngine.ComputeBuffer::SetData(Unity.Collections.NativeArray`1<T>)
// 0x000004D8 System.Void UnityEngine.ComputeBuffer::SetData(System.Collections.Generic.List`1<T>,System.Int32,System.Int32,System.Int32)
// 0x000004D9 System.Void UnityEngine.ComputeBuffer::InternalSetNativeData(System.IntPtr,System.Int32,System.Int32,System.Int32,System.Int32)
extern void ComputeBuffer_InternalSetNativeData_m48FA3DFF2BF7025268AB18F7A2880EBE497320A0 (void);
// 0x000004DA System.Void UnityEngine.ComputeBuffer::InternalSetData(System.Array,System.Int32,System.Int32,System.Int32,System.Int32)
extern void ComputeBuffer_InternalSetData_m490D0FE6E42D04DF9E9320D5D877EDEFBAB608A5 (void);
// 0x000004DB System.Int32 UnityEngine.ComputeShader::FindKernel(System.String)
extern void ComputeShader_FindKernel_m4CEBD37F96732810C4C370A6249CF460BE1F93A3 (void);
// 0x000004DC System.Void UnityEngine.LowerResBlitTexture::LowerResBlitTextureDontStripMe()
extern void LowerResBlitTexture_LowerResBlitTextureDontStripMe_mC89EA382E4636DE8BC0E14D1BB024A80C65F5CAF (void);
// 0x000004DD System.Void UnityEngine.PreloadData::PreloadDataDontStripMe()
extern void PreloadData_PreloadDataDontStripMe_m68DF1A35E18F9FC43A63F2F990EA9970D4E4A78B (void);
// 0x000004DE UnityEngine.OperatingSystemFamily UnityEngine.SystemInfo::get_operatingSystemFamily()
extern void SystemInfo_get_operatingSystemFamily_mA35FE1FF2DD6240B2880DC5F642D4A0CC2B58D8D (void);
// 0x000004DF System.String UnityEngine.SystemInfo::get_processorType()
extern void SystemInfo_get_processorType_m7B14D432F490CAC67239862D69F60512E5E2094B (void);
// 0x000004E0 UnityEngine.DeviceType UnityEngine.SystemInfo::get_deviceType()
extern void SystemInfo_get_deviceType_mAFCA02B695EE4E37FA3B87B8C05804B6616E1528 (void);
// 0x000004E1 UnityEngine.Rendering.GraphicsDeviceType UnityEngine.SystemInfo::get_graphicsDeviceType()
extern void SystemInfo_get_graphicsDeviceType_m675AD9D5FA869DF9E71FAEC03F39E8AE8DEBA8D0 (void);
// 0x000004E2 System.Int32 UnityEngine.SystemInfo::get_graphicsShaderLevel()
extern void SystemInfo_get_graphicsShaderLevel_m04540C22D983AE52CBCC6E1026D16F0C548248EB (void);
// 0x000004E3 System.Boolean UnityEngine.SystemInfo::get_hasHiddenSurfaceRemovalOnGPU()
extern void SystemInfo_get_hasHiddenSurfaceRemovalOnGPU_mE2544E97E6FF38C5B092EEA5B2C9977ACE1EE4ED (void);
// 0x000004E4 System.Boolean UnityEngine.SystemInfo::get_supportsShadows()
extern void SystemInfo_get_supportsShadows_m05F10143737B2C6446A663D48447C2006B8701E3 (void);
// 0x000004E5 UnityEngine.Rendering.CopyTextureSupport UnityEngine.SystemInfo::get_copyTextureSupport()
extern void SystemInfo_get_copyTextureSupport_m70EE252CBB5FE7C1EBE4067AD4563D87A5937A84 (void);
// 0x000004E6 System.Int32 UnityEngine.SystemInfo::get_supportedRenderTargetCount()
extern void SystemInfo_get_supportedRenderTargetCount_mD11B3D770E9DA7EE2F0AC0E9B48299AEDE1B515D (void);
// 0x000004E7 System.Int32 UnityEngine.SystemInfo::get_supportsMultisampledTextures()
extern void SystemInfo_get_supportsMultisampledTextures_m23346E547FC878AD5A6BC98F5A3C89955A2B5BC0 (void);
// 0x000004E8 System.Boolean UnityEngine.SystemInfo::get_supportsMultisampleAutoResolve()
extern void SystemInfo_get_supportsMultisampleAutoResolve_m07B205615F855D67101CDDED752F1F2A6B360386 (void);
// 0x000004E9 System.Boolean UnityEngine.SystemInfo::get_usesReversedZBuffer()
extern void SystemInfo_get_usesReversedZBuffer_m2341C40731784C0DE4EBCFBADC2FBE72E5B8778D (void);
// 0x000004EA System.Boolean UnityEngine.SystemInfo::IsValidEnumValue(System.Enum)
extern void SystemInfo_IsValidEnumValue_m112F964C57B2311EA910CCA5CE0FFABFFF906740 (void);
// 0x000004EB System.Boolean UnityEngine.SystemInfo::SupportsRenderTextureFormat(UnityEngine.RenderTextureFormat)
extern void SystemInfo_SupportsRenderTextureFormat_m74D259714A97501D28951CA48298D9F0AE3B5907 (void);
// 0x000004EC System.Boolean UnityEngine.SystemInfo::SupportsTextureFormat(UnityEngine.TextureFormat)
extern void SystemInfo_SupportsTextureFormat_m1FCBD02367A45D11CAA6503715F3AAE24CA98B79 (void);
// 0x000004ED UnityEngine.OperatingSystemFamily UnityEngine.SystemInfo::GetOperatingSystemFamily()
extern void SystemInfo_GetOperatingSystemFamily_mD20DAFF3A6E6649299A3BCFC845E7EB41BFA1D93 (void);
// 0x000004EE System.String UnityEngine.SystemInfo::GetProcessorType()
extern void SystemInfo_GetProcessorType_mCEB2AE2578AB2C465092C65C718D01C3BA49F209 (void);
// 0x000004EF UnityEngine.DeviceType UnityEngine.SystemInfo::GetDeviceType()
extern void SystemInfo_GetDeviceType_m749955DFFD2554A64E851BD95C41F6C55D6A777E (void);
// 0x000004F0 UnityEngine.Rendering.GraphicsDeviceType UnityEngine.SystemInfo::GetGraphicsDeviceType()
extern void SystemInfo_GetGraphicsDeviceType_m9C6D5E53B3AD6D1B5735517E80A16A78D4CFDDCF (void);
// 0x000004F1 System.Int32 UnityEngine.SystemInfo::GetGraphicsShaderLevel()
extern void SystemInfo_GetGraphicsShaderLevel_mD15672C585F6FDF646F339E954EC72C4F4D5207D (void);
// 0x000004F2 System.Boolean UnityEngine.SystemInfo::HasHiddenSurfaceRemovalOnGPU()
extern void SystemInfo_HasHiddenSurfaceRemovalOnGPU_mEF623DDCB87FAEF077BD46CDFD33090509890FF9 (void);
// 0x000004F3 System.Boolean UnityEngine.SystemInfo::SupportsShadows()
extern void SystemInfo_SupportsShadows_mE90CEC00EBA87DEFAB8E666B02568E07E2E5C771 (void);
// 0x000004F4 UnityEngine.Rendering.CopyTextureSupport UnityEngine.SystemInfo::GetCopyTextureSupport()
extern void SystemInfo_GetCopyTextureSupport_m39519EF827219590A6C531B112C466C7CDD38C66 (void);
// 0x000004F5 System.Int32 UnityEngine.SystemInfo::SupportedRenderTargetCount()
extern void SystemInfo_SupportedRenderTargetCount_mE6CA6DE27146900463A1263DC0A5AB835C528F92 (void);
// 0x000004F6 System.Int32 UnityEngine.SystemInfo::SupportsMultisampledTextures()
extern void SystemInfo_SupportsMultisampledTextures_m7423EF918542CB5AB14E539ABE68BDC0A8E2478D (void);
// 0x000004F7 System.Boolean UnityEngine.SystemInfo::SupportsMultisampleAutoResolve()
extern void SystemInfo_SupportsMultisampleAutoResolve_m33E4DE31B5BB12C4407E8207041A6BAE2CAEBDFE (void);
// 0x000004F8 System.Boolean UnityEngine.SystemInfo::UsesReversedZBuffer()
extern void SystemInfo_UsesReversedZBuffer_m0B788618A525D856C29279D19DFB46FC5C1FF4C7 (void);
// 0x000004F9 System.Boolean UnityEngine.SystemInfo::HasRenderTextureNative(UnityEngine.RenderTextureFormat)
extern void SystemInfo_HasRenderTextureNative_mF35AF7764E483A7FA75DBC06ED64A8588509C468 (void);
// 0x000004FA System.Boolean UnityEngine.SystemInfo::SupportsTextureFormatNative(UnityEngine.TextureFormat)
extern void SystemInfo_SupportsTextureFormatNative_mD028594492646D7AB78A4C2F51CA06F63E665210 (void);
// 0x000004FB System.Boolean UnityEngine.SystemInfo::IsFormatSupported(UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.FormatUsage)
extern void SystemInfo_IsFormatSupported_m6941B7C4566DEE1EFFD7F6DCB7BFA701ECF9C1D6 (void);
// 0x000004FC UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.SystemInfo::GetCompatibleFormat(UnityEngine.Experimental.Rendering.GraphicsFormat,UnityEngine.Experimental.Rendering.FormatUsage)
extern void SystemInfo_GetCompatibleFormat_mC67F0F547EA28CDE08EA9A6B030082516D189EF3 (void);
// 0x000004FD UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.SystemInfo::GetGraphicsFormat(UnityEngine.Experimental.Rendering.DefaultFormat)
extern void SystemInfo_GetGraphicsFormat_m708339B9A94CEBC02A56629FE41F6809DE267F6C (void);
// 0x000004FE System.Single UnityEngine.Time::get_time()
extern void Time_get_time_m7863349C8845BBA36629A2B3F8EF1C3BEA350FD8 (void);
// 0x000004FF System.Single UnityEngine.Time::get_deltaTime()
extern void Time_get_deltaTime_m16F98FC9BA931581236008C288E3B25CBCB7C81E (void);
// 0x00000500 System.Single UnityEngine.Time::get_unscaledTime()
extern void Time_get_unscaledTime_m57F78B855097C5BA632CF9BE60667A9DEBCAA472 (void);
// 0x00000501 System.Single UnityEngine.Time::get_unscaledDeltaTime()
extern void Time_get_unscaledDeltaTime_mA0AE7A144C88AE8AABB42DF17B0F3F0714BA06B2 (void);
// 0x00000502 System.Single UnityEngine.Time::get_smoothDeltaTime()
extern void Time_get_smoothDeltaTime_m22F7BB00188785BB7AE979B00CAA96284363C985 (void);
// 0x00000503 System.Single UnityEngine.Time::get_realtimeSinceStartup()
extern void Time_get_realtimeSinceStartup_mCA1086EC9DFCF135F77BC46D3B7127711EA3DE03 (void);
// 0x00000504 System.Void UnityEngine.TouchScreenKeyboard::Internal_Destroy(System.IntPtr)
extern void TouchScreenKeyboard_Internal_Destroy_m6CD4E2343AB4FE54BC23DCFE62A50180CB3634E0 (void);
// 0x00000505 System.Void UnityEngine.TouchScreenKeyboard::Destroy()
extern void TouchScreenKeyboard_Destroy_m916AE9DA740DBD435A5EDD93C6BC55CCEC8310C3 (void);
// 0x00000506 System.Void UnityEngine.TouchScreenKeyboard::Finalize()
extern void TouchScreenKeyboard_Finalize_m684570CC561058F48B51F7E21A144299FBCE4C76 (void);
// 0x00000507 System.Void UnityEngine.TouchScreenKeyboard::.ctor(System.String,UnityEngine.TouchScreenKeyboardType,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.String,System.Int32)
extern void TouchScreenKeyboard__ctor_mDF71D45DC0F867825BEB1CDF728927FBB0E07F86 (void);
// 0x00000508 System.IntPtr UnityEngine.TouchScreenKeyboard::TouchScreenKeyboard_InternalConstructorHelper(UnityEngine.TouchScreenKeyboard_InternalConstructorHelperArguments&,System.String,System.String)
extern void TouchScreenKeyboard_TouchScreenKeyboard_InternalConstructorHelper_mD608B3B2A2159D17A8DF7961FA4EB1694A416973 (void);
// 0x00000509 System.Boolean UnityEngine.TouchScreenKeyboard::get_isSupported()
extern void TouchScreenKeyboard_get_isSupported_m9163BAF0764DCDD9CB87E75A296D820D629D31CA (void);
// 0x0000050A System.Boolean UnityEngine.TouchScreenKeyboard::get_isInPlaceEditingAllowed()
extern void TouchScreenKeyboard_get_isInPlaceEditingAllowed_m503AB6CB0DFBD8E7D396C8E552C643F20E4A5D47 (void);
// 0x0000050B UnityEngine.TouchScreenKeyboard UnityEngine.TouchScreenKeyboard::Open(System.String,UnityEngine.TouchScreenKeyboardType,System.Boolean,System.Boolean,System.Boolean,System.Boolean,System.String,System.Int32)
extern void TouchScreenKeyboard_Open_mF795EEBFEF7DF5E5418CF2BACA02D1C62291B93A (void);
// 0x0000050C System.String UnityEngine.TouchScreenKeyboard::get_text()
extern void TouchScreenKeyboard_get_text_mC025B2F295D315E1A18E7AA54B013A8072A8FEB0 (void);
// 0x0000050D System.Void UnityEngine.TouchScreenKeyboard::set_text(System.String)
extern void TouchScreenKeyboard_set_text_mF72A794EEC3FC19A9701B61A70BCF392D53B0D38 (void);
// 0x0000050E System.Void UnityEngine.TouchScreenKeyboard::set_hideInput(System.Boolean)
extern void TouchScreenKeyboard_set_hideInput_mA9729B01B360BF98153F40B96DDED39534B94840 (void);
// 0x0000050F System.Boolean UnityEngine.TouchScreenKeyboard::get_active()
extern void TouchScreenKeyboard_get_active_m35A2928E54273BF16CB19D11665989D894D5C79D (void);
// 0x00000510 System.Void UnityEngine.TouchScreenKeyboard::set_active(System.Boolean)
extern void TouchScreenKeyboard_set_active_m8D5FDCFA997C5EAD7896F7EB456165498727792D (void);
// 0x00000511 UnityEngine.TouchScreenKeyboard_Status UnityEngine.TouchScreenKeyboard::get_status()
extern void TouchScreenKeyboard_get_status_m17CF606283E9BAF02D76ADC813F63F036FAE33F2 (void);
// 0x00000512 System.Void UnityEngine.TouchScreenKeyboard::set_characterLimit(System.Int32)
extern void TouchScreenKeyboard_set_characterLimit_m97F392EB376881A77F5210CFA6736F0A49F5D57B (void);
// 0x00000513 System.Boolean UnityEngine.TouchScreenKeyboard::get_canGetSelection()
extern void TouchScreenKeyboard_get_canGetSelection_m8EEC32EA25638ACB54F698EA72450B51BEC9A362 (void);
// 0x00000514 System.Boolean UnityEngine.TouchScreenKeyboard::get_canSetSelection()
extern void TouchScreenKeyboard_get_canSetSelection_m3C9574749CA28A6677C77B8FBE6292B80DF88A10 (void);
// 0x00000515 UnityEngine.RangeInt UnityEngine.TouchScreenKeyboard::get_selection()
extern void TouchScreenKeyboard_get_selection_m9E2AB5FF388968D946B15A3ECDAE1C3C97115AAD (void);
// 0x00000516 System.Void UnityEngine.TouchScreenKeyboard::set_selection(UnityEngine.RangeInt)
extern void TouchScreenKeyboard_set_selection_m27C5DE6B9DBBBFE2CCA68FA80A600D94337215C7 (void);
// 0x00000517 System.Void UnityEngine.TouchScreenKeyboard::GetSelection(System.Int32&,System.Int32&)
extern void TouchScreenKeyboard_GetSelection_mED761F9161A43CC8E507EA27DB1BD11127C6C896 (void);
// 0x00000518 System.Void UnityEngine.TouchScreenKeyboard::SetSelection(System.Int32,System.Int32)
extern void TouchScreenKeyboard_SetSelection_mB728B6A7B07AC33987FB30F7950B3D31E3BA5FBF (void);
// 0x00000519 System.Void UnityEngine.DrivenRectTransformTracker::Add(UnityEngine.Object,UnityEngine.RectTransform,UnityEngine.DrivenTransformProperties)
extern void DrivenRectTransformTracker_Add_m51059F302FBD574E93820E8116283D1608D1AB5A_AdjustorThunk (void);
// 0x0000051A System.Void UnityEngine.DrivenRectTransformTracker::Clear()
extern void DrivenRectTransformTracker_Clear_m328659F339A4FB519C9A208A685DDED106B6FC89_AdjustorThunk (void);
// 0x0000051B System.Void UnityEngine.RectTransform::add_reapplyDrivenProperties(UnityEngine.RectTransform_ReapplyDrivenProperties)
extern void RectTransform_add_reapplyDrivenProperties_mDA1F055B02E43F9041D4198D446D89E00381851E (void);
// 0x0000051C System.Void UnityEngine.RectTransform::remove_reapplyDrivenProperties(UnityEngine.RectTransform_ReapplyDrivenProperties)
extern void RectTransform_remove_reapplyDrivenProperties_m65A8DB93E1A247A5C8CD880906FF03FEA89E7CEB (void);
// 0x0000051D UnityEngine.Rect UnityEngine.RectTransform::get_rect()
extern void RectTransform_get_rect_mE5F283FCB99A66403AC1F0607CA49C156D73A15E (void);
// 0x0000051E UnityEngine.Vector2 UnityEngine.RectTransform::get_anchorMin()
extern void RectTransform_get_anchorMin_mB62D77CAC5A2A086320638AE7DF08135B7028744 (void);
// 0x0000051F System.Void UnityEngine.RectTransform::set_anchorMin(UnityEngine.Vector2)
extern void RectTransform_set_anchorMin_mE965F5B0902C2554635010A5752728414A57020A (void);
// 0x00000520 UnityEngine.Vector2 UnityEngine.RectTransform::get_anchorMax()
extern void RectTransform_get_anchorMax_m1E51C211FBB32326C884375C9F1E8E8221E5C086 (void);
// 0x00000521 System.Void UnityEngine.RectTransform::set_anchorMax(UnityEngine.Vector2)
extern void RectTransform_set_anchorMax_m55EEF00D9E42FE542B5346D7CEDAF9248736F7D3 (void);
// 0x00000522 UnityEngine.Vector2 UnityEngine.RectTransform::get_anchoredPosition()
extern void RectTransform_get_anchoredPosition_mCB2171DBADBC572F354CCFE3ACA19F9506F97907 (void);
// 0x00000523 System.Void UnityEngine.RectTransform::set_anchoredPosition(UnityEngine.Vector2)
extern void RectTransform_set_anchoredPosition_m4DD45DB1A97734A1F3A81E5F259638ECAF35962F (void);
// 0x00000524 UnityEngine.Vector2 UnityEngine.RectTransform::get_sizeDelta()
extern void RectTransform_get_sizeDelta_mDA0A3E73679143B1B52CE2F9A417F90CB9F3DAFF (void);
// 0x00000525 System.Void UnityEngine.RectTransform::set_sizeDelta(UnityEngine.Vector2)
extern void RectTransform_set_sizeDelta_m7729BA56325BA667F0F7D60D642124F7909F1302 (void);
// 0x00000526 UnityEngine.Vector2 UnityEngine.RectTransform::get_pivot()
extern void RectTransform_get_pivot_mA5BEEE2069ACA7C0C717530EED3E7D811D46C463 (void);
// 0x00000527 System.Void UnityEngine.RectTransform::set_pivot(UnityEngine.Vector2)
extern void RectTransform_set_pivot_mB791A383B3C870B9CBD7BC51B2C95711C88E9DCF (void);
// 0x00000528 System.Void UnityEngine.RectTransform::set_offsetMin(UnityEngine.Vector2)
extern void RectTransform_set_offsetMin_m7455ED64FF16C597E648E022BA768CFDCF4531AC (void);
// 0x00000529 System.Void UnityEngine.RectTransform::set_offsetMax(UnityEngine.Vector2)
extern void RectTransform_set_offsetMax_mD55D44AD4740C79B5C2C83C60B0C38BF1090501C (void);
// 0x0000052A System.Void UnityEngine.RectTransform::GetLocalCorners(UnityEngine.Vector3[])
extern void RectTransform_GetLocalCorners_m8761EA5FFE1F36041809D10D8AD7BC40CF06A520 (void);
// 0x0000052B System.Void UnityEngine.RectTransform::GetWorldCorners(UnityEngine.Vector3[])
extern void RectTransform_GetWorldCorners_m073AA4D13C51C5654A5983EE3FE7E2E60F7761B6 (void);
// 0x0000052C System.Void UnityEngine.RectTransform::SetSizeWithCurrentAnchors(UnityEngine.RectTransform_Axis,System.Single)
extern void RectTransform_SetSizeWithCurrentAnchors_m6F93CD5B798E4A53F2085862EA1B4021AEAA6745 (void);
// 0x0000052D System.Void UnityEngine.RectTransform::SendReapplyDrivenProperties(UnityEngine.RectTransform)
extern void RectTransform_SendReapplyDrivenProperties_m231712A8CDDCA340752CB72690FE808111286653 (void);
// 0x0000052E UnityEngine.Vector2 UnityEngine.RectTransform::GetParentSize()
extern void RectTransform_GetParentSize_mFD24CC863A4D7DFBFFE23C982E9A11E9B010D25D (void);
// 0x0000052F System.Void UnityEngine.RectTransform::get_rect_Injected(UnityEngine.Rect&)
extern void RectTransform_get_rect_Injected_m94E98A7B55F470FD170EBDA2D47E44CF919CD89F (void);
// 0x00000530 System.Void UnityEngine.RectTransform::get_anchorMin_Injected(UnityEngine.Vector2&)
extern void RectTransform_get_anchorMin_Injected_m11D468B602FFF89A8CC25685C71ACAA36609EF94 (void);
// 0x00000531 System.Void UnityEngine.RectTransform::set_anchorMin_Injected(UnityEngine.Vector2&)
extern void RectTransform_set_anchorMin_Injected_m8BACA1B777D070E5FF42D1D8B1D7A52FFCD59E40 (void);
// 0x00000532 System.Void UnityEngine.RectTransform::get_anchorMax_Injected(UnityEngine.Vector2&)
extern void RectTransform_get_anchorMax_Injected_m61CE870627E5CB0EFAD38D5F207BC36879378DDD (void);
// 0x00000533 System.Void UnityEngine.RectTransform::set_anchorMax_Injected(UnityEngine.Vector2&)
extern void RectTransform_set_anchorMax_Injected_m6BC717A6F528E130AD92994FB9A3614195FBFFB2 (void);
// 0x00000534 System.Void UnityEngine.RectTransform::get_anchoredPosition_Injected(UnityEngine.Vector2&)
extern void RectTransform_get_anchoredPosition_Injected_mCCBAEBA5DD529E03D42194FDE9C2AD1FBA8194E8 (void);
// 0x00000535 System.Void UnityEngine.RectTransform::set_anchoredPosition_Injected(UnityEngine.Vector2&)
extern void RectTransform_set_anchoredPosition_Injected_mCAEE3D22ADA5AF1CB4E37813EB68BF554220DAEF (void);
// 0x00000536 System.Void UnityEngine.RectTransform::get_sizeDelta_Injected(UnityEngine.Vector2&)
extern void RectTransform_get_sizeDelta_Injected_m225C77C72E97B59C07693E339E0132E9547F8982 (void);
// 0x00000537 System.Void UnityEngine.RectTransform::set_sizeDelta_Injected(UnityEngine.Vector2&)
extern void RectTransform_set_sizeDelta_Injected_mD2B6AE8C7BB4DE09F1C62B4A853E592EEF9E8399 (void);
// 0x00000538 System.Void UnityEngine.RectTransform::get_pivot_Injected(UnityEngine.Vector2&)
extern void RectTransform_get_pivot_Injected_m23095C3331BE90EB3EEFFDAE0DAD791E79485F7F (void);
// 0x00000539 System.Void UnityEngine.RectTransform::set_pivot_Injected(UnityEngine.Vector2&)
extern void RectTransform_set_pivot_Injected_m2914C16D5516DE065A932CB43B61C6EEA3C5D3D3 (void);
// 0x0000053A System.Void UnityEngine.RectTransform_ReapplyDrivenProperties::.ctor(System.Object,System.IntPtr)
extern void ReapplyDrivenProperties__ctor_m0633C1B8E1B058DF2C3648C96D3E4DC006A76CA7 (void);
// 0x0000053B System.Void UnityEngine.RectTransform_ReapplyDrivenProperties::Invoke(UnityEngine.RectTransform)
extern void ReapplyDrivenProperties_Invoke_m37F24671E6F3C60B3D0C7E0CE234B8E125D5928A (void);
// 0x0000053C System.IAsyncResult UnityEngine.RectTransform_ReapplyDrivenProperties::BeginInvoke(UnityEngine.RectTransform,System.AsyncCallback,System.Object)
extern void ReapplyDrivenProperties_BeginInvoke_m5C352648167A36402E86BEDDCAE8FA4784C03604 (void);
// 0x0000053D System.Void UnityEngine.RectTransform_ReapplyDrivenProperties::EndInvoke(System.IAsyncResult)
extern void ReapplyDrivenProperties_EndInvoke_mC8DF7BD47EC8976C477491961F44912BA4C0CD7C (void);
// 0x0000053E System.Void UnityEngine.Transform::.ctor()
extern void Transform__ctor_mE8E10A06C8922623BAC6053550D19B2E297C2F35 (void);
// 0x0000053F UnityEngine.Vector3 UnityEngine.Transform::get_position()
extern void Transform_get_position_mF54C3A064F7C8E24F1C56EE128728B2E4485E294 (void);
// 0x00000540 System.Void UnityEngine.Transform::set_position(UnityEngine.Vector3)
extern void Transform_set_position_mDA89E4893F14ECA5CBEEE7FB80A5BF7C1B8EA6DC (void);
// 0x00000541 UnityEngine.Vector3 UnityEngine.Transform::get_localPosition()
extern void Transform_get_localPosition_m812D43318E05BDCB78310EB7308785A13D85EFD8 (void);
// 0x00000542 System.Void UnityEngine.Transform::set_localPosition(UnityEngine.Vector3)
extern void Transform_set_localPosition_m275F5550DD939F83AFEB5E8D681131172E2E1728 (void);
// 0x00000543 UnityEngine.Vector3 UnityEngine.Transform::get_eulerAngles()
extern void Transform_get_eulerAngles_mF2D798FA8B18F7A1A0C4A2198329ADBAF07E37CA (void);
// 0x00000544 System.Void UnityEngine.Transform::set_eulerAngles(UnityEngine.Vector3)
extern void Transform_set_eulerAngles_m4B2B374C0B089A7ED0B522A3A4C56FA868992685 (void);
// 0x00000545 UnityEngine.Vector3 UnityEngine.Transform::get_localEulerAngles()
extern void Transform_get_localEulerAngles_m445AD7F6706B0BDABA8A875C899EB1E1DF1A2A2B (void);
// 0x00000546 System.Void UnityEngine.Transform::set_localEulerAngles(UnityEngine.Vector3)
extern void Transform_set_localEulerAngles_mC5E92A989DD8B2E7B854F9D84B528A34AEAA1A17 (void);
// 0x00000547 UnityEngine.Vector3 UnityEngine.Transform::get_right()
extern void Transform_get_right_mC32CE648E98D3D4F62F897A2751EE567C7C0CFB0 (void);
// 0x00000548 UnityEngine.Vector3 UnityEngine.Transform::get_forward()
extern void Transform_get_forward_m0BE1E88B86049ADA39391C3ACED2314A624BC67F (void);
// 0x00000549 UnityEngine.Quaternion UnityEngine.Transform::get_rotation()
extern void Transform_get_rotation_m3AB90A67403249AECCA5E02BC70FCE8C90FE9FB9 (void);
// 0x0000054A System.Void UnityEngine.Transform::set_rotation(UnityEngine.Quaternion)
extern void Transform_set_rotation_m429694E264117C6DC682EC6AF45C7864E5155935 (void);
// 0x0000054B UnityEngine.Quaternion UnityEngine.Transform::get_localRotation()
extern void Transform_get_localRotation_mEDA319E1B42EF12A19A95AC0824345B6574863FE (void);
// 0x0000054C System.Void UnityEngine.Transform::set_localRotation(UnityEngine.Quaternion)
extern void Transform_set_localRotation_mE2BECB0954FFC1D93FB631600D9A9BEFF41D9C8A (void);
// 0x0000054D UnityEngine.Vector3 UnityEngine.Transform::get_localScale()
extern void Transform_get_localScale_mD8F631021C2D62B7C341B1A17FA75491F64E13DA (void);
// 0x0000054E System.Void UnityEngine.Transform::set_localScale(UnityEngine.Vector3)
extern void Transform_set_localScale_m7ED1A6E5A87CD1D483515B99D6D3121FB92B0556 (void);
// 0x0000054F UnityEngine.Transform UnityEngine.Transform::get_parent()
extern void Transform_get_parent_m8FA24E38A1FA29D90CBF3CDC9F9F017C65BB3403 (void);
// 0x00000550 System.Void UnityEngine.Transform::set_parent(UnityEngine.Transform)
extern void Transform_set_parent_m65B8E4660B2C554069C57A957D9E55FECA7AA73E (void);
// 0x00000551 UnityEngine.Transform UnityEngine.Transform::get_parentInternal()
extern void Transform_get_parentInternal_mEE407FBF144B4EE785164788FD455CAA82DC7C2E (void);
// 0x00000552 System.Void UnityEngine.Transform::set_parentInternal(UnityEngine.Transform)
extern void Transform_set_parentInternal_m8534EFFADCF054FFA081769F84256F9921B0258C (void);
// 0x00000553 UnityEngine.Transform UnityEngine.Transform::GetParent()
extern void Transform_GetParent_m1C9AFA68C014287E3D62A496A5F9AE16EF9BD7E6 (void);
// 0x00000554 System.Void UnityEngine.Transform::SetParent(UnityEngine.Transform)
extern void Transform_SetParent_mFAF9209CAB6A864552074BA065D740924A4BF979 (void);
// 0x00000555 System.Void UnityEngine.Transform::SetParent(UnityEngine.Transform,System.Boolean)
extern void Transform_SetParent_m268E3814921D90882EFECE244A797264DE2A5E35 (void);
// 0x00000556 UnityEngine.Matrix4x4 UnityEngine.Transform::get_worldToLocalMatrix()
extern void Transform_get_worldToLocalMatrix_m4791F881839B1087B17DC126FC0CA7F9A596073E (void);
// 0x00000557 UnityEngine.Matrix4x4 UnityEngine.Transform::get_localToWorldMatrix()
extern void Transform_get_localToWorldMatrix_mBC86B8C7BA6F53DAB8E0120D77729166399A0EED (void);
// 0x00000558 System.Void UnityEngine.Transform::SetPositionAndRotation(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void Transform_SetPositionAndRotation_mDB9B34321018846FD7E2315CBE8D4A6612E3DE43 (void);
// 0x00000559 UnityEngine.Vector3 UnityEngine.Transform::TransformDirection(UnityEngine.Vector3)
extern void Transform_TransformDirection_m85FC1D7E1322E94F65DA59AEF3B1166850B183EF (void);
// 0x0000055A UnityEngine.Vector3 UnityEngine.Transform::TransformPoint(UnityEngine.Vector3)
extern void Transform_TransformPoint_mA96DC2A20EE7F4F915F7509863A18D99F5DD76CB (void);
// 0x0000055B UnityEngine.Vector3 UnityEngine.Transform::InverseTransformPoint(UnityEngine.Vector3)
extern void Transform_InverseTransformPoint_mB6E3145F20B531B4A781C194BAC43A8255C96C47 (void);
// 0x0000055C System.Int32 UnityEngine.Transform::get_childCount()
extern void Transform_get_childCount_m7665D779DCDB6B175FB52A254276CDF0C384A724 (void);
// 0x0000055D System.Void UnityEngine.Transform::SetAsFirstSibling()
extern void Transform_SetAsFirstSibling_m2CAD80F7C9D89EE145BC9D3D0937D6EBEE909531 (void);
// 0x0000055E System.Boolean UnityEngine.Transform::IsChildOf(UnityEngine.Transform)
extern void Transform_IsChildOf_mCB98BA14F7FB82B6AF6AE961E84C47AE1D99AA80 (void);
// 0x0000055F System.Collections.IEnumerator UnityEngine.Transform::GetEnumerator()
extern void Transform_GetEnumerator_mE98B6C5F644AE362EC1D58C10506327D6A5878FC (void);
// 0x00000560 UnityEngine.Transform UnityEngine.Transform::GetChild(System.Int32)
extern void Transform_GetChild_mC86B9B61E4EC086A571B09EA7A33FFBF50DF52D3 (void);
// 0x00000561 System.Void UnityEngine.Transform::get_position_Injected(UnityEngine.Vector3&)
extern void Transform_get_position_Injected_mFD1BD0E2D17761BA08289ABBB4F87EDFFF7C1EBB (void);
// 0x00000562 System.Void UnityEngine.Transform::set_position_Injected(UnityEngine.Vector3&)
extern void Transform_set_position_Injected_mB6BEBF6B460A566E933ED59C4470ED58D81B3226 (void);
// 0x00000563 System.Void UnityEngine.Transform::get_localPosition_Injected(UnityEngine.Vector3&)
extern void Transform_get_localPosition_Injected_mC1E8F9DAC652621188ABFB58571782157E4C8FBA (void);
// 0x00000564 System.Void UnityEngine.Transform::set_localPosition_Injected(UnityEngine.Vector3&)
extern void Transform_set_localPosition_Injected_m8B4E45BAADCDD69683EB6424992FC9B9045927DE (void);
// 0x00000565 System.Void UnityEngine.Transform::get_rotation_Injected(UnityEngine.Quaternion&)
extern void Transform_get_rotation_Injected_m41BEC8ACE323E571978CED341997B1174340701B (void);
// 0x00000566 System.Void UnityEngine.Transform::set_rotation_Injected(UnityEngine.Quaternion&)
extern void Transform_set_rotation_Injected_m1B409EA2BBF0C5DEE05153F4CD5134669AA2E5C0 (void);
// 0x00000567 System.Void UnityEngine.Transform::get_localRotation_Injected(UnityEngine.Quaternion&)
extern void Transform_get_localRotation_Injected_m1ADF4910B326BAA828892B3ADC5AD1A332DE963B (void);
// 0x00000568 System.Void UnityEngine.Transform::set_localRotation_Injected(UnityEngine.Quaternion&)
extern void Transform_set_localRotation_Injected_mF84F8CFA00AABFB7520AB782BA8A6E4BBF24FDD5 (void);
// 0x00000569 System.Void UnityEngine.Transform::get_localScale_Injected(UnityEngine.Vector3&)
extern void Transform_get_localScale_Injected_mA8987BAB5DA11154A22E2B36995C7328792371BE (void);
// 0x0000056A System.Void UnityEngine.Transform::set_localScale_Injected(UnityEngine.Vector3&)
extern void Transform_set_localScale_Injected_m9BF22FF0CD55A5008834951B58BB8E70D6982AB2 (void);
// 0x0000056B System.Void UnityEngine.Transform::get_worldToLocalMatrix_Injected(UnityEngine.Matrix4x4&)
extern void Transform_get_worldToLocalMatrix_Injected_mFEC701DE6F97A22DF1718EB82FBE3C3E62447936 (void);
// 0x0000056C System.Void UnityEngine.Transform::get_localToWorldMatrix_Injected(UnityEngine.Matrix4x4&)
extern void Transform_get_localToWorldMatrix_Injected_mF5629FA21895EB6851367E1636283C7FB70333A9 (void);
// 0x0000056D System.Void UnityEngine.Transform::SetPositionAndRotation_Injected(UnityEngine.Vector3&,UnityEngine.Quaternion&)
extern void Transform_SetPositionAndRotation_Injected_mD8DC359CE79CE34899FF76F73469884818AC299A (void);
// 0x0000056E System.Void UnityEngine.Transform::TransformDirection_Injected(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void Transform_TransformDirection_Injected_m5E7C9D4E879820DF32F1CB1DE1504C59B8E98943 (void);
// 0x0000056F System.Void UnityEngine.Transform::TransformPoint_Injected(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void Transform_TransformPoint_Injected_mB697D04DF989E68C8AAFAE6BFBBE718B68CB477D (void);
// 0x00000570 System.Void UnityEngine.Transform::InverseTransformPoint_Injected(UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void Transform_InverseTransformPoint_Injected_m320ED08EABA9713FDF7BDAD425630D567D39AB1D (void);
// 0x00000571 System.Void UnityEngine.Transform_Enumerator::.ctor(UnityEngine.Transform)
extern void Enumerator__ctor_mBF5A46090D26A1DD98484C00389566FD8CB80770 (void);
// 0x00000572 System.Object UnityEngine.Transform_Enumerator::get_Current()
extern void Enumerator_get_Current_mD91FA41B0959224F24BF83051D46FCF3AF82F773 (void);
// 0x00000573 System.Boolean UnityEngine.Transform_Enumerator::MoveNext()
extern void Enumerator_MoveNext_mF27E895DC4BB3826D2F00E9484A9ECC635770031 (void);
// 0x00000574 System.Void UnityEngine.Transform_Enumerator::Reset()
extern void Enumerator_Reset_mA4AD59858E0D61FE247C0E158737A4C02FCE244F (void);
// 0x00000575 System.Void UnityEngine.Sprite::.ctor()
extern void Sprite__ctor_m8559FBC54BD7CDA181B190797CC8AC6FB1310F9E (void);
// 0x00000576 System.Int32 UnityEngine.Sprite::GetPackingMode()
extern void Sprite_GetPackingMode_mF0507D88752CDA45A9283445067070092E524317 (void);
// 0x00000577 System.Int32 UnityEngine.Sprite::GetPacked()
extern void Sprite_GetPacked_mBDE07283B07E7FB8892D309C5EDC81584C849BCC (void);
// 0x00000578 UnityEngine.Rect UnityEngine.Sprite::GetTextureRect()
extern void Sprite_GetTextureRect_mE506ABF33181E32E82B75479EE4A0910350B1BF9 (void);
// 0x00000579 UnityEngine.Vector4 UnityEngine.Sprite::GetInnerUVs()
extern void Sprite_GetInnerUVs_m273E051E7DF38ED3D6077781D75A1C1019CABA25 (void);
// 0x0000057A UnityEngine.Vector4 UnityEngine.Sprite::GetOuterUVs()
extern void Sprite_GetOuterUVs_mD78E47470B4D8AD231F194E256136B0094ECEBC5 (void);
// 0x0000057B UnityEngine.Vector4 UnityEngine.Sprite::GetPadding()
extern void Sprite_GetPadding_m5781452D40FAE3B7D0CE78BF8808637FBFE78105 (void);
// 0x0000057C UnityEngine.Sprite UnityEngine.Sprite::CreateSprite(UnityEngine.Texture2D,UnityEngine.Rect,UnityEngine.Vector2,System.Single,System.UInt32,UnityEngine.SpriteMeshType,UnityEngine.Vector4,System.Boolean)
extern void Sprite_CreateSprite_m1F676037B8C5EB3E216F70EE4630662FF144AFC5 (void);
// 0x0000057D UnityEngine.Bounds UnityEngine.Sprite::get_bounds()
extern void Sprite_get_bounds_mD440465B889CCD2D80D118F9174FD5EAB19AE874 (void);
// 0x0000057E UnityEngine.Rect UnityEngine.Sprite::get_rect()
extern void Sprite_get_rect_mF1D59ED35D077D9B5075E2114605FDEB728D3AFF (void);
// 0x0000057F UnityEngine.Vector4 UnityEngine.Sprite::get_border()
extern void Sprite_get_border_m940E803CAD380B3B1B88371D7A4E74DF9A48604F (void);
// 0x00000580 UnityEngine.Texture2D UnityEngine.Sprite::get_texture()
extern void Sprite_get_texture_mA1FF8462BBB398DC8B3F0F92B2AB41BDA6AF69A5 (void);
// 0x00000581 System.Single UnityEngine.Sprite::get_pixelsPerUnit()
extern void Sprite_get_pixelsPerUnit_m54E3B43BD3D255D18CAE3DC8D963A81846983030 (void);
// 0x00000582 UnityEngine.Texture2D UnityEngine.Sprite::get_associatedAlphaSplitTexture()
extern void Sprite_get_associatedAlphaSplitTexture_m2EF38CF62616FBBBBAE7876ECBCC596DB3F42156 (void);
// 0x00000583 UnityEngine.Vector2 UnityEngine.Sprite::get_pivot()
extern void Sprite_get_pivot_m8E3D24C208E01EC8464B0E63FBF3FB9429E4C1D9 (void);
// 0x00000584 System.Boolean UnityEngine.Sprite::get_packed()
extern void Sprite_get_packed_m501A9E7D2C44867665FB579FD1A8C5D397C872C3 (void);
// 0x00000585 UnityEngine.SpritePackingMode UnityEngine.Sprite::get_packingMode()
extern void Sprite_get_packingMode_m1B5AA0F5476DAEADFF14F65E99944B54940D869F (void);
// 0x00000586 UnityEngine.Rect UnityEngine.Sprite::get_textureRect()
extern void Sprite_get_textureRect_m8CDA38796589CB967909F78076E7138907814DCD (void);
// 0x00000587 UnityEngine.Vector2[] UnityEngine.Sprite::get_vertices()
extern void Sprite_get_vertices_mD858385A07239A56691D1559728B1B5765C32722 (void);
// 0x00000588 System.UInt16[] UnityEngine.Sprite::get_triangles()
extern void Sprite_get_triangles_m3B0A097930B40C800E0591E5B095D118D2A33D2E (void);
// 0x00000589 UnityEngine.Vector2[] UnityEngine.Sprite::get_uv()
extern void Sprite_get_uv_mBD484CDCD2DF54AAE452ADBA927806193CB0FE84 (void);
// 0x0000058A UnityEngine.Sprite UnityEngine.Sprite::Create(UnityEngine.Texture2D,UnityEngine.Rect,UnityEngine.Vector2,System.Single,System.UInt32,UnityEngine.SpriteMeshType,UnityEngine.Vector4,System.Boolean)
extern void Sprite_Create_mE9E237E1E936F7A7398361253D1D7C7B7ECD622F (void);
// 0x0000058B UnityEngine.Sprite UnityEngine.Sprite::Create(UnityEngine.Texture2D,UnityEngine.Rect,UnityEngine.Vector2,System.Single,System.UInt32,UnityEngine.SpriteMeshType,UnityEngine.Vector4)
extern void Sprite_Create_m4BF8E8E0F77846FA88502FD896E3AFB6D2AB2E0A (void);
// 0x0000058C UnityEngine.Sprite UnityEngine.Sprite::Create(UnityEngine.Texture2D,UnityEngine.Rect,UnityEngine.Vector2,System.Single,System.UInt32,UnityEngine.SpriteMeshType)
extern void Sprite_Create_mBF0676DF6C3CB8554451DC01E0713CF73C84DB4A (void);
// 0x0000058D UnityEngine.Sprite UnityEngine.Sprite::Create(UnityEngine.Texture2D,UnityEngine.Rect,UnityEngine.Vector2,System.Single,System.UInt32)
extern void Sprite_Create_mE9C9B96A1D1EC541FF41148E2001223C2030F803 (void);
// 0x0000058E UnityEngine.Sprite UnityEngine.Sprite::Create(UnityEngine.Texture2D,UnityEngine.Rect,UnityEngine.Vector2,System.Single)
extern void Sprite_Create_m84A724DB0F0D73AEBE5296B4324D61EBCA72A843 (void);
// 0x0000058F UnityEngine.Sprite UnityEngine.Sprite::Create(UnityEngine.Texture2D,UnityEngine.Rect,UnityEngine.Vector2)
extern void Sprite_Create_m9ED36DA8DA0637F93BA2753A16405EB0F7B17A3C (void);
// 0x00000590 System.Void UnityEngine.Sprite::GetTextureRect_Injected(UnityEngine.Rect&)
extern void Sprite_GetTextureRect_Injected_m3D0143FD7E689267FAE3164F7C149DB5FF3384C2 (void);
// 0x00000591 System.Void UnityEngine.Sprite::GetInnerUVs_Injected(UnityEngine.Vector4&)
extern void Sprite_GetInnerUVs_Injected_m19AF3A32647EE2153374B4B58CB248A5E3715F6B (void);
// 0x00000592 System.Void UnityEngine.Sprite::GetOuterUVs_Injected(UnityEngine.Vector4&)
extern void Sprite_GetOuterUVs_Injected_m57E56A2D7686D47E6948511F102AF8135E98B2B0 (void);
// 0x00000593 System.Void UnityEngine.Sprite::GetPadding_Injected(UnityEngine.Vector4&)
extern void Sprite_GetPadding_Injected_m843873F288F8CBC4BDDF1BBE20211405039ABBDC (void);
// 0x00000594 UnityEngine.Sprite UnityEngine.Sprite::CreateSprite_Injected(UnityEngine.Texture2D,UnityEngine.Rect&,UnityEngine.Vector2&,System.Single,System.UInt32,UnityEngine.SpriteMeshType,UnityEngine.Vector4&,System.Boolean)
extern void Sprite_CreateSprite_Injected_m5393FA2042C8AF5D7E9CC32A2255270EE3DA702D (void);
// 0x00000595 System.Void UnityEngine.Sprite::get_bounds_Injected(UnityEngine.Bounds&)
extern void Sprite_get_bounds_Injected_m6422C2DBFD84A7B7F921DCA14BDFF2157738194B (void);
// 0x00000596 System.Void UnityEngine.Sprite::get_rect_Injected(UnityEngine.Rect&)
extern void Sprite_get_rect_Injected_mABF4FCC2AEDD9EE874797E35EDEFF023A52F5830 (void);
// 0x00000597 System.Void UnityEngine.Sprite::get_border_Injected(UnityEngine.Vector4&)
extern void Sprite_get_border_Injected_mA56DD9A38B61783341DF35C808FBFE93A1BD4BB6 (void);
// 0x00000598 System.Void UnityEngine.Sprite::get_pivot_Injected(UnityEngine.Vector2&)
extern void Sprite_get_pivot_Injected_m526201DCD812D7AB10AACE35E4195F7E53B633EC (void);
// 0x00000599 System.Boolean UnityEngine._Scripting.APIUpdating.APIUpdaterRuntimeHelpers::GetMovedFromAttributeDataForType(System.Type,System.String&,System.String&,System.String&)
extern void APIUpdaterRuntimeHelpers_GetMovedFromAttributeDataForType_m2574674719979232087612C3C17A760E439BCA45 (void);
// 0x0000059A System.Boolean UnityEngine._Scripting.APIUpdating.APIUpdaterRuntimeHelpers::GetObsoleteTypeRedirection(System.Type,System.String&,System.String&,System.String&)
extern void APIUpdaterRuntimeHelpers_GetObsoleteTypeRedirection_m43E0605422153F402426F8959BC2E8C65A69F597 (void);
// 0x0000059B UnityEngine.Vector4 UnityEngine.Sprites.DataUtility::GetInnerUV(UnityEngine.Sprite)
extern void DataUtility_GetInnerUV_m19FC4FF27A6733C9595B63F265EFBEC3BC183732 (void);
// 0x0000059C UnityEngine.Vector4 UnityEngine.Sprites.DataUtility::GetOuterUV(UnityEngine.Sprite)
extern void DataUtility_GetOuterUV_mB7DEA861925EECF861EEB643145C54E8BF449213 (void);
// 0x0000059D UnityEngine.Vector4 UnityEngine.Sprites.DataUtility::GetPadding(UnityEngine.Sprite)
extern void DataUtility_GetPadding_mE967167C8AB44F752F7C3A7B9D0A2789F5BD7034 (void);
// 0x0000059E UnityEngine.Vector2 UnityEngine.Sprites.DataUtility::GetMinSize(UnityEngine.Sprite)
extern void DataUtility_GetMinSize_m8031F50000ACDDD00E1CE4C765FA4B0A2E9255AD (void);
// 0x0000059F System.Void UnityEngine.U2D.PixelPerfectRendering::set_pixelSnapSpacing(System.Single)
extern void PixelPerfectRendering_set_pixelSnapSpacing_mDBC4671A1F9226F5082533483F64B9B2E65DFC32 (void);
// 0x000005A0 System.Boolean UnityEngine.U2D.SpriteAtlasManager::RequestAtlas(System.String)
extern void SpriteAtlasManager_RequestAtlas_m792F61C44C634D9E8F1E15401C8CECB7A12F5DDE (void);
// 0x000005A1 System.Void UnityEngine.U2D.SpriteAtlasManager::add_atlasRegistered(System.Action`1<UnityEngine.U2D.SpriteAtlas>)
extern void SpriteAtlasManager_add_atlasRegistered_m6742D91F217B69CC2A65D80B5F25CFA372A1E2DA (void);
// 0x000005A2 System.Void UnityEngine.U2D.SpriteAtlasManager::remove_atlasRegistered(System.Action`1<UnityEngine.U2D.SpriteAtlas>)
extern void SpriteAtlasManager_remove_atlasRegistered_m55564CC2797E687E4B966DC1797D059ABBB04051 (void);
// 0x000005A3 System.Void UnityEngine.U2D.SpriteAtlasManager::PostRegisteredAtlas(UnityEngine.U2D.SpriteAtlas)
extern void SpriteAtlasManager_PostRegisteredAtlas_m2FCA85EDC754279C0A90CC3AF5E12C3E8F6A61CB (void);
// 0x000005A4 System.Void UnityEngine.U2D.SpriteAtlasManager::Register(UnityEngine.U2D.SpriteAtlas)
extern void SpriteAtlasManager_Register_m2C324F6E122AF09D44E4EE3F8F024323663670D2 (void);
// 0x000005A5 System.Void UnityEngine.U2D.SpriteAtlasManager::.cctor()
extern void SpriteAtlasManager__cctor_m826C9096AB53C9C6CFCF342FA9FDC345A726B6C6 (void);
// 0x000005A6 System.Boolean UnityEngine.U2D.SpriteAtlas::CanBindTo(UnityEngine.Sprite)
extern void SpriteAtlas_CanBindTo_m6CE0E011A4C5F489F9A62317380FB35F20DF7016 (void);
// 0x000005A7 System.Void UnityEngine.Profiling.Sampler::.ctor()
extern void Sampler__ctor_mEDF95F36C69BA3C699F942DE455131B3B74A772A (void);
// 0x000005A8 System.Void UnityEngine.Profiling.Sampler::.cctor()
extern void Sampler__cctor_mF1262C0B147581D48C65976480293BA7E4CE816F (void);
// 0x000005A9 System.Void UnityEngine.Profiling.CustomSampler::.ctor()
extern void CustomSampler__ctor_m6AF8A65CE6483316530AC812D0A3904DD30BE426 (void);
// 0x000005AA System.Void UnityEngine.Profiling.CustomSampler::.ctor(System.IntPtr)
extern void CustomSampler__ctor_m3C1E95E5355AE3C5C736F6DAFCBF5EB92E5E4771 (void);
// 0x000005AB UnityEngine.Profiling.CustomSampler UnityEngine.Profiling.CustomSampler::Create(System.String)
extern void CustomSampler_Create_m454B8B69BB1085AAC8AFC39B1EB311474080C0BA (void);
// 0x000005AC System.IntPtr UnityEngine.Profiling.CustomSampler::CreateInternal(System.String)
extern void CustomSampler_CreateInternal_mDD89E974215C157E5BCD54ABCFCB56CF6BAB3B8F (void);
// 0x000005AD System.Void UnityEngine.Profiling.CustomSampler::.cctor()
extern void CustomSampler__cctor_mB5B9C73DFC279A84D57351F6AE105779B94ABDED (void);
// 0x000005AE System.Void UnityEngine.Profiling.Experimental.DebugScreenCapture::set_rawImageDataReference(Unity.Collections.NativeArray`1<System.Byte>)
extern void DebugScreenCapture_set_rawImageDataReference_mE09725CEBC8D7A846033531E33C8E9B8DA60DFDE_AdjustorThunk (void);
// 0x000005AF System.Void UnityEngine.Profiling.Experimental.DebugScreenCapture::set_imageFormat(UnityEngine.TextureFormat)
extern void DebugScreenCapture_set_imageFormat_m779E16070B55AACD76279BFDDAE5CC470667D3FB_AdjustorThunk (void);
// 0x000005B0 System.Void UnityEngine.Profiling.Experimental.DebugScreenCapture::set_width(System.Int32)
extern void DebugScreenCapture_set_width_mD8B3C521091CD0049D323410FFD201D47B629127_AdjustorThunk (void);
// 0x000005B1 System.Void UnityEngine.Profiling.Experimental.DebugScreenCapture::set_height(System.Int32)
extern void DebugScreenCapture_set_height_mD7E3596B40E77F906A3E9517BC6CE795C0609442_AdjustorThunk (void);
// 0x000005B2 System.Void UnityEngine.Profiling.Memory.Experimental.MetaData::.ctor()
extern void MetaData__ctor_m1852CAF4EDFB43F1ABCE37819D9963CEE959A620 (void);
// 0x000005B3 System.Byte[] UnityEngine.Profiling.Memory.Experimental.MemoryProfiler::PrepareMetadata()
extern void MemoryProfiler_PrepareMetadata_mDFBA7A9960E5B4DF4500092638CD59EB558DD42C (void);
// 0x000005B4 System.Int32 UnityEngine.Profiling.Memory.Experimental.MemoryProfiler::WriteIntToByteArray(System.Byte[],System.Int32,System.Int32)
extern void MemoryProfiler_WriteIntToByteArray_mBC872709F6A09ADFE716F41C459C1FCC1EFF25A0 (void);
// 0x000005B5 System.Int32 UnityEngine.Profiling.Memory.Experimental.MemoryProfiler::WriteStringToByteArray(System.Byte[],System.Int32,System.String)
extern void MemoryProfiler_WriteStringToByteArray_mCAC0D283F16F612E4796C539994FDB487A048332 (void);
// 0x000005B6 System.Void UnityEngine.Profiling.Memory.Experimental.MemoryProfiler::FinalizeSnapshot(System.String,System.Boolean)
extern void MemoryProfiler_FinalizeSnapshot_m48FD62744888BBF0A9B13826622041226C8B9AD7 (void);
// 0x000005B7 System.Void UnityEngine.Profiling.Memory.Experimental.MemoryProfiler::SaveScreenshotToDisk(System.String,System.Boolean,System.IntPtr,System.Int32,UnityEngine.TextureFormat,System.Int32,System.Int32)
extern void MemoryProfiler_SaveScreenshotToDisk_mCA2AE332D689BEDE49DECACD92FDA366EB80047F (void);
// 0x000005B8 System.Void UnityEngine.Windows.Speech.PhraseRecognitionSystem::PhraseRecognitionSystem_InvokeErrorEvent(UnityEngine.Windows.Speech.SpeechError)
extern void PhraseRecognitionSystem_PhraseRecognitionSystem_InvokeErrorEvent_m9FF196C06264F6035686945A734E1AC01A0E2E33 (void);
// 0x000005B9 System.Void UnityEngine.Windows.Speech.PhraseRecognitionSystem::PhraseRecognitionSystem_InvokeStatusChangedEvent(UnityEngine.Windows.Speech.SpeechSystemStatus)
extern void PhraseRecognitionSystem_PhraseRecognitionSystem_InvokeStatusChangedEvent_mF25930BC6443439CCBAF346B89799358451239D8 (void);
// 0x000005BA System.Void UnityEngine.Windows.Speech.PhraseRecognitionSystem_ErrorDelegate::.ctor(System.Object,System.IntPtr)
extern void ErrorDelegate__ctor_mE77BF50AF1FD2FE54199276141F6B3CB17D2E1B1 (void);
// 0x000005BB System.Void UnityEngine.Windows.Speech.PhraseRecognitionSystem_ErrorDelegate::Invoke(UnityEngine.Windows.Speech.SpeechError)
extern void ErrorDelegate_Invoke_m448BAD63228E49AEB609A60052F1E05C93853B17 (void);
// 0x000005BC System.IAsyncResult UnityEngine.Windows.Speech.PhraseRecognitionSystem_ErrorDelegate::BeginInvoke(UnityEngine.Windows.Speech.SpeechError,System.AsyncCallback,System.Object)
extern void ErrorDelegate_BeginInvoke_m3A859400873FD62B71B597C2771E50F94B344E09 (void);
// 0x000005BD System.Void UnityEngine.Windows.Speech.PhraseRecognitionSystem_ErrorDelegate::EndInvoke(System.IAsyncResult)
extern void ErrorDelegate_EndInvoke_m140002C504FD22C3B6C0F150576D37EE4A921189 (void);
// 0x000005BE System.Void UnityEngine.Windows.Speech.PhraseRecognitionSystem_StatusDelegate::.ctor(System.Object,System.IntPtr)
extern void StatusDelegate__ctor_mA3683647B7522FDFCC92DBE0161D7F585741477E (void);
// 0x000005BF System.Void UnityEngine.Windows.Speech.PhraseRecognitionSystem_StatusDelegate::Invoke(UnityEngine.Windows.Speech.SpeechSystemStatus)
extern void StatusDelegate_Invoke_mBA807D0015000ABE36C5B9B6F847D2882D3B26ED (void);
// 0x000005C0 System.IAsyncResult UnityEngine.Windows.Speech.PhraseRecognitionSystem_StatusDelegate::BeginInvoke(UnityEngine.Windows.Speech.SpeechSystemStatus,System.AsyncCallback,System.Object)
extern void StatusDelegate_BeginInvoke_m814D9105249F941053622B079479E04A4FB6D227 (void);
// 0x000005C1 System.Void UnityEngine.Windows.Speech.PhraseRecognitionSystem_StatusDelegate::EndInvoke(System.IAsyncResult)
extern void StatusDelegate_EndInvoke_mF6B9A0C43A10A4CA34F56684DD4FB842FFB5D1FF (void);
// 0x000005C2 System.Void UnityEngine.Windows.Speech.PhraseRecognizer::InvokePhraseRecognizedEvent(System.String,UnityEngine.Windows.Speech.ConfidenceLevel,UnityEngine.Windows.Speech.SemanticMeaning[],System.Int64,System.Int64)
extern void PhraseRecognizer_InvokePhraseRecognizedEvent_mDBD38FADAC58DF9B960342AC84EE32CF221B0F02 (void);
// 0x000005C3 UnityEngine.Windows.Speech.SemanticMeaning[] UnityEngine.Windows.Speech.PhraseRecognizer::MarshalSemanticMeaning(System.IntPtr,System.IntPtr,System.IntPtr,System.Int32)
extern void PhraseRecognizer_MarshalSemanticMeaning_m444804CA07F778FD0E23E78432EE0E377579C26A (void);
// 0x000005C4 System.Void UnityEngine.Windows.Speech.PhraseRecognizer_PhraseRecognizedDelegate::.ctor(System.Object,System.IntPtr)
extern void PhraseRecognizedDelegate__ctor_m0D7CFE194591D6DEE1120B7E23917C77ED5027F1 (void);
// 0x000005C5 System.Void UnityEngine.Windows.Speech.PhraseRecognizer_PhraseRecognizedDelegate::Invoke(UnityEngine.Windows.Speech.PhraseRecognizedEventArgs)
extern void PhraseRecognizedDelegate_Invoke_m6136E32699B51A86EA0C594D338C7EC29F493478 (void);
// 0x000005C6 System.IAsyncResult UnityEngine.Windows.Speech.PhraseRecognizer_PhraseRecognizedDelegate::BeginInvoke(UnityEngine.Windows.Speech.PhraseRecognizedEventArgs,System.AsyncCallback,System.Object)
extern void PhraseRecognizedDelegate_BeginInvoke_m262B7DABBDF14FCBFF43293BF2FB06AC676CB962 (void);
// 0x000005C7 System.Void UnityEngine.Windows.Speech.PhraseRecognizer_PhraseRecognizedDelegate::EndInvoke(System.IAsyncResult)
extern void PhraseRecognizedDelegate_EndInvoke_m53944ABF37F32936C799FBBD922F7ECD9B0235D4 (void);
// 0x000005C8 System.Void UnityEngine.Windows.Speech.DictationRecognizer::DictationRecognizer_InvokeHypothesisGeneratedEvent(System.String)
extern void DictationRecognizer_DictationRecognizer_InvokeHypothesisGeneratedEvent_mD5D8576CD4D2BC21FFBBFACAE879D9E35BFD4BED (void);
// 0x000005C9 System.Void UnityEngine.Windows.Speech.DictationRecognizer::DictationRecognizer_InvokeResultGeneratedEvent(System.String,UnityEngine.Windows.Speech.ConfidenceLevel)
extern void DictationRecognizer_DictationRecognizer_InvokeResultGeneratedEvent_m144DE6D67869D7308AA407D42D068B17410916EA (void);
// 0x000005CA System.Void UnityEngine.Windows.Speech.DictationRecognizer::DictationRecognizer_InvokeCompletedEvent(UnityEngine.Windows.Speech.DictationCompletionCause)
extern void DictationRecognizer_DictationRecognizer_InvokeCompletedEvent_mCB00EBDBFA1E43EEEFEF8A98BC681350ED071479 (void);
// 0x000005CB System.Void UnityEngine.Windows.Speech.DictationRecognizer::DictationRecognizer_InvokeErrorEvent(System.String,System.Int32)
extern void DictationRecognizer_DictationRecognizer_InvokeErrorEvent_mF72B166A7D7F1D73E508FD4350DD6B4A147D047F (void);
// 0x000005CC System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationHypothesisDelegate::.ctor(System.Object,System.IntPtr)
extern void DictationHypothesisDelegate__ctor_mFB606F04C9375D67CD8701F116EA58381924D3A1 (void);
// 0x000005CD System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationHypothesisDelegate::Invoke(System.String)
extern void DictationHypothesisDelegate_Invoke_m13B00B4DADC3F35EF3655EFEA69A68917609CD53 (void);
// 0x000005CE System.IAsyncResult UnityEngine.Windows.Speech.DictationRecognizer_DictationHypothesisDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void DictationHypothesisDelegate_BeginInvoke_mFCA96ECCE23AB50C58CA8DA154B73C7E20C618F1 (void);
// 0x000005CF System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationHypothesisDelegate::EndInvoke(System.IAsyncResult)
extern void DictationHypothesisDelegate_EndInvoke_mD3BED2D554BE05C00F5393F48BD66E3B8AFF283C (void);
// 0x000005D0 System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationResultDelegate::.ctor(System.Object,System.IntPtr)
extern void DictationResultDelegate__ctor_mDECF2707DE7D125C6DE6BE8EC8E1BCD1539CF40C (void);
// 0x000005D1 System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationResultDelegate::Invoke(System.String,UnityEngine.Windows.Speech.ConfidenceLevel)
extern void DictationResultDelegate_Invoke_mC2BCB095B651CD4DE23FED7A0A0C92A6684A5C91 (void);
// 0x000005D2 System.IAsyncResult UnityEngine.Windows.Speech.DictationRecognizer_DictationResultDelegate::BeginInvoke(System.String,UnityEngine.Windows.Speech.ConfidenceLevel,System.AsyncCallback,System.Object)
extern void DictationResultDelegate_BeginInvoke_mB1DAE084A144180C6B6C3FBB95FC11C953E51872 (void);
// 0x000005D3 System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationResultDelegate::EndInvoke(System.IAsyncResult)
extern void DictationResultDelegate_EndInvoke_m9F81B0B190A0455B077CDC0222059CEA973B83C3 (void);
// 0x000005D4 System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationCompletedDelegate::.ctor(System.Object,System.IntPtr)
extern void DictationCompletedDelegate__ctor_m5B703B2796175B619EDBD28F7B6EB86294678369 (void);
// 0x000005D5 System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationCompletedDelegate::Invoke(UnityEngine.Windows.Speech.DictationCompletionCause)
extern void DictationCompletedDelegate_Invoke_m393D08D4E4C4BDC07D2C1086678A3BC34ADD5C37 (void);
// 0x000005D6 System.IAsyncResult UnityEngine.Windows.Speech.DictationRecognizer_DictationCompletedDelegate::BeginInvoke(UnityEngine.Windows.Speech.DictationCompletionCause,System.AsyncCallback,System.Object)
extern void DictationCompletedDelegate_BeginInvoke_m86D73A3A2CE70124C65709ADABB270C4F4A981F1 (void);
// 0x000005D7 System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationCompletedDelegate::EndInvoke(System.IAsyncResult)
extern void DictationCompletedDelegate_EndInvoke_m76C332FC975E3C94B71ED70F0CC1F04DE52BA964 (void);
// 0x000005D8 System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationErrorHandler::.ctor(System.Object,System.IntPtr)
extern void DictationErrorHandler__ctor_m13B3D1B66DB5DB3FA513E70E2DBEEBA1FDC6D0D6 (void);
// 0x000005D9 System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationErrorHandler::Invoke(System.String,System.Int32)
extern void DictationErrorHandler_Invoke_mC67E23094C88F1042656F92133FE2C9E32FFA52F (void);
// 0x000005DA System.IAsyncResult UnityEngine.Windows.Speech.DictationRecognizer_DictationErrorHandler::BeginInvoke(System.String,System.Int32,System.AsyncCallback,System.Object)
extern void DictationErrorHandler_BeginInvoke_mD24E9C40E56521AC36B8D32518198DFB89D9827C (void);
// 0x000005DB System.Void UnityEngine.Windows.Speech.DictationRecognizer_DictationErrorHandler::EndInvoke(System.IAsyncResult)
extern void DictationErrorHandler_EndInvoke_mD1499F5B20B970B36944DFE8111CE94171656798 (void);
// 0x000005DC System.Void UnityEngine.Windows.Speech.PhraseRecognizedEventArgs::.ctor(System.String,UnityEngine.Windows.Speech.ConfidenceLevel,UnityEngine.Windows.Speech.SemanticMeaning[],System.DateTime,System.TimeSpan)
extern void PhraseRecognizedEventArgs__ctor_m362E97ADA890AE34C5E062B0FEED70E46E110ECE_AdjustorThunk (void);
// 0x000005DD UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult UnityEngine.Windows.WebCam.PhotoCapture::MakeCaptureResult(System.Int64)
extern void PhotoCapture_MakeCaptureResult_m30A1524DDA706A094516C9C1E191367B8194B2AA (void);
// 0x000005DE System.Void UnityEngine.Windows.WebCam.PhotoCapture::InvokeOnCreatedResourceDelegate(UnityEngine.Windows.WebCam.PhotoCapture_OnCaptureResourceCreatedCallback,System.IntPtr)
extern void PhotoCapture_InvokeOnCreatedResourceDelegate_mAEC319E9811B816A642DA8A135CCEC3CB91C75DA (void);
// 0x000005DF System.Void UnityEngine.Windows.WebCam.PhotoCapture::.ctor(System.IntPtr)
extern void PhotoCapture__ctor_mD7209B9F37CC0D345E634824E5792EB186EED544 (void);
// 0x000005E0 System.Void UnityEngine.Windows.WebCam.PhotoCapture::InvokeOnPhotoModeStartedDelegate(UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStartedCallback,System.Int64)
extern void PhotoCapture_InvokeOnPhotoModeStartedDelegate_m8C4172E50A49CDC9F2895BCE031428B4EE931CC2 (void);
// 0x000005E1 System.Void UnityEngine.Windows.WebCam.PhotoCapture::InvokeOnPhotoModeStoppedDelegate(UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStoppedCallback,System.Int64)
extern void PhotoCapture_InvokeOnPhotoModeStoppedDelegate_m17CFB212EE2F2E765241E0E6DD8F2B17E03B6F94 (void);
// 0x000005E2 System.Void UnityEngine.Windows.WebCam.PhotoCapture::InvokeOnCapturedPhotoToDiskDelegate(UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToDiskCallback,System.Int64)
extern void PhotoCapture_InvokeOnCapturedPhotoToDiskDelegate_mB6AEB939C6D1ACC29FA6E711E92924319674E604 (void);
// 0x000005E3 System.Void UnityEngine.Windows.WebCam.PhotoCapture::InvokeOnCapturedPhotoToMemoryDelegate(UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToMemoryCallback,System.Int64,System.IntPtr)
extern void PhotoCapture_InvokeOnCapturedPhotoToMemoryDelegate_m81F2206975AEBC72CBE1238EDA770DCE7F9A9ED8 (void);
// 0x000005E4 System.Void UnityEngine.Windows.WebCam.PhotoCapture::Dispose()
extern void PhotoCapture_Dispose_mAC295018942A4ACBBC627647FE0F463C21F94CE0 (void);
// 0x000005E5 System.Void UnityEngine.Windows.WebCam.PhotoCapture::Dispose_Internal()
extern void PhotoCapture_Dispose_Internal_m88BD45BC25F5336BF81ECF697CC14F5FC04D8234 (void);
// 0x000005E6 System.Void UnityEngine.Windows.WebCam.PhotoCapture::Finalize()
extern void PhotoCapture_Finalize_m8F5ABCCAA23CFF5949D6DC26EE6A164C2B952A42 (void);
// 0x000005E7 System.Void UnityEngine.Windows.WebCam.PhotoCapture::DisposeThreaded_Internal()
extern void PhotoCapture_DisposeThreaded_Internal_m2ECAF91B1E62B4B392A1CAA7953C5A599C6115B9 (void);
// 0x000005E8 System.Void UnityEngine.Windows.WebCam.PhotoCapture::.cctor()
extern void PhotoCapture__cctor_mB6B5B17F07B739073CCE8934A6AF65A74DD53259 (void);
// 0x000005E9 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCaptureResourceCreatedCallback::.ctor(System.Object,System.IntPtr)
extern void OnCaptureResourceCreatedCallback__ctor_mAAD465DAB1EA7C5EAEEF4D99E58E790A84523131 (void);
// 0x000005EA System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCaptureResourceCreatedCallback::Invoke(UnityEngine.Windows.WebCam.PhotoCapture)
extern void OnCaptureResourceCreatedCallback_Invoke_m787BA10D9B4F55B5015FF0790E904D3822357A1A (void);
// 0x000005EB System.IAsyncResult UnityEngine.Windows.WebCam.PhotoCapture_OnCaptureResourceCreatedCallback::BeginInvoke(UnityEngine.Windows.WebCam.PhotoCapture,System.AsyncCallback,System.Object)
extern void OnCaptureResourceCreatedCallback_BeginInvoke_mDC83388D4F69C259D3E383BB43257060AC0B9949 (void);
// 0x000005EC System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCaptureResourceCreatedCallback::EndInvoke(System.IAsyncResult)
extern void OnCaptureResourceCreatedCallback_EndInvoke_mB7FDC61A9CC48C49932893AC1FF1B48EBCAA4CF0 (void);
// 0x000005ED System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStartedCallback::.ctor(System.Object,System.IntPtr)
extern void OnPhotoModeStartedCallback__ctor_m990C6B308C927E3A4CF7B9F6B5C8E100990F4030 (void);
// 0x000005EE System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStartedCallback::Invoke(UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult)
extern void OnPhotoModeStartedCallback_Invoke_m55517FF76661702C2833E956934524EDBBF5A7C1 (void);
// 0x000005EF System.IAsyncResult UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStartedCallback::BeginInvoke(UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult,System.AsyncCallback,System.Object)
extern void OnPhotoModeStartedCallback_BeginInvoke_mBCCD40B907D5289FBD9F4E306E68BED5E74D7E4E (void);
// 0x000005F0 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStartedCallback::EndInvoke(System.IAsyncResult)
extern void OnPhotoModeStartedCallback_EndInvoke_m1302B87CE9EB9432AA4DB74D5DFDBD1823E5FD0C (void);
// 0x000005F1 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStoppedCallback::.ctor(System.Object,System.IntPtr)
extern void OnPhotoModeStoppedCallback__ctor_m8A90D66450A8C11352A39C2A61ECA8B4AE482933 (void);
// 0x000005F2 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStoppedCallback::Invoke(UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult)
extern void OnPhotoModeStoppedCallback_Invoke_m48D94A324C05FC097090E2C876AF6B4BC8EE13EE (void);
// 0x000005F3 System.IAsyncResult UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStoppedCallback::BeginInvoke(UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult,System.AsyncCallback,System.Object)
extern void OnPhotoModeStoppedCallback_BeginInvoke_m21A3D9F9B428F00D754B8C4DFAFC6E5C594E5B35 (void);
// 0x000005F4 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnPhotoModeStoppedCallback::EndInvoke(System.IAsyncResult)
extern void OnPhotoModeStoppedCallback_EndInvoke_m32021025A8CCD26030D859237B8304EC0CAF06AD (void);
// 0x000005F5 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToDiskCallback::.ctor(System.Object,System.IntPtr)
extern void OnCapturedToDiskCallback__ctor_m422F63D53BEB921A7685600FBE41069C79959EE3 (void);
// 0x000005F6 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToDiskCallback::Invoke(UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult)
extern void OnCapturedToDiskCallback_Invoke_m9117393C833DA86181047DD79B92317B940AEB06 (void);
// 0x000005F7 System.IAsyncResult UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToDiskCallback::BeginInvoke(UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult,System.AsyncCallback,System.Object)
extern void OnCapturedToDiskCallback_BeginInvoke_mBFF762F91DF363C1BC015BDEF93B1242A02FF9F6 (void);
// 0x000005F8 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToDiskCallback::EndInvoke(System.IAsyncResult)
extern void OnCapturedToDiskCallback_EndInvoke_mC2E3EC1D4522A7910110D94DECC7CCD0B21123D1 (void);
// 0x000005F9 System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToMemoryCallback::.ctor(System.Object,System.IntPtr)
extern void OnCapturedToMemoryCallback__ctor_m377769F37D6EA6AD73ED08D5A14564FCDFBFDACE (void);
// 0x000005FA System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToMemoryCallback::Invoke(UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult,UnityEngine.Windows.WebCam.PhotoCaptureFrame)
extern void OnCapturedToMemoryCallback_Invoke_m2382646696D4D08D880B9621E40F4E7CD969498E (void);
// 0x000005FB System.IAsyncResult UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToMemoryCallback::BeginInvoke(UnityEngine.Windows.WebCam.PhotoCapture_PhotoCaptureResult,UnityEngine.Windows.WebCam.PhotoCaptureFrame,System.AsyncCallback,System.Object)
extern void OnCapturedToMemoryCallback_BeginInvoke_mD05157F78B546F75A987887C683FAC6A922A49B7 (void);
// 0x000005FC System.Void UnityEngine.Windows.WebCam.PhotoCapture_OnCapturedToMemoryCallback::EndInvoke(System.IAsyncResult)
extern void OnCapturedToMemoryCallback_EndInvoke_mE06069F070AC6C019F5C56BD3CEF38D43BDCF550 (void);
// 0x000005FD System.Int32 UnityEngine.Windows.WebCam.PhotoCaptureFrame::get_dataLength()
extern void PhotoCaptureFrame_get_dataLength_m2169CBC908EF8673C1876952BCB9C1642706849C (void);
// 0x000005FE System.Void UnityEngine.Windows.WebCam.PhotoCaptureFrame::set_dataLength(System.Int32)
extern void PhotoCaptureFrame_set_dataLength_m708C3983B97B7470A4E7A4692A590E5338465A5B (void);
// 0x000005FF System.Void UnityEngine.Windows.WebCam.PhotoCaptureFrame::set_hasLocationData(System.Boolean)
extern void PhotoCaptureFrame_set_hasLocationData_mA2E608666F3D923EEBCFFD1F2A8534BFAC938CD9 (void);
// 0x00000600 System.Void UnityEngine.Windows.WebCam.PhotoCaptureFrame::set_pixelFormat(UnityEngine.Windows.WebCam.CapturePixelFormat)
extern void PhotoCaptureFrame_set_pixelFormat_m956028BE24FB4646618B56A24CDB9559026B78D4 (void);
// 0x00000601 System.Int32 UnityEngine.Windows.WebCam.PhotoCaptureFrame::GetDataLength()
extern void PhotoCaptureFrame_GetDataLength_m2D4FC19B5BEED3478C681DD941F7018F142788DB (void);
// 0x00000602 System.Boolean UnityEngine.Windows.WebCam.PhotoCaptureFrame::GetHasLocationData()
extern void PhotoCaptureFrame_GetHasLocationData_m01BDCAD79360F3BAF759FF2A9EB2963C480BEF42 (void);
// 0x00000603 UnityEngine.Windows.WebCam.CapturePixelFormat UnityEngine.Windows.WebCam.PhotoCaptureFrame::GetCapturePixelFormat()
extern void PhotoCaptureFrame_GetCapturePixelFormat_mD1DED87FE85284782AE1533390314119BD1B5C6E (void);
// 0x00000604 System.Void UnityEngine.Windows.WebCam.PhotoCaptureFrame::.ctor(System.IntPtr)
extern void PhotoCaptureFrame__ctor_m2200B47E027A635C22A6822CE3548BBFD38CFF01 (void);
// 0x00000605 System.Void UnityEngine.Windows.WebCam.PhotoCaptureFrame::Cleanup()
extern void PhotoCaptureFrame_Cleanup_m4F7B4E31415ABD61458F394F09597B9CE31C9E0C (void);
// 0x00000606 System.Void UnityEngine.Windows.WebCam.PhotoCaptureFrame::Dispose_Internal()
extern void PhotoCaptureFrame_Dispose_Internal_m24C9E95622D5362B90B3B9231F3E773E4C8B5ECB (void);
// 0x00000607 System.Void UnityEngine.Windows.WebCam.PhotoCaptureFrame::Dispose()
extern void PhotoCaptureFrame_Dispose_mA569A16F2EE402B143C252D57B6C93040B81BABD (void);
// 0x00000608 System.Void UnityEngine.Windows.WebCam.PhotoCaptureFrame::Finalize()
extern void PhotoCaptureFrame_Finalize_m597A19661FD4FDF0B20C50E16891C559B3826EAA (void);
// 0x00000609 UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult UnityEngine.Windows.WebCam.VideoCapture::MakeCaptureResult(System.Int64)
extern void VideoCapture_MakeCaptureResult_m8E3FDAF1FB4B3F56197D02ECB1E94BA16ED01524 (void);
// 0x0000060A System.Void UnityEngine.Windows.WebCam.VideoCapture::InvokeOnCreatedVideoCaptureResourceDelegate(UnityEngine.Windows.WebCam.VideoCapture_OnVideoCaptureResourceCreatedCallback,System.IntPtr)
extern void VideoCapture_InvokeOnCreatedVideoCaptureResourceDelegate_mF9883CC0DE032FC32261999B5DBA0FA3B97BEA12 (void);
// 0x0000060B System.Void UnityEngine.Windows.WebCam.VideoCapture::.ctor(System.IntPtr)
extern void VideoCapture__ctor_m0FE3A72AA0BE57264435FD94F28228F5A82E15FB (void);
// 0x0000060C System.Void UnityEngine.Windows.WebCam.VideoCapture::InvokeOnVideoModeStartedDelegate(UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStartedCallback,System.Int64)
extern void VideoCapture_InvokeOnVideoModeStartedDelegate_m26310208BD52CAC57B4F7581FBAFC7EEF491EA98 (void);
// 0x0000060D System.Void UnityEngine.Windows.WebCam.VideoCapture::InvokeOnVideoModeStoppedDelegate(UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStoppedCallback,System.Int64)
extern void VideoCapture_InvokeOnVideoModeStoppedDelegate_mD5BD41E17DC995244E5466CBAA9C370168EE12C2 (void);
// 0x0000060E System.Void UnityEngine.Windows.WebCam.VideoCapture::InvokeOnStartedRecordingVideoToDiskDelegate(UnityEngine.Windows.WebCam.VideoCapture_OnStartedRecordingVideoCallback,System.Int64)
extern void VideoCapture_InvokeOnStartedRecordingVideoToDiskDelegate_m6D5AEC9ACC849B33AA27AEC954FF67C8333505F2 (void);
// 0x0000060F System.Void UnityEngine.Windows.WebCam.VideoCapture::InvokeOnStoppedRecordingVideoToDiskDelegate(UnityEngine.Windows.WebCam.VideoCapture_OnStoppedRecordingVideoCallback,System.Int64)
extern void VideoCapture_InvokeOnStoppedRecordingVideoToDiskDelegate_m2F132EE579D852F77A5F70639EDEE85E7AE13739 (void);
// 0x00000610 System.Void UnityEngine.Windows.WebCam.VideoCapture::Dispose()
extern void VideoCapture_Dispose_m05A80B67D93D420B5FFA350028C62AC7C3A2791F (void);
// 0x00000611 System.Void UnityEngine.Windows.WebCam.VideoCapture::Dispose_Internal()
extern void VideoCapture_Dispose_Internal_m544E2E76F43A934DA00C58277E89C27E96A6F952 (void);
// 0x00000612 System.Void UnityEngine.Windows.WebCam.VideoCapture::Finalize()
extern void VideoCapture_Finalize_m7B97B93616E65E61B55F4D9B6784E65C4916C2F2 (void);
// 0x00000613 System.Void UnityEngine.Windows.WebCam.VideoCapture::DisposeThreaded_Internal()
extern void VideoCapture_DisposeThreaded_Internal_m731C1AD152F8A05604EC9B286FA69C1591A71068 (void);
// 0x00000614 System.Void UnityEngine.Windows.WebCam.VideoCapture::.cctor()
extern void VideoCapture__cctor_m575F77433389795AB691B84D88DD79C1D2CFBD06 (void);
// 0x00000615 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoCaptureResourceCreatedCallback::.ctor(System.Object,System.IntPtr)
extern void OnVideoCaptureResourceCreatedCallback__ctor_m8126E742A34950E1A69239EA771F99FB4BF0C751 (void);
// 0x00000616 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoCaptureResourceCreatedCallback::Invoke(UnityEngine.Windows.WebCam.VideoCapture)
extern void OnVideoCaptureResourceCreatedCallback_Invoke_mCBAB47A08804FC4A040E3E6D0DB626A3C3471182 (void);
// 0x00000617 System.IAsyncResult UnityEngine.Windows.WebCam.VideoCapture_OnVideoCaptureResourceCreatedCallback::BeginInvoke(UnityEngine.Windows.WebCam.VideoCapture,System.AsyncCallback,System.Object)
extern void OnVideoCaptureResourceCreatedCallback_BeginInvoke_m6EE12058C9073F8075C6104E3793156BC232A0F1 (void);
// 0x00000618 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoCaptureResourceCreatedCallback::EndInvoke(System.IAsyncResult)
extern void OnVideoCaptureResourceCreatedCallback_EndInvoke_m991BC133674B0CC5BD3DFA0114DB7612B1A5297A (void);
// 0x00000619 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStartedCallback::.ctor(System.Object,System.IntPtr)
extern void OnVideoModeStartedCallback__ctor_m1753A0D7909741085AEC31818DDFB57D59EBE539 (void);
// 0x0000061A System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStartedCallback::Invoke(UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult)
extern void OnVideoModeStartedCallback_Invoke_mB9A2828F520201F753009139BDB2C193A38687A0 (void);
// 0x0000061B System.IAsyncResult UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStartedCallback::BeginInvoke(UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult,System.AsyncCallback,System.Object)
extern void OnVideoModeStartedCallback_BeginInvoke_m95E5682FF37266B911974288C4E9090187B416C0 (void);
// 0x0000061C System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStartedCallback::EndInvoke(System.IAsyncResult)
extern void OnVideoModeStartedCallback_EndInvoke_mFF236A689DD47097F9CACB33E48B8D8410B8507D (void);
// 0x0000061D System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStoppedCallback::.ctor(System.Object,System.IntPtr)
extern void OnVideoModeStoppedCallback__ctor_mDAB9D65B5DCFFF1D4BF5C3109D7C95051818A6C8 (void);
// 0x0000061E System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStoppedCallback::Invoke(UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult)
extern void OnVideoModeStoppedCallback_Invoke_m2CFBF6763FCED9C9201834019A962EACF2F1D088 (void);
// 0x0000061F System.IAsyncResult UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStoppedCallback::BeginInvoke(UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult,System.AsyncCallback,System.Object)
extern void OnVideoModeStoppedCallback_BeginInvoke_m21579FF978236D09DEB3AC1F508A4EF4A04A8FAB (void);
// 0x00000620 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnVideoModeStoppedCallback::EndInvoke(System.IAsyncResult)
extern void OnVideoModeStoppedCallback_EndInvoke_mB36D35F04396E8787C3053B300DBDA24E2562DE2 (void);
// 0x00000621 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnStartedRecordingVideoCallback::.ctor(System.Object,System.IntPtr)
extern void OnStartedRecordingVideoCallback__ctor_m5303F5AED4F0183EB22E5108148404E8B1DF7ECD (void);
// 0x00000622 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnStartedRecordingVideoCallback::Invoke(UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult)
extern void OnStartedRecordingVideoCallback_Invoke_mE31381DAE5B30D92A9186FA747C5AC023048114D (void);
// 0x00000623 System.IAsyncResult UnityEngine.Windows.WebCam.VideoCapture_OnStartedRecordingVideoCallback::BeginInvoke(UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult,System.AsyncCallback,System.Object)
extern void OnStartedRecordingVideoCallback_BeginInvoke_m64CB638B651C771C976BC6251A897DBC33F9FFE7 (void);
// 0x00000624 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnStartedRecordingVideoCallback::EndInvoke(System.IAsyncResult)
extern void OnStartedRecordingVideoCallback_EndInvoke_mD9413A65A1749390BD613712A3DD510650A1D267 (void);
// 0x00000625 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnStoppedRecordingVideoCallback::.ctor(System.Object,System.IntPtr)
extern void OnStoppedRecordingVideoCallback__ctor_m87A4D9B5EEF3E3C1C32B7A56D5D60FDAE77890A3 (void);
// 0x00000626 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnStoppedRecordingVideoCallback::Invoke(UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult)
extern void OnStoppedRecordingVideoCallback_Invoke_mA23DA19077DFC878FC21A80106550E09E514EDF4 (void);
// 0x00000627 System.IAsyncResult UnityEngine.Windows.WebCam.VideoCapture_OnStoppedRecordingVideoCallback::BeginInvoke(UnityEngine.Windows.WebCam.VideoCapture_VideoCaptureResult,System.AsyncCallback,System.Object)
extern void OnStoppedRecordingVideoCallback_BeginInvoke_mA96640AB5DA79F3C8C07367769094492D30056BB (void);
// 0x00000628 System.Void UnityEngine.Windows.WebCam.VideoCapture_OnStoppedRecordingVideoCallback::EndInvoke(System.IAsyncResult)
extern void OnStoppedRecordingVideoCallback_EndInvoke_mF7901932350D8462A33A68A8ACD4FCFE21AF383D (void);
// 0x00000629 UnityEngine.Object UnityEngine.Events.ArgumentCache::get_unityObjectArgument()
extern void ArgumentCache_get_unityObjectArgument_m89597514712FB91B443B9FB1A44D099F021DCFA5 (void);
// 0x0000062A System.String UnityEngine.Events.ArgumentCache::get_unityObjectArgumentAssemblyTypeName()
extern void ArgumentCache_get_unityObjectArgumentAssemblyTypeName_mD54EA1424879A2E07B179AE93D374100259FF534 (void);
// 0x0000062B System.Int32 UnityEngine.Events.ArgumentCache::get_intArgument()
extern void ArgumentCache_get_intArgument_mD9D072A7856D998847F159350EAD0D9AA552F76B (void);
// 0x0000062C System.Single UnityEngine.Events.ArgumentCache::get_floatArgument()
extern void ArgumentCache_get_floatArgument_mDDAD91A992319CF1FFFDD4F0F87C5D162BFF187A (void);
// 0x0000062D System.String UnityEngine.Events.ArgumentCache::get_stringArgument()
extern void ArgumentCache_get_stringArgument_mCD1D05766E21EEFDFD03D4DE66C088CF29F84D00 (void);
// 0x0000062E System.Boolean UnityEngine.Events.ArgumentCache::get_boolArgument()
extern void ArgumentCache_get_boolArgument_mCCAB5FB41B0F1C8C8A2C31FB3D46DF99A7A71BE2 (void);
// 0x0000062F System.Void UnityEngine.Events.ArgumentCache::TidyAssemblyTypeName()
extern void ArgumentCache_TidyAssemblyTypeName_m2D4AFE74BEB5F32B14165BB52F6AB29A75306936 (void);
// 0x00000630 System.Void UnityEngine.Events.ArgumentCache::OnBeforeSerialize()
extern void ArgumentCache_OnBeforeSerialize_mCBE8301FE0DDE2E516A18051BBE3DC983BC80FBC (void);
// 0x00000631 System.Void UnityEngine.Events.ArgumentCache::OnAfterDeserialize()
extern void ArgumentCache_OnAfterDeserialize_m59072D771A42C518FECECBE2CE7EE9E15F4BE55F (void);
// 0x00000632 System.Void UnityEngine.Events.ArgumentCache::.ctor()
extern void ArgumentCache__ctor_m9618D660E40F991782873643F0FDCACA32A63541 (void);
// 0x00000633 System.Void UnityEngine.Events.BaseInvokableCall::.ctor()
extern void BaseInvokableCall__ctor_m232CE2068209113988BB35B50A2965FC03FC4A58 (void);
// 0x00000634 System.Void UnityEngine.Events.BaseInvokableCall::.ctor(System.Object,System.Reflection.MethodInfo)
extern void BaseInvokableCall__ctor_m71AC21A8840CE45C2600FF784E8B0B556D7B2BA5 (void);
// 0x00000635 System.Void UnityEngine.Events.BaseInvokableCall::Invoke(System.Object[])
// 0x00000636 System.Void UnityEngine.Events.BaseInvokableCall::ThrowOnInvalidArg(System.Object)
// 0x00000637 System.Boolean UnityEngine.Events.BaseInvokableCall::AllowInvoke(System.Delegate)
extern void BaseInvokableCall_AllowInvoke_m0B193EBF1EF138FC5354933974DD702D3D9FF091 (void);
// 0x00000638 System.Boolean UnityEngine.Events.BaseInvokableCall::Find(System.Object,System.Reflection.MethodInfo)
// 0x00000639 System.Void UnityEngine.Events.InvokableCall::add_Delegate(UnityEngine.Events.UnityAction)
extern void InvokableCall_add_Delegate_mCE91CE04CF7A8B962FF566B018C8C516351AD0F3 (void);
// 0x0000063A System.Void UnityEngine.Events.InvokableCall::remove_Delegate(UnityEngine.Events.UnityAction)
extern void InvokableCall_remove_Delegate_m0CFD9A25842A757309236C500089752BF544E3C7 (void);
// 0x0000063B System.Void UnityEngine.Events.InvokableCall::.ctor(System.Object,System.Reflection.MethodInfo)
extern void InvokableCall__ctor_m2F9F0CD09FCFFEBCBBA87EC75D9BA50058C5B873 (void);
// 0x0000063C System.Void UnityEngine.Events.InvokableCall::.ctor(UnityEngine.Events.UnityAction)
extern void InvokableCall__ctor_m77F593E751D2119119A5F3FD39F8F5D3B653102B (void);
// 0x0000063D System.Void UnityEngine.Events.InvokableCall::Invoke(System.Object[])
extern void InvokableCall_Invoke_mDB8C26B441658DDA48AC3AF259F4A0EBCF673FD0 (void);
// 0x0000063E System.Void UnityEngine.Events.InvokableCall::Invoke()
extern void InvokableCall_Invoke_m0B9E7F14A2C67AB51F01745BD2C6C423114C9394 (void);
// 0x0000063F System.Boolean UnityEngine.Events.InvokableCall::Find(System.Object,System.Reflection.MethodInfo)
extern void InvokableCall_Find_mDC13296B10EFCD0A92E486CD5787E07890C7B8CC (void);
// 0x00000640 System.Void UnityEngine.Events.InvokableCall`1::add_Delegate(UnityEngine.Events.UnityAction`1<T1>)
// 0x00000641 System.Void UnityEngine.Events.InvokableCall`1::remove_Delegate(UnityEngine.Events.UnityAction`1<T1>)
// 0x00000642 System.Void UnityEngine.Events.InvokableCall`1::.ctor(System.Object,System.Reflection.MethodInfo)
// 0x00000643 System.Void UnityEngine.Events.InvokableCall`1::.ctor(UnityEngine.Events.UnityAction`1<T1>)
// 0x00000644 System.Void UnityEngine.Events.InvokableCall`1::Invoke(System.Object[])
// 0x00000645 System.Void UnityEngine.Events.InvokableCall`1::Invoke(T1)
// 0x00000646 System.Boolean UnityEngine.Events.InvokableCall`1::Find(System.Object,System.Reflection.MethodInfo)
// 0x00000647 System.Void UnityEngine.Events.InvokableCall`2::.ctor(System.Object,System.Reflection.MethodInfo)
// 0x00000648 System.Void UnityEngine.Events.InvokableCall`2::Invoke(System.Object[])
// 0x00000649 System.Boolean UnityEngine.Events.InvokableCall`2::Find(System.Object,System.Reflection.MethodInfo)
// 0x0000064A System.Void UnityEngine.Events.InvokableCall`3::.ctor(System.Object,System.Reflection.MethodInfo)
// 0x0000064B System.Void UnityEngine.Events.InvokableCall`3::Invoke(System.Object[])
// 0x0000064C System.Boolean UnityEngine.Events.InvokableCall`3::Find(System.Object,System.Reflection.MethodInfo)
// 0x0000064D System.Void UnityEngine.Events.InvokableCall`4::.ctor(System.Object,System.Reflection.MethodInfo)
// 0x0000064E System.Void UnityEngine.Events.InvokableCall`4::Invoke(System.Object[])
// 0x0000064F System.Boolean UnityEngine.Events.InvokableCall`4::Find(System.Object,System.Reflection.MethodInfo)
// 0x00000650 System.Void UnityEngine.Events.CachedInvokableCall`1::.ctor(UnityEngine.Object,System.Reflection.MethodInfo,T)
// 0x00000651 System.Void UnityEngine.Events.CachedInvokableCall`1::Invoke(System.Object[])
// 0x00000652 System.Void UnityEngine.Events.CachedInvokableCall`1::Invoke(T)
// 0x00000653 UnityEngine.Object UnityEngine.Events.PersistentCall::get_target()
extern void PersistentCall_get_target_mCAD7D486F28743D49DCF268B791721313A7FC8C5 (void);
// 0x00000654 System.String UnityEngine.Events.PersistentCall::get_methodName()
extern void PersistentCall_get_methodName_m164BE545C327516CABE9464D88A417B7F00010E1 (void);
// 0x00000655 UnityEngine.Events.PersistentListenerMode UnityEngine.Events.PersistentCall::get_mode()
extern void PersistentCall_get_mode_mC88324F8D18B5E4E79045AE1F99DF3EB36CEE644 (void);
// 0x00000656 UnityEngine.Events.ArgumentCache UnityEngine.Events.PersistentCall::get_arguments()
extern void PersistentCall_get_arguments_m53AFE12B586F0C8948D60852866EC71F38B3BAE1 (void);
// 0x00000657 System.Boolean UnityEngine.Events.PersistentCall::IsValid()
extern void PersistentCall_IsValid_mF3E3A11AF1547E84B2AC78AFAF6B2907C9B159AE (void);
// 0x00000658 UnityEngine.Events.BaseInvokableCall UnityEngine.Events.PersistentCall::GetRuntimeCall(UnityEngine.Events.UnityEventBase)
extern void PersistentCall_GetRuntimeCall_m68F27109F868C451A47DAC3863B27839C515C3A6 (void);
// 0x00000659 UnityEngine.Events.BaseInvokableCall UnityEngine.Events.PersistentCall::GetObjectCall(UnityEngine.Object,System.Reflection.MethodInfo,UnityEngine.Events.ArgumentCache)
extern void PersistentCall_GetObjectCall_m895EBE1B8E2A4FB297A8C268371CA4CD320F72C9 (void);
// 0x0000065A System.Void UnityEngine.Events.PersistentCall::.ctor()
extern void PersistentCall__ctor_mBF65325BE6B4EBC6B3E8ADAD3C6FA77EF5BBEFA8 (void);
// 0x0000065B System.Void UnityEngine.Events.PersistentCallGroup::.ctor()
extern void PersistentCallGroup__ctor_m46B7802855B55149B9C1ECD9C9C97B8025BF2D7A (void);
// 0x0000065C System.Void UnityEngine.Events.PersistentCallGroup::Initialize(UnityEngine.Events.InvokableCallList,UnityEngine.Events.UnityEventBase)
extern void PersistentCallGroup_Initialize_m9F47B3D16F78FD424D50E9AE41EB066BA9C681A3 (void);
// 0x0000065D System.Void UnityEngine.Events.InvokableCallList::AddPersistentInvokableCall(UnityEngine.Events.BaseInvokableCall)
extern void InvokableCallList_AddPersistentInvokableCall_m62BDD6521FB7B68B58673D5C5B1117FCE4826CAD (void);
// 0x0000065E System.Void UnityEngine.Events.InvokableCallList::AddListener(UnityEngine.Events.BaseInvokableCall)
extern void InvokableCallList_AddListener_mE4069F40E8762EF21140D688175D7A4E46FD2E83 (void);
// 0x0000065F System.Void UnityEngine.Events.InvokableCallList::RemoveListener(System.Object,System.Reflection.MethodInfo)
extern void InvokableCallList_RemoveListener_mC886122D45A6682A85066E48637339065085D6DE (void);
// 0x00000660 System.Void UnityEngine.Events.InvokableCallList::ClearPersistent()
extern void InvokableCallList_ClearPersistent_m4038DB499DCD84B79C0F1A698AAA7B9519553D49 (void);
// 0x00000661 System.Collections.Generic.List`1<UnityEngine.Events.BaseInvokableCall> UnityEngine.Events.InvokableCallList::PrepareInvoke()
extern void InvokableCallList_PrepareInvoke_m5BB28A5FBF10C84ECF5B52EBC52F9FCCDC840DC1 (void);
// 0x00000662 System.Void UnityEngine.Events.InvokableCallList::.ctor()
extern void InvokableCallList__ctor_m8A5D49D58DCCC3D962D84C6DAD703DCABE74EC2D (void);
// 0x00000663 System.Void UnityEngine.Events.UnityEventBase::.ctor()
extern void UnityEventBase__ctor_m57AF08DAFA9C1B4F4C8DA855116900BAE8DF9595 (void);
// 0x00000664 System.Void UnityEngine.Events.UnityEventBase::UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize()
extern void UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m147F610873545A23E9005CCB35CA6A05887E7599 (void);
// 0x00000665 System.Void UnityEngine.Events.UnityEventBase::UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize()
extern void UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m3A87E89948C5FF32BD5BA1BDD1A4D791738A141E (void);
// 0x00000666 System.Reflection.MethodInfo UnityEngine.Events.UnityEventBase::FindMethod_Impl(System.String,System.Object)
// 0x00000667 UnityEngine.Events.BaseInvokableCall UnityEngine.Events.UnityEventBase::GetDelegate(System.Object,System.Reflection.MethodInfo)
// 0x00000668 System.Reflection.MethodInfo UnityEngine.Events.UnityEventBase::FindMethod(UnityEngine.Events.PersistentCall)
extern void UnityEventBase_FindMethod_m4E838DE0D107C86C7CAA5B05D4683066E9EB9C32 (void);
// 0x00000669 System.Reflection.MethodInfo UnityEngine.Events.UnityEventBase::FindMethod(System.String,System.Object,UnityEngine.Events.PersistentListenerMode,System.Type)
extern void UnityEventBase_FindMethod_m82A135403D677ECE42CEE42A322E15EB2EA53797 (void);
// 0x0000066A System.Void UnityEngine.Events.UnityEventBase::DirtyPersistentCalls()
extern void UnityEventBase_DirtyPersistentCalls_m31D9B2D3B265718318F4D7E87373E53F249E65EB (void);
// 0x0000066B System.Void UnityEngine.Events.UnityEventBase::RebuildPersistentCallsIfNeeded()
extern void UnityEventBase_RebuildPersistentCallsIfNeeded_mFC89AED628B42E5B1CBCC702222A6DF97605234F (void);
// 0x0000066C System.Void UnityEngine.Events.UnityEventBase::AddCall(UnityEngine.Events.BaseInvokableCall)
extern void UnityEventBase_AddCall_mD45F68C1A40E2BD9B0754490B7709846B84E8075 (void);
// 0x0000066D System.Void UnityEngine.Events.UnityEventBase::RemoveListener(System.Object,System.Reflection.MethodInfo)
extern void UnityEventBase_RemoveListener_mE7EBC544115373D2357599AC07F41F13A8C5A49E (void);
// 0x0000066E System.Collections.Generic.List`1<UnityEngine.Events.BaseInvokableCall> UnityEngine.Events.UnityEventBase::PrepareInvoke()
extern void UnityEventBase_PrepareInvoke_mFA3E2C97DB776A1089DCC85C9F1DA75C295032AE (void);
// 0x0000066F System.String UnityEngine.Events.UnityEventBase::ToString()
extern void UnityEventBase_ToString_m7672D78CA070AC49FFF04E645523864C300DD66D (void);
// 0x00000670 System.Reflection.MethodInfo UnityEngine.Events.UnityEventBase::GetValidMethodInfo(System.Object,System.String,System.Type[])
extern void UnityEventBase_GetValidMethodInfo_m4521621AB72C7265A2C0EC6911BE4DC42A99B6A5 (void);
// 0x00000671 System.Void UnityEngine.Events.UnityAction::.ctor(System.Object,System.IntPtr)
extern void UnityAction__ctor_mEFC4B92529CE83DF72501F92E07EC5598C54BDAC (void);
// 0x00000672 System.Void UnityEngine.Events.UnityAction::Invoke()
extern void UnityAction_Invoke_mC9FF5AA1F82FDE635B3B6644CE71C94C31C3E71A (void);
// 0x00000673 System.IAsyncResult UnityEngine.Events.UnityAction::BeginInvoke(System.AsyncCallback,System.Object)
extern void UnityAction_BeginInvoke_m6819B1057D192033B17EB15C9E34305720F0401C (void);
// 0x00000674 System.Void UnityEngine.Events.UnityAction::EndInvoke(System.IAsyncResult)
extern void UnityAction_EndInvoke_m9C465516D5977EF185DCEB6CA81D0B90EDAD7370 (void);
// 0x00000675 System.Void UnityEngine.Events.UnityEvent::.ctor()
extern void UnityEvent__ctor_m2F8C02F28E289CA65598FF4FA8EAB84D955FF028 (void);
// 0x00000676 System.Void UnityEngine.Events.UnityEvent::AddListener(UnityEngine.Events.UnityAction)
extern void UnityEvent_AddListener_m31973FDDC5BB0B2828AB6EF519EC4FD6563499C9 (void);
// 0x00000677 System.Reflection.MethodInfo UnityEngine.Events.UnityEvent::FindMethod_Impl(System.String,System.Object)
extern void UnityEvent_FindMethod_Impl_mC96F40A83BB4D1430E254DAE9B091E27E42E8796 (void);
// 0x00000678 UnityEngine.Events.BaseInvokableCall UnityEngine.Events.UnityEvent::GetDelegate(System.Object,System.Reflection.MethodInfo)
extern void UnityEvent_GetDelegate_m8D277E2D713BB3605B3D46E5A3DB708B6A338EB0 (void);
// 0x00000679 UnityEngine.Events.BaseInvokableCall UnityEngine.Events.UnityEvent::GetDelegate(UnityEngine.Events.UnityAction)
extern void UnityEvent_GetDelegate_mDFBD636D71E24D75D0851959256A3B97BA842865 (void);
// 0x0000067A System.Void UnityEngine.Events.UnityEvent::Invoke()
extern void UnityEvent_Invoke_mB2FA1C76256FE34D5E7F84ABE528AC61CE8A0325 (void);
// 0x0000067B System.Void UnityEngine.Events.UnityAction`1::.ctor(System.Object,System.IntPtr)
// 0x0000067C System.Void UnityEngine.Events.UnityAction`1::Invoke(T0)
// 0x0000067D System.IAsyncResult UnityEngine.Events.UnityAction`1::BeginInvoke(T0,System.AsyncCallback,System.Object)
// 0x0000067E System.Void UnityEngine.Events.UnityAction`1::EndInvoke(System.IAsyncResult)
// 0x0000067F System.Void UnityEngine.Events.UnityEvent`1::.ctor()
// 0x00000680 System.Void UnityEngine.Events.UnityEvent`1::AddListener(UnityEngine.Events.UnityAction`1<T0>)
// 0x00000681 System.Void UnityEngine.Events.UnityEvent`1::RemoveListener(UnityEngine.Events.UnityAction`1<T0>)
// 0x00000682 System.Reflection.MethodInfo UnityEngine.Events.UnityEvent`1::FindMethod_Impl(System.String,System.Object)
// 0x00000683 UnityEngine.Events.BaseInvokableCall UnityEngine.Events.UnityEvent`1::GetDelegate(System.Object,System.Reflection.MethodInfo)
// 0x00000684 UnityEngine.Events.BaseInvokableCall UnityEngine.Events.UnityEvent`1::GetDelegate(UnityEngine.Events.UnityAction`1<T0>)
// 0x00000685 System.Void UnityEngine.Events.UnityEvent`1::Invoke(T0)
// 0x00000686 System.Void UnityEngine.Events.UnityAction`2::.ctor(System.Object,System.IntPtr)
// 0x00000687 System.Void UnityEngine.Events.UnityAction`2::Invoke(T0,T1)
// 0x00000688 System.IAsyncResult UnityEngine.Events.UnityAction`2::BeginInvoke(T0,T1,System.AsyncCallback,System.Object)
// 0x00000689 System.Void UnityEngine.Events.UnityAction`2::EndInvoke(System.IAsyncResult)
// 0x0000068A System.Void UnityEngine.Events.UnityEvent`2::.ctor()
// 0x0000068B System.Reflection.MethodInfo UnityEngine.Events.UnityEvent`2::FindMethod_Impl(System.String,System.Object)
// 0x0000068C UnityEngine.Events.BaseInvokableCall UnityEngine.Events.UnityEvent`2::GetDelegate(System.Object,System.Reflection.MethodInfo)
// 0x0000068D System.Void UnityEngine.Events.UnityAction`3::.ctor(System.Object,System.IntPtr)
// 0x0000068E System.Void UnityEngine.Events.UnityAction`3::Invoke(T0,T1,T2)
// 0x0000068F System.IAsyncResult UnityEngine.Events.UnityAction`3::BeginInvoke(T0,T1,T2,System.AsyncCallback,System.Object)
// 0x00000690 System.Void UnityEngine.Events.UnityAction`3::EndInvoke(System.IAsyncResult)
// 0x00000691 System.Void UnityEngine.Events.UnityEvent`3::.ctor()
// 0x00000692 System.Reflection.MethodInfo UnityEngine.Events.UnityEvent`3::FindMethod_Impl(System.String,System.Object)
// 0x00000693 UnityEngine.Events.BaseInvokableCall UnityEngine.Events.UnityEvent`3::GetDelegate(System.Object,System.Reflection.MethodInfo)
// 0x00000694 System.Void UnityEngine.Events.UnityAction`4::.ctor(System.Object,System.IntPtr)
// 0x00000695 System.Void UnityEngine.Events.UnityAction`4::Invoke(T0,T1,T2,T3)
// 0x00000696 System.IAsyncResult UnityEngine.Events.UnityAction`4::BeginInvoke(T0,T1,T2,T3,System.AsyncCallback,System.Object)
// 0x00000697 System.Void UnityEngine.Events.UnityAction`4::EndInvoke(System.IAsyncResult)
// 0x00000698 System.Void UnityEngine.Events.UnityEvent`4::.ctor()
// 0x00000699 System.Reflection.MethodInfo UnityEngine.Events.UnityEvent`4::FindMethod_Impl(System.String,System.Object)
// 0x0000069A UnityEngine.Events.BaseInvokableCall UnityEngine.Events.UnityEvent`4::GetDelegate(System.Object,System.Reflection.MethodInfo)
// 0x0000069B System.Void UnityEngine.Serialization.FormerlySerializedAsAttribute::.ctor(System.String)
extern void FormerlySerializedAsAttribute__ctor_m770651B828F499F804DB06A777E8A4103A3ED2BD (void);
// 0x0000069C System.Void UnityEngine.Scripting.PreserveAttribute::.ctor()
extern void PreserveAttribute__ctor_mD842EE86496947B39FE0FBC67393CE4401AC53AA (void);
// 0x0000069D System.Void UnityEngine.Scripting.APIUpdating.MovedFromAttributeData::Set(System.Boolean,System.String,System.String,System.String)
extern void MovedFromAttributeData_Set_m244D6454BEA753FA4C7C3F2393A5DADCB3166B1C_AdjustorThunk (void);
// 0x0000069E System.Void UnityEngine.Scripting.APIUpdating.MovedFromAttribute::.ctor(System.String)
extern void MovedFromAttribute__ctor_mF87685F9D527910B31D3EF58F0EAA297E1944B42 (void);
// 0x0000069F System.Int32 UnityEngine.SceneManagement.Scene::get_handle()
extern void Scene_get_handle_mFAB5C41D41B90B9CEBB3918A6F3638BD41E980C9_AdjustorThunk (void);
// 0x000006A0 System.Int32 UnityEngine.SceneManagement.Scene::GetHashCode()
extern void Scene_GetHashCode_m65BBB604A5496CF1F2C129860F45D0E437499E34_AdjustorThunk (void);
// 0x000006A1 System.Boolean UnityEngine.SceneManagement.Scene::Equals(System.Object)
extern void Scene_Equals_mD5738AF0B92757DED12A90F136716A5E2DDE3F54_AdjustorThunk (void);
// 0x000006A2 System.Void UnityEngine.SceneManagement.SceneManager::Internal_SceneLoaded(UnityEngine.SceneManagement.Scene,UnityEngine.SceneManagement.LoadSceneMode)
extern void SceneManager_Internal_SceneLoaded_m800F5F7F7B30D5206913EF65548FD7F8DE9EF718 (void);
// 0x000006A3 System.Void UnityEngine.SceneManagement.SceneManager::Internal_SceneUnloaded(UnityEngine.SceneManagement.Scene)
extern void SceneManager_Internal_SceneUnloaded_m32721E87A02DAC634DD4B9857092CC172EE8CB98 (void);
// 0x000006A4 System.Void UnityEngine.SceneManagement.SceneManager::Internal_ActiveSceneChanged(UnityEngine.SceneManagement.Scene,UnityEngine.SceneManagement.Scene)
extern void SceneManager_Internal_ActiveSceneChanged_mE9AB93D6979594CFCED5B3696F727B7D5E6B25F5 (void);
// 0x000006A5 System.Void UnityEngine.SceneManagement.SceneManager::.cctor()
extern void SceneManager__cctor_m36C7C4EECB3F22A383FA829341F6A4EA0B2D3377 (void);
// 0x000006A6 System.Void UnityEngine.LowLevel.PlayerLoopSystem_UpdateFunction::.ctor(System.Object,System.IntPtr)
extern void UpdateFunction__ctor_m203C45C9226ED025C1369B78B759C952ABDA630A (void);
// 0x000006A7 System.Void UnityEngine.LowLevel.PlayerLoopSystem_UpdateFunction::Invoke()
extern void UpdateFunction_Invoke_m6C0E9E5082FCEEF018602FD40A43E613360D410D (void);
// 0x000006A8 System.IAsyncResult UnityEngine.LowLevel.PlayerLoopSystem_UpdateFunction::BeginInvoke(System.AsyncCallback,System.Object)
extern void UpdateFunction_BeginInvoke_m7261B0AA3E858CC7A24FF343DE292DB5A34DAC0C (void);
// 0x000006A9 System.Void UnityEngine.LowLevel.PlayerLoopSystem_UpdateFunction::EndInvoke(System.IAsyncResult)
extern void UpdateFunction_EndInvoke_m49FBADEA0EED0F50341E2E1F5F21349C2059EA55 (void);
// 0x000006AA System.Void UnityEngine.Networking.PlayerConnection.MessageEventArgs::.ctor()
extern void MessageEventArgs__ctor_m436B854CFEEDB949F4D9ACAEA2E512BDAEDC6E1B (void);
// 0x000006AB UnityEngine.Networking.PlayerConnection.PlayerConnection UnityEngine.Networking.PlayerConnection.PlayerConnection::get_instance()
extern void PlayerConnection_get_instance_mF51FB76C702C7CDD0BAEAD466060E3BDF23D390F (void);
// 0x000006AC System.Boolean UnityEngine.Networking.PlayerConnection.PlayerConnection::get_isConnected()
extern void PlayerConnection_get_isConnected_mB902603E2C8CA93299FF0B28E13A9D594CBFE14E (void);
// 0x000006AD UnityEngine.Networking.PlayerConnection.PlayerConnection UnityEngine.Networking.PlayerConnection.PlayerConnection::CreateInstance()
extern void PlayerConnection_CreateInstance_m6325767D9D05B530116767E164CDCBE613A5787F (void);
// 0x000006AE System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::OnEnable()
extern void PlayerConnection_OnEnable_m9D8136CEB952BC0F44A46A212BF2E91E5A769954 (void);
// 0x000006AF UnityEngine.IPlayerEditorConnectionNative UnityEngine.Networking.PlayerConnection.PlayerConnection::GetConnectionNativeApi()
extern void PlayerConnection_GetConnectionNativeApi_mC88D9972FDF9D4FF15CC8C4BB6CA633FB114D918 (void);
// 0x000006B0 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::Register(System.Guid,UnityEngine.Events.UnityAction`1<UnityEngine.Networking.PlayerConnection.MessageEventArgs>)
extern void PlayerConnection_Register_m9B203230984995ADF5E19E50C3D7DF7E21036FF2 (void);
// 0x000006B1 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::Unregister(System.Guid,UnityEngine.Events.UnityAction`1<UnityEngine.Networking.PlayerConnection.MessageEventArgs>)
extern void PlayerConnection_Unregister_m8EB88437DF970AA6627BC301C54A859DAED70534 (void);
// 0x000006B2 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::RegisterConnection(UnityEngine.Events.UnityAction`1<System.Int32>)
extern void PlayerConnection_RegisterConnection_m7E54302209A4F3FB3E27A0E7FEB8ADE32C100F1B (void);
// 0x000006B3 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::RegisterDisconnection(UnityEngine.Events.UnityAction`1<System.Int32>)
extern void PlayerConnection_RegisterDisconnection_m556075060F55D3FA7F44DEB4B34CE1070ECBF823 (void);
// 0x000006B4 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::UnregisterConnection(UnityEngine.Events.UnityAction`1<System.Int32>)
extern void PlayerConnection_UnregisterConnection_mC6A080D398CD6C267C1638D98F7485E2B837D029 (void);
// 0x000006B5 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::UnregisterDisconnection(UnityEngine.Events.UnityAction`1<System.Int32>)
extern void PlayerConnection_UnregisterDisconnection_m148453805654D809DB02F377D0FBC4524F63EBF6 (void);
// 0x000006B6 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::Send(System.Guid,System.Byte[])
extern void PlayerConnection_Send_m1CDF41319A60A5940B487D08ECE14D0B61EDE6AC (void);
// 0x000006B7 System.Boolean UnityEngine.Networking.PlayerConnection.PlayerConnection::TrySend(System.Guid,System.Byte[])
extern void PlayerConnection_TrySend_m3C0D0208A6A8A7F7FF93AF155A71B726ABE8D662 (void);
// 0x000006B8 System.Boolean UnityEngine.Networking.PlayerConnection.PlayerConnection::BlockUntilRecvMsg(System.Guid,System.Int32)
extern void PlayerConnection_BlockUntilRecvMsg_mFCF2DB02D6F07C0A69C0412D8A3F596AF4AC54A2 (void);
// 0x000006B9 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::DisconnectAll()
extern void PlayerConnection_DisconnectAll_m278A4B90D90892338D1B41F5A59CD7C519F1C8D2 (void);
// 0x000006BA System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::MessageCallbackInternal(System.IntPtr,System.UInt64,System.UInt64,System.String)
extern void PlayerConnection_MessageCallbackInternal_m3E9A847ED82FDA9ABB680F81595A876450EFB166 (void);
// 0x000006BB System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::ConnectedCallbackInternal(System.Int32)
extern void PlayerConnection_ConnectedCallbackInternal_mFEC88D604DE3923849942994ED873B26CEEDDA3D (void);
// 0x000006BC System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::DisconnectedCallback(System.Int32)
extern void PlayerConnection_DisconnectedCallback_m2A12A748DDACDD3877D01D7F38ABBC55DEE26A56 (void);
// 0x000006BD System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection::.ctor()
extern void PlayerConnection__ctor_m3E1248C28C3082C592C2E5F69778F31F6610D93D (void);
// 0x000006BE System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection_<>c__DisplayClass12_0::.ctor()
extern void U3CU3Ec__DisplayClass12_0__ctor_m2685C903220EF0EFCFABCCCCE85520064EEB9BCE (void);
// 0x000006BF System.Boolean UnityEngine.Networking.PlayerConnection.PlayerConnection_<>c__DisplayClass12_0::<Register>b__0(UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageTypeSubscribers)
extern void U3CU3Ec__DisplayClass12_0_U3CRegisterU3Eb__0_m1979ADC0BD33A692CDFDD59354B756C347611773 (void);
// 0x000006C0 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection_<>c__DisplayClass13_0::.ctor()
extern void U3CU3Ec__DisplayClass13_0__ctor_m75A34D41161C0967E4A336B2713ACAE2BD5F5F46 (void);
// 0x000006C1 System.Boolean UnityEngine.Networking.PlayerConnection.PlayerConnection_<>c__DisplayClass13_0::<Unregister>b__0(UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageTypeSubscribers)
extern void U3CU3Ec__DisplayClass13_0_U3CUnregisterU3Eb__0_m8C6607EC9FE0F26B57047ED3642837003A532C79 (void);
// 0x000006C2 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection_<>c__DisplayClass20_0::.ctor()
extern void U3CU3Ec__DisplayClass20_0__ctor_m3E72979DC019A7C47E2AB71E1F17B9056A7D068B (void);
// 0x000006C3 System.Void UnityEngine.Networking.PlayerConnection.PlayerConnection_<>c__DisplayClass20_0::<BlockUntilRecvMsg>b__0(UnityEngine.Networking.PlayerConnection.MessageEventArgs)
extern void U3CU3Ec__DisplayClass20_0_U3CBlockUntilRecvMsgU3Eb__0_m89ABCD175D2DA1D535B2645459C38003ECBC896C (void);
// 0x000006C4 System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents::InvokeMessageIdSubscribers(System.Guid,System.Byte[],System.Int32)
extern void PlayerEditorConnectionEvents_InvokeMessageIdSubscribers_mFA28BDF3B52AEF86161F33B52699253181800926 (void);
// 0x000006C5 UnityEngine.Events.UnityEvent`1<UnityEngine.Networking.PlayerConnection.MessageEventArgs> UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents::AddAndCreate(System.Guid)
extern void PlayerEditorConnectionEvents_AddAndCreate_mB5A51595E4A5DA3B9F353AC72F7B0484C675B7D3 (void);
// 0x000006C6 System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents::UnregisterManagedCallback(System.Guid,UnityEngine.Events.UnityAction`1<UnityEngine.Networking.PlayerConnection.MessageEventArgs>)
extern void PlayerEditorConnectionEvents_UnregisterManagedCallback_mFD3A444E636B079C03739DC96BAFFD5FD55C574A (void);
// 0x000006C7 System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents::.ctor()
extern void PlayerEditorConnectionEvents__ctor_m9BE616B901BCACAABEC9063A838BB803AB7EC2A7 (void);
// 0x000006C8 System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageEvent::.ctor()
extern void MessageEvent__ctor_m700B679037ED52893F092843EE603DBCD6EB8386 (void);
// 0x000006C9 System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_ConnectionChangeEvent::.ctor()
extern void ConnectionChangeEvent__ctor_m3F04C39FD710BF0F25416A61F479CBA1B9021F18 (void);
// 0x000006CA System.Guid UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageTypeSubscribers::get_MessageTypeId()
extern void MessageTypeSubscribers_get_MessageTypeId_mE7DD7E800436C92A325A1080AF60663AE1100D25 (void);
// 0x000006CB System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageTypeSubscribers::set_MessageTypeId(System.Guid)
extern void MessageTypeSubscribers_set_MessageTypeId_m294A7B621AAF1984D886D2569CF1206E4F469115 (void);
// 0x000006CC System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageTypeSubscribers::.ctor()
extern void MessageTypeSubscribers__ctor_mD26A2485EA3ECACFA2CB35D08A48256CE9DFE825 (void);
// 0x000006CD System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_mC65CF56D3417BA36ED321886F1E7A1AF8D443966 (void);
// 0x000006CE System.Boolean UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_<>c__DisplayClass6_0::<InvokeMessageIdSubscribers>b__0(UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageTypeSubscribers)
extern void U3CU3Ec__DisplayClass6_0_U3CInvokeMessageIdSubscribersU3Eb__0_m7208417727D24E769D2C1CF90D6E4CC1AE1F2556 (void);
// 0x000006CF System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_<>c__DisplayClass7_0::.ctor()
extern void U3CU3Ec__DisplayClass7_0__ctor_m59072FF40A09DA582550D3DED10DA2A93FBEAFEF (void);
// 0x000006D0 System.Boolean UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_<>c__DisplayClass7_0::<AddAndCreate>b__0(UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageTypeSubscribers)
extern void U3CU3Ec__DisplayClass7_0_U3CAddAndCreateU3Eb__0_m24A60437D2E527CE675AC4AFAC8152BCA69B033B (void);
// 0x000006D1 System.Void UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_<>c__DisplayClass8_0::.ctor()
extern void U3CU3Ec__DisplayClass8_0__ctor_mE25781AE393CFFE6170E4D655A751918973393AB (void);
// 0x000006D2 System.Boolean UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_<>c__DisplayClass8_0::<UnregisterManagedCallback>b__0(UnityEngine.Networking.PlayerConnection.PlayerEditorConnectionEvents_MessageTypeSubscribers)
extern void U3CU3Ec__DisplayClass8_0_U3CUnregisterManagedCallbackU3Eb__0_m11D9A0AFB947855B548E99416A058C4AAA2E2B26 (void);
// 0x000006D3 System.Void UnityEngine.Internal.DefaultValueAttribute::.ctor(System.String)
extern void DefaultValueAttribute__ctor_m2E914CFCFD82ACAB447480971570E5763C42DAAD (void);
// 0x000006D4 System.Object UnityEngine.Internal.DefaultValueAttribute::get_Value()
extern void DefaultValueAttribute_get_Value_m1E1505D5F1838C28CA4C52DED4A20E81F81BFCC3 (void);
// 0x000006D5 System.Boolean UnityEngine.Internal.DefaultValueAttribute::Equals(System.Object)
extern void DefaultValueAttribute_Equals_mD9073A5C537D4DBDFBD5E3616BC5A05B5D0C51B2 (void);
// 0x000006D6 System.Int32 UnityEngine.Internal.DefaultValueAttribute::GetHashCode()
extern void DefaultValueAttribute_GetHashCode_m4782E2C5A005991FA7E705110A690DD5E0E52D50 (void);
// 0x000006D7 System.Void UnityEngine.Internal.ExcludeFromDocsAttribute::.ctor()
extern void ExcludeFromDocsAttribute__ctor_m01F11706D334D5D31B0C59630DB1674ECFBFAF04 (void);
// 0x000006D8 System.Void UnityEngine.Rendering.RenderTargetIdentifier::.ctor(UnityEngine.Rendering.BuiltinRenderTextureType)
extern void RenderTargetIdentifier__ctor_mC9F9E7E9E601C54067BD503DD592A2212594BD16_AdjustorThunk (void);
// 0x000006D9 System.Void UnityEngine.Rendering.RenderTargetIdentifier::.ctor(System.Int32)
extern void RenderTargetIdentifier__ctor_m055D23CB6BA657306005CBD53F58FC995B4DA977_AdjustorThunk (void);
// 0x000006DA System.Void UnityEngine.Rendering.RenderTargetIdentifier::.ctor(System.Int32,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void RenderTargetIdentifier__ctor_mB2D86972876305C456360182A9315B82FEFF8626_AdjustorThunk (void);
// 0x000006DB System.Void UnityEngine.Rendering.RenderTargetIdentifier::.ctor(UnityEngine.Rendering.RenderTargetIdentifier,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void RenderTargetIdentifier__ctor_m52105EEE0684E42DC890D059B45A22FCA5FBEA64_AdjustorThunk (void);
// 0x000006DC System.Void UnityEngine.Rendering.RenderTargetIdentifier::.ctor(UnityEngine.Texture)
extern void RenderTargetIdentifier__ctor_m51C7EDAEACCD0E210235DDA5769507BA62D290E3_AdjustorThunk (void);
// 0x000006DD UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.RenderTargetIdentifier::op_Implicit(UnityEngine.Rendering.BuiltinRenderTextureType)
extern void RenderTargetIdentifier_op_Implicit_m080A48CE8A898732E2554818DD3BF66004369D1B (void);
// 0x000006DE UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.RenderTargetIdentifier::op_Implicit(System.Int32)
extern void RenderTargetIdentifier_op_Implicit_mC840E0D824C89F1B45CF6484764C33FFF0160E1D (void);
// 0x000006DF UnityEngine.Rendering.RenderTargetIdentifier UnityEngine.Rendering.RenderTargetIdentifier::op_Implicit(UnityEngine.Texture)
extern void RenderTargetIdentifier_op_Implicit_mC09883E389EF054E8DDB5F3CFAD57AAE6EB9F222 (void);
// 0x000006E0 System.String UnityEngine.Rendering.RenderTargetIdentifier::ToString()
extern void RenderTargetIdentifier_ToString_mCFDB39041DD38EB31806B9DFE0A617E2F4034623_AdjustorThunk (void);
// 0x000006E1 System.Int32 UnityEngine.Rendering.RenderTargetIdentifier::GetHashCode()
extern void RenderTargetIdentifier_GetHashCode_m2B944611B172983A1960899C5D50D2963CCFC0A0_AdjustorThunk (void);
// 0x000006E2 System.Boolean UnityEngine.Rendering.RenderTargetIdentifier::Equals(UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderTargetIdentifier_Equals_m00E3CCDBDEBC15F4ADEEF48412F283B001EFB6E8_AdjustorThunk (void);
// 0x000006E3 System.Boolean UnityEngine.Rendering.RenderTargetIdentifier::Equals(System.Object)
extern void RenderTargetIdentifier_Equals_mB5F0CAF9B997DC7AE33D33CB48F434534326E9CD_AdjustorThunk (void);
// 0x000006E4 System.Boolean UnityEngine.Rendering.RenderTargetIdentifier::op_Equality(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderTargetIdentifier_op_Equality_mAB9168185A74088E10E2AC74603FA4C8C14FB8DC (void);
// 0x000006E5 System.Boolean UnityEngine.Rendering.RenderTargetIdentifier::op_Inequality(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier)
extern void RenderTargetIdentifier_op_Inequality_m437F3C325DBD8A46ED251E297B0714B15DE3B174 (void);
// 0x000006E6 System.Boolean UnityEngine.Rendering.GraphicsSettings::get_lightsUseLinearIntensity()
extern void GraphicsSettings_get_lightsUseLinearIntensity_mED8D75F87016FCF600955146863696AB214BA29A (void);
// 0x000006E7 System.Void UnityEngine.Rendering.GraphicsSettings::set_lightsUseLinearIntensity(System.Boolean)
extern void GraphicsSettings_set_lightsUseLinearIntensity_mC6F381972C7D65C767AE062D66F96F9C59C3A3AB (void);
// 0x000006E8 System.Void UnityEngine.Rendering.GraphicsSettings::set_useScriptableRenderPipelineBatching(System.Boolean)
extern void GraphicsSettings_set_useScriptableRenderPipelineBatching_mB8156F563763E71E21B4367A3B04242A4E27E513 (void);
// 0x000006E9 System.Boolean UnityEngine.Rendering.GraphicsSettings::AllowEnlightenSupportForUpgradedProject()
extern void GraphicsSettings_AllowEnlightenSupportForUpgradedProject_m00E568FAA4C9D08BEE0944042CF817BC242F2BEF (void);
// 0x000006EA System.Boolean UnityEngine.Rendering.GraphicsSettings::HasShaderDefine(UnityEngine.Rendering.GraphicsTier,UnityEngine.Rendering.BuiltinShaderDefine)
extern void GraphicsSettings_HasShaderDefine_mA450B4FB841C35E87047EABACF23EBB946338DA0 (void);
// 0x000006EB UnityEngine.ScriptableObject UnityEngine.Rendering.GraphicsSettings::get_INTERNAL_currentRenderPipeline()
extern void GraphicsSettings_get_INTERNAL_currentRenderPipeline_m0671B600425EBD6A0E9314CCDD23E4423F4958E8 (void);
// 0x000006EC UnityEngine.Rendering.RenderPipelineAsset UnityEngine.Rendering.GraphicsSettings::get_currentRenderPipeline()
extern void GraphicsSettings_get_currentRenderPipeline_mAF5358722E9516C78CFDCE7653F95C199A08B22E (void);
// 0x000006ED System.Void UnityEngine.Rendering.GraphicsSettings::set_renderPipelineAsset(UnityEngine.Rendering.RenderPipelineAsset)
extern void GraphicsSettings_set_renderPipelineAsset_mE2F18FA93835AAE00130EFADA71084D2638BEFB2 (void);
// 0x000006EE System.Void UnityEngine.Rendering.GraphicsSettings::set_INTERNAL_defaultRenderPipeline(UnityEngine.ScriptableObject)
extern void GraphicsSettings_set_INTERNAL_defaultRenderPipeline_m762F3819352D0E42CCD2D281942787ECE10B4DF5 (void);
// 0x000006EF System.Void UnityEngine.Rendering.GraphicsSettings::set_defaultRenderPipeline(UnityEngine.Rendering.RenderPipelineAsset)
extern void GraphicsSettings_set_defaultRenderPipeline_mDCDB1E887380471F046566C549392954C3BAC4CC (void);
// 0x000006F0 System.Int32 UnityEngine.Rendering.OnDemandRendering::get_renderFrameInterval()
extern void OnDemandRendering_get_renderFrameInterval_m5A12FB459D93296FBACCD6FD59EA27CD092A0132 (void);
// 0x000006F1 System.Void UnityEngine.Rendering.OnDemandRendering::GetRenderFrameInterval(System.Int32&)
extern void OnDemandRendering_GetRenderFrameInterval_m2A6D3ADB578BA19E153C6B049FC668975155EB27 (void);
// 0x000006F2 System.Void UnityEngine.Rendering.OnDemandRendering::.cctor()
extern void OnDemandRendering__cctor_m00887F122A90C963B1B120117276E3BE3A0D258F (void);
// 0x000006F3 System.IntPtr UnityEngine.Rendering.CommandBuffer::InitBuffer()
extern void CommandBuffer_InitBuffer_m4C92D488CE3F9B4F32ECF52DBCE84C7FC4E9169F (void);
// 0x000006F4 System.Void UnityEngine.Rendering.CommandBuffer::ReleaseBuffer()
extern void CommandBuffer_ReleaseBuffer_m330F9401528CDD7D9A7AB6D87719B3740B15977E (void);
// 0x000006F5 System.Void UnityEngine.Rendering.CommandBuffer::Internal_SetComputeTextureParam(UnityEngine.ComputeShader,System.Int32,System.Int32,UnityEngine.Rendering.RenderTargetIdentifier&,System.Int32,UnityEngine.Rendering.RenderTextureSubElement)
extern void CommandBuffer_Internal_SetComputeTextureParam_m96D5BA0A59E7EC8B1650F4BF3B46AA80841996C6 (void);
// 0x000006F6 System.Void UnityEngine.Rendering.CommandBuffer::Internal_DispatchCompute(UnityEngine.ComputeShader,System.Int32,System.Int32,System.Int32,System.Int32)
extern void CommandBuffer_Internal_DispatchCompute_m1DEED4C414F5F4D2926E6E0491A2AE9407553246 (void);
// 0x000006F7 System.Void UnityEngine.Rendering.CommandBuffer::set_name(System.String)
extern void CommandBuffer_set_name_m30052DF9C74868F27260E3A114E02497972C4503 (void);
// 0x000006F8 System.Void UnityEngine.Rendering.CommandBuffer::Clear()
extern void CommandBuffer_Clear_mCE65F50CF8DBEE5543EFE80CA9FEDA780F76F430 (void);
// 0x000006F9 System.Void UnityEngine.Rendering.CommandBuffer::Internal_DrawMesh(UnityEngine.Mesh,UnityEngine.Matrix4x4,UnityEngine.Material,System.Int32,System.Int32,UnityEngine.MaterialPropertyBlock)
extern void CommandBuffer_Internal_DrawMesh_m4B07D0CEEC6669401C9A6184F347578430D33405 (void);
// 0x000006FA System.Void UnityEngine.Rendering.CommandBuffer::Internal_DrawRenderer(UnityEngine.Renderer,UnityEngine.Material,System.Int32,System.Int32)
extern void CommandBuffer_Internal_DrawRenderer_m3DE8FFA9BA7631AEB8DB855ADEF463A0EC03618A (void);
// 0x000006FB System.Void UnityEngine.Rendering.CommandBuffer::Internal_DrawProcedural(UnityEngine.Matrix4x4,UnityEngine.Material,System.Int32,UnityEngine.MeshTopology,System.Int32,System.Int32,UnityEngine.MaterialPropertyBlock)
extern void CommandBuffer_Internal_DrawProcedural_m83E79E951F1C3074932C86FC7CDB69A8991F1029 (void);
// 0x000006FC System.Void UnityEngine.Rendering.CommandBuffer::Internal_DrawOcclusionMesh(UnityEngine.RectInt)
extern void CommandBuffer_Internal_DrawOcclusionMesh_mC9E401F7B969786E6E4BFCAE49AC8A58E0816B36 (void);
// 0x000006FD System.Void UnityEngine.Rendering.CommandBuffer::SetViewport(UnityEngine.Rect)
extern void CommandBuffer_SetViewport_mB4381F35791CB3E1EBF12EB56E50B258CC56AC73 (void);
// 0x000006FE System.Void UnityEngine.Rendering.CommandBuffer::EnableScissorRect(UnityEngine.Rect)
extern void CommandBuffer_EnableScissorRect_m93E69383D1B88B4DD095F9C84FA41C74A5F11446 (void);
// 0x000006FF System.Void UnityEngine.Rendering.CommandBuffer::DisableScissorRect()
extern void CommandBuffer_DisableScissorRect_m7E9FF8FCCB245074C01985F8BAB3CBC4A09731B2 (void);
// 0x00000700 System.Void UnityEngine.Rendering.CommandBuffer::Blit_Identifier(UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Material,System.Int32,UnityEngine.Vector2,UnityEngine.Vector2,System.Int32,System.Int32)
extern void CommandBuffer_Blit_Identifier_m2A46C7B22C0C912DE5E5E479227829C4C9DF547C (void);
// 0x00000701 System.Void UnityEngine.Rendering.CommandBuffer::GetTemporaryRTWithDescriptor(System.Int32,UnityEngine.RenderTextureDescriptor,UnityEngine.FilterMode)
extern void CommandBuffer_GetTemporaryRTWithDescriptor_mA812D41F50EF532AD70F7539734F6219650CCCC6 (void);
// 0x00000702 System.Void UnityEngine.Rendering.CommandBuffer::GetTemporaryRT(System.Int32,UnityEngine.RenderTextureDescriptor,UnityEngine.FilterMode)
extern void CommandBuffer_GetTemporaryRT_m2D1ED99658CAE81F879AA985FD2D17082E4EAF11 (void);
// 0x00000703 System.Void UnityEngine.Rendering.CommandBuffer::ReleaseTemporaryRT(System.Int32)
extern void CommandBuffer_ReleaseTemporaryRT_m3267E003250DF8263AA098E0DEE1868B894312D1 (void);
// 0x00000704 System.Void UnityEngine.Rendering.CommandBuffer::ClearRenderTarget(System.Boolean,System.Boolean,UnityEngine.Color,System.Single)
extern void CommandBuffer_ClearRenderTarget_m269F6929B8F37BFEA0DDBEAE30C1E0406612468B (void);
// 0x00000705 System.Void UnityEngine.Rendering.CommandBuffer::ClearRenderTarget(System.Boolean,System.Boolean,UnityEngine.Color)
extern void CommandBuffer_ClearRenderTarget_mFC9852EE8E501998CFFC2B6311FBD20D9150B79B (void);
// 0x00000706 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalFloat(System.Int32,System.Single)
extern void CommandBuffer_SetGlobalFloat_m403119507077C95E321EE6403ED3E15E3844EDAA (void);
// 0x00000707 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalVector(System.Int32,UnityEngine.Vector4)
extern void CommandBuffer_SetGlobalVector_mC6C9D66DA11EFEFAF580FE1411D32E8A61EC6B3C (void);
// 0x00000708 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalColor(System.Int32,UnityEngine.Color)
extern void CommandBuffer_SetGlobalColor_mCE5542EEC3DA5CB363DCF34213D748F213420BD5 (void);
// 0x00000709 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalMatrix(System.Int32,UnityEngine.Matrix4x4)
extern void CommandBuffer_SetGlobalMatrix_m5F602FC5014073C65BC9C0CA67CA12EE4FCE27F4 (void);
// 0x0000070A System.Void UnityEngine.Rendering.CommandBuffer::EnableShaderKeyword(System.String)
extern void CommandBuffer_EnableShaderKeyword_m026A67186DDDE920448D9C3C45A1C4B9498A9CA2 (void);
// 0x0000070B System.Void UnityEngine.Rendering.CommandBuffer::DisableShaderKeyword(System.String)
extern void CommandBuffer_DisableShaderKeyword_mEC93D09CFC43C5AA7B465E5B49C5ACD617BEFE6E (void);
// 0x0000070C System.Void UnityEngine.Rendering.CommandBuffer::SetViewProjectionMatrices(UnityEngine.Matrix4x4,UnityEngine.Matrix4x4)
extern void CommandBuffer_SetViewProjectionMatrices_m4244BA279DA833E02F12838CF56B8D62BB210385 (void);
// 0x0000070D System.Boolean UnityEngine.Rendering.CommandBuffer::ValidateAgainstExecutionFlags(UnityEngine.Rendering.CommandBufferExecutionFlags,UnityEngine.Rendering.CommandBufferExecutionFlags)
extern void CommandBuffer_ValidateAgainstExecutionFlags_mFE1D4E7FDB70EA8C5D819FBFDA6A33C3698F247C (void);
// 0x0000070E System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalVectorArray(System.Int32,UnityEngine.Vector4[])
extern void CommandBuffer_SetGlobalVectorArray_mDAA1401184E0A4E83A7F14FF2C8D02BC90C91FDE (void);
// 0x0000070F System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalMatrixArray(System.Int32,UnityEngine.Matrix4x4[])
extern void CommandBuffer_SetGlobalMatrixArray_m93A4C4959543348B9781CC5C3188F30A894B3CAB (void);
// 0x00000710 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalTexture_Impl(System.Int32,UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Rendering.RenderTextureSubElement)
extern void CommandBuffer_SetGlobalTexture_Impl_m0C6C71E266DD5BFFA7B3E031153C7D12A6AF51E4 (void);
// 0x00000711 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalBuffer(System.Int32,UnityEngine.ComputeBuffer)
extern void CommandBuffer_SetGlobalBuffer_m156A3B6BD9DE675918639BA72F8AB6A6B2F740C1 (void);
// 0x00000712 System.Void UnityEngine.Rendering.CommandBuffer::BeginSample(System.String)
extern void CommandBuffer_BeginSample_m3CA1DF7A40CAD00ADB4D65DABD9BBAD85270C94B (void);
// 0x00000713 System.Void UnityEngine.Rendering.CommandBuffer::EndSample(System.String)
extern void CommandBuffer_EndSample_m95CE1316AB5FC819FAD6EC713C8761AA08E2D759 (void);
// 0x00000714 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTarget(UnityEngine.Rendering.RenderTargetIdentifier)
extern void CommandBuffer_SetRenderTarget_m4A6843B28AE9DCDC2AB8B346ACD9EEE87624C350 (void);
// 0x00000715 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void CommandBuffer_SetRenderTarget_m68ACC8D2AE163D56A0540F9C86BB6DC2F7BCE34B (void);
// 0x00000716 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void CommandBuffer_SetRenderTarget_m0B46C3DA20A687C5342ADCA092428D06285E6799 (void);
// 0x00000717 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTarget(UnityEngine.Rendering.RenderTargetIdentifier,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CommandBuffer_SetRenderTarget_m55B90D47B8E5114F44265CE5A9B4006C7AE0ADF3 (void);
// 0x00000718 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CommandBuffer_SetRenderTarget_m92DD2D65157954D6A495FEC5C9F1C90E9E36C56C (void);
// 0x00000719 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTarget(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void CommandBuffer_SetRenderTarget_m98CE2A15CE8C7B8B1BDAF6BE95FA170843A43794 (void);
// 0x0000071A System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTarget(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CommandBuffer_SetRenderTarget_mA7F010252636777AF2664CDD0413088D40B8426D (void);
// 0x0000071B System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTargetSingle_Internal(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void CommandBuffer_SetRenderTargetSingle_Internal_m644F8B20A5387FCF5EAE8F7878B65235E06F80BC (void);
// 0x0000071C System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTargetColorDepth_Internal(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void CommandBuffer_SetRenderTargetColorDepth_Internal_mEB22B7C89467D5A0C82C3C307C75690AE5E79F6D (void);
// 0x0000071D System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTargetMultiSubtarget(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderBufferLoadAction[],UnityEngine.Rendering.RenderBufferStoreAction[],UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CommandBuffer_SetRenderTargetMultiSubtarget_m040DAB3E7EDC6C8EFA4F5F53CF87D9ED3600E924 (void);
// 0x0000071E System.Void UnityEngine.Rendering.CommandBuffer::Finalize()
extern void CommandBuffer_Finalize_mD3311714DC6ECA1FDA3A784A543BB475C6D35C0E (void);
// 0x0000071F System.Void UnityEngine.Rendering.CommandBuffer::Dispose()
extern void CommandBuffer_Dispose_m8DC3E2F8552CCCFE67C139585E88F5BC1735BF1C (void);
// 0x00000720 System.Void UnityEngine.Rendering.CommandBuffer::Dispose(System.Boolean)
extern void CommandBuffer_Dispose_m960A52C79A8B46920A321C0636F4EBED21E8AF68 (void);
// 0x00000721 System.Void UnityEngine.Rendering.CommandBuffer::.ctor()
extern void CommandBuffer__ctor_m4394F7E41C9BB751E382A8CAFA38B19F69E03890 (void);
// 0x00000722 System.Void UnityEngine.Rendering.CommandBuffer::SetComputeTextureParam(UnityEngine.ComputeShader,System.Int32,System.String,UnityEngine.Rendering.RenderTargetIdentifier)
extern void CommandBuffer_SetComputeTextureParam_m5296CBD113C2D672F20A0151812BCCF72AA5C350 (void);
// 0x00000723 System.Void UnityEngine.Rendering.CommandBuffer::DispatchCompute(UnityEngine.ComputeShader,System.Int32,System.Int32,System.Int32,System.Int32)
extern void CommandBuffer_DispatchCompute_mDC3B6B6A63C8583EA623A214629EC6F7E4AEEC7A (void);
// 0x00000724 System.Void UnityEngine.Rendering.CommandBuffer::DrawMesh(UnityEngine.Mesh,UnityEngine.Matrix4x4,UnityEngine.Material,System.Int32,System.Int32,UnityEngine.MaterialPropertyBlock)
extern void CommandBuffer_DrawMesh_mEA36EB7C577DE37F8748E5C05A93D4E041856831 (void);
// 0x00000725 System.Void UnityEngine.Rendering.CommandBuffer::DrawMesh(UnityEngine.Mesh,UnityEngine.Matrix4x4,UnityEngine.Material,System.Int32,System.Int32)
extern void CommandBuffer_DrawMesh_m1C8D2B41AD8B7A900983B46AB125C2496B569AAE (void);
// 0x00000726 System.Void UnityEngine.Rendering.CommandBuffer::DrawMesh(UnityEngine.Mesh,UnityEngine.Matrix4x4,UnityEngine.Material,System.Int32)
extern void CommandBuffer_DrawMesh_m5516835A54715967C66C40BD0C473D5E82AF4E78 (void);
// 0x00000727 System.Void UnityEngine.Rendering.CommandBuffer::DrawMesh(UnityEngine.Mesh,UnityEngine.Matrix4x4,UnityEngine.Material)
extern void CommandBuffer_DrawMesh_m99BD39FFA05B90C9C2464095D351A7316B276A3B (void);
// 0x00000728 System.Void UnityEngine.Rendering.CommandBuffer::DrawRenderer(UnityEngine.Renderer,UnityEngine.Material,System.Int32,System.Int32)
extern void CommandBuffer_DrawRenderer_mEED261111FF54C15DCA12EBCCE5917C79CFC0918 (void);
// 0x00000729 System.Void UnityEngine.Rendering.CommandBuffer::DrawRenderer(UnityEngine.Renderer,UnityEngine.Material,System.Int32)
extern void CommandBuffer_DrawRenderer_m945F95EA6511B5C707B1B6B35A9608C4EB90B83C (void);
// 0x0000072A System.Void UnityEngine.Rendering.CommandBuffer::DrawRenderer(UnityEngine.Renderer,UnityEngine.Material)
extern void CommandBuffer_DrawRenderer_mFEBC0E774BB41C84909B49BDF610D84067DA40B4 (void);
// 0x0000072B System.Void UnityEngine.Rendering.CommandBuffer::DrawProcedural(UnityEngine.Matrix4x4,UnityEngine.Material,System.Int32,UnityEngine.MeshTopology,System.Int32,System.Int32,UnityEngine.MaterialPropertyBlock)
extern void CommandBuffer_DrawProcedural_m0CCC835D8D69536F516EF9C71EF311FCCB386D50 (void);
// 0x0000072C System.Void UnityEngine.Rendering.CommandBuffer::DrawOcclusionMesh(UnityEngine.RectInt)
extern void CommandBuffer_DrawOcclusionMesh_m9CD6F32EC9020F4329A3E9C909BD4ED4C849286D (void);
// 0x0000072D System.Void UnityEngine.Rendering.CommandBuffer::Blit(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Material)
extern void CommandBuffer_Blit_mAB18B4FAB53E131FE17ABB00B8891664803B1A58 (void);
// 0x0000072E System.Void UnityEngine.Rendering.CommandBuffer::Blit(UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Material,System.Int32)
extern void CommandBuffer_Blit_m2EC19CD9B2A14AD0674980C17210315BA050FE54 (void);
// 0x0000072F System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalFloat(System.String,System.Single)
extern void CommandBuffer_SetGlobalFloat_m531DDFDE18FE436DA735D58F2271F4DD1624F679 (void);
// 0x00000730 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalVector(System.String,UnityEngine.Vector4)
extern void CommandBuffer_SetGlobalVector_m8FDF51D3D5336EFDA2B93252742D339BD61F8FC2 (void);
// 0x00000731 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalColor(System.String,UnityEngine.Color)
extern void CommandBuffer_SetGlobalColor_m2E1ABCC34C55ECF89E2E70AA6265B22833BF1658 (void);
// 0x00000732 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalMatrix(System.String,UnityEngine.Matrix4x4)
extern void CommandBuffer_SetGlobalMatrix_m5E91602C3778640EA7D0587BF08F80DC6E9EE2C2 (void);
// 0x00000733 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalTexture(System.String,UnityEngine.Rendering.RenderTargetIdentifier)
extern void CommandBuffer_SetGlobalTexture_mB8A5225451E1E43048503A268E5F8737F5F80437 (void);
// 0x00000734 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalTexture(System.Int32,UnityEngine.Rendering.RenderTargetIdentifier)
extern void CommandBuffer_SetGlobalTexture_m8001F4E6981084B9E53FFFBF3ADA29AA080A7496 (void);
// 0x00000735 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalTexture(System.Int32,UnityEngine.Rendering.RenderTargetIdentifier,UnityEngine.Rendering.RenderTextureSubElement)
extern void CommandBuffer_SetGlobalTexture_mEC04BECCC16812161235D47483E5E2BF0F70233F (void);
// 0x00000736 System.Void UnityEngine.Rendering.CommandBuffer::Internal_DrawMesh_Injected(UnityEngine.Mesh,UnityEngine.Matrix4x4&,UnityEngine.Material,System.Int32,System.Int32,UnityEngine.MaterialPropertyBlock)
extern void CommandBuffer_Internal_DrawMesh_Injected_m03A7D079E2C3C87D9774BF3D5FCF56F30C5D0AEA (void);
// 0x00000737 System.Void UnityEngine.Rendering.CommandBuffer::Internal_DrawProcedural_Injected(UnityEngine.Matrix4x4&,UnityEngine.Material,System.Int32,UnityEngine.MeshTopology,System.Int32,System.Int32,UnityEngine.MaterialPropertyBlock)
extern void CommandBuffer_Internal_DrawProcedural_Injected_m2B1DD80639018659DA66B4502EBDE38AC72BCD21 (void);
// 0x00000738 System.Void UnityEngine.Rendering.CommandBuffer::Internal_DrawOcclusionMesh_Injected(UnityEngine.RectInt&)
extern void CommandBuffer_Internal_DrawOcclusionMesh_Injected_mC0E2824DFD6ACBBB9CDF7B2357D9C0FA0F6696E6 (void);
// 0x00000739 System.Void UnityEngine.Rendering.CommandBuffer::SetViewport_Injected(UnityEngine.Rect&)
extern void CommandBuffer_SetViewport_Injected_m1BAF7CF8FC8C2EA01B480F202AE04C90BAC768EE (void);
// 0x0000073A System.Void UnityEngine.Rendering.CommandBuffer::EnableScissorRect_Injected(UnityEngine.Rect&)
extern void CommandBuffer_EnableScissorRect_Injected_m2EFF33BE41BF2C0F03AD9E1DD1337219ECB7FD88 (void);
// 0x0000073B System.Void UnityEngine.Rendering.CommandBuffer::Blit_Identifier_Injected(UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Material,System.Int32,UnityEngine.Vector2&,UnityEngine.Vector2&,System.Int32,System.Int32)
extern void CommandBuffer_Blit_Identifier_Injected_mD466A36D8110C0D8D458FCE4B2A4545A30207F03 (void);
// 0x0000073C System.Void UnityEngine.Rendering.CommandBuffer::GetTemporaryRTWithDescriptor_Injected(System.Int32,UnityEngine.RenderTextureDescriptor&,UnityEngine.FilterMode)
extern void CommandBuffer_GetTemporaryRTWithDescriptor_Injected_m1E919DF93296D82BA0A17AF4B6CB03DE15C3F822 (void);
// 0x0000073D System.Void UnityEngine.Rendering.CommandBuffer::ClearRenderTarget_Injected(System.Boolean,System.Boolean,UnityEngine.Color&,System.Single)
extern void CommandBuffer_ClearRenderTarget_Injected_m33BD666160A5331D0B164F36D4222ACD2D629355 (void);
// 0x0000073E System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalVector_Injected(System.Int32,UnityEngine.Vector4&)
extern void CommandBuffer_SetGlobalVector_Injected_mBA68058B2D3C0E6A7C32EFF9356489ED5A65E74A (void);
// 0x0000073F System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalColor_Injected(System.Int32,UnityEngine.Color&)
extern void CommandBuffer_SetGlobalColor_Injected_m542893E3ED6D761D188252EFC447E0577E79415C (void);
// 0x00000740 System.Void UnityEngine.Rendering.CommandBuffer::SetGlobalMatrix_Injected(System.Int32,UnityEngine.Matrix4x4&)
extern void CommandBuffer_SetGlobalMatrix_Injected_m6B89FBA274BC550DE264027C40CB603541866C0C (void);
// 0x00000741 System.Void UnityEngine.Rendering.CommandBuffer::SetViewProjectionMatrices_Injected(UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&)
extern void CommandBuffer_SetViewProjectionMatrices_Injected_m733213BCC938EDED6595BDCA26A5F6065DAEB71D (void);
// 0x00000742 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTargetSingle_Internal_Injected(UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void CommandBuffer_SetRenderTargetSingle_Internal_Injected_mBC700D63DEB5998C857DA9694837AA65387A4C7C (void);
// 0x00000743 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTargetColorDepth_Internal_Injected(UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction)
extern void CommandBuffer_SetRenderTargetColorDepth_Internal_Injected_m90FAA369BC20773B54F298636A780D722741094D (void);
// 0x00000744 System.Void UnityEngine.Rendering.CommandBuffer::SetRenderTargetMultiSubtarget_Injected(UnityEngine.Rendering.RenderTargetIdentifier[],UnityEngine.Rendering.RenderTargetIdentifier&,UnityEngine.Rendering.RenderBufferLoadAction[],UnityEngine.Rendering.RenderBufferStoreAction[],UnityEngine.Rendering.RenderBufferLoadAction,UnityEngine.Rendering.RenderBufferStoreAction,System.Int32,UnityEngine.CubemapFace,System.Int32)
extern void CommandBuffer_SetRenderTargetMultiSubtarget_Injected_m0D92DFDC0BD84730CF35D815F107C068520A5C3D (void);
// 0x00000745 System.Single UnityEngine.Rendering.SphericalHarmonicsL2::get_Item(System.Int32,System.Int32)
extern void SphericalHarmonicsL2_get_Item_m82A8676E14B978464C341AD2FA510C6332DEB690_AdjustorThunk (void);
// 0x00000746 System.Int32 UnityEngine.Rendering.SphericalHarmonicsL2::GetHashCode()
extern void SphericalHarmonicsL2_GetHashCode_mDE2A1FBF5564831948DB2A1D4C30069B3D1F1F0F_AdjustorThunk (void);
// 0x00000747 System.Boolean UnityEngine.Rendering.SphericalHarmonicsL2::Equals(System.Object)
extern void SphericalHarmonicsL2_Equals_mD5CEC114E1C53B65C9F7AD47BC625E5D817707CB_AdjustorThunk (void);
// 0x00000748 System.Boolean UnityEngine.Rendering.SphericalHarmonicsL2::Equals(UnityEngine.Rendering.SphericalHarmonicsL2)
extern void SphericalHarmonicsL2_Equals_mF10B8F6B3BAC7AF361CF908C6135A07A6C18E431_AdjustorThunk (void);
// 0x00000749 System.Boolean UnityEngine.Rendering.SphericalHarmonicsL2::op_Equality(UnityEngine.Rendering.SphericalHarmonicsL2,UnityEngine.Rendering.SphericalHarmonicsL2)
extern void SphericalHarmonicsL2_op_Equality_mE15995C406879B7A0B606C4535F2E3EC20DA00DC (void);
// 0x0000074A System.Void UnityEngine.Rendering.BatchCullingContext::.ctor(Unity.Collections.NativeArray`1<UnityEngine.Plane>,Unity.Collections.NativeArray`1<UnityEngine.Rendering.BatchVisibility>,Unity.Collections.NativeArray`1<System.Int32>,UnityEngine.Rendering.LODParameters)
extern void BatchCullingContext__ctor_m5BB85EDAC0F7C5AFFABF7AD30F18AD272EA23E32_AdjustorThunk (void);
// 0x0000074B System.Void UnityEngine.Rendering.BatchRendererGroup::InvokeOnPerformCulling(UnityEngine.Rendering.BatchRendererGroup,UnityEngine.Rendering.BatchRendererCullingOutput&,UnityEngine.Rendering.LODParameters&)
extern void BatchRendererGroup_InvokeOnPerformCulling_mE7F3139F1032B8B6160F5601BB55410609D0EF6E (void);
// 0x0000074C System.Void UnityEngine.Rendering.BatchRendererGroup_OnPerformCulling::.ctor(System.Object,System.IntPtr)
extern void OnPerformCulling__ctor_mC901B41F5C6F0A0A144862B9014047CAE3702E2F (void);
// 0x0000074D Unity.Jobs.JobHandle UnityEngine.Rendering.BatchRendererGroup_OnPerformCulling::Invoke(UnityEngine.Rendering.BatchRendererGroup,UnityEngine.Rendering.BatchCullingContext)
extern void OnPerformCulling_Invoke_m91277025DBB74E928F6C98E7A6745B07F5B2FD59 (void);
// 0x0000074E System.IAsyncResult UnityEngine.Rendering.BatchRendererGroup_OnPerformCulling::BeginInvoke(UnityEngine.Rendering.BatchRendererGroup,UnityEngine.Rendering.BatchCullingContext,System.AsyncCallback,System.Object)
extern void OnPerformCulling_BeginInvoke_m8179E1CC4FD6B2858D0333578FCB43594551DAAD (void);
// 0x0000074F Unity.Jobs.JobHandle UnityEngine.Rendering.BatchRendererGroup_OnPerformCulling::EndInvoke(System.IAsyncResult)
extern void OnPerformCulling_EndInvoke_m3EB7184DC9175B0F722CE41E1CE6507887CA55DB (void);
// 0x00000750 UnityEngine.Rendering.BlendState UnityEngine.Rendering.BlendState::get_defaultValue()
extern void BlendState_get_defaultValue_mD779BFF820CEFD4DC3E9D9ED6745B29BCA989FC9 (void);
// 0x00000751 System.Void UnityEngine.Rendering.BlendState::.ctor(System.Boolean,System.Boolean)
extern void BlendState__ctor_m74AE96850682F048EB45745E8081C78573072117_AdjustorThunk (void);
// 0x00000752 System.Boolean UnityEngine.Rendering.BlendState::Equals(UnityEngine.Rendering.BlendState)
extern void BlendState_Equals_mA8EDACDA477AAB9E60C1C2A7FC568F8DB9707F9D_AdjustorThunk (void);
// 0x00000753 System.Boolean UnityEngine.Rendering.BlendState::Equals(System.Object)
extern void BlendState_Equals_m4432F73926DDA5349F3EBC402F0E74C0DDC096F5_AdjustorThunk (void);
// 0x00000754 System.Int32 UnityEngine.Rendering.BlendState::GetHashCode()
extern void BlendState_GetHashCode_mEBF901015C36A6618A26E0EEBDB8E576B68BEF78_AdjustorThunk (void);
// 0x00000755 System.Boolean UnityEngine.Rendering.CoreCameraValues::Equals(UnityEngine.Rendering.CoreCameraValues)
extern void CoreCameraValues_Equals_mCF002AD7C14B85902AF18F2ED870B767E442E092_AdjustorThunk (void);
// 0x00000756 System.Boolean UnityEngine.Rendering.CoreCameraValues::Equals(System.Object)
extern void CoreCameraValues_Equals_m63B9697F5C101FB73ADE5D36A768CD53D9EB0B51_AdjustorThunk (void);
// 0x00000757 System.Int32 UnityEngine.Rendering.CoreCameraValues::GetHashCode()
extern void CoreCameraValues_GetHashCode_m6CF09BCD18D9C423387247346F275E1EA8677E65_AdjustorThunk (void);
// 0x00000758 UnityEngine.Plane UnityEngine.Rendering.CameraProperties::GetShadowCullingPlane(System.Int32)
extern void CameraProperties_GetShadowCullingPlane_m59D2AD18CC32DFD00035BCAC76066B580C4ED1F8_AdjustorThunk (void);
// 0x00000759 UnityEngine.Plane UnityEngine.Rendering.CameraProperties::GetCameraCullingPlane(System.Int32)
extern void CameraProperties_GetCameraCullingPlane_mF12B28E5D0DED39216717B26BAFA3A204CD98235_AdjustorThunk (void);
// 0x0000075A System.Boolean UnityEngine.Rendering.CameraProperties::Equals(UnityEngine.Rendering.CameraProperties)
extern void CameraProperties_Equals_mB337807818FA5B1186271C11ED6BED966E5DFED2_AdjustorThunk (void);
// 0x0000075B System.Boolean UnityEngine.Rendering.CameraProperties::Equals(System.Object)
extern void CameraProperties_Equals_mD757026849E7166ED35F025EAF3ECF8AFEA01D09_AdjustorThunk (void);
// 0x0000075C System.Int32 UnityEngine.Rendering.CameraProperties::GetHashCode()
extern void CameraProperties_GetHashCode_mC57BC84CD0C4C0FF93E501CFEC78F0DB1FF39AFA_AdjustorThunk (void);
// 0x0000075D System.Int32 UnityEngine.Rendering.ScriptableCullingParameters::get_cullingPlaneCount()
extern void ScriptableCullingParameters_get_cullingPlaneCount_m67039C9499D1E2704DCFA130B74CBCF200331B1F_AdjustorThunk (void);
// 0x0000075E System.Void UnityEngine.Rendering.ScriptableCullingParameters::set_isOrthographic(System.Boolean)
extern void ScriptableCullingParameters_set_isOrthographic_mEF6A28AEF683251F51167816FE4C07F17378DCCB_AdjustorThunk (void);
// 0x0000075F System.Void UnityEngine.Rendering.ScriptableCullingParameters::set_shadowDistance(System.Single)
extern void ScriptableCullingParameters_set_shadowDistance_mDF1E31636326E2A29BF66D54D764D2E42E7F2D9D_AdjustorThunk (void);
// 0x00000760 UnityEngine.Rendering.CullingOptions UnityEngine.Rendering.ScriptableCullingParameters::get_cullingOptions()
extern void ScriptableCullingParameters_get_cullingOptions_m2FEA92265EF0460E8B42A767370CBDE6C95B9FF7_AdjustorThunk (void);
// 0x00000761 System.Void UnityEngine.Rendering.ScriptableCullingParameters::set_cullingOptions(UnityEngine.Rendering.CullingOptions)
extern void ScriptableCullingParameters_set_cullingOptions_m3743C1B77E7404612AD43ACEF8E4395F9C73A947_AdjustorThunk (void);
// 0x00000762 System.Single UnityEngine.Rendering.ScriptableCullingParameters::GetLayerCullingDistance(System.Int32)
extern void ScriptableCullingParameters_GetLayerCullingDistance_m921444B2ED20478C6A4F79BCA88289EA97A53852_AdjustorThunk (void);
// 0x00000763 UnityEngine.Plane UnityEngine.Rendering.ScriptableCullingParameters::GetCullingPlane(System.Int32)
extern void ScriptableCullingParameters_GetCullingPlane_mA18B64C14443CAFD24A58060A76AFE55BB5DA146_AdjustorThunk (void);
// 0x00000764 System.Boolean UnityEngine.Rendering.ScriptableCullingParameters::Equals(UnityEngine.Rendering.ScriptableCullingParameters)
extern void ScriptableCullingParameters_Equals_mFB5D9CE0FB089EC44A8487285EB4748522D60898_AdjustorThunk (void);
// 0x00000765 System.Boolean UnityEngine.Rendering.ScriptableCullingParameters::Equals(System.Object)
extern void ScriptableCullingParameters_Equals_mA9D6FDE1D691E461989197858871686AA0BFB739_AdjustorThunk (void);
// 0x00000766 System.Int32 UnityEngine.Rendering.ScriptableCullingParameters::GetHashCode()
extern void ScriptableCullingParameters_GetHashCode_mFB94E70582ACC5C30BC172C9190F9F58E57869B2_AdjustorThunk (void);
// 0x00000767 System.Void UnityEngine.Rendering.ScriptableCullingParameters::.cctor()
extern void ScriptableCullingParameters__cctor_m3D1DDA0E0FACF810E53B8D17043970F1110890D3 (void);
// 0x00000768 System.Int32 UnityEngine.Rendering.CullingResults::GetLightIndexCount(System.IntPtr)
extern void CullingResults_GetLightIndexCount_m6CB083E56D9DD7F2BCCC7896C857656C2F3CEC31 (void);
// 0x00000769 System.Int32 UnityEngine.Rendering.CullingResults::GetReflectionProbeIndexCount(System.IntPtr)
extern void CullingResults_GetReflectionProbeIndexCount_m2AC7AA1AB45D57D01723DB0013628178F6B7F831 (void);
// 0x0000076A System.Void UnityEngine.Rendering.CullingResults::FillLightAndReflectionProbeIndices(System.IntPtr,UnityEngine.ComputeBuffer)
extern void CullingResults_FillLightAndReflectionProbeIndices_mB0C3A11B23CFC3530435CA821739C2035895A3D0 (void);
// 0x0000076B System.Int32 UnityEngine.Rendering.CullingResults::GetLightIndexMapSize(System.IntPtr)
extern void CullingResults_GetLightIndexMapSize_mC52FA8F1CAD2C5389BD3388C90D6F8C63D25B839 (void);
// 0x0000076C System.Void UnityEngine.Rendering.CullingResults::FillLightIndexMap(System.IntPtr,System.IntPtr,System.Int32)
extern void CullingResults_FillLightIndexMap_m225AF3BCBA56D56FE998A18816D116F8E3DFF3C1 (void);
// 0x0000076D System.Void UnityEngine.Rendering.CullingResults::SetLightIndexMap(System.IntPtr,System.IntPtr,System.Int32)
extern void CullingResults_SetLightIndexMap_m2A22BD3FDE332141F3F1F9DCF41B92983739699C (void);
// 0x0000076E System.Boolean UnityEngine.Rendering.CullingResults::GetShadowCasterBounds(System.IntPtr,System.Int32,UnityEngine.Bounds&)
extern void CullingResults_GetShadowCasterBounds_m74D9F506D439462ACE12B68EE448E7B7F6529F79 (void);
// 0x0000076F System.Boolean UnityEngine.Rendering.CullingResults::ComputeSpotShadowMatricesAndCullingPrimitives(System.IntPtr,System.Int32,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Rendering.ShadowSplitData&)
extern void CullingResults_ComputeSpotShadowMatricesAndCullingPrimitives_m69822200F58EB7952BC26EE5FC30F2B4EDB09FAF (void);
// 0x00000770 System.Boolean UnityEngine.Rendering.CullingResults::ComputeDirectionalShadowMatricesAndCullingPrimitives(System.IntPtr,System.Int32,System.Int32,System.Int32,UnityEngine.Vector3,System.Int32,System.Single,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Rendering.ShadowSplitData&)
extern void CullingResults_ComputeDirectionalShadowMatricesAndCullingPrimitives_mC2C3CE3FB7E8B2CF7DCB60361D2ECF0BF8B2F709 (void);
// 0x00000771 Unity.Collections.NativeArray`1<UnityEngine.Rendering.VisibleLight> UnityEngine.Rendering.CullingResults::get_visibleLights()
extern void CullingResults_get_visibleLights_mF7FE02023976E76F78058AB97D61BA7AC1491E2C_AdjustorThunk (void);
// 0x00000772 Unity.Collections.NativeArray`1<T> UnityEngine.Rendering.CullingResults::GetNativeArray(System.Void*,System.Int32)
// 0x00000773 System.Int32 UnityEngine.Rendering.CullingResults::get_lightAndReflectionProbeIndexCount()
extern void CullingResults_get_lightAndReflectionProbeIndexCount_m9B77AC9C4F955AA82C3C3FB50D0C849FFABAEB63_AdjustorThunk (void);
// 0x00000774 System.Void UnityEngine.Rendering.CullingResults::FillLightAndReflectionProbeIndices(UnityEngine.ComputeBuffer)
extern void CullingResults_FillLightAndReflectionProbeIndices_mCC188839E66568E445A2271C91D533770681910C_AdjustorThunk (void);
// 0x00000775 Unity.Collections.NativeArray`1<System.Int32> UnityEngine.Rendering.CullingResults::GetLightIndexMap(Unity.Collections.Allocator)
extern void CullingResults_GetLightIndexMap_m3685972D6DB3D1D473A6DCA50676A6BF60C0BC6F_AdjustorThunk (void);
// 0x00000776 System.Void UnityEngine.Rendering.CullingResults::SetLightIndexMap(Unity.Collections.NativeArray`1<System.Int32>)
extern void CullingResults_SetLightIndexMap_mA274F23D6A03E0C537912F8803245C5BC3A8E804_AdjustorThunk (void);
// 0x00000777 System.Boolean UnityEngine.Rendering.CullingResults::GetShadowCasterBounds(System.Int32,UnityEngine.Bounds&)
extern void CullingResults_GetShadowCasterBounds_m4550764F8697432A7C523FC3B0BCEACD0B44DF60_AdjustorThunk (void);
// 0x00000778 System.Boolean UnityEngine.Rendering.CullingResults::ComputeSpotShadowMatricesAndCullingPrimitives(System.Int32,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Rendering.ShadowSplitData&)
extern void CullingResults_ComputeSpotShadowMatricesAndCullingPrimitives_m34C7A7431179181F5CD5CE677414E51B14B7F5CA_AdjustorThunk (void);
// 0x00000779 System.Boolean UnityEngine.Rendering.CullingResults::ComputeDirectionalShadowMatricesAndCullingPrimitives(System.Int32,System.Int32,System.Int32,UnityEngine.Vector3,System.Int32,System.Single,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Rendering.ShadowSplitData&)
extern void CullingResults_ComputeDirectionalShadowMatricesAndCullingPrimitives_m75000CD6EEE423308C50720E2609A594BD7D089D_AdjustorThunk (void);
// 0x0000077A System.Boolean UnityEngine.Rendering.CullingResults::Equals(UnityEngine.Rendering.CullingResults)
extern void CullingResults_Equals_mA31A3924C0B0E10C6FE07CEBF8DF48D52B040460_AdjustorThunk (void);
// 0x0000077B System.Boolean UnityEngine.Rendering.CullingResults::Equals(System.Object)
extern void CullingResults_Equals_m37650670C974A08FAED2DF2E028FFE173E3FC19C_AdjustorThunk (void);
// 0x0000077C System.Int32 UnityEngine.Rendering.CullingResults::GetHashCode()
extern void CullingResults_GetHashCode_m092C0888338AF8B1D3B25A23477B00FD71A685B3_AdjustorThunk (void);
// 0x0000077D System.Boolean UnityEngine.Rendering.CullingResults::ComputeDirectionalShadowMatricesAndCullingPrimitives_Injected(System.IntPtr,System.Int32,System.Int32,System.Int32,UnityEngine.Vector3&,System.Int32,System.Single,UnityEngine.Matrix4x4&,UnityEngine.Matrix4x4&,UnityEngine.Rendering.ShadowSplitData&)
extern void CullingResults_ComputeDirectionalShadowMatricesAndCullingPrimitives_Injected_m722BE0A4A0FE97DC4EF58CD86946E1977163A812 (void);
// 0x0000077E UnityEngine.Rendering.DepthState UnityEngine.Rendering.DepthState::get_defaultValue()
extern void DepthState_get_defaultValue_m7ABBFF624BB587EA1BA5244A06C0E433AF53F7A4 (void);
// 0x0000077F System.Void UnityEngine.Rendering.DepthState::.ctor(System.Boolean,UnityEngine.Rendering.CompareFunction)
extern void DepthState__ctor_m296B75647D432FB7A06CAB944CECBE8A54D1E4A0_AdjustorThunk (void);
// 0x00000780 System.Boolean UnityEngine.Rendering.DepthState::Equals(UnityEngine.Rendering.DepthState)
extern void DepthState_Equals_mBAB748FD4F8C461C9AFB3D622AD46D366232E873_AdjustorThunk (void);
// 0x00000781 System.Boolean UnityEngine.Rendering.DepthState::Equals(System.Object)
extern void DepthState_Equals_mAB22C1750F2B575266075D84C253CF9F9C98F4CF_AdjustorThunk (void);
// 0x00000782 System.Int32 UnityEngine.Rendering.DepthState::GetHashCode()
extern void DepthState_GetHashCode_m8FB208CD53B72DD0FB3742059CEE9F298B7B3F9E_AdjustorThunk (void);
// 0x00000783 System.Void UnityEngine.Rendering.DrawingSettings::.ctor(UnityEngine.Rendering.ShaderTagId,UnityEngine.Rendering.SortingSettings)
extern void DrawingSettings__ctor_m2F119B3CF65B1FFA436A7B4A991C9A689C4C8FBB_AdjustorThunk (void);
// 0x00000784 UnityEngine.Rendering.SortingSettings UnityEngine.Rendering.DrawingSettings::get_sortingSettings()
extern void DrawingSettings_get_sortingSettings_mA64046907F290D8F3D317ED8F4BB1D8A9E4D8875_AdjustorThunk (void);
// 0x00000785 System.Void UnityEngine.Rendering.DrawingSettings::set_sortingSettings(UnityEngine.Rendering.SortingSettings)
extern void DrawingSettings_set_sortingSettings_mFD4C60DFFA5C123A2DEC30C7DC960D92FC019A2E_AdjustorThunk (void);
// 0x00000786 System.Void UnityEngine.Rendering.DrawingSettings::set_perObjectData(UnityEngine.Rendering.PerObjectData)
extern void DrawingSettings_set_perObjectData_m6A4F6E34388D3FFE3494206B463B595948FFB321_AdjustorThunk (void);
// 0x00000787 System.Void UnityEngine.Rendering.DrawingSettings::set_enableDynamicBatching(System.Boolean)
extern void DrawingSettings_set_enableDynamicBatching_mAA13C7A89709FDB2CA882E078238A0F73AAA4A44_AdjustorThunk (void);
// 0x00000788 System.Void UnityEngine.Rendering.DrawingSettings::set_enableInstancing(System.Boolean)
extern void DrawingSettings_set_enableInstancing_m8994A09CDD7A03F7612A7B5CE527888214559BFC_AdjustorThunk (void);
// 0x00000789 System.Void UnityEngine.Rendering.DrawingSettings::set_overrideMaterial(UnityEngine.Material)
extern void DrawingSettings_set_overrideMaterial_mD4B5D818602EA17036A0C98F28530770A8C9627A_AdjustorThunk (void);
// 0x0000078A System.Void UnityEngine.Rendering.DrawingSettings::set_overrideMaterialPassIndex(System.Int32)
extern void DrawingSettings_set_overrideMaterialPassIndex_mD20615AE6699346E72D20695A9E54C5447C7081A_AdjustorThunk (void);
// 0x0000078B System.Void UnityEngine.Rendering.DrawingSettings::set_mainLightIndex(System.Int32)
extern void DrawingSettings_set_mainLightIndex_m59B22E23577931C5348546E297C2FDB5B3B6FD72_AdjustorThunk (void);
// 0x0000078C UnityEngine.Rendering.ShaderTagId UnityEngine.Rendering.DrawingSettings::GetShaderPassName(System.Int32)
extern void DrawingSettings_GetShaderPassName_mC19E60468AD2B769FFC9F299E13E46458CF23037_AdjustorThunk (void);
// 0x0000078D System.Void UnityEngine.Rendering.DrawingSettings::SetShaderPassName(System.Int32,UnityEngine.Rendering.ShaderTagId)
extern void DrawingSettings_SetShaderPassName_mC570D206B1D6158491BB5AE5B9669AF54764F9AD_AdjustorThunk (void);
// 0x0000078E System.Boolean UnityEngine.Rendering.DrawingSettings::Equals(UnityEngine.Rendering.DrawingSettings)
extern void DrawingSettings_Equals_mE7BD5DAFE2A9BCFA04ED43D264A667D4859B071C_AdjustorThunk (void);
// 0x0000078F System.Boolean UnityEngine.Rendering.DrawingSettings::Equals(System.Object)
extern void DrawingSettings_Equals_m20C6C79F7A33E55521B546A634CB59967B23B157_AdjustorThunk (void);
// 0x00000790 System.Int32 UnityEngine.Rendering.DrawingSettings::GetHashCode()
extern void DrawingSettings_GetHashCode_m10BFA80936AFD9587C09E7BE2F7701389781765D_AdjustorThunk (void);
// 0x00000791 System.Void UnityEngine.Rendering.DrawingSettings::.cctor()
extern void DrawingSettings__cctor_mF0435125E65C97D927E644D6786A7829E665EC1D (void);
// 0x00000792 System.Void UnityEngine.Rendering.FilteringSettings::.ctor(System.Nullable`1<UnityEngine.Rendering.RenderQueueRange>,System.Int32,System.UInt32,System.Int32)
extern void FilteringSettings__ctor_m17296E7A507C13F758B3CCCD00C4B364364540FE_AdjustorThunk (void);
// 0x00000793 System.Void UnityEngine.Rendering.FilteringSettings::set_renderQueueRange(UnityEngine.Rendering.RenderQueueRange)
extern void FilteringSettings_set_renderQueueRange_mEBA3759ADFB8D437DBDF285AE7CAC6116358D396_AdjustorThunk (void);
// 0x00000794 System.Void UnityEngine.Rendering.FilteringSettings::set_layerMask(System.Int32)
extern void FilteringSettings_set_layerMask_m6DE0420680D7D053384BE02989AC1DC1C541AC62_AdjustorThunk (void);
// 0x00000795 System.Void UnityEngine.Rendering.FilteringSettings::set_renderingLayerMask(System.UInt32)
extern void FilteringSettings_set_renderingLayerMask_m71841C84FBD32A0B097B649A6EA035C0A706A2F9_AdjustorThunk (void);
// 0x00000796 System.Void UnityEngine.Rendering.FilteringSettings::set_excludeMotionVectorObjects(System.Boolean)
extern void FilteringSettings_set_excludeMotionVectorObjects_mC15F14289E6CA27DCF2D2D4C4A6729A426E4C1AF_AdjustorThunk (void);
// 0x00000797 System.Void UnityEngine.Rendering.FilteringSettings::set_sortingLayerRange(UnityEngine.Rendering.SortingLayerRange)
extern void FilteringSettings_set_sortingLayerRange_m71CBCB0A643F3A00347C111F1C7DFCB49873C32A_AdjustorThunk (void);
// 0x00000798 System.Boolean UnityEngine.Rendering.FilteringSettings::Equals(UnityEngine.Rendering.FilteringSettings)
extern void FilteringSettings_Equals_mAB7A18838983321A60F7D010BE81DEA3811C2D03_AdjustorThunk (void);
// 0x00000799 System.Boolean UnityEngine.Rendering.FilteringSettings::Equals(System.Object)
extern void FilteringSettings_Equals_mB9F939984F1C93ACA9BA6BFAAB7C00376278FFD4_AdjustorThunk (void);
// 0x0000079A System.Int32 UnityEngine.Rendering.FilteringSettings::GetHashCode()
extern void FilteringSettings_GetHashCode_m1FB9EEA742BE8D7429785DD1D5B20E6071C6B789_AdjustorThunk (void);
// 0x0000079B System.Boolean UnityEngine.Rendering.LODParameters::Equals(UnityEngine.Rendering.LODParameters)
extern void LODParameters_Equals_mA7C4CFD75190B341999074C56E1BAD9E5136CF61_AdjustorThunk (void);
// 0x0000079C System.Boolean UnityEngine.Rendering.LODParameters::Equals(System.Object)
extern void LODParameters_Equals_m03754D13F85184E596AFBBCF6DA1EDB06CA58F6B_AdjustorThunk (void);
// 0x0000079D System.Int32 UnityEngine.Rendering.LODParameters::GetHashCode()
extern void LODParameters_GetHashCode_m532D8960CCF3340F7CDF6B757D33BAE13B152716_AdjustorThunk (void);
// 0x0000079E System.Void UnityEngine.Rendering.RasterState::.ctor(UnityEngine.Rendering.CullMode,System.Int32,System.Single,System.Boolean)
extern void RasterState__ctor_m406D67E2352F073428C9B11A06B7D5737913B316_AdjustorThunk (void);
// 0x0000079F System.Boolean UnityEngine.Rendering.RasterState::Equals(UnityEngine.Rendering.RasterState)
extern void RasterState_Equals_m29A194E6B6731C4651E5404F5237FA90777E02B7_AdjustorThunk (void);
// 0x000007A0 System.Boolean UnityEngine.Rendering.RasterState::Equals(System.Object)
extern void RasterState_Equals_mF19AC1C01B6E65D8CB13832FA625ACC2C1FE9C17_AdjustorThunk (void);
// 0x000007A1 System.Int32 UnityEngine.Rendering.RasterState::GetHashCode()
extern void RasterState_GetHashCode_m68F131D584F611BD2573BE33616A89388ADD3D18_AdjustorThunk (void);
// 0x000007A2 System.Void UnityEngine.Rendering.RasterState::.cctor()
extern void RasterState__cctor_mD45EB6E6F1529D4067EBD7C58425DB6DD6CF74AB (void);
// 0x000007A3 System.Void UnityEngine.Rendering.RenderPipeline::Render(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera[])
// 0x000007A4 System.Void UnityEngine.Rendering.RenderPipeline::BeginFrameRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera[])
extern void RenderPipeline_BeginFrameRendering_mA1E6462B6473351723C6AF121834824C1E5DAFFE (void);
// 0x000007A5 System.Void UnityEngine.Rendering.RenderPipeline::BeginCameraRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void RenderPipeline_BeginCameraRendering_mBDA378BECAF708F3006B3AB94352F54ABD698F86 (void);
// 0x000007A6 System.Void UnityEngine.Rendering.RenderPipeline::EndFrameRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera[])
extern void RenderPipeline_EndFrameRendering_m4EAF314449AA5B74B43B135E3F45230C31849902 (void);
// 0x000007A7 System.Void UnityEngine.Rendering.RenderPipeline::EndCameraRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void RenderPipeline_EndCameraRendering_m8BC96F3C24F010AD2665EBCED0BE21B62531DB66 (void);
// 0x000007A8 System.Void UnityEngine.Rendering.RenderPipeline::InternalRender(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera[])
extern void RenderPipeline_InternalRender_m3601304F718BEEDCC63FAC61AF865392A1B97159 (void);
// 0x000007A9 System.Boolean UnityEngine.Rendering.RenderPipeline::get_disposed()
extern void RenderPipeline_get_disposed_mA11FE959A1C7309A86F26893DA04D00DD5D61149 (void);
// 0x000007AA System.Void UnityEngine.Rendering.RenderPipeline::set_disposed(System.Boolean)
extern void RenderPipeline_set_disposed_m6319C7F5991E861B961370FF374CF87E9F0DA691 (void);
// 0x000007AB System.Void UnityEngine.Rendering.RenderPipeline::Dispose()
extern void RenderPipeline_Dispose_mFFDBE5963DA828BA99417035F8F6228535E0EAAB (void);
// 0x000007AC System.Void UnityEngine.Rendering.RenderPipeline::Dispose(System.Boolean)
extern void RenderPipeline_Dispose_m256C636C8C66B12ED0E67F4C6F6470A79CBAA49B (void);
// 0x000007AD System.Void UnityEngine.Rendering.RenderPipeline::.ctor()
extern void RenderPipeline__ctor_m951F82954ED852CE97F36C8D0B906EC20509F5A5 (void);
// 0x000007AE UnityEngine.Rendering.RenderPipeline UnityEngine.Rendering.RenderPipelineAsset::InternalCreatePipeline()
extern void RenderPipelineAsset_InternalCreatePipeline_m7FC3209A9640269E6E01FCBCC879E3FC36B23264 (void);
// 0x000007AF System.String[] UnityEngine.Rendering.RenderPipelineAsset::get_renderingLayerMaskNames()
extern void RenderPipelineAsset_get_renderingLayerMaskNames_mD9D46ECB8CB3AA207307DF715AB738EBE9774D4C (void);
// 0x000007B0 UnityEngine.Material UnityEngine.Rendering.RenderPipelineAsset::get_defaultMaterial()
extern void RenderPipelineAsset_get_defaultMaterial_mB049EB56C99330E8392028148336A9329A1F6BEF (void);
// 0x000007B1 UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_autodeskInteractiveShader()
extern void RenderPipelineAsset_get_autodeskInteractiveShader_mACEA652B47468186F0B74AAE63A5625A70E500A4 (void);
// 0x000007B2 UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_autodeskInteractiveTransparentShader()
extern void RenderPipelineAsset_get_autodeskInteractiveTransparentShader_mBC027215A56E8FD6C3B3CC5008B69540BBEBD1FD (void);
// 0x000007B3 UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_autodeskInteractiveMaskedShader()
extern void RenderPipelineAsset_get_autodeskInteractiveMaskedShader_m5342E858293BCAB426D1A6E84242CD7D26EE5BC7 (void);
// 0x000007B4 UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_terrainDetailLitShader()
extern void RenderPipelineAsset_get_terrainDetailLitShader_mE16DBCD806DD77447A89F3C1109E35CD24FEA7CF (void);
// 0x000007B5 UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_terrainDetailGrassShader()
extern void RenderPipelineAsset_get_terrainDetailGrassShader_mAF8F368B3B67F7E6C71A70A93696122E73ED6C47 (void);
// 0x000007B6 UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_terrainDetailGrassBillboardShader()
extern void RenderPipelineAsset_get_terrainDetailGrassBillboardShader_m2DAE45A6FF177CB2996EC95EDF1AC05F59A7470B (void);
// 0x000007B7 UnityEngine.Material UnityEngine.Rendering.RenderPipelineAsset::get_defaultParticleMaterial()
extern void RenderPipelineAsset_get_defaultParticleMaterial_m131DA69D30E5A400B227B98B8877C94A118E9F49 (void);
// 0x000007B8 UnityEngine.Material UnityEngine.Rendering.RenderPipelineAsset::get_defaultLineMaterial()
extern void RenderPipelineAsset_get_defaultLineMaterial_m9FF591F569273D367C4020C1AC3A30AA161CE6BC (void);
// 0x000007B9 UnityEngine.Material UnityEngine.Rendering.RenderPipelineAsset::get_defaultTerrainMaterial()
extern void RenderPipelineAsset_get_defaultTerrainMaterial_mA6D10A07A29A577D83AF711CDE2E70B28D51A91A (void);
// 0x000007BA UnityEngine.Material UnityEngine.Rendering.RenderPipelineAsset::get_defaultUIMaterial()
extern void RenderPipelineAsset_get_defaultUIMaterial_m39BD27EC73AE39354158451661A0112FC4E4F7F6 (void);
// 0x000007BB UnityEngine.Material UnityEngine.Rendering.RenderPipelineAsset::get_defaultUIOverdrawMaterial()
extern void RenderPipelineAsset_get_defaultUIOverdrawMaterial_m0FE02710211BE1CF77728A1086BDC5EDCE106D35 (void);
// 0x000007BC UnityEngine.Material UnityEngine.Rendering.RenderPipelineAsset::get_defaultUIETC1SupportedMaterial()
extern void RenderPipelineAsset_get_defaultUIETC1SupportedMaterial_mB8E2388C7F45E6D1B4EC728EC2335B527A741470 (void);
// 0x000007BD UnityEngine.Material UnityEngine.Rendering.RenderPipelineAsset::get_default2DMaterial()
extern void RenderPipelineAsset_get_default2DMaterial_mF68C0199E16004C348D11AD0BA4C9482CCFC9762 (void);
// 0x000007BE UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_defaultShader()
extern void RenderPipelineAsset_get_defaultShader_m8F4DD3FBD2EA1A55DE3EB45EF41C3FD502141A40 (void);
// 0x000007BF UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_defaultSpeedTree7Shader()
extern void RenderPipelineAsset_get_defaultSpeedTree7Shader_mE81955ABC171A01E496BD2E6166CC0BCDCC12E39 (void);
// 0x000007C0 UnityEngine.Shader UnityEngine.Rendering.RenderPipelineAsset::get_defaultSpeedTree8Shader()
extern void RenderPipelineAsset_get_defaultSpeedTree8Shader_mF5025B6116D23E28B7A872C3694ADED33A6DE9B0 (void);
// 0x000007C1 UnityEngine.Rendering.RenderPipeline UnityEngine.Rendering.RenderPipelineAsset::CreatePipeline()
// 0x000007C2 System.Void UnityEngine.Rendering.RenderPipelineAsset::OnValidate()
extern void RenderPipelineAsset_OnValidate_m232856172D71149CC85645BE94902D01628A1A8E (void);
// 0x000007C3 System.Void UnityEngine.Rendering.RenderPipelineAsset::OnDisable()
extern void RenderPipelineAsset_OnDisable_m6DB5D6EE17E7CAEC1254135C61F4EB3E249FDD52 (void);
// 0x000007C4 System.Void UnityEngine.Rendering.RenderPipelineAsset::.ctor()
extern void RenderPipelineAsset__ctor_mCB26E546B9DC1F2518E0F0F4A7E6CFF519D852F2 (void);
// 0x000007C5 UnityEngine.Rendering.RenderPipeline UnityEngine.Rendering.RenderPipelineManager::get_currentPipeline()
extern void RenderPipelineManager_get_currentPipeline_m07358604B9829E6C1EEDE94064729109D9259852 (void);
// 0x000007C6 System.Void UnityEngine.Rendering.RenderPipelineManager::set_currentPipeline(UnityEngine.Rendering.RenderPipeline)
extern void RenderPipelineManager_set_currentPipeline_mDCF377780787BD6CAB3BC9F4A04B01B478293B88 (void);
// 0x000007C7 System.Void UnityEngine.Rendering.RenderPipelineManager::add_beginCameraRendering(System.Action`2<UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera>)
extern void RenderPipelineManager_add_beginCameraRendering_m49A42A94633EDC2DDE0B2326AFB16648F3EA4655 (void);
// 0x000007C8 System.Void UnityEngine.Rendering.RenderPipelineManager::remove_beginCameraRendering(System.Action`2<UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera>)
extern void RenderPipelineManager_remove_beginCameraRendering_m1E9FF5693BD4A7CFF90A2F76F0E36F54857DC757 (void);
// 0x000007C9 System.Void UnityEngine.Rendering.RenderPipelineManager::add_endCameraRendering(System.Action`2<UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera>)
extern void RenderPipelineManager_add_endCameraRendering_mAAB014A733DF153D0B535C34827A626B838A24D5 (void);
// 0x000007CA System.Void UnityEngine.Rendering.RenderPipelineManager::remove_endCameraRendering(System.Action`2<UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera>)
extern void RenderPipelineManager_remove_endCameraRendering_m71A598F738E2D4DED262A2DF7DAAD1EE85E92860 (void);
// 0x000007CB System.Void UnityEngine.Rendering.RenderPipelineManager::BeginFrameRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera[])
extern void RenderPipelineManager_BeginFrameRendering_m73DFC13D37084610A3320A3087C45FF96100AC90 (void);
// 0x000007CC System.Void UnityEngine.Rendering.RenderPipelineManager::BeginCameraRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void RenderPipelineManager_BeginCameraRendering_m2074DD98F47E3C5EF42CEB0B6FC4598AE207231A (void);
// 0x000007CD System.Void UnityEngine.Rendering.RenderPipelineManager::EndFrameRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera[])
extern void RenderPipelineManager_EndFrameRendering_mB39C68E3EBB09CAC4EBD5235B1ED7B0B0EC19DA3 (void);
// 0x000007CE System.Void UnityEngine.Rendering.RenderPipelineManager::EndCameraRendering(UnityEngine.Rendering.ScriptableRenderContext,UnityEngine.Camera)
extern void RenderPipelineManager_EndCameraRendering_m4E62F4F4D17A5E3FAF35BEC5830AC6D433AEA4C5 (void);
// 0x000007CF System.Void UnityEngine.Rendering.RenderPipelineManager::CleanupRenderPipeline()
extern void RenderPipelineManager_CleanupRenderPipeline_m82AC5DAD81AE3B10147198B7C7CFAAD8AE528010 (void);
// 0x000007D0 System.Void UnityEngine.Rendering.RenderPipelineManager::GetCameras(UnityEngine.Rendering.ScriptableRenderContext)
extern void RenderPipelineManager_GetCameras_m53602210E7576F801085A741B2068BEA0995433F (void);
// 0x000007D1 System.Void UnityEngine.Rendering.RenderPipelineManager::DoRenderLoop_Internal(UnityEngine.Rendering.RenderPipelineAsset,System.IntPtr)
extern void RenderPipelineManager_DoRenderLoop_Internal_mF16D72874EE44C297C2D0623933207B448BFCD32 (void);
// 0x000007D2 System.Void UnityEngine.Rendering.RenderPipelineManager::PrepareRenderPipeline(UnityEngine.Rendering.RenderPipelineAsset)
extern void RenderPipelineManager_PrepareRenderPipeline_m4A4D5CD3B9803F6D92DBD7D245A3D925F9028CC7 (void);
// 0x000007D3 System.Void UnityEngine.Rendering.RenderPipelineManager::.cctor()
extern void RenderPipelineManager__cctor_m7B3FA781696A3B82639DA7705E02A4E0BD418421 (void);
// 0x000007D4 UnityEngine.Rendering.RenderQueueRange UnityEngine.Rendering.RenderQueueRange::get_all()
extern void RenderQueueRange_get_all_mA3F6A2BCFDD1C70DCF6C5FB39A66A21764341447 (void);
// 0x000007D5 UnityEngine.Rendering.RenderQueueRange UnityEngine.Rendering.RenderQueueRange::get_opaque()
extern void RenderQueueRange_get_opaque_mE172B321960F4D55A56B287E39CCB50927107B7C (void);
// 0x000007D6 UnityEngine.Rendering.RenderQueueRange UnityEngine.Rendering.RenderQueueRange::get_transparent()
extern void RenderQueueRange_get_transparent_m1CF8E0923DA509879885DB20FEA78CCE027255B9 (void);
// 0x000007D7 System.Boolean UnityEngine.Rendering.RenderQueueRange::Equals(UnityEngine.Rendering.RenderQueueRange)
extern void RenderQueueRange_Equals_m4C359E94CCFE49E8989B8B8844E26848BF9FC265_AdjustorThunk (void);
// 0x000007D8 System.Boolean UnityEngine.Rendering.RenderQueueRange::Equals(System.Object)
extern void RenderQueueRange_Equals_mBFB376C90D44224911F400ABBAC181A0AB5A1592_AdjustorThunk (void);
// 0x000007D9 System.Int32 UnityEngine.Rendering.RenderQueueRange::GetHashCode()
extern void RenderQueueRange_GetHashCode_m1DFED684DB51CE12FE84A5AB54050C8630E82274_AdjustorThunk (void);
// 0x000007DA System.Void UnityEngine.Rendering.RenderQueueRange::.cctor()
extern void RenderQueueRange__cctor_mEA846D826B022C1E26E9562DD45680625F6112A3 (void);
// 0x000007DB System.Void UnityEngine.Rendering.RenderStateBlock::.ctor(UnityEngine.Rendering.RenderStateMask)
extern void RenderStateBlock__ctor_m48003DB81752663592D20E4697643A9320D82EFB_AdjustorThunk (void);
// 0x000007DC System.Void UnityEngine.Rendering.RenderStateBlock::set_depthState(UnityEngine.Rendering.DepthState)
extern void RenderStateBlock_set_depthState_m85E6842AFBAEB4179ABFA8F3C81533EC51829758_AdjustorThunk (void);
// 0x000007DD System.Void UnityEngine.Rendering.RenderStateBlock::set_stencilState(UnityEngine.Rendering.StencilState)
extern void RenderStateBlock_set_stencilState_m814032B71A44F9A14DF1677E6BDA0F02842491E3_AdjustorThunk (void);
// 0x000007DE System.Void UnityEngine.Rendering.RenderStateBlock::set_stencilReference(System.Int32)
extern void RenderStateBlock_set_stencilReference_mAE73008443F7445B0277B8E6376DC2D00382B590_AdjustorThunk (void);
// 0x000007DF UnityEngine.Rendering.RenderStateMask UnityEngine.Rendering.RenderStateBlock::get_mask()
extern void RenderStateBlock_get_mask_mE690A0C5AA9506C9DDFFCF11B2BCC20FADD495E9_AdjustorThunk (void);
// 0x000007E0 System.Void UnityEngine.Rendering.RenderStateBlock::set_mask(UnityEngine.Rendering.RenderStateMask)
extern void RenderStateBlock_set_mask_m1829425552BFD051A106DA12F367104EFE2CB0FE_AdjustorThunk (void);
// 0x000007E1 System.Boolean UnityEngine.Rendering.RenderStateBlock::Equals(UnityEngine.Rendering.RenderStateBlock)
extern void RenderStateBlock_Equals_m16021C56F492DF3F064C9316A7C6A352F180B798_AdjustorThunk (void);
// 0x000007E2 System.Boolean UnityEngine.Rendering.RenderStateBlock::Equals(System.Object)
extern void RenderStateBlock_Equals_m0E8A2D2F56D621408EF5962FAA5BE280DE8C0BD4_AdjustorThunk (void);
// 0x000007E3 System.Int32 UnityEngine.Rendering.RenderStateBlock::GetHashCode()
extern void RenderStateBlock_GetHashCode_m1F7F40E3B1CF65CC83FC569C413F06BCEFF5C71C_AdjustorThunk (void);
// 0x000007E4 UnityEngine.Rendering.RenderTargetBlendState UnityEngine.Rendering.RenderTargetBlendState::get_defaultValue()
extern void RenderTargetBlendState_get_defaultValue_m3444F0C0CD14104F3A75355CAE4C0EA2D20FE505 (void);
// 0x000007E5 System.Void UnityEngine.Rendering.RenderTargetBlendState::.ctor(UnityEngine.Rendering.ColorWriteMask,UnityEngine.Rendering.BlendMode,UnityEngine.Rendering.BlendMode,UnityEngine.Rendering.BlendMode,UnityEngine.Rendering.BlendMode,UnityEngine.Rendering.BlendOp,UnityEngine.Rendering.BlendOp)
extern void RenderTargetBlendState__ctor_m9867E3C16C73C883A83BA0D7A8082942E6B2AD85_AdjustorThunk (void);
// 0x000007E6 System.Boolean UnityEngine.Rendering.RenderTargetBlendState::Equals(UnityEngine.Rendering.RenderTargetBlendState)
extern void RenderTargetBlendState_Equals_m765987071D3AD0B98F2B5ADB8981128052E57B68_AdjustorThunk (void);
// 0x000007E7 System.Boolean UnityEngine.Rendering.RenderTargetBlendState::Equals(System.Object)
extern void RenderTargetBlendState_Equals_mA207F23FCA550F6C5BFC77D513ECE1C5CCD2F4DB_AdjustorThunk (void);
// 0x000007E8 System.Int32 UnityEngine.Rendering.RenderTargetBlendState::GetHashCode()
extern void RenderTargetBlendState_GetHashCode_m056162E23B1AD394477E05F4B4B48747159166AF_AdjustorThunk (void);
// 0x000007E9 System.Void UnityEngine.Rendering.ScriptableRenderContext::Internal_Cull(UnityEngine.Rendering.ScriptableCullingParameters&,UnityEngine.Rendering.ScriptableRenderContext,System.IntPtr)
extern void ScriptableRenderContext_Internal_Cull_mFD76253744E69C86617B1CB320C206A0347269A2 (void);
// 0x000007EA System.Void UnityEngine.Rendering.ScriptableRenderContext::InitializeSortSettings(UnityEngine.Camera,UnityEngine.Rendering.SortingSettings&)
extern void ScriptableRenderContext_InitializeSortSettings_m28764ABF60F041BFB2634D0F5D105F3ABDA6DB5F (void);
// 0x000007EB System.Void UnityEngine.Rendering.ScriptableRenderContext::Submit_Internal()
extern void ScriptableRenderContext_Submit_Internal_mAAE0CC08056C1DDE85A89A19BBE8E7EED87C515F_AdjustorThunk (void);
// 0x000007EC System.Int32 UnityEngine.Rendering.ScriptableRenderContext::GetNumberOfCameras_Internal()
extern void ScriptableRenderContext_GetNumberOfCameras_Internal_m58DE22F11E08F3B9C7E4B1D9788711101EBD2395_AdjustorThunk (void);
// 0x000007ED UnityEngine.Camera UnityEngine.Rendering.ScriptableRenderContext::GetCamera_Internal(System.Int32)
extern void ScriptableRenderContext_GetCamera_Internal_m1E56C9D9782F0E99A7ED3C64C15F3A06A8A0B917_AdjustorThunk (void);
// 0x000007EE System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawRenderers_Internal(System.IntPtr,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,System.IntPtr,System.IntPtr,System.Int32)
extern void ScriptableRenderContext_DrawRenderers_Internal_m42B37848BB342A4E5842AC899121624B49112F03_AdjustorThunk (void);
// 0x000007EF System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawShadows_Internal(System.IntPtr)
extern void ScriptableRenderContext_DrawShadows_Internal_m26D9998BA2D211BF6413294423AFD43438E55D30_AdjustorThunk (void);
// 0x000007F0 System.Void UnityEngine.Rendering.ScriptableRenderContext::ExecuteCommandBuffer_Internal(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderContext_ExecuteCommandBuffer_Internal_m6BDE1A07FB715DC99F1126AF36DBDDE8C73019D4_AdjustorThunk (void);
// 0x000007F1 System.Void UnityEngine.Rendering.ScriptableRenderContext::SetupCameraProperties_Internal(UnityEngine.Camera,System.Boolean,System.Int32)
extern void ScriptableRenderContext_SetupCameraProperties_Internal_mED05BC7D41C7B3E1FBA2A7C4EF5269275848B5AF_AdjustorThunk (void);
// 0x000007F2 System.Void UnityEngine.Rendering.ScriptableRenderContext::StereoEndRender_Internal(UnityEngine.Camera,System.Int32,System.Boolean)
extern void ScriptableRenderContext_StereoEndRender_Internal_m3C8BD0BCE398DC4253B9D94F9BBACFAB5BEA49A7_AdjustorThunk (void);
// 0x000007F3 System.Void UnityEngine.Rendering.ScriptableRenderContext::StartMultiEye_Internal(UnityEngine.Camera,System.Int32)
extern void ScriptableRenderContext_StartMultiEye_Internal_m161C0DC08488F76505BAF21C66E84EF72EDEC53E_AdjustorThunk (void);
// 0x000007F4 System.Void UnityEngine.Rendering.ScriptableRenderContext::StopMultiEye_Internal(UnityEngine.Camera)
extern void ScriptableRenderContext_StopMultiEye_Internal_mA80FA0BF5222B49BF6F9E16A04CC30B9D0AD6442_AdjustorThunk (void);
// 0x000007F5 System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawSkybox_Internal(UnityEngine.Camera)
extern void ScriptableRenderContext_DrawSkybox_Internal_mF0A6A4B91FCB1185A275E55926D860F3C50B4520_AdjustorThunk (void);
// 0x000007F6 System.Void UnityEngine.Rendering.ScriptableRenderContext::InvokeOnRenderObjectCallback_Internal()
extern void ScriptableRenderContext_InvokeOnRenderObjectCallback_Internal_m1BD2722EF4155A2EAE724492A66BCF51C79560CE_AdjustorThunk (void);
// 0x000007F7 System.Void UnityEngine.Rendering.ScriptableRenderContext::.ctor(System.IntPtr)
extern void ScriptableRenderContext__ctor_m554E9C4BB7F69601E65F71557914C6958D3181EE_AdjustorThunk (void);
// 0x000007F8 System.Void UnityEngine.Rendering.ScriptableRenderContext::Submit()
extern void ScriptableRenderContext_Submit_m93F8AB4A95BAD8135BD19CA6ED07B1A14F2CC87C_AdjustorThunk (void);
// 0x000007F9 System.Int32 UnityEngine.Rendering.ScriptableRenderContext::GetNumberOfCameras()
extern void ScriptableRenderContext_GetNumberOfCameras_mF14CD21DA4E8A43DCE5811735E48748313F71CBA_AdjustorThunk (void);
// 0x000007FA UnityEngine.Camera UnityEngine.Rendering.ScriptableRenderContext::GetCamera(System.Int32)
extern void ScriptableRenderContext_GetCamera_mCC4F389E3EB259D9FF01E7F7801D39137BC0E41C_AdjustorThunk (void);
// 0x000007FB System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawRenderers(UnityEngine.Rendering.CullingResults,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&)
extern void ScriptableRenderContext_DrawRenderers_mBD9F5C26FEF615D84B4657B6FDE0854B629DD8B0_AdjustorThunk (void);
// 0x000007FC System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawRenderers(UnityEngine.Rendering.CullingResults,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,UnityEngine.Rendering.RenderStateBlock&)
extern void ScriptableRenderContext_DrawRenderers_m67847BB31C9F8792D016A3BE4B0F5BD4C10AFD39_AdjustorThunk (void);
// 0x000007FD System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawShadows(UnityEngine.Rendering.ShadowDrawingSettings&)
extern void ScriptableRenderContext_DrawShadows_m87B0FF3E8B7050791A2DBA3516C6BF0525DF9244_AdjustorThunk (void);
// 0x000007FE System.Void UnityEngine.Rendering.ScriptableRenderContext::ExecuteCommandBuffer(UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderContext_ExecuteCommandBuffer_m7564285E9D694FADA319BF5BB0A864B2EBF313AF_AdjustorThunk (void);
// 0x000007FF System.Void UnityEngine.Rendering.ScriptableRenderContext::SetupCameraProperties(UnityEngine.Camera,System.Boolean,System.Int32)
extern void ScriptableRenderContext_SetupCameraProperties_mA0648392A1F6B5A0F8B11C73E0A337DA0A6644CC_AdjustorThunk (void);
// 0x00000800 System.Void UnityEngine.Rendering.ScriptableRenderContext::StereoEndRender(UnityEngine.Camera,System.Int32,System.Boolean)
extern void ScriptableRenderContext_StereoEndRender_m3EDDC1DE013EB3B3AEF0EBC181E1FF4DBBCD40BA_AdjustorThunk (void);
// 0x00000801 System.Void UnityEngine.Rendering.ScriptableRenderContext::StartMultiEye(UnityEngine.Camera,System.Int32)
extern void ScriptableRenderContext_StartMultiEye_m763B41DFA957DEE5B4D226E2D0E6363E20EFA87D_AdjustorThunk (void);
// 0x00000802 System.Void UnityEngine.Rendering.ScriptableRenderContext::StopMultiEye(UnityEngine.Camera)
extern void ScriptableRenderContext_StopMultiEye_m6B68D7362BAD3C2EF68E814F983B8436079C33C6_AdjustorThunk (void);
// 0x00000803 System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawSkybox(UnityEngine.Camera)
extern void ScriptableRenderContext_DrawSkybox_m34BF2168F50F04A51CFDB5EEFA9F837880CD03BF_AdjustorThunk (void);
// 0x00000804 System.Void UnityEngine.Rendering.ScriptableRenderContext::InvokeOnRenderObjectCallback()
extern void ScriptableRenderContext_InvokeOnRenderObjectCallback_mED67F10A990A965345F95633FA51AE83D2FDD441_AdjustorThunk (void);
// 0x00000805 UnityEngine.Rendering.CullingResults UnityEngine.Rendering.ScriptableRenderContext::Cull(UnityEngine.Rendering.ScriptableCullingParameters&)
extern void ScriptableRenderContext_Cull_m193842B732EFDA3A6B462A06D4B656C0551F4889_AdjustorThunk (void);
// 0x00000806 System.Boolean UnityEngine.Rendering.ScriptableRenderContext::Equals(UnityEngine.Rendering.ScriptableRenderContext)
extern void ScriptableRenderContext_Equals_m0612225D9DC8BE5574C67738B9B185A05B306803_AdjustorThunk (void);
// 0x00000807 System.Boolean UnityEngine.Rendering.ScriptableRenderContext::Equals(System.Object)
extern void ScriptableRenderContext_Equals_m239EBA23E760DDF7CC7112D3299D9B4CEA449683_AdjustorThunk (void);
// 0x00000808 System.Int32 UnityEngine.Rendering.ScriptableRenderContext::GetHashCode()
extern void ScriptableRenderContext_GetHashCode_m2A894A66C98DF28B51758A3579EE04B87D2AC6D6_AdjustorThunk (void);
// 0x00000809 System.Void UnityEngine.Rendering.ScriptableRenderContext::Internal_Cull_Injected(UnityEngine.Rendering.ScriptableCullingParameters&,UnityEngine.Rendering.ScriptableRenderContext&,System.IntPtr)
extern void ScriptableRenderContext_Internal_Cull_Injected_mBF4FAD3354E079A2BE20FE65B3D510EE33398B60 (void);
// 0x0000080A System.Void UnityEngine.Rendering.ScriptableRenderContext::Submit_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&)
extern void ScriptableRenderContext_Submit_Internal_Injected_m0873AB61AF51418408CB683059B99385DCC8B2DE (void);
// 0x0000080B System.Int32 UnityEngine.Rendering.ScriptableRenderContext::GetNumberOfCameras_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&)
extern void ScriptableRenderContext_GetNumberOfCameras_Internal_Injected_m70F9C34BAA4E5548D1B5848EFFBA6ACDC1B9781B (void);
// 0x0000080C UnityEngine.Camera UnityEngine.Rendering.ScriptableRenderContext::GetCamera_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,System.Int32)
extern void ScriptableRenderContext_GetCamera_Internal_Injected_m43E535C1F7FC90BF7254A0D043E624D45B70E459 (void);
// 0x0000080D System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawRenderers_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,System.IntPtr,UnityEngine.Rendering.DrawingSettings&,UnityEngine.Rendering.FilteringSettings&,System.IntPtr,System.IntPtr,System.Int32)
extern void ScriptableRenderContext_DrawRenderers_Internal_Injected_mDB5C687C0C9F7930B25631107134AEF8A1F7571A (void);
// 0x0000080E System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawShadows_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,System.IntPtr)
extern void ScriptableRenderContext_DrawShadows_Internal_Injected_mBD7A5802D4D4D9B0E8C97571F94C94153683E630 (void);
// 0x0000080F System.Void UnityEngine.Rendering.ScriptableRenderContext::ExecuteCommandBuffer_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Rendering.CommandBuffer)
extern void ScriptableRenderContext_ExecuteCommandBuffer_Internal_Injected_m93612BE8FA6714852C3CFF474B2699F369DE7C22 (void);
// 0x00000810 System.Void UnityEngine.Rendering.ScriptableRenderContext::SetupCameraProperties_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Camera,System.Boolean,System.Int32)
extern void ScriptableRenderContext_SetupCameraProperties_Internal_Injected_m1A38D96372E32AFF7535AC1F8C18DE08676E8FEE (void);
// 0x00000811 System.Void UnityEngine.Rendering.ScriptableRenderContext::StereoEndRender_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Camera,System.Int32,System.Boolean)
extern void ScriptableRenderContext_StereoEndRender_Internal_Injected_m3223FBF747D4D32801BF5F9D351F6A97EC289E1D (void);
// 0x00000812 System.Void UnityEngine.Rendering.ScriptableRenderContext::StartMultiEye_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Camera,System.Int32)
extern void ScriptableRenderContext_StartMultiEye_Internal_Injected_m8BC7A82B98E30DEF798D9A0CAB31DA4357510C0D (void);
// 0x00000813 System.Void UnityEngine.Rendering.ScriptableRenderContext::StopMultiEye_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Camera)
extern void ScriptableRenderContext_StopMultiEye_Internal_Injected_mB59DC2073C99657D74DE96E4B9B26AE1126EB645 (void);
// 0x00000814 System.Void UnityEngine.Rendering.ScriptableRenderContext::DrawSkybox_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&,UnityEngine.Camera)
extern void ScriptableRenderContext_DrawSkybox_Internal_Injected_mE7C766A1E68506A171066B9AA74B7C9AEC7F7A5E (void);
// 0x00000815 System.Void UnityEngine.Rendering.ScriptableRenderContext::InvokeOnRenderObjectCallback_Internal_Injected(UnityEngine.Rendering.ScriptableRenderContext&)
extern void ScriptableRenderContext_InvokeOnRenderObjectCallback_Internal_Injected_m563B766BE42287E25E697BFC50616BF662932D0E (void);
// 0x00000816 System.Void UnityEngine.Rendering.ShaderTagId::.ctor(System.String)
extern void ShaderTagId__ctor_m12711C3099F1BBDED9B114567F6A6C382A6C1F5E_AdjustorThunk (void);
// 0x00000817 System.Int32 UnityEngine.Rendering.ShaderTagId::get_id()
extern void ShaderTagId_get_id_mB1AB67FC09D015D245DAB1F6C491F2D59558C5D5_AdjustorThunk (void);
// 0x00000818 System.Void UnityEngine.Rendering.ShaderTagId::set_id(System.Int32)
extern void ShaderTagId_set_id_m47A84B8D0203D1BAE247CF591D1E2B43A1FFEF1E_AdjustorThunk (void);
// 0x00000819 System.Boolean UnityEngine.Rendering.ShaderTagId::Equals(System.Object)
extern void ShaderTagId_Equals_m7C6B4B00D502970BEDA5032CC9F791795B8C44EE_AdjustorThunk (void);
// 0x0000081A System.Boolean UnityEngine.Rendering.ShaderTagId::Equals(UnityEngine.Rendering.ShaderTagId)
extern void ShaderTagId_Equals_mC8A45F721611717B4CB12DBD73E23200C67AA7AF_AdjustorThunk (void);
// 0x0000081B System.Int32 UnityEngine.Rendering.ShaderTagId::GetHashCode()
extern void ShaderTagId_GetHashCode_m51C1D9E4417AD43F0A5E9CCF7FF88C10BCDB2905_AdjustorThunk (void);
// 0x0000081C System.Boolean UnityEngine.Rendering.ShaderTagId::op_Equality(UnityEngine.Rendering.ShaderTagId,UnityEngine.Rendering.ShaderTagId)
extern void ShaderTagId_op_Equality_mBCF8FA710D713780FC23AC5D982A7F95C9179927 (void);
// 0x0000081D System.Boolean UnityEngine.Rendering.ShaderTagId::op_Inequality(UnityEngine.Rendering.ShaderTagId,UnityEngine.Rendering.ShaderTagId)
extern void ShaderTagId_op_Inequality_m402802CD41D679E07675D4178CF8A05084A2B31E (void);
// 0x0000081E System.Void UnityEngine.Rendering.ShaderTagId::.cctor()
extern void ShaderTagId__cctor_mC73D6F5DE8D099CE53149E383ADF6B64F3EA763D (void);
// 0x0000081F UnityEngine.Rendering.ShadowSplitData UnityEngine.Rendering.ShadowDrawingSettings::get_splitData()
extern void ShadowDrawingSettings_get_splitData_m181634A672466BB78C5D07AC459C7D03BED52B21_AdjustorThunk (void);
// 0x00000820 System.Void UnityEngine.Rendering.ShadowDrawingSettings::set_splitData(UnityEngine.Rendering.ShadowSplitData)
extern void ShadowDrawingSettings_set_splitData_mFD018747362F76EA0A2AFAEB0AEF16FFA385E9CD_AdjustorThunk (void);
// 0x00000821 System.Void UnityEngine.Rendering.ShadowDrawingSettings::.ctor(UnityEngine.Rendering.CullingResults,System.Int32)
extern void ShadowDrawingSettings__ctor_mB16160F768301351FCB350175F9D4CAA6933F06E_AdjustorThunk (void);
// 0x00000822 System.Boolean UnityEngine.Rendering.ShadowDrawingSettings::Equals(UnityEngine.Rendering.ShadowDrawingSettings)
extern void ShadowDrawingSettings_Equals_m835B1C914090FC8971F7C06091F6378B2802ED4C_AdjustorThunk (void);
// 0x00000823 System.Boolean UnityEngine.Rendering.ShadowDrawingSettings::Equals(System.Object)
extern void ShadowDrawingSettings_Equals_m3F42D86A4397FEAC349A8DF247474441FAE37BEA_AdjustorThunk (void);
// 0x00000824 System.Int32 UnityEngine.Rendering.ShadowDrawingSettings::GetHashCode()
extern void ShadowDrawingSettings_GetHashCode_m173F0560EBC60E94F2AF816DBD77673486883B2A_AdjustorThunk (void);
// 0x00000825 System.Int32 UnityEngine.Rendering.ShadowSplitData::get_cullingPlaneCount()
extern void ShadowSplitData_get_cullingPlaneCount_m50740AF255ABF29DAFF5C1AC466DC32DF2AF1ABF_AdjustorThunk (void);
// 0x00000826 UnityEngine.Vector4 UnityEngine.Rendering.ShadowSplitData::get_cullingSphere()
extern void ShadowSplitData_get_cullingSphere_mD8D0343483420281198C1ADDB980D9D12EEB2B12_AdjustorThunk (void);
// 0x00000827 System.Void UnityEngine.Rendering.ShadowSplitData::set_cullingSphere(UnityEngine.Vector4)
extern void ShadowSplitData_set_cullingSphere_mFF499B760D7ED1FA7FBCAF97FD0DA010AF24CC94_AdjustorThunk (void);
// 0x00000828 System.Void UnityEngine.Rendering.ShadowSplitData::set_shadowCascadeBlendCullingFactor(System.Single)
extern void ShadowSplitData_set_shadowCascadeBlendCullingFactor_m8505213D2AA1742B31E47194E138C4CD6C3C408F_AdjustorThunk (void);
// 0x00000829 UnityEngine.Plane UnityEngine.Rendering.ShadowSplitData::GetCullingPlane(System.Int32)
extern void ShadowSplitData_GetCullingPlane_mAAD500FB0AE82378EC6A749DB8259011075463CB_AdjustorThunk (void);
// 0x0000082A System.Boolean UnityEngine.Rendering.ShadowSplitData::Equals(UnityEngine.Rendering.ShadowSplitData)
extern void ShadowSplitData_Equals_mB8782F941169D85E024BB62257CADFCA3C903438_AdjustorThunk (void);
// 0x0000082B System.Boolean UnityEngine.Rendering.ShadowSplitData::Equals(System.Object)
extern void ShadowSplitData_Equals_m5149323E2B11FDDF90F8B1A20EF6EE7F4040338A_AdjustorThunk (void);
// 0x0000082C System.Int32 UnityEngine.Rendering.ShadowSplitData::GetHashCode()
extern void ShadowSplitData_GetHashCode_mA15BCD7F6B7FC695DA294B34EEF5CE92D1396AA7_AdjustorThunk (void);
// 0x0000082D System.Void UnityEngine.Rendering.ShadowSplitData::.cctor()
extern void ShadowSplitData__cctor_mEE17BC8B51CA98ABF4A4B66B94AA7F6ABEB8F2FB (void);
// 0x0000082E System.Void UnityEngine.Rendering.SortingLayerRange::.ctor(System.Int16,System.Int16)
extern void SortingLayerRange__ctor_m634A50CF97DED78D9EE04F59089ADFC8404CC108_AdjustorThunk (void);
// 0x0000082F UnityEngine.Rendering.SortingLayerRange UnityEngine.Rendering.SortingLayerRange::get_all()
extern void SortingLayerRange_get_all_m796E1D9B448FE441F810C7B1637C829584792914 (void);
// 0x00000830 System.Boolean UnityEngine.Rendering.SortingLayerRange::Equals(UnityEngine.Rendering.SortingLayerRange)
extern void SortingLayerRange_Equals_mAEE1B3D2ABDAF056DA9C9E259C152679A37DBA6D_AdjustorThunk (void);
// 0x00000831 System.Boolean UnityEngine.Rendering.SortingLayerRange::Equals(System.Object)
extern void SortingLayerRange_Equals_mC9CABA22A3A3D3EFFCFED34D136B137A27FA2FC5_AdjustorThunk (void);
// 0x00000832 System.Int32 UnityEngine.Rendering.SortingLayerRange::GetHashCode()
extern void SortingLayerRange_GetHashCode_m6EB3305DF1B44508D1A888DEF8192BCD74F6F1DF_AdjustorThunk (void);
// 0x00000833 System.Void UnityEngine.Rendering.SortingSettings::.ctor(UnityEngine.Camera)
extern void SortingSettings__ctor_m05CC25CC8BCE175ABD0B67393C11B25616C93BE9_AdjustorThunk (void);
// 0x00000834 System.Void UnityEngine.Rendering.SortingSettings::set_customAxis(UnityEngine.Vector3)
extern void SortingSettings_set_customAxis_m201EA863932FC631A79B9042C589EFD20B0D710A_AdjustorThunk (void);
// 0x00000835 UnityEngine.Rendering.SortingCriteria UnityEngine.Rendering.SortingSettings::get_criteria()
extern void SortingSettings_get_criteria_mC4A5DED8DD361A05446351B680526AC2D2B9E390_AdjustorThunk (void);
// 0x00000836 System.Void UnityEngine.Rendering.SortingSettings::set_criteria(UnityEngine.Rendering.SortingCriteria)
extern void SortingSettings_set_criteria_m6D617C21387E5FB780193B122EC6E99F53694BA6_AdjustorThunk (void);
// 0x00000837 System.Void UnityEngine.Rendering.SortingSettings::set_distanceMetric(UnityEngine.Rendering.DistanceMetric)
extern void SortingSettings_set_distanceMetric_mC1BC65D6F352F56C11FCFE66084626AF6DD5E894_AdjustorThunk (void);
// 0x00000838 System.Boolean UnityEngine.Rendering.SortingSettings::Equals(UnityEngine.Rendering.SortingSettings)
extern void SortingSettings_Equals_m592EFC54F954B3ECACCBC2F74C066BB14B151144_AdjustorThunk (void);
// 0x00000839 System.Boolean UnityEngine.Rendering.SortingSettings::Equals(System.Object)
extern void SortingSettings_Equals_m9BB6F63E8A0C4F1B32229B6AE40A1CA149CD7DE1_AdjustorThunk (void);
// 0x0000083A System.Int32 UnityEngine.Rendering.SortingSettings::GetHashCode()
extern void SortingSettings_GetHashCode_m2A5DE15F0AE8B86F4F7862F316C2C7579EC1DB5C_AdjustorThunk (void);
// 0x0000083B UnityEngine.Rendering.StencilState UnityEngine.Rendering.StencilState::get_defaultValue()
extern void StencilState_get_defaultValue_m23346895118822B73BE908CD6BA45D80DA044DD6 (void);
// 0x0000083C System.Void UnityEngine.Rendering.StencilState::.ctor(System.Boolean,System.Byte,System.Byte,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.StencilOp)
extern void StencilState__ctor_mE63E73C425D1B93B7761FE3847715904A5ED7778_AdjustorThunk (void);
// 0x0000083D System.Void UnityEngine.Rendering.StencilState::.ctor(System.Boolean,System.Byte,System.Byte,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.StencilOp)
extern void StencilState__ctor_m9D74151811E5B6EB01FEA9738FE99D2B938B41EE_AdjustorThunk (void);
// 0x0000083E System.Boolean UnityEngine.Rendering.StencilState::get_enabled()
extern void StencilState_get_enabled_m64131ECAE790CCB31DD756158547B7C86E1F12D4_AdjustorThunk (void);
// 0x0000083F System.Void UnityEngine.Rendering.StencilState::set_enabled(System.Boolean)
extern void StencilState_set_enabled_m74BFD7FEDD9520F20DD89CB19A71651758329954_AdjustorThunk (void);
// 0x00000840 System.Void UnityEngine.Rendering.StencilState::SetCompareFunction(UnityEngine.Rendering.CompareFunction)
extern void StencilState_SetCompareFunction_m8A6DF9ED845CA019FFAAEDE176C656CC26583FF4_AdjustorThunk (void);
// 0x00000841 System.Void UnityEngine.Rendering.StencilState::SetPassOperation(UnityEngine.Rendering.StencilOp)
extern void StencilState_SetPassOperation_mC31938C4783210A8C9FECFCA9E2601FDE677780F_AdjustorThunk (void);
// 0x00000842 System.Void UnityEngine.Rendering.StencilState::SetFailOperation(UnityEngine.Rendering.StencilOp)
extern void StencilState_SetFailOperation_m3C36F224A6CFAB101DD489D11BEA05D9B4CC8454_AdjustorThunk (void);
// 0x00000843 System.Void UnityEngine.Rendering.StencilState::SetZFailOperation(UnityEngine.Rendering.StencilOp)
extern void StencilState_SetZFailOperation_mC2EA216433E31AB4DDEB6B09AD8B4EED19CEA834_AdjustorThunk (void);
// 0x00000844 System.Void UnityEngine.Rendering.StencilState::set_compareFunctionFront(UnityEngine.Rendering.CompareFunction)
extern void StencilState_set_compareFunctionFront_mBE9C600C33516DD7A41AF16414CE2B3677659F4F_AdjustorThunk (void);
// 0x00000845 System.Void UnityEngine.Rendering.StencilState::set_passOperationFront(UnityEngine.Rendering.StencilOp)
extern void StencilState_set_passOperationFront_m8F4ECB3726CE0598ED1759D24A61ED7AD1F5CD7D_AdjustorThunk (void);
// 0x00000846 System.Void UnityEngine.Rendering.StencilState::set_failOperationFront(UnityEngine.Rendering.StencilOp)
extern void StencilState_set_failOperationFront_mE764F5190ADFE5E00272DD8D22D728464A309DEF_AdjustorThunk (void);
// 0x00000847 System.Void UnityEngine.Rendering.StencilState::set_zFailOperationFront(UnityEngine.Rendering.StencilOp)
extern void StencilState_set_zFailOperationFront_m5C98C971FFE0729FF3428BFEB3C874BA7E660049_AdjustorThunk (void);
// 0x00000848 System.Void UnityEngine.Rendering.StencilState::set_compareFunctionBack(UnityEngine.Rendering.CompareFunction)
extern void StencilState_set_compareFunctionBack_m1D9D4DEB9F190A5358FB5AB63E7B3E8276EE6F75_AdjustorThunk (void);
// 0x00000849 System.Void UnityEngine.Rendering.StencilState::set_passOperationBack(UnityEngine.Rendering.StencilOp)
extern void StencilState_set_passOperationBack_mB5045FFA7058C6AB7616CAE7B0F00622E3041C5C_AdjustorThunk (void);
// 0x0000084A System.Void UnityEngine.Rendering.StencilState::set_failOperationBack(UnityEngine.Rendering.StencilOp)
extern void StencilState_set_failOperationBack_m7147B6C2E7A2057BC1FF837E1424748784DAD304_AdjustorThunk (void);
// 0x0000084B System.Void UnityEngine.Rendering.StencilState::set_zFailOperationBack(UnityEngine.Rendering.StencilOp)
extern void StencilState_set_zFailOperationBack_mA749E7E40D0EA8836ABF1DE10C3541BEC3C46D62_AdjustorThunk (void);
// 0x0000084C System.Boolean UnityEngine.Rendering.StencilState::Equals(UnityEngine.Rendering.StencilState)
extern void StencilState_Equals_m1479C86015904B22C0B117F63A040915444EB870_AdjustorThunk (void);
// 0x0000084D System.Boolean UnityEngine.Rendering.StencilState::Equals(System.Object)
extern void StencilState_Equals_mD71613CA8665973266A04A8CE01D1DDFE8809E4A_AdjustorThunk (void);
// 0x0000084E System.Int32 UnityEngine.Rendering.StencilState::GetHashCode()
extern void StencilState_GetHashCode_mB1FD5BCCD93E54C1D525CEC275DBBB317E74B5A8_AdjustorThunk (void);
// 0x0000084F UnityEngine.Rendering.SupportedRenderingFeatures UnityEngine.Rendering.SupportedRenderingFeatures::get_active()
extern void SupportedRenderingFeatures_get_active_m2C2E65CE6B3B9197E71D6390B4CE3AF024EFC286 (void);
// 0x00000850 System.Void UnityEngine.Rendering.SupportedRenderingFeatures::set_active(UnityEngine.Rendering.SupportedRenderingFeatures)
extern void SupportedRenderingFeatures_set_active_m2E459FC4898691C6E729A5EC2D2B08A1733CDCC2 (void);
// 0x00000851 UnityEngine.Rendering.SupportedRenderingFeatures_LightmapMixedBakeModes UnityEngine.Rendering.SupportedRenderingFeatures::get_defaultMixedLightingModes()
extern void SupportedRenderingFeatures_get_defaultMixedLightingModes_m903DC0B0AB86F4C047E8930E0C59C4131DA600C9 (void);
// 0x00000852 UnityEngine.Rendering.SupportedRenderingFeatures_LightmapMixedBakeModes UnityEngine.Rendering.SupportedRenderingFeatures::get_mixedLightingModes()
extern void SupportedRenderingFeatures_get_mixedLightingModes_m87742B8CBD950598883F391C22FF036BE774E2D9 (void);
// 0x00000853 UnityEngine.LightmapBakeType UnityEngine.Rendering.SupportedRenderingFeatures::get_lightmapBakeTypes()
extern void SupportedRenderingFeatures_get_lightmapBakeTypes_m6B99531AE2EDEB49D54886E103AF12CFB1BC426A (void);
// 0x00000854 UnityEngine.LightmapsMode UnityEngine.Rendering.SupportedRenderingFeatures::get_lightmapsModes()
extern void SupportedRenderingFeatures_get_lightmapsModes_mAAAC00FB06849B233D053DB11B47E8DA8666583B (void);
// 0x00000855 System.Boolean UnityEngine.Rendering.SupportedRenderingFeatures::get_enlighten()
extern void SupportedRenderingFeatures_get_enlighten_m493ED393C99DC9105CCC2D8D28D43D6AB0B96C78 (void);
// 0x00000856 System.Void UnityEngine.Rendering.SupportedRenderingFeatures::FallbackMixedLightingModeByRef(System.IntPtr)
extern void SupportedRenderingFeatures_FallbackMixedLightingModeByRef_m91AC959EB7DD16F061466CF2123820AFA257BD76 (void);
// 0x00000857 System.Boolean UnityEngine.Rendering.SupportedRenderingFeatures::IsMixedLightingModeSupported(UnityEngine.MixedLightingMode)
extern void SupportedRenderingFeatures_IsMixedLightingModeSupported_m22C3916FDD1308FCDD201651709ED3861DBC09AB (void);
// 0x00000858 System.Void UnityEngine.Rendering.SupportedRenderingFeatures::IsMixedLightingModeSupportedByRef(UnityEngine.MixedLightingMode,System.IntPtr)
extern void SupportedRenderingFeatures_IsMixedLightingModeSupportedByRef_mE77416221A79F75F9EF7FD062AF9674264D1E069 (void);
// 0x00000859 System.Boolean UnityEngine.Rendering.SupportedRenderingFeatures::IsLightmapBakeTypeSupported(UnityEngine.LightmapBakeType)
extern void SupportedRenderingFeatures_IsLightmapBakeTypeSupported_mD21AC518EFAA0892131E4ADE0EBA1DA980937A61 (void);
// 0x0000085A System.Void UnityEngine.Rendering.SupportedRenderingFeatures::IsLightmapBakeTypeSupportedByRef(UnityEngine.LightmapBakeType,System.IntPtr)
extern void SupportedRenderingFeatures_IsLightmapBakeTypeSupportedByRef_mE33A63BE6E3D6D4DF4B5584E4F451713DC776DB8 (void);
// 0x0000085B System.Void UnityEngine.Rendering.SupportedRenderingFeatures::IsLightmapsModeSupportedByRef(UnityEngine.LightmapsMode,System.IntPtr)
extern void SupportedRenderingFeatures_IsLightmapsModeSupportedByRef_mAFD9EC8C77CF9874911FFC0C084FC161C27E9A13 (void);
// 0x0000085C System.Void UnityEngine.Rendering.SupportedRenderingFeatures::IsLightmapperSupportedByRef(System.Int32,System.IntPtr)
extern void SupportedRenderingFeatures_IsLightmapperSupportedByRef_m96E352A96F40887994AE8BA5F07BBB87D8A3E557 (void);
// 0x0000085D System.Void UnityEngine.Rendering.SupportedRenderingFeatures::FallbackLightmapperByRef(System.IntPtr)
extern void SupportedRenderingFeatures_FallbackLightmapperByRef_m04F1D58EF96BB1E1E20C72A562E86F17EEF3B1B9 (void);
// 0x0000085E System.Void UnityEngine.Rendering.SupportedRenderingFeatures::.ctor()
extern void SupportedRenderingFeatures__ctor_mFA6FBB0F889B8A9ECD5B77C0CE2EEF685C0310F5 (void);
// 0x0000085F System.Void UnityEngine.Rendering.SupportedRenderingFeatures::.cctor()
extern void SupportedRenderingFeatures__cctor_m0AAC399710A8663753C069DDC8CAE61039630C40 (void);
// 0x00000860 UnityEngine.Light UnityEngine.Rendering.VisibleLight::get_light()
extern void VisibleLight_get_light_mBFDEA0FA083D1606373637E8ABBB1DD65C9D25A7_AdjustorThunk (void);
// 0x00000861 UnityEngine.LightType UnityEngine.Rendering.VisibleLight::get_lightType()
extern void VisibleLight_get_lightType_mE1C9653B71D5C00C756CBFF0C8F5ACEC2B325F3C_AdjustorThunk (void);
// 0x00000862 UnityEngine.Color UnityEngine.Rendering.VisibleLight::get_finalColor()
extern void VisibleLight_get_finalColor_mCBE20D4E88F3FA1865B8E27817E4C18F4BDC4964_AdjustorThunk (void);
// 0x00000863 UnityEngine.Matrix4x4 UnityEngine.Rendering.VisibleLight::get_localToWorldMatrix()
extern void VisibleLight_get_localToWorldMatrix_mE8EF56DEFDCE473A3C178B36C3E3FAB6966D53B1_AdjustorThunk (void);
// 0x00000864 System.Single UnityEngine.Rendering.VisibleLight::get_range()
extern void VisibleLight_get_range_m704917DFACCA204B15A2C8BF85186C5162006157_AdjustorThunk (void);
// 0x00000865 System.Single UnityEngine.Rendering.VisibleLight::get_spotAngle()
extern void VisibleLight_get_spotAngle_m7AC099D76961795FA55436FA4933C80BBA568596_AdjustorThunk (void);
// 0x00000866 System.Boolean UnityEngine.Rendering.VisibleLight::Equals(UnityEngine.Rendering.VisibleLight)
extern void VisibleLight_Equals_m0BF2234DCEA6C61BF33864040A15F70A281BA66A_AdjustorThunk (void);
// 0x00000867 System.Boolean UnityEngine.Rendering.VisibleLight::Equals(System.Object)
extern void VisibleLight_Equals_mBFFD5A8CFA341A4AFC0A6E2D45EBE341D076CDCA_AdjustorThunk (void);
// 0x00000868 System.Int32 UnityEngine.Rendering.VisibleLight::GetHashCode()
extern void VisibleLight_GetHashCode_m11027F568A276C0B13F69B10C7A747DD0B778334_AdjustorThunk (void);
// 0x00000869 System.Boolean UnityEngine.Rendering.VisibleReflectionProbe::Equals(UnityEngine.Rendering.VisibleReflectionProbe)
extern void VisibleReflectionProbe_Equals_mA3C9F4E406435B3C8D69882F7FC8E96C2C03AAB1_AdjustorThunk (void);
// 0x0000086A System.Boolean UnityEngine.Rendering.VisibleReflectionProbe::Equals(System.Object)
extern void VisibleReflectionProbe_Equals_mE7F229880369A006CC83B61BAB0B56EE26A08E1A_AdjustorThunk (void);
// 0x0000086B System.Int32 UnityEngine.Rendering.VisibleReflectionProbe::GetHashCode()
extern void VisibleReflectionProbe_GetHashCode_m0016B00F3A385A04BFF7BEBAF7CEBBE449BD8CCB_AdjustorThunk (void);
// 0x0000086C System.Int32 UnityEngine.Rendering.ShaderKeyword::GetGlobalKeywordIndex(System.String)
extern void ShaderKeyword_GetGlobalKeywordIndex_m2297A7E7248ECAB6D1BBD158F98D56A3F1DFE4C1 (void);
// 0x0000086D System.Void UnityEngine.Rendering.ShaderKeyword::.ctor(System.String)
extern void ShaderKeyword__ctor_m95799F6B14823F6C9C48A3975EC58B884A69C14B_AdjustorThunk (void);
// 0x0000086E System.Void UnityEngine.Playables.INotificationReceiver::OnNotify(UnityEngine.Playables.Playable,UnityEngine.Playables.INotification,System.Object)
// 0x0000086F System.Void UnityEngine.Playables.IPlayableBehaviour::OnGraphStart(UnityEngine.Playables.Playable)
// 0x00000870 System.Void UnityEngine.Playables.IPlayableBehaviour::OnGraphStop(UnityEngine.Playables.Playable)
// 0x00000871 System.Void UnityEngine.Playables.IPlayableBehaviour::OnPlayableCreate(UnityEngine.Playables.Playable)
// 0x00000872 System.Void UnityEngine.Playables.IPlayableBehaviour::OnPlayableDestroy(UnityEngine.Playables.Playable)
// 0x00000873 System.Void UnityEngine.Playables.IPlayableBehaviour::OnBehaviourPlay(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
// 0x00000874 System.Void UnityEngine.Playables.IPlayableBehaviour::OnBehaviourPause(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
// 0x00000875 System.Void UnityEngine.Playables.IPlayableBehaviour::PrepareFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
// 0x00000876 System.Void UnityEngine.Playables.IPlayableBehaviour::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
// 0x00000877 UnityEngine.Playables.Playable UnityEngine.Playables.Playable::get_Null()
extern void Playable_get_Null_m1641F4B851ACAA6CBCC9BB400EC783EDEAF1A48D (void);
// 0x00000878 System.Void UnityEngine.Playables.Playable::.ctor(UnityEngine.Playables.PlayableHandle)
extern void Playable__ctor_m24C6ED455A921F585698BFFEC5CCED397205543E_AdjustorThunk (void);
// 0x00000879 UnityEngine.Playables.PlayableHandle UnityEngine.Playables.Playable::GetHandle()
extern void Playable_GetHandle_m952F17BACFC90BEACD3CB9880E65E69B3271108A_AdjustorThunk (void);
// 0x0000087A System.Boolean UnityEngine.Playables.Playable::Equals(UnityEngine.Playables.Playable)
extern void Playable_Equals_m1EC7E8B579C862BA8C979BD616224EC1B3364DD1_AdjustorThunk (void);
// 0x0000087B System.Void UnityEngine.Playables.Playable::.cctor()
extern void Playable__cctor_m5655D443F6D04230DB5D37BF7D5EDCA71FD85A32 (void);
// 0x0000087C UnityEngine.Playables.Playable UnityEngine.Playables.PlayableAsset::CreatePlayable(UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject)
// 0x0000087D System.Double UnityEngine.Playables.PlayableAsset::get_duration()
extern void PlayableAsset_get_duration_m58C1A4AC3A8CF2783815016BE58378D6E17D22D2 (void);
// 0x0000087E System.Collections.Generic.IEnumerable`1<UnityEngine.Playables.PlayableBinding> UnityEngine.Playables.PlayableAsset::get_outputs()
extern void PlayableAsset_get_outputs_mD839CEB7A22543AC17FAE1C3C4BCD9A7B8DA82B1 (void);
// 0x0000087F System.Void UnityEngine.Playables.PlayableAsset::Internal_CreatePlayable(UnityEngine.Playables.PlayableAsset,UnityEngine.Playables.PlayableGraph,UnityEngine.GameObject,System.IntPtr)
extern void PlayableAsset_Internal_CreatePlayable_mB36624F1FD210AAD53A848BF8F26912D47DFC09C (void);
// 0x00000880 System.Void UnityEngine.Playables.PlayableAsset::Internal_GetPlayableAssetDuration(UnityEngine.Playables.PlayableAsset,System.IntPtr)
extern void PlayableAsset_Internal_GetPlayableAssetDuration_m099C6F58730A818ACA8C837D3DDBFC4ACA75693F (void);
// 0x00000881 System.Void UnityEngine.Playables.PlayableAsset::.ctor()
extern void PlayableAsset__ctor_m669F459CFACFE65873346E428F206C457B488167 (void);
// 0x00000882 System.Void UnityEngine.Playables.PlayableBehaviour::.ctor()
extern void PlayableBehaviour__ctor_mE96A877D927BEEC8C9368A0673FEAD77A78C35EE (void);
// 0x00000883 System.Void UnityEngine.Playables.PlayableBehaviour::OnGraphStart(UnityEngine.Playables.Playable)
extern void PlayableBehaviour_OnGraphStart_m41537F7ED140E16D8666B4959D99EF9BC16FF622 (void);
// 0x00000884 System.Void UnityEngine.Playables.PlayableBehaviour::OnGraphStop(UnityEngine.Playables.Playable)
extern void PlayableBehaviour_OnGraphStop_m5B1C17F7DA22FFBF8BABB18CBA090AB64FD51740 (void);
// 0x00000885 System.Void UnityEngine.Playables.PlayableBehaviour::OnPlayableCreate(UnityEngine.Playables.Playable)
extern void PlayableBehaviour_OnPlayableCreate_m963F9A0600B2208400FE3F90647FBACE0B5FE0DD (void);
// 0x00000886 System.Void UnityEngine.Playables.PlayableBehaviour::OnPlayableDestroy(UnityEngine.Playables.Playable)
extern void PlayableBehaviour_OnPlayableDestroy_mC1C991442A5940826928EA321FC5EFBE68482A57 (void);
// 0x00000887 System.Void UnityEngine.Playables.PlayableBehaviour::OnBehaviourPlay(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
extern void PlayableBehaviour_OnBehaviourPlay_m4B44CD41A9CB3EA391BCB142FA3B9A80AFAFF820 (void);
// 0x00000888 System.Void UnityEngine.Playables.PlayableBehaviour::OnBehaviourPause(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
extern void PlayableBehaviour_OnBehaviourPause_mBC9C4536B30B413E248C96294F53CDABA2C1490C (void);
// 0x00000889 System.Void UnityEngine.Playables.PlayableBehaviour::PrepareFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData)
extern void PlayableBehaviour_PrepareFrame_m0FC4368B39C1DBC6586E417C8505D1A8C49235E2 (void);
// 0x0000088A System.Void UnityEngine.Playables.PlayableBehaviour::ProcessFrame(UnityEngine.Playables.Playable,UnityEngine.Playables.FrameData,System.Object)
extern void PlayableBehaviour_ProcessFrame_m32F9B265BB54D1A3A290E2709FDD0B873360B25A (void);
// 0x0000088B System.Object UnityEngine.Playables.PlayableBehaviour::Clone()
extern void PlayableBehaviour_Clone_m2BB70A16D658FD18307D084EFFFE4A7B1BB234FD (void);
// 0x0000088C System.Void UnityEngine.Playables.PlayableBinding::.cctor()
extern void PlayableBinding__cctor_mF1C450FA8C820DA444D8AB9235958EC750AE60C8 (void);
// 0x0000088D System.Void UnityEngine.Playables.PlayableBinding_CreateOutputMethod::.ctor(System.Object,System.IntPtr)
extern void CreateOutputMethod__ctor_m252187F08E76732D791C8458AF5629F29BDDB8F2 (void);
// 0x0000088E UnityEngine.Playables.PlayableOutput UnityEngine.Playables.PlayableBinding_CreateOutputMethod::Invoke(UnityEngine.Playables.PlayableGraph,System.String)
extern void CreateOutputMethod_Invoke_m56F81543465C6F9C65319BEEEFC5AEEF6A0D7764 (void);
// 0x0000088F System.IAsyncResult UnityEngine.Playables.PlayableBinding_CreateOutputMethod::BeginInvoke(UnityEngine.Playables.PlayableGraph,System.String,System.AsyncCallback,System.Object)
extern void CreateOutputMethod_BeginInvoke_m4FC768B14DF77F9DB8847F3FAF1CBFD11048030D (void);
// 0x00000890 UnityEngine.Playables.PlayableOutput UnityEngine.Playables.PlayableBinding_CreateOutputMethod::EndInvoke(System.IAsyncResult)
extern void CreateOutputMethod_EndInvoke_m61A9C47D6ED76402024C0C7139C4A6F1D58D4C47 (void);
// 0x00000891 System.Boolean UnityEngine.Playables.PlayableHandle::IsPlayableOfType()
// 0x00000892 UnityEngine.Playables.PlayableHandle UnityEngine.Playables.PlayableHandle::get_Null()
extern void PlayableHandle_get_Null_m09DE585EF795EFA2811950173C80F4FA24CBAAD1 (void);
// 0x00000893 System.Boolean UnityEngine.Playables.PlayableHandle::op_Equality(UnityEngine.Playables.PlayableHandle,UnityEngine.Playables.PlayableHandle)
extern void PlayableHandle_op_Equality_mBA774AE123AF794A1EB55148206CDD52DAFA42DF (void);
// 0x00000894 System.Boolean UnityEngine.Playables.PlayableHandle::Equals(System.Object)
extern void PlayableHandle_Equals_m7D3DC594EE8EE029E514FF9505C5E7A820D2435E_AdjustorThunk (void);
// 0x00000895 System.Boolean UnityEngine.Playables.PlayableHandle::Equals(UnityEngine.Playables.PlayableHandle)
extern void PlayableHandle_Equals_mBCBD135BA1DBB6B5F8884A21EE55FDD5EADB555C_AdjustorThunk (void);
// 0x00000896 System.Int32 UnityEngine.Playables.PlayableHandle::GetHashCode()
extern void PlayableHandle_GetHashCode_mFEF967B1397A1DC2EE05FC8DBB9C5E13161E3C45_AdjustorThunk (void);
// 0x00000897 System.Boolean UnityEngine.Playables.PlayableHandle::CompareVersion(UnityEngine.Playables.PlayableHandle,UnityEngine.Playables.PlayableHandle)
extern void PlayableHandle_CompareVersion_m24BEA91E99FF5FD3472B1A71CB78296D99F808A9 (void);
// 0x00000898 System.Boolean UnityEngine.Playables.PlayableHandle::IsValid()
extern void PlayableHandle_IsValid_mDA0A998EA6E2442C5F3B6CDFAF07EBA9A6873059_AdjustorThunk (void);
// 0x00000899 System.Type UnityEngine.Playables.PlayableHandle::GetPlayableType()
extern void PlayableHandle_GetPlayableType_m962BE384C093FF07EAF156DA373806C2D6EF1AD1_AdjustorThunk (void);
// 0x0000089A System.Void UnityEngine.Playables.PlayableHandle::.cctor()
extern void PlayableHandle__cctor_m6FA486FD9ECB91B10F04E59EFE993EC7663B6EA3 (void);
// 0x0000089B System.Boolean UnityEngine.Playables.PlayableHandle::IsValid_Injected(UnityEngine.Playables.PlayableHandle&)
extern void PlayableHandle_IsValid_Injected_mCCEEB80CD0855FD683299F6DBD4F9BA864C58C31 (void);
// 0x0000089C System.Type UnityEngine.Playables.PlayableHandle::GetPlayableType_Injected(UnityEngine.Playables.PlayableHandle&)
extern void PlayableHandle_GetPlayableType_Injected_m65C3EB2DEC74C0A02707B6A61D25B3BFEC91DB66 (void);
// 0x0000089D System.Void UnityEngine.Playables.PlayableOutput::.ctor(UnityEngine.Playables.PlayableOutputHandle)
extern void PlayableOutput__ctor_m881EC9E4BAD358971373EE1D6BF9C37DDB7A4943_AdjustorThunk (void);
// 0x0000089E UnityEngine.Playables.PlayableOutputHandle UnityEngine.Playables.PlayableOutput::GetHandle()
extern void PlayableOutput_GetHandle_m079ADC0139E95AA914CD7502F27EC79BB1A876F3_AdjustorThunk (void);
// 0x0000089F System.Boolean UnityEngine.Playables.PlayableOutput::Equals(UnityEngine.Playables.PlayableOutput)
extern void PlayableOutput_Equals_m458689DD056559A7460CCE496BF6BEC45EB47C5B_AdjustorThunk (void);
// 0x000008A0 System.Void UnityEngine.Playables.PlayableOutput::.cctor()
extern void PlayableOutput__cctor_m833F06DD46347C62096CEF4E22DBC3EB9ECDACD5 (void);
// 0x000008A1 UnityEngine.Playables.PlayableOutputHandle UnityEngine.Playables.PlayableOutputHandle::get_Null()
extern void PlayableOutputHandle_get_Null_mA462EF24F3B0CDD5B3C3F0C57073D49CED316FA4 (void);
// 0x000008A2 System.Int32 UnityEngine.Playables.PlayableOutputHandle::GetHashCode()
extern void PlayableOutputHandle_GetHashCode_mC35D44FD77BCA850B945C047C6E2913436B1DF1C_AdjustorThunk (void);
// 0x000008A3 System.Boolean UnityEngine.Playables.PlayableOutputHandle::op_Equality(UnityEngine.Playables.PlayableOutputHandle,UnityEngine.Playables.PlayableOutputHandle)
extern void PlayableOutputHandle_op_Equality_m9917DCF55902BB4984B830C4E3955F9C4E4CE0C0 (void);
// 0x000008A4 System.Boolean UnityEngine.Playables.PlayableOutputHandle::Equals(System.Object)
extern void PlayableOutputHandle_Equals_m42558FEC083CC424CB4BD715FC1A6561A2E47EB2_AdjustorThunk (void);
// 0x000008A5 System.Boolean UnityEngine.Playables.PlayableOutputHandle::Equals(UnityEngine.Playables.PlayableOutputHandle)
extern void PlayableOutputHandle_Equals_m1FCA747BC3F69DC784912A932557EB3B24DC3F18_AdjustorThunk (void);
// 0x000008A6 System.Boolean UnityEngine.Playables.PlayableOutputHandle::CompareVersion(UnityEngine.Playables.PlayableOutputHandle,UnityEngine.Playables.PlayableOutputHandle)
extern void PlayableOutputHandle_CompareVersion_m4DD52E80EDD984F824FE235F35B849C5BA9B4964 (void);
// 0x000008A7 System.Void UnityEngine.Playables.PlayableOutputHandle::.cctor()
extern void PlayableOutputHandle__cctor_mD1C850FF555697A09A580322C66357B593C9294E (void);
// 0x000008A8 UnityEngine.Experimental.GlobalIllumination.LinearColor UnityEngine.Experimental.GlobalIllumination.LinearColor::Convert(UnityEngine.Color,System.Single)
extern void LinearColor_Convert_m34C66A797B11DE3EE19A9ED913B286C5C76F3B4E (void);
// 0x000008A9 UnityEngine.Experimental.GlobalIllumination.LinearColor UnityEngine.Experimental.GlobalIllumination.LinearColor::Black()
extern void LinearColor_Black_m0C3B7331D5DEBB72F85BAFC175BC785D964D30D8 (void);
// 0x000008AA System.Void UnityEngine.Experimental.GlobalIllumination.LightDataGI::Init(UnityEngine.Experimental.GlobalIllumination.DirectionalLight&)
extern void LightDataGI_Init_m93EBCF45B2A5F8A0C9879FD2CF1B853514837F4B_AdjustorThunk (void);
// 0x000008AB System.Void UnityEngine.Experimental.GlobalIllumination.LightDataGI::Init(UnityEngine.Experimental.GlobalIllumination.PointLight&)
extern void LightDataGI_Init_m236C2DEE096CDCF4B4489B9A5630E231531DF022_AdjustorThunk (void);
// 0x000008AC System.Void UnityEngine.Experimental.GlobalIllumination.LightDataGI::Init(UnityEngine.Experimental.GlobalIllumination.SpotLight&)
extern void LightDataGI_Init_mBCCAA12227CF3845C831463F7B8572F00CB17CF3_AdjustorThunk (void);
// 0x000008AD System.Void UnityEngine.Experimental.GlobalIllumination.LightDataGI::Init(UnityEngine.Experimental.GlobalIllumination.RectangleLight&)
extern void LightDataGI_Init_m24775B5AF758CAE25BA180BC17D9E032064B52B9_AdjustorThunk (void);
// 0x000008AE System.Void UnityEngine.Experimental.GlobalIllumination.LightDataGI::Init(UnityEngine.Experimental.GlobalIllumination.DiscLight&)
extern void LightDataGI_Init_m00F56356E1220B292978ABE384B6500A1F1C9291_AdjustorThunk (void);
// 0x000008AF System.Void UnityEngine.Experimental.GlobalIllumination.LightDataGI::InitNoBake(System.Int32)
extern void LightDataGI_InitNoBake_m660C58A4878A0DB9E842F642AA6D2800D30F0C48_AdjustorThunk (void);
// 0x000008B0 UnityEngine.Experimental.GlobalIllumination.LinearColor UnityEngine.Experimental.GlobalIllumination.LightmapperUtils::ExtractIndirect(UnityEngine.Light)
extern void LightmapperUtils_ExtractIndirect_m1BA4D17B92F68DE86B8696BCA09901CB9F70E352 (void);
// 0x000008B1 System.Single UnityEngine.Experimental.GlobalIllumination.LightmapperUtils::ExtractInnerCone(UnityEngine.Light)
extern void LightmapperUtils_ExtractInnerCone_mAB6BC006F6841F7881DAC60077A61BA525E09C48 (void);
// 0x000008B2 System.Void UnityEngine.Experimental.GlobalIllumination.LightmapperUtils::Extract(UnityEngine.Light,UnityEngine.Experimental.GlobalIllumination.DirectionalLight&)
extern void LightmapperUtils_Extract_mA213675C1DD2F46927D6B0D02619CD0F2247E98D (void);
// 0x000008B3 System.Void UnityEngine.Experimental.GlobalIllumination.LightmapperUtils::Extract(UnityEngine.Light,UnityEngine.Experimental.GlobalIllumination.PointLight&)
extern void LightmapperUtils_Extract_mC23121E46C67B16DA74D2B74AA96BC9B734B4A86 (void);
// 0x000008B4 System.Void UnityEngine.Experimental.GlobalIllumination.LightmapperUtils::Extract(UnityEngine.Light,UnityEngine.Experimental.GlobalIllumination.SpotLight&)
extern void LightmapperUtils_Extract_mC6A2DEE19D89B532926E1E1EF0F6815E069F27C2 (void);
// 0x000008B5 System.Void UnityEngine.Experimental.GlobalIllumination.LightmapperUtils::Extract(UnityEngine.Light,UnityEngine.Experimental.GlobalIllumination.RectangleLight&)
extern void LightmapperUtils_Extract_mFF46D8454835FF7AC4B35A807B1F29222425B594 (void);
// 0x000008B6 System.Void UnityEngine.Experimental.GlobalIllumination.LightmapperUtils::Extract(UnityEngine.Light,UnityEngine.Experimental.GlobalIllumination.DiscLight&)
extern void LightmapperUtils_Extract_mF66211092ADB3241E3E1902CB84FF8E1A84A301F (void);
// 0x000008B7 System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping::SetDelegate(UnityEngine.Experimental.GlobalIllumination.Lightmapping_RequestLightsDelegate)
extern void Lightmapping_SetDelegate_mEA4A2549370F078869895AAC4E01EB916BB49A01 (void);
// 0x000008B8 UnityEngine.Experimental.GlobalIllumination.Lightmapping_RequestLightsDelegate UnityEngine.Experimental.GlobalIllumination.Lightmapping::GetDelegate()
extern void Lightmapping_GetDelegate_mCFE706531D3E5A96E71ED963AF8CB4B93A1C0AEE (void);
// 0x000008B9 System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping::ResetDelegate()
extern void Lightmapping_ResetDelegate_m25E3082200DFB9F101AEE07039FC4A33C4183738 (void);
// 0x000008BA System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping::RequestLights(UnityEngine.Light[],System.IntPtr,System.Int32)
extern void Lightmapping_RequestLights_m572FA5D5ADA94FF109696431E2EAE13B6D5C9AB6 (void);
// 0x000008BB System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping::.cctor()
extern void Lightmapping__cctor_m542D9D32613B348F62541FB1F0AF70EBF7EBB93A (void);
// 0x000008BC System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping_RequestLightsDelegate::.ctor(System.Object,System.IntPtr)
extern void RequestLightsDelegate__ctor_m32E80A59669219265627BAF616170C5BA130CA77 (void);
// 0x000008BD System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping_RequestLightsDelegate::Invoke(UnityEngine.Light[],Unity.Collections.NativeArray`1<UnityEngine.Experimental.GlobalIllumination.LightDataGI>)
extern void RequestLightsDelegate_Invoke_m2B97E4D1ED4DC45416B5EC472FC12B581373E403 (void);
// 0x000008BE System.IAsyncResult UnityEngine.Experimental.GlobalIllumination.Lightmapping_RequestLightsDelegate::BeginInvoke(UnityEngine.Light[],Unity.Collections.NativeArray`1<UnityEngine.Experimental.GlobalIllumination.LightDataGI>,System.AsyncCallback,System.Object)
extern void RequestLightsDelegate_BeginInvoke_m842A0B872EE1BDC505161CC083CA189F222784A8 (void);
// 0x000008BF System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping_RequestLightsDelegate::EndInvoke(System.IAsyncResult)
extern void RequestLightsDelegate_EndInvoke_mB5DE6574659D68281BC3D8179211DA892A481333 (void);
// 0x000008C0 System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping_<>c::.cctor()
extern void U3CU3Ec__cctor_mB5E5B471CF113C81A1D2CF2C4245C2181590DB0C (void);
// 0x000008C1 System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping_<>c::.ctor()
extern void U3CU3Ec__ctor_m9919FB3B009FEC46DBE2AAB63233F08B8B8D798D (void);
// 0x000008C2 System.Void UnityEngine.Experimental.GlobalIllumination.Lightmapping_<>c::<.cctor>b__7_0(UnityEngine.Light[],Unity.Collections.NativeArray`1<UnityEngine.Experimental.GlobalIllumination.LightDataGI>)
extern void U3CU3Ec_U3C_cctorU3Eb__7_0_m2D9D2C1DEA68EC9BC1F47CA41F462BB9EF72CF7B (void);
// 0x000008C3 UnityEngine.Playables.PlayableHandle UnityEngine.Experimental.Playables.CameraPlayable::GetHandle()
extern void CameraPlayable_GetHandle_mC710651CAEE2596697CFFC01014BEB041C67E2B4_AdjustorThunk (void);
// 0x000008C4 System.Boolean UnityEngine.Experimental.Playables.CameraPlayable::Equals(UnityEngine.Experimental.Playables.CameraPlayable)
extern void CameraPlayable_Equals_mBA0325A3187672B8FDE237D2D5229474C19E3A52_AdjustorThunk (void);
// 0x000008C5 UnityEngine.Playables.PlayableHandle UnityEngine.Experimental.Playables.MaterialEffectPlayable::GetHandle()
extern void MaterialEffectPlayable_GetHandle_mB0F6F324656489CE4DE4EFA8ACCE37458D292439_AdjustorThunk (void);
// 0x000008C6 System.Boolean UnityEngine.Experimental.Playables.MaterialEffectPlayable::Equals(UnityEngine.Experimental.Playables.MaterialEffectPlayable)
extern void MaterialEffectPlayable_Equals_m9C2DB0EB37CFB9679961D667B61E2360384C71DA_AdjustorThunk (void);
// 0x000008C7 UnityEngine.Playables.PlayableHandle UnityEngine.Experimental.Playables.TextureMixerPlayable::GetHandle()
extern void TextureMixerPlayable_GetHandle_mBC5D38A23834675B7A8D5314DCF4655C83AE649C_AdjustorThunk (void);
// 0x000008C8 System.Boolean UnityEngine.Experimental.Playables.TextureMixerPlayable::Equals(UnityEngine.Experimental.Playables.TextureMixerPlayable)
extern void TextureMixerPlayable_Equals_mEDE18FD43C9501F04871D2357DC66BABE43F397B_AdjustorThunk (void);
// 0x000008C9 System.Boolean UnityEngine.Experimental.Rendering.BuiltinRuntimeReflectionSystem::TickRealtimeProbes()
extern void BuiltinRuntimeReflectionSystem_TickRealtimeProbes_m7100EF316D04C407A21C27A35752826E463603EB (void);
// 0x000008CA System.Void UnityEngine.Experimental.Rendering.BuiltinRuntimeReflectionSystem::Dispose()
extern void BuiltinRuntimeReflectionSystem_Dispose_m60454D78E8492E739E2537F0B80FC76AC5DA1FCC (void);
// 0x000008CB System.Void UnityEngine.Experimental.Rendering.BuiltinRuntimeReflectionSystem::Dispose(System.Boolean)
extern void BuiltinRuntimeReflectionSystem_Dispose_m46A331A4A718F67B97CC07E98D419C0BBF38A8B0 (void);
// 0x000008CC System.Boolean UnityEngine.Experimental.Rendering.BuiltinRuntimeReflectionSystem::BuiltinUpdate()
extern void BuiltinRuntimeReflectionSystem_BuiltinUpdate_mE62DD3456554487F133F6CCF3D07E0CE6B7A07AB (void);
// 0x000008CD UnityEngine.Experimental.Rendering.BuiltinRuntimeReflectionSystem UnityEngine.Experimental.Rendering.BuiltinRuntimeReflectionSystem::Internal_BuiltinRuntimeReflectionSystem_New()
extern void BuiltinRuntimeReflectionSystem_Internal_BuiltinRuntimeReflectionSystem_New_m1B6EE7816B71869B7F874488A51FF0093F1FF8CB (void);
// 0x000008CE System.Void UnityEngine.Experimental.Rendering.BuiltinRuntimeReflectionSystem::.ctor()
extern void BuiltinRuntimeReflectionSystem__ctor_mB95177E1C8083A75B0980623778F2B6F3A80FE52 (void);
// 0x000008CF System.Boolean UnityEngine.Experimental.Rendering.IScriptableRuntimeReflectionSystem::TickRealtimeProbes()
// 0x000008D0 System.Void UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemSettings::set_Internal_ScriptableRuntimeReflectionSystemSettings_system(UnityEngine.Experimental.Rendering.IScriptableRuntimeReflectionSystem)
extern void ScriptableRuntimeReflectionSystemSettings_set_Internal_ScriptableRuntimeReflectionSystemSettings_system_m9D4C5A04E52667F4A9C15144B854A9D84D089590 (void);
// 0x000008D1 UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemWrapper UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemSettings::get_Internal_ScriptableRuntimeReflectionSystemSettings_instance()
extern void ScriptableRuntimeReflectionSystemSettings_get_Internal_ScriptableRuntimeReflectionSystemSettings_instance_m67BF9AE5DFB70144A8114705C51C96FFB497AA3E (void);
// 0x000008D2 System.Void UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemSettings::ScriptingDirtyReflectionSystemInstance()
extern void ScriptableRuntimeReflectionSystemSettings_ScriptingDirtyReflectionSystemInstance_m02B2FCD9BBCFA4ECC1D91A0B5B8B83856AC55718 (void);
// 0x000008D3 System.Void UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemSettings::.cctor()
extern void ScriptableRuntimeReflectionSystemSettings__cctor_m9CC42ECA95CACFFF874575B63D1FA461667D194C (void);
// 0x000008D4 UnityEngine.Experimental.Rendering.IScriptableRuntimeReflectionSystem UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemWrapper::get_implementation()
extern void ScriptableRuntimeReflectionSystemWrapper_get_implementation_mABDBD524BA9D869BCC02159B00C3B5F6DEE21895 (void);
// 0x000008D5 System.Void UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemWrapper::set_implementation(UnityEngine.Experimental.Rendering.IScriptableRuntimeReflectionSystem)
extern void ScriptableRuntimeReflectionSystemWrapper_set_implementation_m7866062401FA10180983AFE19BA672AE63CED29B (void);
// 0x000008D6 System.Void UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemWrapper::Internal_ScriptableRuntimeReflectionSystemWrapper_TickRealtimeProbes(System.Boolean&)
extern void ScriptableRuntimeReflectionSystemWrapper_Internal_ScriptableRuntimeReflectionSystemWrapper_TickRealtimeProbes_m65564441C57A8D5D3BA116C171ECE95B91F734A2 (void);
// 0x000008D7 System.Void UnityEngine.Experimental.Rendering.ScriptableRuntimeReflectionSystemWrapper::.ctor()
extern void ScriptableRuntimeReflectionSystemWrapper__ctor_mB936D4EA457BCCBEB0413F3F5B216164D88C4A3F (void);
// 0x000008D8 UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Experimental.Rendering.GraphicsFormatUtility::GetFormat(UnityEngine.Texture)
extern void GraphicsFormatUtility_GetFormat_m8DDA73529B51539BEE2A75451CBFA60186888589 (void);
// 0x000008D9 UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Experimental.Rendering.GraphicsFormatUtility::GetGraphicsFormat(UnityEngine.TextureFormat,System.Boolean)
extern void GraphicsFormatUtility_GetGraphicsFormat_mBA4E395B8A78B67B0969356DE19F6F1E73D284E0 (void);
// 0x000008DA UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Experimental.Rendering.GraphicsFormatUtility::GetGraphicsFormat_Native_TextureFormat(UnityEngine.TextureFormat,System.Boolean)
extern void GraphicsFormatUtility_GetGraphicsFormat_Native_TextureFormat_mAB77B8E00F9BE01455C0E011CF426FFBC53FA533 (void);
// 0x000008DB UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Experimental.Rendering.GraphicsFormatUtility::GetGraphicsFormat(UnityEngine.RenderTextureFormat,System.Boolean)
extern void GraphicsFormatUtility_GetGraphicsFormat_mA94B78BFCA8AFEBB85150D361A9A20C83FC5277E (void);
// 0x000008DC UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Experimental.Rendering.GraphicsFormatUtility::GetGraphicsFormat_Native_RenderTextureFormat(UnityEngine.RenderTextureFormat,System.Boolean)
extern void GraphicsFormatUtility_GetGraphicsFormat_Native_RenderTextureFormat_m36427FF5F0909DFE7AB6849EAC2D01A4E8D5ECF8 (void);
// 0x000008DD UnityEngine.Experimental.Rendering.GraphicsFormat UnityEngine.Experimental.Rendering.GraphicsFormatUtility::GetGraphicsFormat(UnityEngine.RenderTextureFormat,UnityEngine.RenderTextureReadWrite)
extern void GraphicsFormatUtility_GetGraphicsFormat_m4527266E37A786CC45C6BDD520A793C3B5A3A09E (void);
// 0x000008DE System.Boolean UnityEngine.Experimental.Rendering.GraphicsFormatUtility::IsSRGBFormat(UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void GraphicsFormatUtility_IsSRGBFormat_mBF49E7451A3960BD67B1F13745BCA3AC5C8AC66E (void);
// 0x000008DF UnityEngine.RenderTextureFormat UnityEngine.Experimental.Rendering.GraphicsFormatUtility::GetRenderTextureFormat(UnityEngine.Experimental.Rendering.GraphicsFormat)
extern void GraphicsFormatUtility_GetRenderTextureFormat_m4A8B97E7A7BD031B38EE1C5DA0C93B0F65016468 (void);
// 0x000008E0 System.Boolean UnityEngine.Experimental.Rendering.GraphicsFormatUtility::IsCompressedTextureFormat(UnityEngine.TextureFormat)
extern void GraphicsFormatUtility_IsCompressedTextureFormat_m456D7B059F25F7378E05E3346CB1670517A46C71 (void);
// 0x000008E1 System.Boolean UnityEngine.Experimental.Rendering.GraphicsFormatUtility::IsCrunchFormat(UnityEngine.TextureFormat)
extern void GraphicsFormatUtility_IsCrunchFormat_m97E8A6551AAEE6B1E4E92F92167FC97CC7D73DB1 (void);
// 0x000008E2 System.Void UnityEngine.Assertions.Assert::Fail(System.String,System.String)
extern void Assert_Fail_m9A3A2A08A2E1D18D0BB7D0C635055839EAA2EF02 (void);
// 0x000008E3 System.Void UnityEngine.Assertions.Assert::AreEqual(T,T,System.String)
// 0x000008E4 System.Void UnityEngine.Assertions.Assert::AreEqual(T,T,System.String,System.Collections.Generic.IEqualityComparer`1<T>)
// 0x000008E5 System.Void UnityEngine.Assertions.Assert::AreEqual(UnityEngine.Object,UnityEngine.Object,System.String)
extern void Assert_AreEqual_mFD46F687B9319093BA13D285D19999C801DC0A60 (void);
// 0x000008E6 System.Void UnityEngine.Assertions.Assert::AreEqual(System.Int32,System.Int32)
extern void Assert_AreEqual_mF4EDACE982A071478F520E76D1901B840411A91E (void);
// 0x000008E7 System.Void UnityEngine.Assertions.Assert::.cctor()
extern void Assert__cctor_mB34E1F44EB37A40F434BDB787B5E55F2B4033AF5 (void);
// 0x000008E8 System.Void UnityEngine.Assertions.AssertionException::.ctor(System.String,System.String)
extern void AssertionException__ctor_mDB97D95CF48EE1F6C184D30F6C3E099E1C4DA7FD (void);
// 0x000008E9 System.String UnityEngine.Assertions.AssertionException::get_Message()
extern void AssertionException_get_Message_m857FDA8060518415B2FFFCCA4A6BEE7B9BF66ECE (void);
// 0x000008EA System.String UnityEngine.Assertions.AssertionMessageUtil::GetMessage(System.String)
extern void AssertionMessageUtil_GetMessage_mA6DC7467BAF09543EA091FC63587C9011E1CA261 (void);
// 0x000008EB System.String UnityEngine.Assertions.AssertionMessageUtil::GetMessage(System.String,System.String)
extern void AssertionMessageUtil_GetMessage_m97506B9B19E9F75E8FE164BF64085466FC96EA18 (void);
// 0x000008EC System.String UnityEngine.Assertions.AssertionMessageUtil::GetEqualityMessage(System.Object,System.Object,System.Boolean)
extern void AssertionMessageUtil_GetEqualityMessage_mDBD27DDE3A03418E4A2F8DB377AE866F656C812A (void);
static Il2CppMethodPointer s_methodPointers[2284] = 
{
	MathfInternal__cctor_m885D4921B8E928763E7ABB4466659665780F860F,
	TypeInferenceRuleAttribute__ctor_m389751AED6740F401AC8DFACD5914C13AB24D8A6,
	TypeInferenceRuleAttribute__ctor_m34920F979AA071F4973CEEEF6F91B5B6A53E5765,
	TypeInferenceRuleAttribute_ToString_m49343B52ED0F3E75B3E56E37CF523F63E5A746F6,
	GenericStack__ctor_m0659B84DB6B093AF1F01F566686C510DDEEAE848,
	ProfilerMarker__ctor_mF9F9BDCB1E4618F9533D83D47EAD7325A32FDC2A_AdjustorThunk,
	ProfilerMarker_Auto_m27C8BA4E46F26F3005760C48C4B92EBC284A5D02_AdjustorThunk,
	ProfilerMarker_Internal_Create_m92F2A7651D4BF3F3D0CB62078DD79B71839FA370,
	ProfilerMarker_Internal_Begin_m79272E72708A53AFDEEEB81CF66C7D62920AC5B5,
	ProfilerMarker_Internal_End_mE25FE55A23DF111614CE890359972D96A65B499A,
	AutoScope__ctor_mDB99051F3C5C2BFFF71574AC515AB523F04E3320_AdjustorThunk,
	AutoScope_Dispose_m3663B79F5E62F2FA39FAAB5956A5EA141BA98AF2_AdjustorThunk,
	JobHandle_ScheduleBatchedJobs_mE52469B0B3D765B57BC658E82815840C83A6A4D0,
	NativeLeakDetection_Initialize_m70E48965BE4B399698C8034015B4F0EBD8D4C6E7,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NativeContainerAttribute__ctor_mD22697FA575BA0404B981921B295C1A4B89C9F42,
	NativeContainerSupportsMinMaxWriteRestrictionAttribute__ctor_m3D87D41F66CB34605B2C23D12BD04E9546AF321D,
	NativeContainerSupportsDeallocateOnJobCompletionAttribute__ctor_m56D5D2E8D7FE0BF8368167A7139204F4740A875B,
	NativeContainerSupportsDeferredConvertListToArray__ctor_m81D3D40F97FDB1675D128ACD785A9658E5E9DBB2,
	WriteAccessRequiredAttribute__ctor_mBB72625FD2C0CE5081BCEBF5C6122581723574B5,
	NativeDisableUnsafePtrRestrictionAttribute__ctor_m25F3A64C3715BB3C92C7150DB1F46BC88091B653,
	NULL,
	NULL,
	NULL,
	NULL,
	UnsafeUtility_Malloc_m43BC7C9BE1437A70DD9A236418B0906CD3617331,
	UnsafeUtility_Free_mAC082BB03B10D20CA9E5AD7FBA33164DF2B52E89,
	UnsafeUtility_MemCpy_mA675903DD7350CC5EC22947C0899B18944E3578C,
	UnsafeUtility_MemSet_m2877A4878CEB99D6B13B8F6A49FDA1C0C924AE24,
	UnsafeUtility_MemClear_m288BC0ABEB3E1A7B941FB28033D391E661887545,
	UnsafeUtility_IsBlittable_m4FE85090DA275D2B489A8E57BCD2DAA1859B5A8E,
	UnsafeUtility_IsBlittableValueType_mF403D8551AA7A8503B5D1587941B7DB248EA5637,
	UnsafeUtility_GetReasonForTypeNonBlittableImpl_m8ED27B0E929F764C6A75971117783802277AE5C2,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	SortingLayer_get_id_mC93B809F988E70775D746B1BEA41FCC97D0DAA51_AdjustorThunk,
	SortingLayer_get_value_mAA4CF694CCFF3EB7ACD26B95319C2DC2DDDB77F7_AdjustorThunk,
	SortingLayer_get_layers_m5F1CE882A1DC669B4A3E3233817577419FFFEC56,
	SortingLayer_GetSortingLayerIDsInternal_mC6BE877C3F2F1C09A3E07BD11632CED281D616C1,
	SortingLayer_GetLayerValueFromID_m564F9C83200E5EC3E9578A75854CB943CE5546F8,
	SortingLayer_IDToName_m5D8BC7962C906483BC1A544B157026E30568F1BC,
	Keyframe__ctor_m10FFFE5FE1213C3AE88359375398F213B24F18D5_AdjustorThunk,
	Keyframe_get_time_m5A49381A903E63DD63EF8A381BA26C1A2DEF935D_AdjustorThunk,
	Keyframe_set_time_mAD4CA2282CD1B7C1D330C3EE75F79AD636C7FC83_AdjustorThunk,
	AnimationCurve_Internal_Destroy_m295BAECEF97D64ACFE55D7EA91B9E9C077DB6A7C,
	AnimationCurve_Internal_Create_mA7A2A0191C4AAE7BD5B18F0DCC05AD4290D1691B,
	AnimationCurve_Internal_Equals_m7ACF09175F2DC61D95006ABB5BBE1CF7434B2D1D,
	AnimationCurve_Finalize_mDF0DECA505DA883A56B2E3FCE1EF19CC3959F11D,
	AnimationCurve_Evaluate_m51CAA6B1C54B7EF44FE4D74B422C1DA1FA6F8776,
	AnimationCurve_get_keys_m88E1848D255C2893F379E855A522DA9B0E0F78FB,
	AnimationCurve_set_keys_m3AA5ED7D9B0D9BCBCD349355160810B2DF939096,
	AnimationCurve_AddKey_m67EF6AFE4C0083D8B08926D5CA2B32A907DBB216,
	AnimationCurve_AddKey_mBF33163D92DCC0BC0A10D2308038A8D49750E961,
	AnimationCurve_AddKey_Internal_mC89C6E030F40FE6586C3D1609DB24F075EDE9B64,
	AnimationCurve_MoveKey_m20405AA535659CAAC9BC1B100301C5BD76201735,
	AnimationCurve_RemoveKey_m25D7337353EE1BE94799C156BEDC8D971B1A1F13,
	AnimationCurve_get_Item_m303DEF117A2702D57F8F5D55D422EC395E4388FC,
	AnimationCurve_get_length_m36B9D49BCB7D677C38A7963FF00313A2E48E7B26,
	AnimationCurve_SetKeys_mDC9E9E871BEED0B5C3F25A991F1BEF18F23602FC,
	AnimationCurve_GetKey_m2FD7B7AB3633B9C353FA59FC3927BC7EB904691F,
	AnimationCurve_GetKeys_mC61A3A3E0D17E5849768B3AB3698F2139CF70EBE,
	AnimationCurve_SmoothTangents_mEC6BDF7315345A949E35C4D34B0314DDC8DAFD76,
	AnimationCurve__ctor_mE9462D171C06A2A746B9DA1B0A6B0F4FC7DB94CF,
	AnimationCurve__ctor_mA12B39D1FD275B9A8150227B24805C7B218CDF2C,
	AnimationCurve_Equals_m5E3528A0595AC6714584CAD54549D756C9B3DDD5,
	AnimationCurve_Equals_m60310C21F9B109BAC9BA4FACE9BEF88931B22DED,
	AnimationCurve_GetHashCode_m22EEE795E7C76841C40A1563E3E90CBB089B19A6,
	AnimationCurve_AddKey_Internal_Injected_mD23B51D3B53AF2181150952AC124A5889C4B1B02,
	AnimationCurve_MoveKey_Injected_m8BA9D6C6BB0BB094BEBAB730F4443C282CDE2E32,
	AnimationCurve_GetKey_Injected_m01C24E74FE72837D5E6A59BBB1BACAEC308454EA,
	Application_Quit_m514D6F92E1A06D53D1BCA2F2A646ABA6678717B2,
	Application_Quit_mA005EB22CB989AC3794334754F15E1C0D2FF1C95,
	Application_get_isPlaying_mF43B519662E7433DD90D883E5AE22EC3CFB65CA5,
	Application_get_platform_m6AFFFF3B077F4D5CA1F71CF14ABA86A83FC71672,
	Application_get_isMobilePlatform_m11B260E344378D2A3CE53FCCA64DAC70F0B783E7,
	Application_CallLowMemory_m4C6693BD717D61DB33C2FB061FDA8CE055966E75,
	Application_CallLogCallback_mCA351E4FBE7397C3D09A7FBD8A9B074A4745ED89,
	Application_Internal_ApplicationWantsToQuit_mDF35192EF816ECD73F0BD4AFBCDE1460EF06442A,
	Application_Internal_ApplicationQuit_mC9ACAA5CB0800C837DBD9925E1E389FB918F3DED,
	Application_InvokeOnBeforeRender_mF2E1F3E67C1D160AD1209C1DBC1EC91E8FB88C97,
	Application_InvokeFocusChanged_m61786C9688D01809FAC41250B371CE13C9DBBD6F,
	Application_InvokeDeepLinkActivated_m473D851836BD708C896850AA1DAE2B56A4B01176,
	Application_get_isEditor_m347E6EE16E5109EF613C83ED98DB1EC6E3EF5E26,
	LowMemoryCallback__ctor_m9A428FDE023342AE31B3749FC821B078AEDA2290,
	LowMemoryCallback_Invoke_m3082D6F2046585D3504696B94A59A4CBC43262F8,
	LowMemoryCallback_BeginInvoke_m4686E95B4CF6EDE103DB0448FC54354BAE5F1745,
	LowMemoryCallback_EndInvoke_mB8843171E51584D380B62D3B79BC4F4930A22D0C,
	LogCallback__ctor_mF61E7CECD9E360B0B8A992720860F9816E165731,
	LogCallback_Invoke_mCB0C38C44CBF8BBE88690BE6C0382011C5D5B61F,
	LogCallback_BeginInvoke_mECA20C96EB7E35915BC9202F833685D0ED5F66A7,
	LogCallback_EndInvoke_m03CD6E28DACBF36E7A756F8CC653E546CBF3FD54,
	BootConfigData_WrapBootConfigData_m7C2DCB60E1456C2B7748ECFAAEB492611A5D7690,
	BootConfigData__ctor_m6C109EB48CAE91C89BB6C4BFD10C77EA6723E5AE,
	Camera_get_nearClipPlane_mD9D3E3D27186BBAC2CC354CE3609E6118A5BF66C,
	Camera_get_farClipPlane_mF51F1FF5BE87719CFAC293E272B1138DC1EFFD4B,
	Camera_get_fieldOfView_m065A50B70AC3661337ACA482DDEFA29CCBD249D6,
	Camera_get_allowHDR_m665C9AE59920BD6FD436C85EA3517D4914477759,
	Camera_get_allowMSAA_m857F27DB6C26C843A9F4A65D05C12E5E1BFA097F,
	Camera_get_allowDynamicResolution_m914F4649B78C663DC318AFA9C8488F1E1272194D,
	Camera_get_orthographicSize_m700FCD8CF48BC59A0415A624328B4A627B88D958,
	Camera_set_orthographicSize_mF15F37A294A7AA2ADD9519728A495DFA0A836428,
	Camera_get_orthographic_m801883D15C8D9816091F6B9C742CA5FA3650C8E6,
	Camera_get_opaqueSortMode_m44EA1DE8FAB7C81906D992A95EFA6C1309241A1A,
	Camera_get_transparencySortMode_m5AFD99D6A373C9ECE90803BBA6C4C0F3E74C5AE4,
	Camera_get_depth_m436C49A1C7669E4AD5665A1F1107BDFBA38742CD,
	Camera_get_cullingMask_m0992E96D87A4221E38746EBD882780CEFF7C2BCD,
	Camera_get_eventMask_m1D85900090AF34244340C69B53A42CDE5E9669D3,
	Camera_get_cameraType_m8AE222219696578F70EA285D5AF182630089F21C,
	Camera_get_backgroundColor_m14496C5DC24582D7227277AF71DBE96F8E9E64FF,
	Camera_get_clearFlags_m1D02BA1ABD7310269F6121C58AF41DCDEF1E0266,
	Camera_get_rect_m3570AA056526AB01C7733B4E7BE69F332E128A08,
	Camera_set_rect_m6DB9964EA6E519E2B07561C8CE6AA423980FEC11,
	Camera_get_pixelRect_mBA87D6C23FD7A5E1A7F3CE0E8F9B86A9318B5317,
	Camera_set_pixelRect_m9380482EFA5D7912988D585E9538A58988C8E0E9,
	Camera_get_pixelWidth_m67EC53853580E35527F32D6EA002FE21C234172E,
	Camera_get_pixelHeight_m38879ACBA6B21C25E83AB07FA37A8E5EB7A51B05,
	Camera_get_targetTexture_m1E776560FAC888D8210D49CEE310BB39D34A3FDC,
	Camera_get_targetDisplay_m2C318D2EB9A016FEC76B13F7F7AE382F443FB731,
	Camera_get_worldToCameraMatrix_mDE5C634A92CD1303D6B1ADC65E4ED852108FBECE,
	Camera_set_worldToCameraMatrix_m1B6A7FCD4185E771264938CA68FF999B22238B6F,
	Camera_get_projectionMatrix_m50964A6A11D1E3F8857A0B6E60BBB9C208BE473A,
	Camera_get_nonJitteredProjectionMatrix_mE4E183D92A45925D9C26D1D781ED9639903788BE,
	Camera_ResetWorldToCameraMatrix_m2B62CFBE1575C53DC43501F4FDAF8B6DEE10E607,
	Camera_WorldToScreenPoint_m315B44D111E92F6C81C39B7B0927622289C1BC52,
	Camera_WorldToScreenPoint_m880F9611E4848C11F21FDF1A1D307B401C61B1BF,
	Camera_ScreenToViewportPoint_m52ABFA35ADAA0B4FF3A7EE675F92F8F483E821FD,
	Camera_ScreenPointToRay_m84C3D8E0A4E8390A353C2361A0900372742065A0,
	Camera_ScreenPointToRay_m7069BC09C3D802595AC1FBAEFB3C59C8F1FE5FE2,
	Camera_ScreenPointToRay_m27638E78502DB6D6D7113F81AF7C210773B828F3,
	Camera_get_main_m9256A9F84F92D7ED73F3E6C4E2694030AD8B61FA,
	Camera_get_stereoEnabled_m24FC636CCDA9B771F2A975C4F5DB561454357856,
	Camera_get_stereoTargetEye_mC9A7C0AB7FE7858D2CD9B7B09DAD4FCA7BE16D21,
	Camera_GetAllCamerasCount_mBA721F43F94AA5DB555461DE11351CBAF8267662,
	Camera_GetAllCamerasImpl_mC93829FFC53391EA6C5012E5FA3817BA20DBEA89,
	Camera_get_allCamerasCount_mF6CDC46D6F61B1F1A0337A9AD7DFA485E408E6A1,
	Camera_GetAllCameras_m500A4F27E7BE1C259E9EAA0AEBB1E1B35893059C,
	Camera_FireOnPreCull_m7E8B65875444B1DE75170805AE22908ADE52301E,
	Camera_FireOnPreRender_m996699B5D50FC3D0AB05EED9F9CE581CCDC2FF67,
	Camera_FireOnPostRender_m17457A692D59CBDDDBBE0E4C441D393DAD58654B,
	Camera_TryGetCullingParameters_mCCA2EAAEFB8C8DA2C81B51BA5111A0C1F6BB064C,
	Camera_GetCullingParameters_Internal_m97DCDFD9FC11DFE1024ACDDB2E6233079883F774,
	Camera__ctor_mD07AB17467A910BC7A4EE32BB9DD546748E31254,
	Camera_get_backgroundColor_Injected_m35D7092E021C199D24A3457297EEEAA520CAC999,
	Camera_get_rect_Injected_m88F10E0BE4F27E638C97010D4616DBB14338EEED,
	Camera_set_rect_Injected_m62EE0CFFE15C612C226DEAB0ADB3D3B81ABE0C4E,
	Camera_get_pixelRect_Injected_mDE6A7F125BC1DD2BCFEA3CB03DFA948E5635E631,
	Camera_set_pixelRect_Injected_mBE9F9ED0BC921A91C9E1B85075E8E7F8ECD61D45,
	Camera_get_worldToCameraMatrix_Injected_mF75446D0941E2CBEC1DDFE4FCFBE13E7ACAD0025,
	Camera_set_worldToCameraMatrix_Injected_mA848604C2BE1736B773F75FD83D39C4EF8E68EFA,
	Camera_get_projectionMatrix_Injected_mB52990E81F3B593935C384045A72611A1E160E30,
	Camera_get_nonJitteredProjectionMatrix_Injected_m0D047D1DFCAA06176DA978B02E5522EDB12DF23A,
	Camera_WorldToScreenPoint_Injected_m640C6AFA68F6C2AD25AFD9E06C1AEFEAC5B48B01,
	Camera_ScreenToViewportPoint_Injected_m407A30EDD4AC317DE3DD0B4361664F438E5A6639,
	Camera_ScreenPointToRay_Injected_m1135D2C450C7DED657837BEFE5AD7FAFB9B99387,
	CameraCallback__ctor_m7CAE962B355F00AB2868577DC302A1FA80939C50,
	CameraCallback_Invoke_m2B4F10A7BF2620A9BBF1C071D5B4EE828FFE821F,
	CameraCallback_BeginInvoke_m46CF0E3E7E6A18868CBEBEA62D012713B20A8B14,
	CameraCallback_EndInvoke_m3B1E210D6A4F41F0FF74B187B3D7CB64C302D146,
	CullingGroup__ctor_m9930683B9FE5B8B3409C4C60476D592863306EC5,
	CullingGroup_Finalize_m67D1F84462EC91AACBB9899B859D26CAD5BE24AB,
	CullingGroup_DisposeInternal_m50A7ADA8944DDE68D1D10A7CFFEB37EE2FB4EB19,
	CullingGroup_Dispose_mBB6749664C63EA7289A5AB405A479DFEAD90A2EF,
	CullingGroup_set_targetCamera_m5FC653577169438F41E58DA5DF9D006FCFF0FF18,
	CullingGroup_SetBoundingSpheres_m23F40B24D0A5DFF2CBA61444FD491B0D23225974,
	CullingGroup_SetBoundingSphereCount_m0BA4EA985BFEC46C6D6F8703D5EB947647002CCA,
	CullingGroup_IsVisible_mDF6806EB7EE918F7919377D0CE00AF44DDD31F7B,
	CullingGroup_SendEvents_m08EBF10EEFF49CF9894BA940FD969C8F53F807E7,
	CullingGroup_Init_m1F9C9FAFDD0D2B89FF7C8DC662886734450021FE,
	CullingGroup_FinalizerFailure_mB9C9DC09F2124724B22C0726B6B1EA2957D87973,
	StateChanged__ctor_m8DCC0DCE42D5257F92FEA1F2B4DA2EF4558006F9,
	StateChanged_Invoke_m2E371D6B1AD1F23F20038D0DEEEFED15D76BC545,
	StateChanged_BeginInvoke_m5BD458B36BF2E71F4FB19444B0FAAA1B87BF8912,
	StateChanged_EndInvoke_mBC050D5602C1F3EC3F8137908D81894E646F5212,
	ReflectionProbe_CallReflectionProbeEvent_mA6273CE84793FD3CC7AA0506C525EED4F4935B62,
	ReflectionProbe_CallSetDefaultReflection_m97EFBE5F8A57BB7C8CA65C65FF4BD9889060325D,
	DebugLogHandler_Internal_Log_m2B637FD9089DEAA9D9FDE458DF5415CDF97424C3,
	DebugLogHandler_Internal_LogException_m8400B0D97B8D4A155A449BD28A32C68373A1A856,
	DebugLogHandler_LogFormat_m3C9B0AD4B5CDFF5AF195F9AA9FCBA908053BA41D,
	DebugLogHandler_LogException_m816CF2DDA84DFC1D1715B24F9626BD623FF05416,
	DebugLogHandler__ctor_mE9664BE5E6020FB88C6A301465811C80DEDFA392,
	Debug_get_unityLogger_mFA75EC397E067D09FD66D56B4E7692C3FCC3E960,
	Debug_Log_m4B7C70BAFD477C6BDB59C88A0934F0B018D03708,
	Debug_LogError_m3BCF9B78263152261565DCA9DB7D55F0C391ED29,
	Debug_LogError_m97139CB2EE76D5CD8308C1AD0499A5F163FC7F51,
	Debug_LogErrorFormat_mB54A656B267CF936439D50348FC828921AEDA8A9,
	Debug_LogErrorFormat_m994E4759C25BF0E9DD4179C10E3979558137CCF0,
	Debug_LogException_mBAA6702C240E37B2A834AA74E4FDC15A3A5589A9,
	Debug_LogException_m3CC9A37CD398E5B7F2305896F0969939F1BD1E3E,
	Debug_LogWarning_m37338644DC81F640CCDFEAE35A223F0E965F0568,
	Debug_LogWarning_mD417697331190AC1D21C463F412C475103A7256E,
	Debug_LogWarningFormat_m4A02CCF91F3A9392F4AA93576DCE2222267E5945,
	Debug_Assert_m0283DD85C5E5F5029793C17A335DB16BC307E62E,
	Debug_Assert_m84EE43ACFD01E8C0CEC0160C494B2CE77338F7BC,
	Debug_LogAssertion_m2A8940871EC1BD01A405103429F2FCE2AFB12506,
	Debug_get_isDebugBuild_mED5A7963C7B055A9ACC5565862BBBA6F3D86EDE8,
	Debug_CallOverridenDebugHandler_m5F5FC22445A9C957A655734DA5B661A5E256BEBE,
	Debug__cctor_m9BFDFB65B30AA2962FDACD15F36FC666471D1C5E,
	Bounds__ctor_m294E77A20EC1A3E96985FE1A925CB271D1B5266D_AdjustorThunk,
	Bounds_GetHashCode_m9F5F751E9D52F99FCC3DC07407410078451F06AC_AdjustorThunk,
	Bounds_Equals_m1ECFAEFE19BAFB61FFECA5C0B8AE068483A39C61_AdjustorThunk,
	Bounds_Equals_mC2E2B04AB16455E2C17CD0B3C1497835DEA39859_AdjustorThunk,
	Bounds_get_center_m4FB6E99F0533EE2D432988B08474D6DC9B8B744B_AdjustorThunk,
	Bounds_set_center_mAD29DD80FD631F83AF4E7558BB27A0398E8FD841_AdjustorThunk,
	Bounds_get_size_m0739F2686AE2D3416A33AEF892653091347FD4A6_AdjustorThunk,
	Bounds_set_size_m70855AC67A54062D676174B416FB06019226B39A_AdjustorThunk,
	Bounds_get_extents_mBA4B2196036DD5A858BDAD53BC71A778B41841C9_AdjustorThunk,
	Bounds_set_extents_mC83719146B06D0575A160CDDE9997202A1192B35_AdjustorThunk,
	Bounds_get_min_m2D48F74D29BF904D1AF19C562932E34ACAE2467C_AdjustorThunk,
	Bounds_set_min_m5933955F04FCC8E3B372EA72ECCD398BB057C844_AdjustorThunk,
	Bounds_get_max_mC3BE43C2A865BAC138D117684BC01E289892549B_AdjustorThunk,
	Bounds_set_max_m12B864B082A4A188C7624C1ABEFA34028DD5A603_AdjustorThunk,
	Bounds_op_Equality_m8168B65BF71D8E5B2F0181677ED79957DD754FF4,
	Bounds_op_Inequality_mA6EBEDD980A41D5E206CBE009731EB1CA0B25502,
	Bounds_SetMinMax_m04969DE5CBC7F9843C12926ADD5F591159C86CA6_AdjustorThunk,
	Bounds_Encapsulate_mD1F1DAC416D7147E07BF54D87CA7FF84C1088D8D_AdjustorThunk,
	Bounds_ToString_m4637EA7C58B9C75651A040182471E9BAB9295666_AdjustorThunk,
	Plane__ctor_m6535EAD5E675627C2533962F1F7890CBFA2BA44A_AdjustorThunk,
	Plane_Raycast_m04E61D7C78A5DA70F4F73F9805ABB54177B799A9_AdjustorThunk,
	Plane_ToString_mF92ABB5136759C7DFBC26FD3957532B3C26F2099_AdjustorThunk,
	Ray__ctor_m695D219349B8AA4C82F96C55A27D384C07736F6B_AdjustorThunk,
	Ray_get_origin_m3773CA7B1E2F26F6F1447652B485D86C0BEC5187_AdjustorThunk,
	Ray_get_direction_m9E6468CD87844B437FC4B93491E63D388322F76E_AdjustorThunk,
	Ray_GetPoint_mE8830D3BA68A184AD70514428B75F5664105ED08_AdjustorThunk,
	Ray_ToString_m73B5291E29C9C691773B44590C467A0D4FBE0EC1_AdjustorThunk,
	Rect__ctor_m50B92C75005C9C5A0D05E6E0EBB43AFAF7C66280_AdjustorThunk,
	Rect__ctor_m027E778E437FED8E6DBCE0C01C854ADF54986ECE_AdjustorThunk,
	Rect_get_zero_m4CF0F9AD904132829A6EFCA85A1BF52794E7E56B,
	Rect_MinMaxRect_m9513FDB332B24FB8B49202C7350FF7223477F54F,
	Rect_get_x_mC51A461F546D14832EB96B11A7198DADDE2597B7_AdjustorThunk,
	Rect_set_x_m49EFE25263C03A48D52499C3E9C097298E0EA3A6_AdjustorThunk,
	Rect_get_y_m53E3E4F62D9840FBEA751A66293038F1F5D1D45C_AdjustorThunk,
	Rect_set_y_mCFDB9BD77334EF9CD896F64BE63C755777D7CCD5_AdjustorThunk,
	Rect_get_position_m54A2ACD2F97988561D6C83FCEF7D082BC5226D4C_AdjustorThunk,
	Rect_set_position_mD92DFF591D9C96CDD6AF22EA2052BB3D468D68ED_AdjustorThunk,
	Rect_get_center_mA6E659EAAACC32132022AB199793BF641B3068CB_AdjustorThunk,
	Rect_get_min_m17345668569CF57C5F1D2B2DADD05DD4220A5950_AdjustorThunk,
	Rect_get_max_m3BFB033D741F205FB04EF163A9D5785E7E020756_AdjustorThunk,
	Rect_get_width_m54FF69FC2C086E2DC349ED091FD0D6576BFB1484_AdjustorThunk,
	Rect_set_width_mC81EF602AC91E0C615C12FCE060254A461A152B8_AdjustorThunk,
	Rect_get_height_m088C36990E0A255C5D7DCE36575DCE23ABB364B5_AdjustorThunk,
	Rect_set_height_mF4CB5A97D4706696F1C9EA31A5D8C466E48050D6_AdjustorThunk,
	Rect_get_size_m731642B8F03F6CE372A2C9E2E4A925450630606C_AdjustorThunk,
	Rect_set_size_m4618056983660063A74F40CCFF9A683933CB4C93_AdjustorThunk,
	Rect_get_xMin_mFDFA74F66595FD2B8CE360183D1A92B575F0A76E_AdjustorThunk,
	Rect_set_xMin_mD8F9BF59F4F33F9C3AB2FEFF32D8C16756B51E34_AdjustorThunk,
	Rect_get_yMin_m31EDC3262BE39D2F6464B15397F882237E6158C3_AdjustorThunk,
	Rect_set_yMin_m58C137C81F3D098CF81498964E1B5987882883A7_AdjustorThunk,
	Rect_get_xMax_mA16D7C3C2F30F8608719073ED79028C11CE90983_AdjustorThunk,
	Rect_set_xMax_m1775041FCD5CA22C77D75CC780D158CD2B31CEAF_AdjustorThunk,
	Rect_get_yMax_m8AA5E92C322AF3FF571330F00579DA864F33341B_AdjustorThunk,
	Rect_set_yMax_m4F1C5632CD4836853A22E979C810C279FBB20B95_AdjustorThunk,
	Rect_Contains_mAD3D41C88795960F177088F847509C9DDA23B682_AdjustorThunk,
	Rect_Contains_m5072228CE6251E7C754F227BA330F9ADA95C1495_AdjustorThunk,
	Rect_OrderMinMax_m1BE37D433FE6B7FB0FB73652E166A4FB887214CD,
	Rect_Overlaps_m2FE484659899E54C13772AB7D9E202239A637559_AdjustorThunk,
	Rect_Overlaps_m4FFECCEAB3FBF23ED5A51B2E26220F035B942B4B_AdjustorThunk,
	Rect_op_Inequality_mAF9DC03779A7C3E1B430D7FFA797F2C4CEAD1FC7,
	Rect_op_Equality_mFBE3505CEDD6B73F66276E782C1B02E0E5633563,
	Rect_GetHashCode_mA23F5D7C299F7E05A0390DF2FA663F5A003799C6_AdjustorThunk,
	Rect_Equals_m76E3B7E2E5CC43299C4BF4CB2EA9EF6E989E23E3_AdjustorThunk,
	Rect_Equals_mC8430F80283016D0783FB6C4E7461BEED4B55C82_AdjustorThunk,
	Rect_ToString_m045E7857658F27052323E301FBA3867AD13A6FE5_AdjustorThunk,
	RectInt_get_x_mF20D556E7923C4CFD7BB968287E81EEFC777E1AE_AdjustorThunk,
	RectInt_set_x_m789BBF9F6936E14405F20C659F103F23E8BE108E_AdjustorThunk,
	RectInt_get_y_m25B8B729B867E3A3B095763A9D44B4ACD82FA3FC_AdjustorThunk,
	RectInt_set_y_mB44F87E3B83ABA670CA1F8AF175B3C18F23E222A_AdjustorThunk,
	RectInt_get_width_mDA704D3EB9595731CBD251E57AADD56264D4A63A_AdjustorThunk,
	RectInt_set_width_m26A0E2678960FBCD030AF849842D6179B0D694C7_AdjustorThunk,
	RectInt_get_height_m72A9DC291C6C2B36646646FFCC9FBE5018DAC2BC_AdjustorThunk,
	RectInt_set_height_mEE6F6F740F5F0BC97D81EB8D707434517FD8E389_AdjustorThunk,
	RectInt__ctor_mF85AFBAF60C3270995656D8A05A002304D57B8E4_AdjustorThunk,
	RectInt_ToString_m8EB8256D9DD212E3949E2C3ED629B710731C89DA_AdjustorThunk,
	RectInt_Equals_m653C25536C79F1002A12DC2D8F69C714BEF3926F_AdjustorThunk,
	RectOffset__ctor_m4A29807F411591FC06BE9367167B8F417EF73828,
	RectOffset__ctor_m23620FE61AAF476219462230C6839B86736B80BA,
	RectOffset_Finalize_m69453D37706F46DD3A2A6F39A018D371A5E7072C,
	RectOffset_ToString_m6852E54822C1FACE624F3306DD9DC71628E91F93,
	RectOffset_Destroy_mE1A6BDB23EC0B1A51AD5365CEF0055F7856AA533,
	RectOffset_InternalCreate_m6638B085A0DA1CB1DA37B7C91CAC98DCF2CF7A16,
	RectOffset_InternalDestroy_m4FAB64D6AECF15082E19BDC4F22913152D5C6FA1,
	RectOffset_get_left_mA86EC00866C1940134873E3A1565A1F700DE67AD,
	RectOffset_get_right_m9B05958C3C1B31F1FAB8675834A492C7208F6C96,
	RectOffset_get_top_mBA813D4147BFBC079933054018437F411B6B41E1,
	RectOffset_get_bottom_mE5162CADD266B59539E3EE1967EE9A74705E5632,
	RectOffset_get_horizontal_m9274B965D5D388F6F750D127B3E57F70DF0D89C1,
	RectOffset_get_vertical_m89ED337C8D303C8994B2B056C05368E4286CFC5E,
	Gizmos_DrawIcon_m68377BABAC05C0DA18A2678D3B3AD6F574326275,
	Gizmos_DrawIcon_Injected_m4D9D38623FBCF115DC08EC5B3135CA16B04E8B5C,
	BeforeRenderHelper_Invoke_m5CADC9F58196CF3F11CB1203AEAF40003C7D4ADD,
	BeforeRenderHelper__cctor_mAF1DF30E8F7C2CE586303CAA41303230FE2DEB0D,
	Display__ctor_m1E66361E430C3698C98D242CEB6820E9B4FC7EB8,
	Display__ctor_mE84D2B0874035D8A772F4BAE78E0B8A2C7008E46,
	Display_get_renderingWidth_mA02F65BF724686D7A0CD0C192954CA22592C3B12,
	Display_get_renderingHeight_m1496BF9D66501280B4F75A31A515D8CF416838B0,
	Display_get_systemWidth_mA14AF2D3B017CF4BA2C2990DC2398E528AF83413,
	Display_get_systemHeight_m0D7950CB39015167C175634EF8A5E0C52FBF5EC7,
	Display_get_requiresBlitToBackbuffer_m18F968721D2394EA154886F0F7F8429171DE3415,
	Display_get_requiresSrgbBlitToBackbuffer_mC06CB63E2F9E0B46C765E4024AB934D6799F5062,
	Display_RelativeMouseAt_mABDA4BAC2C1B328A2C6A205D552AA5488BFFAA93,
	Display_get_main_mDC0ED8AD60BF5BC3C83384E9C5131403E7033AFA,
	Display_RecreateDisplayList_mA7E2B69AF4BD88A0C45B9A0BB7E1FFDDA5C60FE8,
	Display_FireDisplaysUpdated_m1655DF7464EA901E47BCDD6C3BBB9AFF52757D86,
	Display_GetSystemExtImpl_m946E5A2D11FC99291208F123B660978106C0B5C6,
	Display_GetRenderingExtImpl_m14405A2EC3C99F90D5CD080F3262BB7B4AC2BA49,
	Display_RelativeMouseAtImpl_mDC1A8A011C9B7FF7BC9A53A10FEDE8D817D68CDB,
	Display_RequiresBlitToBackbufferImpl_mBB4242A691C1957869352322174800929B4465A5,
	Display_RequiresSrgbBlitToBackbufferImpl_m238B00D35DE436ED16E3E0412C31E9C0136527F3,
	Display__cctor_mC1A1851D26DD51ECF2C09DBB1147A7CF05EEEC9D,
	DisplaysUpdatedDelegate__ctor_m976C17F642CEF8A7F95FA4C414B17BF0EC025197,
	DisplaysUpdatedDelegate_Invoke_mBCC82165E169B27958A8FD4E5A90B83A108DAE89,
	DisplaysUpdatedDelegate_BeginInvoke_m5DA06B0A901673F809EA597946702A73F9436BFF,
	DisplaysUpdatedDelegate_EndInvoke_m470B70745AF2631D69A51A3883D774E9B49DD2E2,
	Screen_get_width_m8ECCEF7FF17395D1237BC0193D7A6640A3FEEAD3,
	Screen_get_height_mF5B64EBC4CDE0EAAA5713C1452ED2CE475F25150,
	Screen_get_dpi_m92A755DE9E23ABA717B5594F4F52AFB0FBEAC1D3,
	Screen_get_fullScreenMode_m89BD87B3D0CB7D42B845E3DE1D36EFC5B3577115,
	Graphics_Internal_GetMaxDrawMeshInstanceCount_mB5F6508A9AB7DBEBC192C6C7BDEF872295FB9801,
	Graphics_get_activeTier_mC69EEB666BDB6DD90E0DD89D18179DBB54C25141,
	Graphics_GetPreserveFramebufferAlpha_mF3E90C35ECADF153C649949335E8B6CE215B1CC3,
	Graphics_get_preserveFramebufferAlpha_m39E2A13F37D33E13828A727957AFBBBEBB3C9CF6,
	Graphics_CopyTexture_Slice_m8633121E05B15579BA27F1E0892CDFED06EAAFBE,
	Graphics_CopyTexture_m9328A3205B2969652666FDA6054DF8395BC7355B,
	Graphics__cctor_m87F7D324CC82B1B70ADFEC237B2BBEDC1767F1FF,
	GL_GetGPUProjectionMatrix_mE662E5FB0439D4794169BA587BA480960AFADD3E,
	GL_GetGPUProjectionMatrix_Injected_mA3C07257B2C404BE78FC6E36CF0794414C70446E,
	ScalableBufferManager_get_widthScaleFactor_mABF8DAEDB2E92B657CF2CA67118E4B77A21EEBCC,
	ScalableBufferManager_get_heightScaleFactor_m7E3D9F0A90F159C41231FC60DC47CC696FC93C96,
	ScalableBufferManager_ResizeBuffers_m11AEC8322CFB1490B64F242438DE125D43B43FDF,
	Resolution_ToString_m42289CE0FC4ED41A9DC62B398F46F7954BC52F04_AdjustorThunk,
	QualitySettings_get_antiAliasing_m28EE8A60C753C1D160BB393D92D98CC0E1776B16,
	QualitySettings_set_antiAliasing_m0D256DE219D099724FADED02DA8ED7563412F3A5,
	QualitySettings_get_activeColorSpace_m13DBB3B679AA5D5CEA05C2B4517A1FDE1B2CF9B0,
	ImageEffectAllowedInSceneView__ctor_m7A0019F3F3121A17776CF2E017375BD003E5816C,
	MaterialPropertyBlock_CreateImpl_m24B31B00E85647888CE23025A887F670066C167A,
	MaterialPropertyBlock_DestroyImpl_m8BE5B07A016787E1B841496630E77F31243EF109,
	MaterialPropertyBlock_Clear_mEE49CDB81EC589B9797128CF99068C45AEF0532D,
	MaterialPropertyBlock_Clear_m6082C33086704A4A407BBEFD6E5C465E55BEE315,
	MaterialPropertyBlock__ctor_m9055A333A5DA8CC70CC3D837BD59B54C313D39F3,
	MaterialPropertyBlock_Finalize_m26F82696BBE81EC8910C0991AD7CFD9B4B26DA3D,
	MaterialPropertyBlock_Dispose_m3DED1CD5B678C080B844E4B8CB9F32FDC50041ED,
	Renderer_get_bounds_mB29E41E26DD95939C09F3EC67F5B2793A438BDB5,
	Renderer_get_sortingLayerID_m2E204E68869EDA3176C334AE1C62219F380A5D85,
	Renderer_get_sortingOrder_m33DD50ED293AA672FDAD862B4A4865666B5FEBAF,
	Renderer_get_bounds_Injected_mDC960C9F758AFCA774D4359860F9D188E00EA027,
	RenderSettings_get_subtractiveShadowColor_mB8C271901D1295E64E36C1627D6450CD2DBA14C5,
	RenderSettings_get_skybox_mB18548A547E6D62BBD82B0049BC9BA82E784EDF6,
	RenderSettings_get_sun_m6CF6A8CC535CB1EC64D85EF8BB7A31FDD6B0A349,
	RenderSettings_get_ambientProbe_mA0894D3DD7B43D3F52A6078E68EA5E57831C512E,
	RenderSettings_get_reflectionIntensity_m8340055281B6CEFF02994D4A8572302BCD59C214,
	RenderSettings_get_subtractiveShadowColor_Injected_m7351BE1097E219178C3173F571F7951BE87959F7,
	RenderSettings_get_ambientProbe_Injected_mDB78986D41A558628706617FA52A6E44FDBF5972,
	Shader_Find_m755654AA68D1C663A3E20A10E00CDC10F96C962B,
	Shader_get_isSupported_m3660681289CDFE742D399C3030A6CF5C4D8B030D,
	Shader_set_globalRenderPipeline_mDD57BC9253ECF13404F987D52A55A288817F3B21,
	Shader_EnableKeyword_m600614EB1D434CA8ECFC8DAA5BC6E2ED4E55CD9F,
	Shader_DisableKeyword_m2D15FB4C26535D9AF45445B4149EADD4BF68C701,
	Shader_TagToID_m0597E33DAA0FD822B2E10881E7740E42222A8392,
	Shader_PropertyToID_m831E5B48743620DB9E3E3DD15A8DEA483981DD45,
	Shader_SetGlobalVectorImpl_m2741D71F920CDE4F2416EFA61A3B44CA258348B7,
	Shader_SetGlobalMatrixImpl_mA5166FA119796B15645170AF95169C532C75B967,
	Shader_SetGlobalVector_m95C42CE1CC56A5BD792C48C60EDD1DF220046566,
	Shader_SetGlobalMatrix_mE9F00E107B245DEFB3210F00228F72F2BF2B8112,
	Shader__ctor_m6D011DE6D578D5F19FBF7EAED326C7209C419E21,
	Shader_SetGlobalVectorImpl_Injected_m163EB9DAE823DD5F7AD16969CA24DA6C2F130D1A,
	Shader_SetGlobalMatrixImpl_Injected_m52914EC8C70103DF40621F04ACD8975DCEBE3E67,
	Material_CreateWithShader_m41F159D25DC785C3BB43E6908057BB2BD1D2CB7F,
	Material_CreateWithMaterial_mD3140BCB57EBB406D063C7A7B0B9D1A4C74DA3F2,
	Material_CreateWithString_mCF4047522DD7D38087CF9AF121766E0D69B9BB55,
	Material__ctor_m81E76B5C1316004F25D4FE9CEC0E78A7428DABA8,
	Material__ctor_m0171C6D4D3FD04D58C70808F255DBA67D0ED2BDE,
	Material__ctor_m02F4232D67F46B1EE84441089306E867B1788924,
	Material_get_mainTexture_mE85CF647728AD145D7E03A172EFD5930773E514E,
	Material_GetFirstPropertyNameIdByAttribute_m34991F73A65FE72151842050D18EB3EC8969A8C2,
	Material_HasProperty_m901DE6C516A0D2C986B849C7B44F679AE21B8927,
	Material_HasProperty_m8611FACA6F9D9B2B5C3E92B6D93D2D514B443512,
	Material_EnableKeyword_m7466758182CBBC40134C9048CDF682DF46F32FA9,
	Material_DisableKeyword_m2ACBFC5D28ED46FF2CF5532F00D702FF62C02ED3,
	Material_SetShaderKeywords_m32714E17C5D17AAE15927F89624416E14B044A82,
	Material_set_shaderKeywords_m336EBA03D542BE657FEBDD62C7546568CD3081C9,
	Material_SetFloatImpl_mFD6022220F625E704EC4F27691F496166E590094,
	Material_SetColorImpl_m0779CF8FCCFC298AAF42A9E9FF6503C9FDC43CFE,
	Material_SetMatrixImpl_mAC50A1E655FF577F6AEB3C67F14DAE7D1AA60C4B,
	Material_SetTextureImpl_mBCF204C1FAD811B00DBAE98847D6D533EE05B135,
	Material_GetTextureImpl_m19D8CE6C5701AC4B69A6D5354E08240DF6C036D2,
	Material_SetFloat_m4B7D3FAA00D20BCB3C487E72B7E4B2691D5ECAD2,
	Material_SetFloat_mC2FDDF0798373DEE6BBA9B9FFFE03EC3CFB9BF47,
	Material_SetInt_m1FCBDBB985E6A299AE11C3D8AF29BB4D7C7DF278,
	Material_SetInt_m8D3776E4EF0DFA2A278B456F40741E07D83508CD,
	Material_SetVector_m95B7CB07B91F004B4DD9DB5DFA5146472737B8EA,
	Material_SetMatrix_mE3D3FA75DA02FED1B97E2BECA258F45399715764,
	Material_SetTexture_m4FFF0B403A64253B83534701104F017840142ACA,
	Material_GetTexture_mCD6B822EA19773B8D39368FF1A285E7B69043896,
	Material_GetTexture_mDB1B89D76D44AD07BD214224C59A6FE0B62F6477,
	Material_SetColorImpl_Injected_mEE762DBD0B37ACA313061179B3CB767B59E4B0FB,
	Material_SetMatrixImpl_Injected_mD2486E408D7547B08CC36A2DE70520F97A68529C,
	Light_get_type_m24F8A5EFB5D0B0B5F4820623132D1EAA327D06E3,
	Light_get_spotAngle_m1EAB341E449675D41E86A63F047BF3ABE2B99C3B,
	Light_get_innerSpotAngle_m663952080C39817A16E86C1E8FD9F4A4538B6B7C,
	Light_get_color_m7A83B30FE716A1A931D450A6035A0069A2DD7698,
	Light_get_intensity_m4E9152844D85D03FEDA5AE4599AFAFC3C66EFF23,
	Light_get_bounceIntensity_m9185F30A7DED7FB480B1026B2CC6DBA357FAE9A7,
	Light_get_shadowBias_mFB01780F645A252821DA6F126E2F72384E18F140,
	Light_get_shadowNormalBias_m021AD7A43D53CE417DC4EB7E647D84CBCB6E17EB,
	Light_get_shadowNearPlane_m4AA787C5BCB1A12A7E512D5FB2CFEA81C78D6EE0,
	Light_get_range_m3AA5F21DB9441E888A0E89C465F928445150061A,
	Light_get_bakingOutput_mE447036D9B09ADED8D4244DF0155092D5BB32917,
	Light_get_shadows_m8FBBEDB8C442B0426E5D3E457330AA81D764C8F2,
	Light_get_shadowStrength_mB46E58530AF939421D198670434F15D331BFB672,
	Light__ctor_m23741EFAFF3A57B788747187A39CDA35A57A913E,
	Light_get_color_Injected_m266FA6B59B6A43AE5C2717FE58D91E93626D48DE,
	Light_get_bakingOutput_Injected_m376A3C0E44091FC917D7A44B9905AAC8D2789C15,
	MeshFilter_DontStripMeshFilter_m7FBA33F8214DB646F74E00F7CEFFDF2D0018004C,
	MeshRenderer_DontStripMeshRenderer_mC5359CA39BA768EBDB3C90D4FAE999F4EB1B6B24,
	Mesh_Internal_Create_mF1F8E9F726EAC9A087D49C81E2F1609E8266649E,
	Mesh__ctor_m3AEBC82AB71D4F9498F6E254174BEBA8372834B4,
	Mesh_GetIndicesImpl_m2118C6CA196093FD19BB05E5258C0DCE06FEAD30,
	Mesh_SetIndicesImpl_m05B1C648F5E02990B89D1FFF002F5D5672779D8B,
	Mesh_PrintErrorCantAccessChannel_m2E8A25959739B006557A94F7E460E8BE0B3ABB19,
	Mesh_HasVertexAttribute_m87C57B859ECB5224EEB77ED9BD3B6FF30F5A9B1C,
	Mesh_SetArrayForChannelImpl_m6FDE8B55C37DC1828C0041DDA3AD1E6D2C028E6C,
	Mesh_GetAllocArrayFromChannelImpl_mFDE324953466F6DBAC14CD4B48105B62181CC399,
	Mesh_get_canAccess_m1E0020EA7961227FBC0D90D851A49BCF7EB1E194,
	Mesh_get_subMeshCount_m6BE7CFB52CE84AEE45B4E5A704E865954397F52F,
	Mesh_ClearImpl_mFFD3A4748AF067B75DBD646B4A64B3D9A2F3EE14,
	Mesh_RecalculateBoundsImpl_m43DE3DEFC2DADC090DC6FD2C27F44D6DBB88CEF6,
	Mesh_UploadMeshDataImpl_m1D48BFFC3E32EAD6D206C1DBFD8E2D23B63425D7,
	Mesh_GetUVChannel_m15BB0A6CC8E32867621A78627CD5FF2CAEA163CC,
	Mesh_DefaultDimensionForChannel_mF943AF434BB9F54DBB3B3DE65F7B816E617A89C9,
	NULL,
	NULL,
	Mesh_SetSizedArrayForChannel_mBBB7F5AE4D5A5A6D5794742745385B02B13E082D,
	NULL,
	NULL,
	NULL,
	Mesh_get_vertices_m7D07DC0F071C142B87F675B148FC0F7A243238B9,
	Mesh_set_vertices_mC1406AE08BC3495F3B0E29B53BACC9FD7BA685C6,
	Mesh_get_normals_m3CE4668899836CBD17C3F85EB24261CBCEB3EABB,
	Mesh_set_normals_m4054D319A67DAAA25A794D67AD37278A84406589,
	Mesh_get_tangents_mFF92BD7D6EBA8C7EB8340E1529B1CB98006F44DD,
	Mesh_set_tangents_mE66D8020B76E43A5CA3C4E60DB61CD962D7D3C57,
	Mesh_get_uv_m0EBA5CA4644C9D5F1B2125AF3FE3873EFC8A4616,
	Mesh_set_uv_m56E4B52315669FBDA89DC9C550AC89EEE8A4E7C8,
	Mesh_get_uv2_m3E70D5DD7A5C6910A074A78296269EBF2CBAE97F,
	Mesh_get_uv3_mC56484D8B69A65DA948C7F23B06ED490BCFBE8B0,
	Mesh_get_uv4_m1C5734938A443D8004339E8D8DDDC33B3E0935F6,
	Mesh_set_colors_m704D0EF58B7AED0D64AE4763EA375638FB08E026,
	Mesh_get_colors32_m24C6C6BC1A40B7F09FF390F304A96728A4C99246,
	Mesh_SetVertices_m5F487FC255C9CAF4005B75CFE67A88C8C0E7BB06,
	Mesh_SetVertices_mCFFD77B857B3041D407D4EB6BEA3F4FC8F258655,
	Mesh_SetNormals_m76D71A949B9288FA8ED17DDADC530365307B9797,
	Mesh_SetNormals_m2D6A6379F1C1E974C155DFD0E59812316B17F6B2,
	Mesh_SetTangents_m6EEAB861C9286B1DA4935B87A883045ADD3955E5,
	Mesh_SetTangents_m2C28E9ED06F035D4F726DA8F8782F75B81AF1BF9,
	Mesh_SetColors_m237E41213E82D4BB882ED96FD81A17D9366590CF,
	Mesh_SetColors_m7F5D50EA329435A03C41DCF4A6CFAB57504FAAAF,
	NULL,
	Mesh_SetUVs_m0210150B0387289B823488D421BDF9CBF9769116,
	Mesh_SetUVs_m5E152C09C814455B8A8FB6672ACD15C0D6804EC5,
	Mesh_PrintErrorCantAccessIndices_mA45D3609288655A328AEB0F2F436403B1ECE5077,
	Mesh_CheckCanAccessSubmesh_mF86EBD1C9EC3FE557880FA138510F7761585D227,
	Mesh_CheckCanAccessSubmeshTriangles_m214B5F30F7461C620D03F10F6CF1CAF53DBEE509,
	Mesh_CheckCanAccessSubmeshIndices_m81DF83B1676084AF0B70A36BC7621ADB08430722,
	Mesh_set_triangles_m143A1C262BADCFACE43587EBA2CDC6EBEB5DFAED,
	Mesh_GetIndices_m2FD8417547E7595F590CE55D381E0D13A8D72AA5,
	Mesh_GetIndices_m4260DCF1026449C4E8C4C40229D12AF8CAB26EAF,
	Mesh_CheckIndicesArrayRange_m6DEDA2715437F79DAC8BD7F818B5B2DBAD9BFEBE,
	Mesh_SetTrianglesImpl_m0AD2B3D12113B5E82AC9E29D2C6308E7410E2B98,
	Mesh_SetTriangles_m6A43D705DE751C622CCF88EC31C4EF1B53578BE5,
	Mesh_SetTriangles_m39FB983B90F36D724CC1C21BA7821C9697F86116,
	Mesh_SetTriangles_mBD39F430A044A27A171AD8FD80F2B9DDFDB4A469,
	Mesh_SetIndices_m18C0006CF36C43FF16B1917099E2970C2D4145BD,
	Mesh_SetIndices_m84F3CDB60B5C8FA4374B83E3F77C9DAA4C946BCF,
	Mesh_SetIndices_mFE6F2769EF170F0CD84C739E96976A15052B7024,
	Mesh_SetIndices_m5E72EA4BED8BA7B0732E80227199026B1CD9B6C5,
	Mesh_Clear_mB750E1DCAB658124AAD81A02B93DED7601047B60,
	Mesh_RecalculateBounds_m1BF701FE2CEA4E8E1183FF878B812808ED1EBA49,
	Mesh_UploadMeshData_m809A98624475785C493269B72EC6C41B556759A1,
	Texture__ctor_m19850F4654F76731DD82B99217AD5A2EB6974C6C,
	Texture_get_graphicsFormat_m4169EBAA431C6A3FFF2CA66C83B4659E2CAA4194,
	Texture_GetDataWidth_m862817D573E6B1BAE31E9412DB1F1C9B3A15B21D,
	Texture_GetDataHeight_m3E5739F25B967D6AF703541F236F0B1F3F8F939E,
	Texture_GetDimension_m823F205A9A9A8416E745A322D0C86851BF4C85C3,
	Texture_get_width_mEF9D208720B8FB3E7A29F3A5A5C381B56E657ED2,
	Texture_set_width_m9E42C8B8ED703644B85F54D8DCFB51BF954F56DA,
	Texture_get_height_m3A004CD1FA238B3D0B32FE7030634B9038EC4AA0,
	Texture_set_height_m601E103C6E803353701370B161F992A5B0C89AB6,
	Texture_get_dimension_m9BFA811A908673794B77310CADF1FF86B388A5FF,
	Texture_set_dimension_mC2221B460AB7728D06B94DCE6B83FFA93ACF68E9,
	Texture_get_isReadable_mFB3D8E8799AC5EFD9E1AB68386DA16F3607631BD,
	Texture_get_wrapMode_mC21054C7BC6E958937B7459DAF1D17654284B07A,
	Texture_set_wrapMode_m85E9A995D5947B59FE13A7311E891F3DEDEBBCEC,
	Texture_set_filterMode_mB9AC927A527EFE95771B9B438E2CFB9EDA84AF01,
	Texture_set_anisoLevel_mD2F6FE80CC33E408368734983EBA1463BB2D5712,
	Texture_set_mipMapBias_m38BD81110AE2AA28186242FF551691BC83AB8354,
	Texture_get_texelSize_m89BA9E4CF5276F4FDBAAD6B497809F3E6DB1E30C,
	Texture_ValidateFormat_m23ED49E24864EE9D1C4EF775002A91EE049561B1,
	Texture_ValidateFormat_mA62E75B693BFABECB7CB732C165139B8492DE0ED,
	Texture_CreateNonReadableException_m66E69BE853119A5A9FE2C27EA788B62BF7CFE34D,
	Texture__cctor_m63D3A3E79E62355737DCF71786623D516FAA07E1,
	Texture_get_texelSize_Injected_m812BEA61C30039FF16BE6A2E174C81DCB40000DE,
	Texture2D_get_format_mF0EE5CEB9F84280D4E722B71546BBBA577101E9F,
	Texture2D_get_whiteTexture_mF447523DE8957109355641ECE0DD3D3C8D2F6C41,
	Texture2D_get_blackTexture_mCF4F978DF9B6066794E7130E0C14618216ED0956,
	Texture2D_Internal_CreateImpl_mE77AB26318BC128ABD08D138FD3EF3A9954F8A5C,
	Texture2D_Internal_Create_mC33D3C13F046ADDAF417534E99A741FCF96538B1,
	Texture2D_get_isReadable_mCF446A169E1D8BF244235F4E9B35DDC4F5E696AD,
	Texture2D_ApplyImpl_mEFE072AD63B1B7B317225DAEDDB1FF9012DB398B,
	Texture2D_SetPixelImpl_m62B6A2252516D1D5E09701BA550D72ACB79E328B,
	Texture2D_GetPixelBilinearImpl_m950AB40E4151F10B6AA6C5759903BA07348114FB,
	Texture2D_SetPixelsImpl_m8102FB784092E318608E2BC2BB92A82D1C0C9AD1,
	Texture2D__ctor_mB33D5D6E83136BF8A42D2628405B10BE0889F439,
	Texture2D__ctor_m01B7AF7873AA43495B8216926C1768FEDDF4CE64,
	Texture2D__ctor_m22561E039BC96019757E6B2427BE09734AE2C44A,
	Texture2D_SetPixel_m8BE87C152447B812D06CB894B3570269CC2DE7C3,
	Texture2D_SetPixels_mC768DC908606FE162BF77A8761AD3ED7BAC1612C,
	Texture2D_SetPixels_mDE50229135F49F323D265340C415D680CCB2FB92,
	Texture2D_GetPixelBilinear_m3E0E9A22A0989E99A7295BC6FE6999728F290A78,
	Texture2D_Apply_mCC17B1895AEB420CF75B1A50A62AB623C225A6C1,
	Texture2D_Apply_m0F3B4A4B1B89E44E2AF60ABDEFAA18D93735B5CA,
	Texture2D_SetPixelImpl_Injected_m21934648C4DE2227463F16A67EFA3DC740682ACC,
	Texture2D_GetPixelBilinearImpl_Injected_m120BD9810D176C39E874FFDAF53AD3AC3B6ADF85,
	Cubemap_Internal_CreateImpl_m2E42502B311D4511987453F591F469EFD3D46C7E,
	Cubemap_Internal_Create_m7D1672F9247A6CA2578874A69C901311B6196289,
	Cubemap_ApplyImpl_m685B04A32C22E02263439BCAB68D1485427874F6,
	Cubemap_get_isReadable_m97956094F4DBC9C67A86AEC8CCE73AB237694121,
	Cubemap_SetPixelImpl_mE574550B3ED1AAD204EA189CDF534B3B2BC17671,
	Cubemap__ctor_mA198007748E1B40309793BFD41C6DA8506BFC36E,
	Cubemap__ctor_mC713C6EC5AA4BB7091AF19FC75E1A5D3A133550B,
	Cubemap__ctor_m823CBFD84E8497FEEDE6858F1781ADECB0C6CFBF,
	Cubemap__ctor_mDEAB11F63268FC5F1115D928499AC270F21FB249,
	Cubemap__ctor_mFC82AF58FF4875D6750838AF47A05D5B203523A8,
	Cubemap__ctor_m619C9524BF966423D2DE66E878C824113616C371,
	Cubemap__ctor_mB0430DC19209C90736915B41A670C7AC65698D71,
	Cubemap_SetPixel_m84EC07CAB35F83FF229C83E4FCE5257EC64D131A,
	Cubemap_Apply_mEED93FB138644F26274EC7A9E91E996178E5492B,
	Cubemap_Apply_mDC3AC8509F8B673A1D3B4D05A1C2BBAA78848446,
	Cubemap_SetPixelImpl_Injected_mDB88DCC7521A128F118EA17598E3FFC92143A62C,
	Texture3D_get_isReadable_m2793D34A645AA2A88B903D7C0CBC05BC180A489F,
	Texture3D_Internal_CreateImpl_m6B7F1E0A4F0A8DF201C84B8F5EBE88F5BC2D0ED5,
	Texture3D_Internal_Create_mCE8880719B54D2E8426234438DF2BA893B16CAA5,
	Texture3D_ApplyImpl_mF64D926DEC8B3F84C5D45679455C0535723CF51A,
	Texture3D_SetPixels_m800F0485825F86CBABB48AB5C0F5B178DDCDB4AE,
	Texture3D__ctor_m3819CE6527C761C3514E46566BAE8D09CEE6C6C0,
	Texture3D__ctor_m080D4201C72C73ECB718F44491858309CDCCBF40,
	Texture3D__ctor_m9FB382B0BC5C568B195C9E27E7BCA34C108F5FF7,
	Texture3D__ctor_m13ADB707E9EA6970AE5D6A5DDF8A5DAAD88DD2B0,
	Texture3D__ctor_m7086160504490544C327FF1C7823830B44441466,
	Texture3D_Apply_m7E14DDF5C1A548E55424048088F9FD2283A314F0,
	Texture3D_Apply_m9EF036FDBCD9DC9DE056689D47FF5D4224D86074,
	Texture2DArray_get_allSlices_mF7A27FED8FB4B534155070AF350A8DB4DB1E50CC,
	Texture2DArray_get_isReadable_mB2E454ED94BB334E77B42E6CD9DABC0B1D679C1A,
	Texture2DArray_Internal_CreateImpl_mF6D0DD31CE06DB61D0E3C8D875F20692B33C776E,
	Texture2DArray_Internal_Create_m53A30DE93DCDA75588C999A967F8004AB0EE113F,
	Texture2DArray__ctor_m92A39957ECC1DBE79437D3849A1FA7A98615A9F0,
	Texture2DArray__ctor_mD92521FF6DA05FF47471B741DDC7E4D5B3C3F4E2,
	Texture2DArray__ctor_mF94531ED3A27A6583DCACE742D6D6A56C3B1CB76,
	Texture2DArray__ctor_m982669D0408998D2038575A421440A8D537D67E6,
	Texture2DArray__ctor_mEDE73B65A89EACA4B487FFBA92B155ED5B09970F,
	Texture2DArray__ctor_mE0F6B7F60470C479258E1CC295456BCA103E66BF,
	CubemapArray_get_isReadable_mBE24F088422FA9FE007086C36C7D16A6D6377919,
	CubemapArray_Internal_CreateImpl_mDA1FF7D490A441C86198448B72B62C2D38B9A046,
	CubemapArray_Internal_Create_m2503EFCE0A71CBCCCA87C93E15B9F83709274A58,
	CubemapArray_ApplyImpl_mBA3A00B7915C7E6E8CA85D7B39FD9D145E12E383,
	CubemapArray_SetPixels_m68601785D408414D206F01EBB351F0A0361DF503,
	CubemapArray_SetPixels_m614E9EADABB21CCA01EECA6FE0D38713D279A27F,
	CubemapArray__ctor_m44E378D2D09F711CF0AEF479DC7D12426C449CF6,
	CubemapArray__ctor_m390539598EAAEE1AAE0B89D2241A60EE6BD1B219,
	CubemapArray__ctor_m88D0AB083EEF112A636EE307337BAFAF036E0A2B,
	CubemapArray__ctor_m1FC2738B93636229EC645E15D36C9A3F67FE0E54,
	CubemapArray__ctor_mE9E5A417064CB9CF4283C8A82F4AE5C463C4014E,
	CubemapArray__ctor_mD52A7D884A01A8DF05B40D820584C1F3869317AC,
	CubemapArray_Apply_mAA584F103CAA850A51C0099E34633337116BF919,
	CubemapArray_Apply_m37532D4ADC2C693BED0B279303B0C316A2BBE7BF,
	RenderTexture_get_width_m246F1304B26711BE9D18EE186F130590B9EDADDB,
	RenderTexture_set_width_m10EF29F6167493A1C5826869ACB10EA9C7A5BDCE,
	RenderTexture_get_height_m26FBCCE11E1C6C9A47566CC4421258BAF5F35CE6,
	RenderTexture_set_height_m4402FEFDF6D35ABE3FBA485FE9A144FB4204B561,
	RenderTexture_get_dimension_m63E0A3DC2C36BF788682CA938338EE88AAEA68DB,
	RenderTexture_set_dimension_m946594E580FC4E1D4D07050C981350FDF1ACFECB,
	RenderTexture_get_graphicsFormat_mE0A181AB88D5E381CD945440A67187929328382E,
	RenderTexture_set_graphicsFormat_mF60798F07D5994C46C53826F8A8F2E553B8F85CF,
	RenderTexture_get_useMipMap_mF9C82146D1CC2D08645CA990FC8D533F9D9D73AE,
	RenderTexture_set_useMipMap_m5C5D90A9CA6125C21536E945890A84B7B7560D51,
	RenderTexture_get_sRGB_m73E0F48DF924CBD308CD2B34E2B410E299F47B6A,
	RenderTexture_set_memorylessMode_m9C1C6EB31B28619D92243DD865BD8C9DC0D0546A,
	RenderTexture_get_format_mC500BCC10B2A6D6808645B505DB510056516D1FF,
	RenderTexture_set_stencilFormat_m1879238C289901C8C8A818FF70005104145CE54C,
	RenderTexture_set_autoGenerateMips_mD2592BAF6AB49EB936DF81BB118E5324F3C18085,
	RenderTexture_get_volumeDepth_m8F15924EC6BAA5B422E44AEA6C385F5ADA2A0C51,
	RenderTexture_set_volumeDepth_mF0FE016DC6C99C4901BE79291E15DB8415406672,
	RenderTexture_get_antiAliasing_mD49E94DED64C07E6855967E5B04A77F06AC9EEEF,
	RenderTexture_set_antiAliasing_mBE37447FA23E0D57731C1456165E03303EC9B559,
	RenderTexture_set_bindTextureMS_mCEE784272C9FB149DB3E3FEBCE3E98900B26E975,
	RenderTexture_set_enableRandomWrite_mFD4FF62C1DFC56BDAB62D86ACDCAA61030DAB2FD,
	RenderTexture_set_useDynamicScale_mF64047DE064AC493C6F178198B022FD2AD728A4E,
	RenderTexture_Create_mD0960B8843B57D80B9B956D6D36E3338C46B9F41,
	RenderTexture_Release_m8CB0AC4A96E59F351807F2011EC2E8EC8C933FC5,
	RenderTexture_SetSRGBReadWrite_mD553522060790CB4984886D2508B79897C3DC2DE,
	RenderTexture_Internal_Create_m924B30E7AFD36150F0279057C3A3869D94D7646A,
	RenderTexture_SetRenderTextureDescriptor_mF584353E0834F202C955EAC6499CBD0C6A571527,
	RenderTexture_GetDescriptor_mBDAE7C44038663205A31293B7C4C5AE763CD1128,
	RenderTexture_GetTemporary_Internal_mCEA100492B9216DC823FB449EBFB71B15126E026,
	RenderTexture_ReleaseTemporary_mFBA6F18138965049AA901D62A0080B1A087A38EA,
	RenderTexture_set_depth_mD4BCB0A9251B7FCF570459A705E03FFFEA4DB3B0,
	RenderTexture__ctor_mFB50DBD262C99B38016F518AA0FBF753FE22D13A,
	RenderTexture__ctor_mEC30DF610263D5A16EC16E34BD86AD4BC0C87A9B,
	RenderTexture__ctor_m3B3534A6C9696C5CB12ADC78F922237F69CEA33A,
	RenderTexture__ctor_mBAE127BF530990C9C8DBF5E155BA05A068777129,
	RenderTexture__ctor_m7C2F727F747019FC14CF7FB5FF5C29A349F9FCD9,
	RenderTexture__ctor_m2DD279268931EC6E725CAB584DC7D499E4BDCB82,
	RenderTexture__ctor_m32060CA5A5C306C485DB6AF9B9050B2FF2AB3A4C,
	RenderTexture__ctor_m0FF5DDAB599ED301091CF23D4C76691D8EC70CA5,
	RenderTexture__ctor_mB54A3ABBD56D38AB762D0AB8B789E2771BC42A7D,
	RenderTexture__ctor_mDB3D67FD662C79D27F0C42C6DBA1A7EFF80C2D1E,
	RenderTexture_get_descriptor_m67E7BCFA6A50634F6E3863E2F5BA1D4923E4DD00,
	RenderTexture_set_descriptor_m88048ECD2E447B3549D59032F5F9B52D4CA3D528,
	RenderTexture_ValidateRenderTextureDesc_mE4BA319BF91FCA90B517EF080E84EE395A4EAD01,
	RenderTexture_GetCompatibleFormat_m1C84A2875CC17182DEB4CC7EF277E7089B160095,
	RenderTexture_GetTemporary_m8E85E142DCF332F8F7250E7B6495964D0BF35D25,
	RenderTexture_GetTemporaryImpl_mEBD2063A0B8EBB410018015230D7C40458575F18,
	RenderTexture_GetTemporary_m6E0EF85D2DEC0626DE5BB5D008A659F1CD66D9F8,
	RenderTexture_SetRenderTextureDescriptor_Injected_m72AC0A28D6BF9041721D95E43BAC302A56C99019,
	RenderTexture_GetDescriptor_Injected_m9A137437A3EAD31E2AE4BC123329BF3945B22A64,
	RenderTexture_GetTemporary_Internal_Injected_m120A90D9E06335E3DED4581D48BC18F0E9F1006A,
	RenderTextureDescriptor_get_width_m225FBFD7C33BD02D6879A93F1D57997BC251F3F5_AdjustorThunk,
	RenderTextureDescriptor_set_width_m48ADD4AB04E8DBEEC5CA8CC96F86D2674F4FE55F_AdjustorThunk,
	RenderTextureDescriptor_get_height_m947A620B3D28090A57A5DC0D6A126CBBF818B97F_AdjustorThunk,
	RenderTextureDescriptor_set_height_mD19D74EC9679250F63489CF1950351EFA83A1A45_AdjustorThunk,
	RenderTextureDescriptor_get_msaaSamples_mEBE0D743E17068D1898DAE2D281C913E39A33616_AdjustorThunk,
	RenderTextureDescriptor_set_msaaSamples_m5856FC43DAD667D4462B6BCA938B70E42068D24C_AdjustorThunk,
	RenderTextureDescriptor_get_volumeDepth_mBC82F4621E4158E3D2F2457487D1C220AA782AC6_AdjustorThunk,
	RenderTextureDescriptor_set_volumeDepth_mDC402E6967166BE8CADDA690B32136A1E0AB8583_AdjustorThunk,
	RenderTextureDescriptor_set_mipCount_m98C1CE257A8152D8B23EC27D68D0C4C35683DEE5_AdjustorThunk,
	RenderTextureDescriptor_get_graphicsFormat_mD2DD8AC2E1324779F8D497697E725FB93341A14D_AdjustorThunk,
	RenderTextureDescriptor_set_graphicsFormat_mF24C183BA9C9C42923CEC3ED353661D54AA741CA_AdjustorThunk,
	RenderTextureDescriptor_get_colorFormat_m5BC2FC0A958FA5B820C82DA8E166BAEF20C481D6_AdjustorThunk,
	RenderTextureDescriptor_set_colorFormat_m26BBE54C0CD58DE267331FED099D449D47801858_AdjustorThunk,
	RenderTextureDescriptor_get_sRGB_mB06940B9BE55946E7E8CCEF912EBA1888FA93B3D_AdjustorThunk,
	RenderTextureDescriptor_set_sRGB_m19974099678BC320DA80ED60E71E1F46DAE5426F_AdjustorThunk,
	RenderTextureDescriptor_get_depthBufferBits_m51E82C47A0CA0BD8B20F90D43169C956C4F24996_AdjustorThunk,
	RenderTextureDescriptor_set_depthBufferBits_mED58A8D9643740713597B0244BF76D0395C1C479_AdjustorThunk,
	RenderTextureDescriptor_get_dimension_mCFB2C2CD795A0C0482F4A5B9E3F9E52D42027B5C_AdjustorThunk,
	RenderTextureDescriptor_set_dimension_mBC3C8793345AC5E627BDD932B46A5F93568ACCE5_AdjustorThunk,
	RenderTextureDescriptor_set_shadowSamplingMode_m0AC43F8A8BE0755567EED4DDFADBE207739E1ECF_AdjustorThunk,
	RenderTextureDescriptor_set_vrUsage_mC591604135749B0BD156865141E114F51812E502_AdjustorThunk,
	RenderTextureDescriptor_set_memoryless_m1FB3F7E8B482C71BDB549AD71D762BCF337D8185_AdjustorThunk,
	RenderTextureDescriptor__ctor_m8F804E105E65451663825D24C55B3660AC598696_AdjustorThunk,
	RenderTextureDescriptor__ctor_mC2F88C9BE0407671CD463877068A9194158ACBFB_AdjustorThunk,
	RenderTextureDescriptor__ctor_m227EBED323830B1059806874C69E1426DDC16B85_AdjustorThunk,
	RenderTextureDescriptor_SetOrClearRenderTextureCreationFlag_m387E338D17ED601B0587EF4E5CEB10DDFC42CC05_AdjustorThunk,
	RenderTextureDescriptor_set_useMipMap_m6945F823439A1355129CD99358F5CD2514823D8E_AdjustorThunk,
	RenderTextureDescriptor_set_autoGenerateMips_m65E46C31C8A8F4942AFD3605111D19367E6B52E5_AdjustorThunk,
	RenderTextureDescriptor_set_enableRandomWrite_m40E4833717B6D9AB1E4DABD4F5AD31C31077055E_AdjustorThunk,
	RenderTextureDescriptor_set_bindMS_m7585E1C1850022AE4B139C6DB5FB59913F7D8B9D_AdjustorThunk,
	RenderTextureDescriptor_set_createdFromScript_m1AD9EEA1A2C28F445C710EF281970A180FF5EDA2_AdjustorThunk,
	RenderTextureDescriptor_set_useDynamicScale_m7DA7110A51900A67962FB0839833928B20F64BE7_AdjustorThunk,
	RenderTextureDescriptor__cctor_mA5675E6684E1E8C26E848D2390FB2ABE8E3C11FD,
	Hash128__ctor_m600462667D7BE3F6E017E8ECDF6242A525F3FD8E_AdjustorThunk,
	Hash128_get_u64_0_m5EA1CF70752F0A303C01B0F9CE819FC8490390DB_AdjustorThunk,
	Hash128_get_u64_1_m163DB2AB90204E672FB6F09DD8F5A28FBAE15036_AdjustorThunk,
	Hash128_CompareTo_m0BC4F8F4228CF2B48C615E39CD3CE260386CC5BC_AdjustorThunk,
	Hash128_ToString_mD81890597BCFD67BE47646DA5366347C545EB5E8_AdjustorThunk,
	Hash128_Internal_Hash128ToString_m0C8F22C98723DA1488DC4FC86886662AC030E798,
	Hash128_Equals_m4701FDD64B5C5F81B1E494D5586C5CB4519BC007_AdjustorThunk,
	Hash128_Equals_m85BCDD87EB2A629FB8BB72FD63244787BC47E52D_AdjustorThunk,
	Hash128_GetHashCode_m65DA1711C64E83AB514A3D498C568CB10EAA0D69_AdjustorThunk,
	Hash128_CompareTo_m3595697B0FC7ACAED77C03FEC7FF80A073A4F6AE_AdjustorThunk,
	Hash128_op_Equality_m77950F7840A081CBFE1D01A2B72DA521A4AF5065,
	Hash128_op_LessThan_m2F98815644822762B642B483F79A72CFB4BADB39,
	Hash128_op_GreaterThan_m1B6A95E0C9A75EE36E33D0E75ADB0D1872B843A1,
	Hash128_Internal_Hash128ToString_Injected_m6B07AAF4C1F86D9B7E482FD030AFB9CB15527583,
	HashUtilities_AppendHash_m925038D55CA5EDF96EEE6C3F4F7A7495C45BBB9B,
	HashUnsafeUtilities_ComputeHash128_m87F6E52DA65D183D96B903F2A8B5D0DDC9513042,
	HashUnsafeUtilities_ComputeHash128_mFD8128869575343C3B3D61E6D9D387065F2FEC50,
	SpookyHash_AttemptDetectAllowUnalignedRead_m16DAF389E8D6613FEFD72496B7EA1F816502D01E,
	SpookyHash_Hash_m412D286990E0C1CF2C53709BF8D195FB75C027AE,
	SpookyHash_End_m3965A09BB1DDE0E6DA8154A0F3DC5331BB9B1791,
	SpookyHash_EndPartial_mCF833335448A20FC7BD032F684BC8CCEDA2CF263,
	SpookyHash_Rot64_mF3D9A87021715ED95DA32FCDBFB009111F8E4C33,
	SpookyHash_Short_m6DD9B8A72AD13F6CA1A273A959C9B9844F9F0B22,
	SpookyHash_ShortMix_m30CA9B50F80B2A28C41E1778AE673150B8A1EE12,
	SpookyHash_ShortEnd_m0A83C3EDC139579B3CE4E899263237EB6CD45F14,
	SpookyHash_Mix_mC591F4B57A475E0BDA906AA873A6C3611EE07213,
	SpookyHash_memset_m3D0988877733DBBE392E56D257C6BFCFF1277316,
	SpookyHash__cctor_m846879BD0451CCED57A97386509A49F9A78236BC,
	U__ctor_mA51EB7CBBF4D6A6B4F2687CD280D0DEC08D3BA6F_AdjustorThunk,
	Cursor_set_visible_mDB51E60B3D7B14873A6F5FBE5E0A432D4A46C431,
	Cursor_get_lockState_mE0C93F496E3AA120AD168ED30371C35ED79C9DF1,
	Cursor_set_lockState_m019E27A0FE021A28A1C672801416ACA5E770933F,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Logger__ctor_m447215F90AA8D1508924BFB1CD1E49AFCCE04FFE,
	Logger_get_logHandler_m0C450B6FE86FA1B07422A1359CF278D1F5945CCD,
	Logger_set_logHandler_m891099050CB8C36A01ECA861E4820441B7080C73,
	Logger_get_logEnabled_m5AE50375671516B8E1171838E34C63C3A326E927,
	Logger_set_logEnabled_m3CEBD8A4B6DC548168EC38CFC5CB982222DB655F,
	Logger_get_filterLogType_mD850DE3FD8CC67E4B076FCC6B05F8FA603B5B38B,
	Logger_set_filterLogType_m1829D8E1B8350B8CFCE881598BABB2AA1826EE72,
	Logger_IsLogTypeAllowed_m7B2A793443A642C8CA0759D1DD0FBDFAED4E1FCB,
	Logger_GetString_m0078CBA4ADAE877152C264A4BEA5408BAB1DC514,
	Logger_Log_m653FDC5B68CB933887D8886762C7BBA75243A9AF,
	Logger_Log_mE06FF98F674C73E4BB67302E1EEDEA72F7655FF0,
	Logger_LogFormat_m7F6CBF8AF6A60EF05CF9EE795502036CBAC847A7,
	Logger_LogFormat_m549605E9E6499650E70B0A168E047727490F31B7,
	Logger_LogException_m362D3434D3B275B0B98E434BFBFBF52C76BBC9C3,
	UnityLogWriter_WriteStringToUnityLog_m0036CA8A9FB1FE3CFF460CA0212B6377B09E6504,
	UnityLogWriter_WriteStringToUnityLogImpl_mA39CCE94FF5BD2ABD4A8C8D78A00E366C64B4985,
	UnityLogWriter_Init_mAD1F3BFE2183E39CFA1E7BEFB948B368547D9E99,
	UnityLogWriter_Write_mB1200B0B26545C48E178BFE952BEE14BDE53D2A7,
	UnityLogWriter_Write_mE3A4616A06A79B87512C3B0C8100EB508BB85C52,
	UnityLogWriter_Write_mE21873E7757E51C3771C58321E995DEBB2ADF750,
	UnityLogWriter__ctor_mE8DC0EAD466C5F290F6D32CC07F0F70590688833,
	Color__ctor_m20DF490CEB364C4FC36D7EE392640DF5B7420D7C_AdjustorThunk,
	Color__ctor_mC9AEEB3931D5B8C37483A884DD8EB40DC8946369_AdjustorThunk,
	Color_ToString_m17A27E0CFB20D9946D130DAEDB5BDCACA5A4473F_AdjustorThunk,
	Color_GetHashCode_m88317C719D2DAA18E293B3F5CD17B9FB80E26CF1_AdjustorThunk,
	Color_Equals_m63ECBA87A0F27CD7D09EEA36BCB697652E076F4E_AdjustorThunk,
	Color_Equals_mA81EEDDC4250DE67C2F43BC88A102EA32A138052_AdjustorThunk,
	Color_op_Multiply_mF36917AD6235221537542FD079817CAB06CB1934,
	Color_op_Multiply_m2A972C4CDC2883F4225CC2E431D7808ECBAC3567,
	Color_op_Equality_m71B1A2F64AD6228F10E20149EF6440460D2C748E,
	Color_op_Inequality_m9C3EFC058BB205C298A2D3166173342303E660B9,
	Color_Lerp_mD37EF718F1BAC65A7416655F0BC902CE76559C46,
	Color_RGBMultiplied_m41914B23903491843FAA3B0C02027EF8B70F34CF_AdjustorThunk,
	Color_get_red_m5562DD438931CF0D1FBBBB29BF7F8B752AF38957,
	Color_get_white_mE7F3AC4FF0D6F35E48049C73116A222CBE96D905,
	Color_get_black_mEB3C91F45F8AA7E4842238DFCC578BB322723DAF,
	Color_get_magenta_m04E2DDB63AA6288C701A93E248643A06EBD2D7AD,
	Color_get_grey_mC37E72622FEB89E52EBCB5245D42DBF63E4FE3B7,
	Color_get_clear_m419239BDAEB3D3C4B4291BF2C6EF09A7D7D81360,
	Color_get_linear_mB10CD29D56ADE2C811AD74A605BA11F6656E9D1A_AdjustorThunk,
	Color_get_gamma_m38A0BB5A9A0A7F860BEEB3BD9F69F72CFA926A79_AdjustorThunk,
	Color_get_maxColorComponent_mBA8595CB2790747F42145CB696C10E64C9BBD76D_AdjustorThunk,
	Color_op_Implicit_m653C1CE2391B0A04114B9132C37E41AC92B33AFE,
	Color_op_Implicit_m51CEC50D37ABC484073AECE7EB958B414F2B6E7B,
	Color32__ctor_m1AEF46FBBBE4B522E6984D081A3D158198E10AA2_AdjustorThunk,
	Color32_op_Implicit_m52B034473369A651C8952BD916A2AB193E0E5B30,
	Color32_op_Implicit_mA89CAD76E78975F51DF7374A67D18A5F6EF8DA61,
	Color32_ToString_m217F2AD5C02E630E37BE5CFB0933630F6D0C3555_AdjustorThunk,
	Gradient_Init_m56D09BE88E111535F8D2278E03BE81C9D70EFAAD,
	Gradient_Cleanup_mD38D8100E8FAAC7FBD5047380555802E638DF718,
	Gradient_Internal_Equals_m210D28E9843DBA28E2F60FDBB366FE2B5B739B1A,
	Gradient__ctor_m297B6B928FDA6BD99A142736017F5C0E2B30BE7F,
	Gradient_Finalize_mB8CB38D86D7935F98000B5F4A0EBF419BD859210,
	Gradient_Equals_m0A13AD7938F81F21CC380609A506A39B37CF2097,
	Gradient_Equals_m7F23C7692189DDD94FC31758493D4C99C2F3FB1E,
	Gradient_GetHashCode_m2596E6672ACDAD829961AB1FBD3EB649A908DE64,
	Matrix4x4_TRS_m5BB2EBA1152301BAC92FDC7F33ECA732BAE57990,
	Matrix4x4_Inverse_mECB7765A8E71D8D2DAF064F94AAD33DE8976A85D,
	Matrix4x4_get_inverse_mBD3145C0D7977962E18C8B3BF63DD671F7917166_AdjustorThunk,
	Matrix4x4_Perspective_mCFA40C620EE4661CBEA269EF57F44A7D29425EA2,
	Matrix4x4__ctor_mC7C5A4F0791B2A3ADAFE1E6C491B7705B6492B12_AdjustorThunk,
	Matrix4x4_set_Item_mDD63AFD70962132EC5468F486A641B560234CB63_AdjustorThunk,
	Matrix4x4_set_Item_m63E67A0D3E7C3CFEA191C2E73D4380A07C9046AE_AdjustorThunk,
	Matrix4x4_GetHashCode_m6627C82FBE2092AE4711ABA909D0E2C3C182028F_AdjustorThunk,
	Matrix4x4_Equals_m7FB9C1A249956C6CDE761838B92097C525596D31_AdjustorThunk,
	Matrix4x4_Equals_mF8358F488D95A9C2E5A9F69F31EC7EA0F4640E51_AdjustorThunk,
	Matrix4x4_op_Multiply_mF6693A950E1917204E356366892C3CCB0553436E,
	Matrix4x4_GetColumn_m34D9081FB464BB7CF124C50BB5BE4C22E2DBFA9E_AdjustorThunk,
	Matrix4x4_SetColumn_m8AFBFEE401780B02DC32B58BF8FCE9AAA34C7F88_AdjustorThunk,
	Matrix4x4_MultiplyPoint_mD5D082585C5B3564A5EFC90A3C5CAFFE47E45B65_AdjustorThunk,
	Matrix4x4_MultiplyPoint3x4_m7C872FDCC9E3378E00A40977F641A45A24994E9A_AdjustorThunk,
	Matrix4x4_MultiplyVector_mFED70C58FB201633483463CE64DBF0D0BE081863_AdjustorThunk,
	Matrix4x4_Translate_m73101FF77DD95B0B88F06EF9E58992F7B7CD2B36,
	Matrix4x4_get_zero_m0998BBFF9505014951817FEDB16FAED8C5791A39,
	Matrix4x4_get_identity_mA0CECDE2A5E85CF014375084624F3770B5B7B79B,
	Matrix4x4_ToString_m7E29D2447E2FC1EAB3D8565B7DCAFB9037C69E1D_AdjustorThunk,
	Matrix4x4__cctor_mC5A7950045F0C8DBAD83A45D08812BEDBC6E159E,
	Matrix4x4_TRS_Injected_mADF67489B3C6715B6BA35E22B0BA6713784100CC,
	Matrix4x4_Inverse_Injected_m7849F11A4307E901FDBAD8FBC9FB9606B6827673,
	Matrix4x4_Perspective_Injected_mF2D589F7B16B6874134AEF870BAA466CE65E0C45,
	Vector3_Lerp_m5BA75496B803820CC64079383956D73C6FD4A8A1,
	Vector3_get_Item_mC3B9D35C070A91D7CA5C5B47280BD0EA3E148AC6_AdjustorThunk,
	Vector3_set_Item_m89FF112CEC0D9ED43F1C4FE01522C75394B30AE6_AdjustorThunk,
	Vector3__ctor_m08F61F548AA5836D8789843ACB4A81E4963D2EE1_AdjustorThunk,
	Vector3__ctor_m6AD8F21FFCC7723C6F507CCF2E4E2EFFC4871584_AdjustorThunk,
	Vector3_Cross_m3E9DBC445228FDB850BDBB4B01D6F61AC0111887,
	Vector3_GetHashCode_m6C42B4F413A489535D180E8A99BE0298AD078B0B_AdjustorThunk,
	Vector3_Equals_m1F74B1FB7EE51589FFFA61D894F616B8F258C056_AdjustorThunk,
	Vector3_Equals_m6B991540378DB8541CEB9472F7ED2BF5FF72B5DB_AdjustorThunk,
	Vector3_Normalize_mDEA51D0C131125535DA2B49B7281E0086ED583DC,
	Vector3_Normalize_m174460238EC6322B9095A378AA8624B1DD9000F3_AdjustorThunk,
	Vector3_get_normalized_mE20796F1D2D36244FACD4D14DADB245BE579849B_AdjustorThunk,
	Vector3_Dot_m0C530E1C51278DE28B77906D56356506232272C1,
	Vector3_Distance_mE316E10B9B319A5C2A29F86E028740FD528149E7,
	Vector3_Magnitude_m3958BE20951093E6B035C5F90493027063B39437,
	Vector3_get_magnitude_m9A750659B60C5FE0C30438A7F9681775D5DB1274_AdjustorThunk,
	Vector3_get_sqrMagnitude_m1C6E190B4A933A183B308736DEC0DD64B0588968_AdjustorThunk,
	Vector3_Min_m0D0997E6CDFF77E5177C8D4E0A21C592C63F747E,
	Vector3_Max_m78495079CA1E29B0658699B856AFF22E23180F36,
	Vector3_get_zero_m3CDDCAE94581DF3BB16C4B40A100E28E9C6649C2,
	Vector3_get_one_mA11B83037CB269C6076CBCF754E24C8F3ACEC2AB,
	Vector3_get_forward_m3E2E192B3302130098738C308FA1EE1439449D0D,
	Vector3_get_back_mE7EF8625637E6F8B9E6B42A6AE140777C51E02F7,
	Vector3_get_up_m6309EBC4E42D6D0B3D28056BD23D0331275306F7,
	Vector3_get_down_m3F76A48E5B7C82B35EE047375538AFD91A305F55,
	Vector3_get_left_m74B52D8CFD8C62138067B2EB6846B6E9E51B7C20,
	Vector3_get_right_m6DD9559CA0C75BBA42D9140021C4C2A9AAA9B3F5,
	Vector3_op_Addition_m929F9C17E5D11B94D50B4AFF1D730B70CB59B50E,
	Vector3_op_Subtraction_mF9846B723A5034F8B9F5F5DCB78E3D67649143D3,
	Vector3_op_UnaryNegation_m2AFBBF22801F9BCA5A4EBE642A29F433FE1339C2,
	Vector3_op_Multiply_m1C5F07723615156ACF035D88A1280A9E8F35A04E,
	Vector3_op_Multiply_mC7A8D6FD19E58DBF98E30D454F59F142F7BF8839,
	Vector3_op_Division_mDF34F1CC445981B4D1137765BC6277419E561624,
	Vector3_op_Equality_mA9E2F96E98E71AE7ACCE74766D700D41F0404806,
	Vector3_op_Inequality_mFEEAA4C4BF743FB5B8A47FF4967A5E2C73273D6E,
	Vector3_ToString_m2682D27AB50CD1CE4677C38D0720A302D582348D_AdjustorThunk,
	Vector3__cctor_m83F3F89A8A8AFDBB54273660ABCA2E5AE1EAFDBD,
	Quaternion_Inverse_mC3A78571A826F05CE179637E675BD25F8B203E0C,
	Quaternion_Internal_FromEulerRad_mC6AB58E2F3C37DFE2089A38D578E862B3430E755,
	Quaternion_Internal_ToEulerRad_m5F7B68953CC22DCE9EC246396B02F0ADC0B1C470,
	Quaternion_LookRotation_m7BED8FBB457FF073F183AC7962264E5110794672,
	Quaternion__ctor_m7502F0C38E04C6DE24C965D1CAF278DDD02B9D61_AdjustorThunk,
	Quaternion_get_identity_m548B37D80F2DEE60E41D1F09BF6889B557BE1A64,
	Quaternion_op_Multiply_mD5999DE317D808808B72E58E7A978C4C0995879C,
	Quaternion_IsEqualUsingDot_mA5E0CF75CBB488E3EC55BE9397FC3C92439A0BEF,
	Quaternion_op_Equality_m0DBCE8FE48EEF2D7C79741E498BFFB984DF4956F,
	Quaternion_op_Inequality_mDA6D2E63A498C8A9AB9A11DD7EA3B96567390C70,
	Quaternion_Dot_m0C931CC8127C5461E5B8A857BDE2CE09297E468B,
	Quaternion_SetLookRotation_mDB3D5A8083E5AB5881FA9CC1EACFC196F61B8204_AdjustorThunk,
	Quaternion_Internal_MakePositive_mC458BD7036703798B11C6C46675814B57E236597,
	Quaternion_get_eulerAngles_mF8ABA8EB77CD682017E92F0F457374E54BC943F9_AdjustorThunk,
	Quaternion_Euler_m537DD6CEAE0AD4274D8A84414C24C30730427D05,
	Quaternion_Euler_m55C96FCD397CC69109261572710608D12A4CBD2B,
	Quaternion_GetHashCode_m43BDCF3A72E31FA4063C1DEB770890FF47033458_AdjustorThunk,
	Quaternion_Equals_m099618C36B86DC63B2E7C89673C8566B18E5996E_AdjustorThunk,
	Quaternion_Equals_m0A269A9B77E915469801463C8BBEF7A06EF94A09_AdjustorThunk,
	Quaternion_ToString_m38DF4A1C05A91331D0A208F45CE74AF005AB463D_AdjustorThunk,
	Quaternion__cctor_m026361EBBB33BB651A59FC7BC6128195AEDCF935,
	Quaternion_Inverse_Injected_m1CD79ADF97C60D5645C15C5F04219021EE4654DD,
	Quaternion_Internal_FromEulerRad_Injected_m2197C7F75B2DB8B99C1947CD7C92714FE8D0099D,
	Quaternion_Internal_ToEulerRad_Injected_mE55FFD02837E4FFFFFF8689E63B4EAF4F3B7396D,
	Quaternion_LookRotation_Injected_m59A46014572ACB8F5C8A377B773D12EACCB53D4A,
	Mathf_GammaToLinearSpace_m537DFDE30A58265FDA50F4D245B9599BBA8A4772,
	Mathf_LinearToGammaSpace_m2E1C2A97C0D476FB5659601D09500CC8DDE09F61,
	Mathf_Sin_m5275643192EFB3BD27A722901C6A4228A0DB8BB6,
	Mathf_Cos_mC5ECAE74D1FE9AF6F6EFF50AD3CD6BA1941B267A,
	Mathf_Tan_m436F7A034334BCB42BD46ABC94D1200C70E81A49,
	Mathf_Acos_mF3B88F0C8A5AE43F4C4A42676C8D3DE67B3EAF82,
	Mathf_Atan_m1FF47E958C869FCB8BADF804011E04736E23C6F9,
	Mathf_Sqrt_mF1FBD3142F5A3BCC5C35DFB922A14765BC0A8E2B,
	Mathf_Abs_mD852D98E3D4846B45F57D0AD4A8C6E00EF272662,
	Mathf_Min_mCF9BE0E9CAC9F18D207692BB2DAC7F3E1D4E1CB7,
	Mathf_Min_m1A2CC204E361AE13C329B6535165179798D3313A,
	Mathf_Max_m670AE0EC1B09ED1A56FF9606B0F954670319CB65,
	Mathf_Max_mBDE4C6F1883EE3215CD7AE62550B2AC90592BC3F,
	Mathf_Pow_mC1BFA8F6235567CBB31F3D9507A6275635A38B5F,
	Mathf_Exp_m7C92A75E0245B9FAEE93683523C22910C0877693,
	Mathf_Log_mD0CFD1242805BD697B5156AA46FBB43E7636A19B,
	Mathf_Log_m3D3FFA950CF7BC75C2C13E3F22950FF3314CAB61,
	Mathf_Ceil_m4FC7645E3D0F8FEDC33FE507E3D913108DD94E94,
	Mathf_Floor_mD447D35DE1D81DE09C2EFE21A75F0444E2AEF9E1,
	Mathf_Round_mC8FAD403F9E68B0339CF65C8F63BFA3107DB3FC9,
	Mathf_CeilToInt_m0230CCC7CC9266F18125D9425C38A25D1CA4275B,
	Mathf_FloorToInt_m0C42B64571CE92A738AD7BB82388CE12FBE7457C,
	Mathf_RoundToInt_m0EAD8BD38FCB72FA1D8A04E96337C820EC83F041,
	Mathf_Sign_m6FA1D12786BEE0419D4B9426E5E4955F286BC8D3,
	Mathf_Clamp_m033DD894F89E6DCCDAFC580091053059C86A4507,
	Mathf_Clamp_mE1EA15D719BF2F632741D42DF96F0BC797A20389,
	Mathf_Clamp01_m1E5F736941A7E6DC4DBCA88A1E38FE9FBFE0C42B,
	Mathf_Lerp_m9A74C5A0C37D0CDF45EE66E7774D12A9B93B1364,
	Mathf_Approximately_m91AF00403E0D2DEA1AAE68601AD218CFAD70DF7E,
	Mathf_SmoothDamp_m00F6830F4979901CACDE66A7CEECD8AA467342C8,
	Mathf_Repeat_m8459F4AAFF92DB770CC892BF71EE9438D9D0F779,
	Mathf_InverseLerp_m7054CDF25056E9B27D2467F91C95D628508F1F31,
	Mathf__cctor_m4855BF06F66120E2029CFA4F3E82FBDB197A86EC,
	Vector2_get_Item_m67344A67120E48C32D9419E24BA7AED29F063379_AdjustorThunk,
	Vector2_set_Item_m2335DC41E2BB7E64C21CDF0EEDE64FFB56E7ABD1_AdjustorThunk,
	Vector2__ctor_mEE8FB117AB1F8DB746FB8B3EB4C0DA3BF2A230D0_AdjustorThunk,
	Vector2_Scale_m7AA97B65C683CB3B0BCBC61270A7F1A6350355A2,
	Vector2_Normalize_m99A2CC6E4CB65C1B9231F898D5B7A12B6D72E722_AdjustorThunk,
	Vector2_get_normalized_m058E75C38C6FC66E178D7C8EF1B6298DE8F0E14B_AdjustorThunk,
	Vector2_ToString_m83C7C331834382748956B053E252AE3BD21807C4_AdjustorThunk,
	Vector2_GetHashCode_m028AB6B14EBC6D668CFA45BF6EDEF17E2C44EA54_AdjustorThunk,
	Vector2_Equals_m4A2A75BC3D09933321220BCEF21219B38AF643AE_AdjustorThunk,
	Vector2_Equals_mD6BF1A738E3CAF57BB46E604B030C072728F4EEB_AdjustorThunk,
	Vector2_Dot_m34F6A75BE3FC6F728233811943AC4406C7D905BA,
	Vector2_get_magnitude_m66097AFDF9696BD3E88467D4398D4F82B8A4C7DF_AdjustorThunk,
	Vector2_get_sqrMagnitude_mAEE10A8ECE7D5754E10727BA8C9068A759AD7002_AdjustorThunk,
	Vector2_Distance_mB07492BC42EC582754AD11554BE5B7F8D0E93CF4,
	Vector2_op_Addition_m81A4D928B8E399DA3A4E3ACD8937EDFDCB014682,
	Vector2_op_Subtraction_m2B347E4311EDBBBF27573E34899D2492E6B063C0,
	Vector2_op_Multiply_mEDF9FDDF3BFFAEC997FBCDE5FA34871F2955E7C4,
	Vector2_op_Division_mEF4FA1379564288637A7CF5E73BA30CA2259E591,
	Vector2_op_UnaryNegation_m3FA0AE2F9B031765EFA566B25F5453C3B001FF4D,
	Vector2_op_Multiply_m8A843A37F2F3199EBE99DC7BDABC1DC2EE01AF56,
	Vector2_op_Division_m0961A935168EE6701E098E2B37013DFFF46A5077,
	Vector2_op_Equality_m0E86E1B1038DDB8554A8A0D58729A7788D989588,
	Vector2_op_Inequality_mC16161C640C89D98A00800924F83FF09FD7C100E,
	Vector2_op_Implicit_mEA1F75961E3D368418BA8CEB9C40E55C25BA3C28,
	Vector2_op_Implicit_mD152B6A34B4DB7FFECC2844D74718568FE867D6F,
	Vector2_get_zero_mFE0C3213BB698130D6C5247AB4B887A59074D0A8,
	Vector2_get_one_m6E01BE09CEA40781CB12CCB6AF33BBDA0F60CEED,
	Vector2_get_up_mC4548731D5E7C71164D18C390A1AC32501DAE441,
	Vector2_get_down_mCB2BC667A6C70DCA1B522DEA470F9C9DDA3D2F0F,
	Vector2_get_right_mB4BD67462D579461853F297C0DE85D81E07E911E,
	Vector2_get_negativeInfinity_mCD1BFAFDD738F768ACF2A6C712689D6C8956597F,
	Vector2__cctor_m13D18E02B3AC28597F5049D2F54830C9E4BDBE84,
	Vector2Int_get_x_m300C7C05CD66D24EE62D91CDC0C557A6C0ABF25E_AdjustorThunk,
	Vector2Int_set_x_mC6F9F1E43668A7F8E8C44CEFB427BA97389F1420_AdjustorThunk,
	Vector2Int_get_y_m0D6E131AB5FA4AD532DEC377F981AADA189E680B_AdjustorThunk,
	Vector2Int_set_y_mF79CD7FACF0A9A1CC12678E2E24BD43C5E836D88_AdjustorThunk,
	Vector2Int__ctor_m501C34762BA7ECDDCFC25C19A4B9C93BC15004E1_AdjustorThunk,
	Vector2Int_Max_m8B01A60534D0D8D91735C92E359B729DE81FBFD0,
	Vector2Int_op_Implicit_m05B84E680DA5408143C51CB664F97AC4702DC200,
	Vector2Int_op_Equality_m7EDB885618BE7B785798F96DDDDA70E53461BB4B,
	Vector2Int_op_Inequality_mAC8212BEC016167196A2EF04A381D3439070ECAE,
	Vector2Int_Equals_mF7D7EFBC0286224832BA76701801C28530D40479_AdjustorThunk,
	Vector2Int_Equals_m65420C995F326F5C340E4825EA5E16BDE68F5A9C_AdjustorThunk,
	Vector2Int_GetHashCode_m73E874F4E94DF3D2603035E2E892873B139A7A9E_AdjustorThunk,
	Vector2Int_ToString_mB0D67C1885311767BA89D4C4A6E3A5A515194BF3_AdjustorThunk,
	Vector2Int_get_zero_m40CBB0090688CF55366641596C62128561AA659C,
	Vector2Int_get_one_mD4B8C3B5B30E367C52D89BAD69B1026520737CC0,
	Vector2Int__cctor_mCCA5D2394D22AB700421D56C1EB6998F4E3C810A,
	Vector3Int_get_x_m23CB00F1579FD4CE86291940E2E75FB13405D53A_AdjustorThunk,
	Vector3Int_get_y_m1C2F0AB641A167DF22F9C3C57092EC05AEF8CA26_AdjustorThunk,
	Vector3Int_get_z_m9A88DC2346FD1838EC611CC8AB2FC29951E94183_AdjustorThunk,
	Vector3Int__ctor_m171D642C38B163B353DAE9CCE90ACFE0894C1156_AdjustorThunk,
	Vector3Int_op_Equality_mC2E3A3395AC3E18397283F3CBEA7167B2E463DFC,
	Vector3Int_Equals_m704D204F83B9C64C7AF06152F98B542C5C400DC7_AdjustorThunk,
	Vector3Int_Equals_m9F98F28666ADF5AD0575C4CABAF6881F1317D4C1_AdjustorThunk,
	Vector3Int_GetHashCode_m6CDE2FEC995180949111253817BD0E4ECE7EAE3D_AdjustorThunk,
	Vector3Int_ToString_m08AB1BE6A674B2669839B1C44ACCF6D85EBCFB91_AdjustorThunk,
	Vector3Int__cctor_m0EE114B6FDC7C783EF7B206D4E25F5CE900003C9,
	Vector4_get_Item_m39878FDA732B20347BB37CD1485560E9267EDC98_AdjustorThunk,
	Vector4_set_Item_m56FB3A149299FEF1C0CF638CFAF71C7F0685EE45_AdjustorThunk,
	Vector4__ctor_m545458525879607A5392A10B175D0C19B2BC715D_AdjustorThunk,
	Vector4__ctor_mFADAC87CAF1F57AD3FE715E6930D78BF7D303D81_AdjustorThunk,
	Vector4_GetHashCode_m7329FEA2E90CDBDBF4F09F51D92C87E08F5DC92E_AdjustorThunk,
	Vector4_Equals_m552ECA9ECD220D6526D8ECC9902016B6FC6D49B5_AdjustorThunk,
	Vector4_Equals_mB9894C2D4EE56C6E8FDF6CC40DCE0CE16BA4F7BF_AdjustorThunk,
	Vector4_Dot_m9FAE8FE89CF99841AD8D2113DFCDB8764F9FBB18,
	Vector4_get_sqrMagnitude_m6B2707CBD31D237605D066A5925E6419D28B5397_AdjustorThunk,
	Vector4_get_zero_m42821248DDFA4F9A3E0B2E84CBCB737BE9DCE3E9,
	Vector4_op_Addition_m2079975CEB29719BDECFA861B53E499C70AA7015,
	Vector4_op_UnaryNegation_m80D997A3F98FA21070490720343B60F22144B447,
	Vector4_op_Multiply_mC2CF8F5A9CA3041B34527E66770AEBA5E58B84F0,
	Vector4_op_Division_m1D1BD7FFEF0CDBB7CE063CA139C22210A0B76689,
	Vector4_op_Equality_m9AE0D09EC7E02201F94AE469ADE9F416D0E20441,
	Vector4_op_Implicit_m5BFA8D95F88CB2AEA6E02B200A61B718314A8495,
	Vector4_op_Implicit_mEAB05A77FF8B3EE79C31499F0CF0A0D621A6496C,
	Vector4_op_Implicit_m3CB789809FDA1B5598EC3C928B173C62FC152656,
	Vector4_ToString_m769402E3F7CBD6C92464D916527CC87BBBA53EF9_AdjustorThunk,
	Vector4__cctor_m478FA6A83B8E23F8323F150FF90B1FB934B1C251,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_SendMessage_m00395F263B4C7FD7F10C32B1F4C4C1F00503D4BB,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_TrySendMessage_m950332D66588946F8699A64E5B8DBA8956A45303,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_Poll_mEAAE7671B5D8E0360BFE50E61E89FFF65DB825E4,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_RegisterInternal_m991A5281F58D94FA0F095A538BD91CA72B864965,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_UnregisterInternal_mAF6931079473185968AFCD40A23A610F7D6CC3A0,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_Initialize_mBC677B0244B87A53875C8C3A3A716DC09A8D541F,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_IsConnected_m08B0A552BE45CC80F911E22D990B8FE6C82B53DD,
	PlayerConnectionInternal_UnityEngine_IPlayerEditorConnectionNative_DisconnectAll_m5849A206AC5D274115B352114BD5F4B72900F651,
	PlayerConnectionInternal_IsConnected_m4AD0EABFF2FCE8DE9DE1A6B520C707F300721FB2,
	PlayerConnectionInternal_Initialize_mB0E05590ED32D5DCD074FD6CB60064F8A96BB4FD,
	PlayerConnectionInternal_RegisterInternal_mC3FB67053C4C7DB1AABAB7E78E1F1345720ED84F,
	PlayerConnectionInternal_UnregisterInternal_m675B2C87E01FCBBF5CB1A205375A2E95A8F150B2,
	PlayerConnectionInternal_SendMessage_m83801DCA5BBCC8116F1C7898FB6A755CCAF6F928,
	PlayerConnectionInternal_TrySendMessage_mE31F212ED59D69FD01FC2B6B4503A5AF97C1948D,
	PlayerConnectionInternal_PollInternal_m46079D478471FAB04EE8E613CAE8F6E79822472E,
	PlayerConnectionInternal_DisconnectAll_m58AFB71131F174149D6AA98C312D9026C15C6090,
	PlayerConnectionInternal__ctor_m882227F7C855BCF5CE1B0D44752124106BE31389,
	PropertyAttribute__ctor_m7F5C473F39D5601486C1127DA0D52F2DC293FC35,
	TooltipAttribute__ctor_m13242D6EEE484B1CCA7B3A8FA720C5BCC44AF5DF,
	SpaceAttribute__ctor_m645A0DE9B507F2AFD8C67853D788F5F419D547C7,
	SpaceAttribute__ctor_mA70DC7F5FDC5474223B45E0F71A9003BBED1EFD0,
	HeaderAttribute__ctor_m0E05B3623D1742E60908E9E5E73CB6CE9C12A4DD,
	RangeAttribute__ctor_mB9CC43849A074C59DD99F154215A755131D47D89,
	TextAreaAttribute__ctor_m6134ACE5D232B16A9433AA1F47081FAA9BAC1BA1,
	ColorUsageAttribute__ctor_m356D0BA237E55A0B1B843D3891A774E74F41D11A,
	PropertyNameUtils_PropertyNameFromString_m38F9FC2E83C99C0723DAC4BBC5A2A7EA87752174,
	PropertyNameUtils_PropertyNameFromString_Injected_mB89F8191FB9B39ADA1F0C627AD130E4F6E37DB38,
	PropertyName__ctor_mE0853FF14F978FFAF3EEE0B98DA973E17C962B37_AdjustorThunk,
	PropertyName__ctor_mF8DCC97F6EC552F9313CE85ACC9D3357F45FA16D_AdjustorThunk,
	PropertyName_op_Equality_m15312EA01DB9104A41667A1F7CFF6841E31DBD68,
	PropertyName_GetHashCode_mBFB70A344042610A7EC9532BFBD83BB6623B128F_AdjustorThunk,
	PropertyName_Equals_mD2B2AD96A94DAFFAC506CF7E89C3493E5BA90CB1_AdjustorThunk,
	PropertyName_Equals_m1CA96DE357EEF70D3171B14B4836F121DA3B09A6_AdjustorThunk,
	PropertyName_ToString_mBB9266CFD39F9DDF58BECC30B5C85467C55E21C8_AdjustorThunk,
	Random_get_value_mC998749E08291DD42CF31C026FAC4F14F746831C,
	NULL,
	Resources_Load_mF0FA033BF566CDDA6A0E69BB97283B44C40726E7,
	Resources_GetBuiltinResource_m73DDAC485E1E06C925628AA7285AC63D0797BD0A,
	NULL,
	AsyncOperation_InvokeCompletionEvent_m5F86FF01A5143016630C9CFADF6AA01DBBBD73A5,
	AttributeHelperEngine_GetParentTypeDisallowingMultipleInclusion_m716999F8F469E9398A275432AA5C68E81DD8DB24,
	AttributeHelperEngine_GetRequiredComponents_m869E1FF24FE124874E0723E11C12A906E57E3007,
	AttributeHelperEngine_GetExecuteMode_mDE99262C53FA67B470B8668A13F968B4D5A8E0A1,
	AttributeHelperEngine_CheckIsEditorScript_m95CEEF4147D16BC2985EAADD300905AB736F857E,
	AttributeHelperEngine_GetDefaultExecutionOrderFor_m0972E47FA03C9CEF196B1E7B2E708E30DF4AD063,
	NULL,
	AttributeHelperEngine__cctor_mAE0863DCF7EF9C1806BDC1D4DF64573464674964,
	DisallowMultipleComponent__ctor_m108E5D8C0DB938F0A747C6D2BA481B4FA9CDECB3,
	RequireComponent__ctor_m27819B55F8BD1517378CEFECA00FB183A13D9397,
	AddComponentMenu__ctor_m33A9DE8FEE9BC9C12F67CF58BFEBECA372C236A3,
	AddComponentMenu__ctor_m78D1D62B91D88424AE2175501B17E4609EF645EA,
	ExecuteInEditMode__ctor_m9A67409D4A11562F23F928655D9A3EFB7A69BB81,
	ExecuteAlways__ctor_m6199E1FB2E787ABEE85C19153D3C90B815572092,
	HideInInspector__ctor_mED96F804290F203756C1EDDE57F47C0E5A8FF4B4,
	HelpURLAttribute__ctor_mE8D73F64B451D3746E3427E74D332B7731D9D3AB,
	DefaultExecutionOrder_get_order_mFD2CD99AEF550E218FAFC6CB3DDA3CE8D78614A9,
	ExcludeFromPresetAttribute__ctor_mB8BE49E17E4360DDB485784D219AE49847A85FB2,
	Behaviour_get_enabled_mAA0C9ED5A3D1589C1C8AA22636543528DB353CFB,
	Behaviour_set_enabled_m9755D3B17D7022D23D1E4C618BD9A6B66A5ADC6B,
	Behaviour_get_isActiveAndEnabled_mC42DFCC1ECC2C94D52928FFE446CE7E266CA8B61,
	Behaviour__ctor_m409AEC21511ACF9A4CC0654DF4B8253E0D81D22C,
	ClassLibraryInitializer_Init_mB8588C1A9DD9CB6B5CE77DB1F79AE301C46E0CE7,
	Component_get_transform_m00F05BD782F920C301A7EBA480F3B7A904C07EC9,
	Component_get_gameObject_m0B0570BA8DDD3CD78A9DB568EA18D7317686603C,
	Component_GetComponent_m5E75925F29811EEC97BD17CDC7D4BD8460F3090F,
	Component_GetComponentFastPath_mDEB49C6B56084E436C7FC3D555339FA16949937E,
	NULL,
	NULL,
	Component_GetComponentInChildren_mEF7890FAC10EA2F776464285B0DCC58B8C373D34,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Component_GetComponentInParent_mFD9A8F6311ABAF986CA0DA556662F89FD9234E7D,
	NULL,
	NULL,
	NULL,
	NULL,
	Component_GetComponentsForListInternal_m469B4C3A883942213BEA0EAAA54629219A042480,
	Component_GetComponents_m1ACBE6B9A75ECC898BA3B21D59AA7B3339D7735A,
	NULL,
	NULL,
	Component__ctor_m5E2740C0ACA4B368BC460315FAA2EDBFEAC0B8EF,
	Coroutine__ctor_mCA679040DA81B31D1E341400E98F6CF569269201,
	Coroutine_Finalize_mACCDC3AFBA7F1D247231AA875B5099200AF9ECC5,
	Coroutine_ReleaseCoroutine_mD33DD220788EEA099B98DD1258D6332A46D3D571,
	SetupCoroutine_InvokeMoveNext_m9106BA4E8AE0E794B17F184F1021A53F1D071F31,
	SetupCoroutine_InvokeMember_m0F2AD1D817B8E221C0DCAB9A81DA8359B20A8EFB,
	NULL,
	CustomYieldInstruction_get_Current_m9B2B482ED92A58E85B4D90A5AC7C89DFF87E33DC,
	CustomYieldInstruction_MoveNext_m7EA6BAAEF6A01DC791D0B013D5AB5C377F9A6990,
	CustomYieldInstruction_Reset_m9B3349022DFDDA3A059F14D199F2408725727290,
	CustomYieldInstruction__ctor_m06E2B5BC73763FE2E734FAA600D567701EA21EC5,
	ExcludeFromObjectFactoryAttribute__ctor_mE0437C73993AD36DCB7A002D70AC988340742CD0,
	ExtensionOfNativeClassAttribute__ctor_m2D759F6D70D6FE632D8872A7D7C3E7ECFF83EE46,
	NULL,
	GameObject_GetComponent_mECB756C7EB39F6BB79F8C065AB0013354763B151,
	GameObject_GetComponentFastPath_m5B276335DD94F6B307E604272A26C15B997C3CD4,
	GameObject_GetComponentInChildren_mBC5C12CDA1749A827D136DABBF10498B1096A086,
	NULL,
	NULL,
	GameObject_GetComponentInParent_mA5BF9DFCA90C9003EB8F392CD64C45DFCB80F988,
	GameObject_GetComponentsInternal_mAB759217A3AD0831ABD9387163126D391459E1B8,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	GameObject_TryGetComponentFastPath_mBCE2196B5F774DB34EAE23EA89FDAFB427A04AC2,
	GameObject_Internal_AddComponentWithType_m452B72618245B846503E5CA7DEA4662A77FB9896,
	GameObject_AddComponent_m489C9D5426F2050795FA696CD478BB49AAE4BD70,
	NULL,
	GameObject_get_transform_mA5C38857137F137CB96C69FAA624199EB1C2FB2C,
	GameObject_get_layer_m0DE90D8A3D3AA80497A3A80FBEAC2D207C16B9C8,
	GameObject_set_layer_mDAC8037FCFD0CE62DB66004C4342EA20CF604907,
	GameObject_SetActive_m25A39F6D9FB68C51F13313F9804E85ACC937BC04,
	GameObject_get_activeSelf_mFE1834886CAE59884AC2BE707A3B821A1DB61F44,
	GameObject_get_activeInHierarchy_mDEE60F1B28281974BA9880EC448682F3DAABB1EF,
	GameObject_SendMessage_mB9147E503F1F55C4F3BC2816C0BDA8C21EA22E95,
	GameObject__ctor_mBB454E679AD9CF0B84D3609A01E6A9753ACF4686,
	GameObject__ctor_mA4DFA8F4471418C248E95B55070665EF344B4B2D,
	GameObject__ctor_m20BE06980A232E1D64016957059A9DD834173F68,
	GameObject_Internal_CreateGameObject_m9DC9E92BD086A7ADD9ABCE858646A951FA77F437,
	LayerMask_op_Implicit_m2AFFC7F931005437E8F356C953F439829AF4CFA5,
	LayerMask_op_Implicit_m3F256A7D96C66548F5B62C4621B9725301850300,
	LayerMask_get_value_m682288E860BBE36F5668DCDBC59245DE6319E537_AdjustorThunk,
	ManagedStreamHelpers_ValidateLoadFromStream_m550BE5DED66EC83AF331265B81084185B35FD846,
	ManagedStreamHelpers_ManagedStreamRead_mC0BDD6B226BBF621F6DAC184E3FC798D6BB0D47B,
	ManagedStreamHelpers_ManagedStreamSeek_m450DB930DD5085114F382A6FE05CF15C5CB21168,
	ManagedStreamHelpers_ManagedStreamLength_mB518EF67FCBA5080CA4C45F34496C05041E07B98,
	MonoBehaviour_IsInvoking_mD0C27BE34FB97F408191450A702FA016E19997E5,
	MonoBehaviour_CancelInvoke_m6ACF5FC83F8FE5A6E744CE1E83A94CB3B0A8B7EF,
	MonoBehaviour_Invoke_m979EDEF812D4630882E2E8346776B6CA5A9176BF,
	MonoBehaviour_InvokeRepeating_m99F21547D281B3F835745B681E5472F070E7E593,
	MonoBehaviour_CancelInvoke_mDD95225EF4DFBB8C00B865468DE8AFEB5D30490F,
	MonoBehaviour_IsInvoking_mCA9E133D28B55AE0CE0E8EDBB183081DEEE57FBC,
	MonoBehaviour_StartCoroutine_m590A0A7F161D579C18E678B4C5ACCE77B1B318DD,
	MonoBehaviour_StartCoroutine_mCD250A96284E3C39D579CEC447432681DE8D1E44,
	MonoBehaviour_StartCoroutine_mBF8044CE06A35D76A69669ADD8977D05956616B7,
	MonoBehaviour_StartCoroutine_Auto_m5002506E1DE4625F7FEACC4D7F0ED8595E3B3AB5,
	MonoBehaviour_StopCoroutine_m3CDD6C046CC660D4CD6583FCE97F88A9735FD5FA,
	MonoBehaviour_StopCoroutine_mC465FFA3C386BA22384F7AFA5495FF2286510562,
	MonoBehaviour_StopCoroutine_mC2C29B39556BFC68657F27343602BCC57AA6604F,
	MonoBehaviour_StopAllCoroutines_mA5469BB7BBB59B8A94BB86590B051E0DFACC12DD,
	MonoBehaviour_get_useGUILayout_m468C9F5A4D7F37643D26EEF41E5BA521CD81C267,
	MonoBehaviour_set_useGUILayout_m00327593C0DC39787FB9310328489F802FF63167,
	MonoBehaviour_print_m171D860AF3370C46648FE8F3EE3E0E6535E1C774,
	MonoBehaviour_Internal_CancelInvokeAll_m11071D9A8C6743C4FA754C1A079CFF5171638AB1,
	MonoBehaviour_Internal_IsInvokingAll_m44707A3C084E2CABC98FBCAF3531E547C6D59644,
	MonoBehaviour_InvokeDelayed_mB70D589B53A55251F47641C6D3A51DA59F973D63,
	MonoBehaviour_CancelInvoke_m38D5CC0BF3FFDD89DD5F5A47E852B1E04BAAC5BB,
	MonoBehaviour_IsInvoking_mA209C7787032B92CEC40A5C571CB257D7A87457E,
	MonoBehaviour_IsObjectMonoBehaviour_mCB948905029893B860CCD5D852878660A1CEF0D7,
	MonoBehaviour_StartCoroutineManaged_m53873D1C040DB245BF13B74D2781072015B1EB66,
	MonoBehaviour_StartCoroutineManaged2_m114327BBBA9F208E8BA2F8BBF71FA0E8E996F7B8,
	MonoBehaviour_StopCoroutineManaged_mB9F1DBC3C5CCF4F64D5277B87518A54DEF7509C2,
	MonoBehaviour_StopCoroutineFromEnumeratorManaged_mA0D7F798094DF352E354304A50E8D97D9AB6900B,
	MonoBehaviour_GetScriptClassName_mB38B7D00E1629DF772709F844EDB4C20074A208F,
	MonoBehaviour__ctor_mEAEC84B222C60319D593E456D769B3311DFCEF97,
	NoAllocHelpers_SafeLength_m85E794F370BFE9D3954E72480AE6ED358AF5102C,
	NULL,
	NoAllocHelpers_ExtractArrayFromList_mB4B8B76B4F160975C949FB3E15C1D497DBAE8EDC,
	RangeInt_get_end_m7A5182161CC5454E1C200E0173668572BA7FAAFD_AdjustorThunk,
	RangeInt__ctor_mACFE54DF73DE3F62053F851423525DB5AC1B100E_AdjustorThunk,
	RuntimeInitializeOnLoadMethodAttribute__ctor_mF7E0CAAF0DA4A1F5BAD4CF4C02C4C3A5AB2515D0,
	RuntimeInitializeOnLoadMethodAttribute__ctor_mB64D0D2B5788BC105D3640A22A70FCD5183CB413,
	RuntimeInitializeOnLoadMethodAttribute_set_loadType_m99C91FFBB561C344A90B86F6AF9ED8642CB87532,
	ScriptableObject__ctor_m6E2B3821A4A361556FC12E9B1C71E1D5DC002C5B,
	ScriptableObject_CreateInstance_mDC77B7257A5E276CB272D3475B9B473B23A7128D,
	NULL,
	ScriptableObject_CreateScriptableObject_m0DEEBEC415354F586C010E7863AEA64D2F628D0B,
	ScriptableObject_CreateScriptableObjectInstanceFromType_m251F32A1C8B865FBED309AA24B8EAB3A35E2E25C,
	ScriptingUtility_IsManagedCodeWorking_m4E53313183C7CB038C14545B933F81E249E707F3,
	SelectionBaseAttribute__ctor_mD7E83E67AFD9920E70551A353A33CC94D0584E8E,
	StackTraceUtility_SetProjectFolder_m05FBBB2FF161F2F9F8551EB67D44B50F7CC98E21,
	StackTraceUtility_ExtractStackTrace_mEDFB4ECA329B87BC7DF2AA3EF7F9A31DAC052DC0,
	StackTraceUtility_ExtractStringFromExceptionInternal_m1FB3D6414E31C313AC633A24653DA4B1FB59C975,
	StackTraceUtility_ExtractFormattedStackTrace_m02A2ACEEF753617FAAA08B4EA840A49263901660,
	StackTraceUtility__cctor_mDDEE2A2B6EBEDB75E0C28C81AFEDB1E9C372A165,
	UnityException__ctor_m68C827240B217197615D8DA06FD3A443127D81DE,
	UnityException__ctor_mE42363D886E6DD7F075A6AEA689434C8E96722D9,
	UnityException__ctor_m27B11548FE152B9AB9402E54CB6A50A2EE6FFE31,
	TextAsset_get_text_mD3FBCD974CF552C7F7C7CD9A07BACAE51A2C5D42,
	TextAsset_ToString_m8C7ED5DD80E20B3A16A2100F62319811BE5DC830,
	UnhandledExceptionHandler_RegisterUECatcher_mE45C6A0301C35F6193F5774B7683683EF78D21DA,
	U3CU3Ec__cctor_m64F27758792E69C7BFBBDB0705955F951E2F162B,
	U3CU3Ec__ctor_mAE51BB926802D8ED0E892556F421B0E93398FE96,
	U3CU3Ec_U3CRegisterUECatcherU3Eb__0_0_m55F5FA1A6235A1DF6306D232C25ACE1883E494D0,
	Object_GetInstanceID_m33A817CEE904B3362C8BAAF02DB45976575CBEF4,
	Object_GetHashCode_mCF9141C6640C2989CD354118673711D5F3741984,
	Object_Equals_m813F5A9FF65C9BC0D6907570C2A9913507D58F32,
	Object_op_Implicit_m8B2A44B4B1406ED346D1AE6D962294FD58D0D534,
	Object_CompareBaseObjects_mE918232D595FB366CE5FAD4411C5FBD86809CC04,
	Object_IsNativeObjectAlive_m683A8A1607CB2FF5E56EC09C5D150A8DA7D3FF08,
	Object_GetCachedPtr_m8CCFA6D419ADFBA8F9EF83CB45DFD75C2704C4A0,
	Object_get_name_mA2D400141CB3C991C87A2556429781DE961A83CE,
	Object_set_name_m538711B144CDE30F929376BCF72D0DC8F85D0826,
	Object_Instantiate_m17AA3123A55239124BC54A907AEEE509034F0830,
	Object_Instantiate_m674B3934708548332899CE953CA56BB696C1C887,
	NULL,
	NULL,
	NULL,
	Object_Destroy_m09F51D8BDECFD2E8C618498EF7377029B669030D,
	Object_Destroy_m23B4562495BA35A74266D4372D45368F8C05109A,
	Object_DestroyImmediate_mFCE7947857C832BCBB366FCCE50072ACAD9A4C51,
	Object_DestroyImmediate_mF6F4415EF22249D6E650FAA40E403283F19B7446,
	Object_FindObjectsOfType_m3FC26FB3B36525BFBFCCCD1AEEE8A86712A12203,
	Object_DontDestroyOnLoad_m4DC90770AD6084E4B1B8489C6B41205DC020C207,
	Object_set_hideFlags_mB0B45A19A5871EF407D7B09E0EB76003496BA4F0,
	NULL,
	Object_CheckNullArgument_m8D42F516655D770DFEEAA13CF86A2612214AAA9B,
	Object_FindObjectOfType_mCDF38E1667CF4502F60C59709D70B60EF7E408DA,
	Object_ToString_m4EBF621C98D5BFA9C0522C27953BB45AB2430FE1,
	Object_op_Equality_mBC2401774F3BE33E8CF6F0A8148E66C95D6CFF1C,
	Object_op_Inequality_m31EF58E217E8F4BDD3E409DEF79E1AEE95874FC1,
	Object_GetOffsetOfInstanceIDInCPlusPlusObject_m7C7130E8611F32F6CC9A47400AC5BDC2BA5E6D23,
	Object_Internal_CloneSingle_m4231A0B9138AC40B76655B772F687CC7E6160C06,
	Object_Internal_CloneSingleWithParent_m32F1D681010B51B98CDBC82E3510FC260D2D1E17,
	Object_ToString_m7A4BBACD14901DD0181038A25BED62520D273EDC,
	Object_GetName_m1691C0D50AEBC1C86229AEAC2FBC1EE2DC6B67AF,
	Object_SetName_m2CBABC30BA2B93EFF6A39B3295A7AB85901E60E8,
	Object_FindObjectFromInstanceID_m7594ED98F525AAE38FEC80052729ECAF3E821350,
	Object__ctor_m091EBAEBC7919B0391ABDAFB7389ADC12206525B,
	Object__cctor_m14515D6A9B514D3A8590E2CAE4372A0956E8976C,
	UnitySynchronizationContext__ctor_mCABD0C784640450930DF24FAD73E8AD6D1B52037,
	UnitySynchronizationContext__ctor_m9D104656F4EAE96CB3A40DDA6EDCEBA752664612,
	UnitySynchronizationContext_Send_m25CDC5B5ABF8D55B70EB314AA46923E3CF2AD4B9,
	UnitySynchronizationContext_Post_mB4E900B6E9350E8E944011B6BF3D16C0657375FE,
	UnitySynchronizationContext_CreateCopy_mC20AC170E7947120E65ED75D71889CDAC957A5CD,
	UnitySynchronizationContext_Exec_m07342201E337E047B73C8B3259710820EFF75A9C,
	UnitySynchronizationContext_HasPendingTasks_mBFCAC1697C6B71584E72079A6EDB83D52EC1700A,
	UnitySynchronizationContext_InitializeSynchronizationContext_m0F2A055040D6848FAD84A08DBC410E56B2D9E6A3,
	UnitySynchronizationContext_ExecuteTasks_m027AF329D90D6451B83A2EAF3528C9021800A962,
	UnitySynchronizationContext_ExecutePendingTasks_m74DCC56A938FEECD533CFE58CAC4B8B9ED001122,
	WorkRequest__ctor_mE19AE1779B544378C8CB488F1576BDE618548599_AdjustorThunk,
	WorkRequest_Invoke_m67D71A48794EEBB6B9793E6F1E015DE90C03C1ED_AdjustorThunk,
	WaitForEndOfFrame__ctor_m6CDB79476A4A84CEC62947D36ADED96E907BA20B,
	WaitForSecondsRealtime_get_waitTime_m6D1B0EDEAFA3DBBBFE1A0CC2D372BAB8EA82E2FB,
	WaitForSecondsRealtime_set_waitTime_m867F4482BEE354E33A6FD9191344D74B9CC8C790,
	WaitForSecondsRealtime_get_keepWaiting_mC257FFC53D5734250B919A8B6BE460A6D8A7CD99,
	WaitForSecondsRealtime__ctor_m775503EC1F4963D8E5BBDD7989B40F6A000E0525,
	YieldInstruction__ctor_mA72AD367FB081E0C2493649C6E8F7CFC592AB620,
	SerializeField__ctor_mEE7F6BB7A9643562D8CEF189848925B74F87DA27,
	NULL,
	NULL,
	ComputeBuffer_Finalize_m1656E84A6F9AA3DFFF24F62A89EC378DAAE6A012,
	ComputeBuffer_Dispose_m002F431B0EBF0B24DF20C7EB8FC2F44B596A6FFE,
	ComputeBuffer_Dispose_mCD0266359E7566AE532568FC801D2883B9AE04F2,
	ComputeBuffer_InitBuffer_m4EA013B54E8B195654CFCAE9E6FD92ACD15B73DD,
	ComputeBuffer_DestroyBuffer_m506890E60C1B0B63CAD39EB38C5821F8C415C537,
	ComputeBuffer__ctor_mDB6AADE63A5BF60A472D9FF9E533AF38D15C6B1E,
	ComputeBuffer__ctor_m908F94257168ACBAFCA674B2B5EFACC4C84BFE22,
	ComputeBuffer_Release_m7DCC16A68F5C00C9C1EA70EE9AFC016AC47F6386,
	ComputeBuffer_get_count_m2D80EF2880723F6627924C0ABC642D8DB538D04D,
	NULL,
	NULL,
	ComputeBuffer_InternalSetNativeData_m48FA3DFF2BF7025268AB18F7A2880EBE497320A0,
	ComputeBuffer_InternalSetData_m490D0FE6E42D04DF9E9320D5D877EDEFBAB608A5,
	ComputeShader_FindKernel_m4CEBD37F96732810C4C370A6249CF460BE1F93A3,
	LowerResBlitTexture_LowerResBlitTextureDontStripMe_mC89EA382E4636DE8BC0E14D1BB024A80C65F5CAF,
	PreloadData_PreloadDataDontStripMe_m68DF1A35E18F9FC43A63F2F990EA9970D4E4A78B,
	SystemInfo_get_operatingSystemFamily_mA35FE1FF2DD6240B2880DC5F642D4A0CC2B58D8D,
	SystemInfo_get_processorType_m7B14D432F490CAC67239862D69F60512E5E2094B,
	SystemInfo_get_deviceType_mAFCA02B695EE4E37FA3B87B8C05804B6616E1528,
	SystemInfo_get_graphicsDeviceType_m675AD9D5FA869DF9E71FAEC03F39E8AE8DEBA8D0,
	SystemInfo_get_graphicsShaderLevel_m04540C22D983AE52CBCC6E1026D16F0C548248EB,
	SystemInfo_get_hasHiddenSurfaceRemovalOnGPU_mE2544E97E6FF38C5B092EEA5B2C9977ACE1EE4ED,
	SystemInfo_get_supportsShadows_m05F10143737B2C6446A663D48447C2006B8701E3,
	SystemInfo_get_copyTextureSupport_m70EE252CBB5FE7C1EBE4067AD4563D87A5937A84,
	SystemInfo_get_supportedRenderTargetCount_mD11B3D770E9DA7EE2F0AC0E9B48299AEDE1B515D,
	SystemInfo_get_supportsMultisampledTextures_m23346E547FC878AD5A6BC98F5A3C89955A2B5BC0,
	SystemInfo_get_supportsMultisampleAutoResolve_m07B205615F855D67101CDDED752F1F2A6B360386,
	SystemInfo_get_usesReversedZBuffer_m2341C40731784C0DE4EBCFBADC2FBE72E5B8778D,
	SystemInfo_IsValidEnumValue_m112F964C57B2311EA910CCA5CE0FFABFFF906740,
	SystemInfo_SupportsRenderTextureFormat_m74D259714A97501D28951CA48298D9F0AE3B5907,
	SystemInfo_SupportsTextureFormat_m1FCBD02367A45D11CAA6503715F3AAE24CA98B79,
	SystemInfo_GetOperatingSystemFamily_mD20DAFF3A6E6649299A3BCFC845E7EB41BFA1D93,
	SystemInfo_GetProcessorType_mCEB2AE2578AB2C465092C65C718D01C3BA49F209,
	SystemInfo_GetDeviceType_m749955DFFD2554A64E851BD95C41F6C55D6A777E,
	SystemInfo_GetGraphicsDeviceType_m9C6D5E53B3AD6D1B5735517E80A16A78D4CFDDCF,
	SystemInfo_GetGraphicsShaderLevel_mD15672C585F6FDF646F339E954EC72C4F4D5207D,
	SystemInfo_HasHiddenSurfaceRemovalOnGPU_mEF623DDCB87FAEF077BD46CDFD33090509890FF9,
	SystemInfo_SupportsShadows_mE90CEC00EBA87DEFAB8E666B02568E07E2E5C771,
	SystemInfo_GetCopyTextureSupport_m39519EF827219590A6C531B112C466C7CDD38C66,
	SystemInfo_SupportedRenderTargetCount_mE6CA6DE27146900463A1263DC0A5AB835C528F92,
	SystemInfo_SupportsMultisampledTextures_m7423EF918542CB5AB14E539ABE68BDC0A8E2478D,
	SystemInfo_SupportsMultisampleAutoResolve_m33E4DE31B5BB12C4407E8207041A6BAE2CAEBDFE,
	SystemInfo_UsesReversedZBuffer_m0B788618A525D856C29279D19DFB46FC5C1FF4C7,
	SystemInfo_HasRenderTextureNative_mF35AF7764E483A7FA75DBC06ED64A8588509C468,
	SystemInfo_SupportsTextureFormatNative_mD028594492646D7AB78A4C2F51CA06F63E665210,
	SystemInfo_IsFormatSupported_m6941B7C4566DEE1EFFD7F6DCB7BFA701ECF9C1D6,
	SystemInfo_GetCompatibleFormat_mC67F0F547EA28CDE08EA9A6B030082516D189EF3,
	SystemInfo_GetGraphicsFormat_m708339B9A94CEBC02A56629FE41F6809DE267F6C,
	Time_get_time_m7863349C8845BBA36629A2B3F8EF1C3BEA350FD8,
	Time_get_deltaTime_m16F98FC9BA931581236008C288E3B25CBCB7C81E,
	Time_get_unscaledTime_m57F78B855097C5BA632CF9BE60667A9DEBCAA472,
	Time_get_unscaledDeltaTime_mA0AE7A144C88AE8AABB42DF17B0F3F0714BA06B2,
	Time_get_smoothDeltaTime_m22F7BB00188785BB7AE979B00CAA96284363C985,
	Time_get_realtimeSinceStartup_mCA1086EC9DFCF135F77BC46D3B7127711EA3DE03,
	TouchScreenKeyboard_Internal_Destroy_m6CD4E2343AB4FE54BC23DCFE62A50180CB3634E0,
	TouchScreenKeyboard_Destroy_m916AE9DA740DBD435A5EDD93C6BC55CCEC8310C3,
	TouchScreenKeyboard_Finalize_m684570CC561058F48B51F7E21A144299FBCE4C76,
	TouchScreenKeyboard__ctor_mDF71D45DC0F867825BEB1CDF728927FBB0E07F86,
	TouchScreenKeyboard_TouchScreenKeyboard_InternalConstructorHelper_mD608B3B2A2159D17A8DF7961FA4EB1694A416973,
	TouchScreenKeyboard_get_isSupported_m9163BAF0764DCDD9CB87E75A296D820D629D31CA,
	TouchScreenKeyboard_get_isInPlaceEditingAllowed_m503AB6CB0DFBD8E7D396C8E552C643F20E4A5D47,
	TouchScreenKeyboard_Open_mF795EEBFEF7DF5E5418CF2BACA02D1C62291B93A,
	TouchScreenKeyboard_get_text_mC025B2F295D315E1A18E7AA54B013A8072A8FEB0,
	TouchScreenKeyboard_set_text_mF72A794EEC3FC19A9701B61A70BCF392D53B0D38,
	TouchScreenKeyboard_set_hideInput_mA9729B01B360BF98153F40B96DDED39534B94840,
	TouchScreenKeyboard_get_active_m35A2928E54273BF16CB19D11665989D894D5C79D,
	TouchScreenKeyboard_set_active_m8D5FDCFA997C5EAD7896F7EB456165498727792D,
	TouchScreenKeyboard_get_status_m17CF606283E9BAF02D76ADC813F63F036FAE33F2,
	TouchScreenKeyboard_set_characterLimit_m97F392EB376881A77F5210CFA6736F0A49F5D57B,
	TouchScreenKeyboard_get_canGetSelection_m8EEC32EA25638ACB54F698EA72450B51BEC9A362,
	TouchScreenKeyboard_get_canSetSelection_m3C9574749CA28A6677C77B8FBE6292B80DF88A10,
	TouchScreenKeyboard_get_selection_m9E2AB5FF388968D946B15A3ECDAE1C3C97115AAD,
	TouchScreenKeyboard_set_selection_m27C5DE6B9DBBBFE2CCA68FA80A600D94337215C7,
	TouchScreenKeyboard_GetSelection_mED761F9161A43CC8E507EA27DB1BD11127C6C896,
	TouchScreenKeyboard_SetSelection_mB728B6A7B07AC33987FB30F7950B3D31E3BA5FBF,
	DrivenRectTransformTracker_Add_m51059F302FBD574E93820E8116283D1608D1AB5A_AdjustorThunk,
	DrivenRectTransformTracker_Clear_m328659F339A4FB519C9A208A685DDED106B6FC89_AdjustorThunk,
	RectTransform_add_reapplyDrivenProperties_mDA1F055B02E43F9041D4198D446D89E00381851E,
	RectTransform_remove_reapplyDrivenProperties_m65A8DB93E1A247A5C8CD880906FF03FEA89E7CEB,
	RectTransform_get_rect_mE5F283FCB99A66403AC1F0607CA49C156D73A15E,
	RectTransform_get_anchorMin_mB62D77CAC5A2A086320638AE7DF08135B7028744,
	RectTransform_set_anchorMin_mE965F5B0902C2554635010A5752728414A57020A,
	RectTransform_get_anchorMax_m1E51C211FBB32326C884375C9F1E8E8221E5C086,
	RectTransform_set_anchorMax_m55EEF00D9E42FE542B5346D7CEDAF9248736F7D3,
	RectTransform_get_anchoredPosition_mCB2171DBADBC572F354CCFE3ACA19F9506F97907,
	RectTransform_set_anchoredPosition_m4DD45DB1A97734A1F3A81E5F259638ECAF35962F,
	RectTransform_get_sizeDelta_mDA0A3E73679143B1B52CE2F9A417F90CB9F3DAFF,
	RectTransform_set_sizeDelta_m7729BA56325BA667F0F7D60D642124F7909F1302,
	RectTransform_get_pivot_mA5BEEE2069ACA7C0C717530EED3E7D811D46C463,
	RectTransform_set_pivot_mB791A383B3C870B9CBD7BC51B2C95711C88E9DCF,
	RectTransform_set_offsetMin_m7455ED64FF16C597E648E022BA768CFDCF4531AC,
	RectTransform_set_offsetMax_mD55D44AD4740C79B5C2C83C60B0C38BF1090501C,
	RectTransform_GetLocalCorners_m8761EA5FFE1F36041809D10D8AD7BC40CF06A520,
	RectTransform_GetWorldCorners_m073AA4D13C51C5654A5983EE3FE7E2E60F7761B6,
	RectTransform_SetSizeWithCurrentAnchors_m6F93CD5B798E4A53F2085862EA1B4021AEAA6745,
	RectTransform_SendReapplyDrivenProperties_m231712A8CDDCA340752CB72690FE808111286653,
	RectTransform_GetParentSize_mFD24CC863A4D7DFBFFE23C982E9A11E9B010D25D,
	RectTransform_get_rect_Injected_m94E98A7B55F470FD170EBDA2D47E44CF919CD89F,
	RectTransform_get_anchorMin_Injected_m11D468B602FFF89A8CC25685C71ACAA36609EF94,
	RectTransform_set_anchorMin_Injected_m8BACA1B777D070E5FF42D1D8B1D7A52FFCD59E40,
	RectTransform_get_anchorMax_Injected_m61CE870627E5CB0EFAD38D5F207BC36879378DDD,
	RectTransform_set_anchorMax_Injected_m6BC717A6F528E130AD92994FB9A3614195FBFFB2,
	RectTransform_get_anchoredPosition_Injected_mCCBAEBA5DD529E03D42194FDE9C2AD1FBA8194E8,
	RectTransform_set_anchoredPosition_Injected_mCAEE3D22ADA5AF1CB4E37813EB68BF554220DAEF,
	RectTransform_get_sizeDelta_Injected_m225C77C72E97B59C07693E339E0132E9547F8982,
	RectTransform_set_sizeDelta_Injected_mD2B6AE8C7BB4DE09F1C62B4A853E592EEF9E8399,
	RectTransform_get_pivot_Injected_m23095C3331BE90EB3EEFFDAE0DAD791E79485F7F,
	RectTransform_set_pivot_Injected_m2914C16D5516DE065A932CB43B61C6EEA3C5D3D3,
	ReapplyDrivenProperties__ctor_m0633C1B8E1B058DF2C3648C96D3E4DC006A76CA7,
	ReapplyDrivenProperties_Invoke_m37F24671E6F3C60B3D0C7E0CE234B8E125D5928A,
	ReapplyDrivenProperties_BeginInvoke_m5C352648167A36402E86BEDDCAE8FA4784C03604,
	ReapplyDrivenProperties_EndInvoke_mC8DF7BD47EC8976C477491961F44912BA4C0CD7C,
	Transform__ctor_mE8E10A06C8922623BAC6053550D19B2E297C2F35,
	Transform_get_position_mF54C3A064F7C8E24F1C56EE128728B2E4485E294,
	Transform_set_position_mDA89E4893F14ECA5CBEEE7FB80A5BF7C1B8EA6DC,
	Transform_get_localPosition_m812D43318E05BDCB78310EB7308785A13D85EFD8,
	Transform_set_localPosition_m275F5550DD939F83AFEB5E8D681131172E2E1728,
	Transform_get_eulerAngles_mF2D798FA8B18F7A1A0C4A2198329ADBAF07E37CA,
	Transform_set_eulerAngles_m4B2B374C0B089A7ED0B522A3A4C56FA868992685,
	Transform_get_localEulerAngles_m445AD7F6706B0BDABA8A875C899EB1E1DF1A2A2B,
	Transform_set_localEulerAngles_mC5E92A989DD8B2E7B854F9D84B528A34AEAA1A17,
	Transform_get_right_mC32CE648E98D3D4F62F897A2751EE567C7C0CFB0,
	Transform_get_forward_m0BE1E88B86049ADA39391C3ACED2314A624BC67F,
	Transform_get_rotation_m3AB90A67403249AECCA5E02BC70FCE8C90FE9FB9,
	Transform_set_rotation_m429694E264117C6DC682EC6AF45C7864E5155935,
	Transform_get_localRotation_mEDA319E1B42EF12A19A95AC0824345B6574863FE,
	Transform_set_localRotation_mE2BECB0954FFC1D93FB631600D9A9BEFF41D9C8A,
	Transform_get_localScale_mD8F631021C2D62B7C341B1A17FA75491F64E13DA,
	Transform_set_localScale_m7ED1A6E5A87CD1D483515B99D6D3121FB92B0556,
	Transform_get_parent_m8FA24E38A1FA29D90CBF3CDC9F9F017C65BB3403,
	Transform_set_parent_m65B8E4660B2C554069C57A957D9E55FECA7AA73E,
	Transform_get_parentInternal_mEE407FBF144B4EE785164788FD455CAA82DC7C2E,
	Transform_set_parentInternal_m8534EFFADCF054FFA081769F84256F9921B0258C,
	Transform_GetParent_m1C9AFA68C014287E3D62A496A5F9AE16EF9BD7E6,
	Transform_SetParent_mFAF9209CAB6A864552074BA065D740924A4BF979,
	Transform_SetParent_m268E3814921D90882EFECE244A797264DE2A5E35,
	Transform_get_worldToLocalMatrix_m4791F881839B1087B17DC126FC0CA7F9A596073E,
	Transform_get_localToWorldMatrix_mBC86B8C7BA6F53DAB8E0120D77729166399A0EED,
	Transform_SetPositionAndRotation_mDB9B34321018846FD7E2315CBE8D4A6612E3DE43,
	Transform_TransformDirection_m85FC1D7E1322E94F65DA59AEF3B1166850B183EF,
	Transform_TransformPoint_mA96DC2A20EE7F4F915F7509863A18D99F5DD76CB,
	Transform_InverseTransformPoint_mB6E3145F20B531B4A781C194BAC43A8255C96C47,
	Transform_get_childCount_m7665D779DCDB6B175FB52A254276CDF0C384A724,
	Transform_SetAsFirstSibling_m2CAD80F7C9D89EE145BC9D3D0937D6EBEE909531,
	Transform_IsChildOf_mCB98BA14F7FB82B6AF6AE961E84C47AE1D99AA80,
	Transform_GetEnumerator_mE98B6C5F644AE362EC1D58C10506327D6A5878FC,
	Transform_GetChild_mC86B9B61E4EC086A571B09EA7A33FFBF50DF52D3,
	Transform_get_position_Injected_mFD1BD0E2D17761BA08289ABBB4F87EDFFF7C1EBB,
	Transform_set_position_Injected_mB6BEBF6B460A566E933ED59C4470ED58D81B3226,
	Transform_get_localPosition_Injected_mC1E8F9DAC652621188ABFB58571782157E4C8FBA,
	Transform_set_localPosition_Injected_m8B4E45BAADCDD69683EB6424992FC9B9045927DE,
	Transform_get_rotation_Injected_m41BEC8ACE323E571978CED341997B1174340701B,
	Transform_set_rotation_Injected_m1B409EA2BBF0C5DEE05153F4CD5134669AA2E5C0,
	Transform_get_localRotation_Injected_m1ADF4910B326BAA828892B3ADC5AD1A332DE963B,
	Transform_set_localRotation_Injected_mF84F8CFA00AABFB7520AB782BA8A6E4BBF24FDD5,
	Transform_get_localScale_Injected_mA8987BAB5DA11154A22E2B36995C7328792371BE,
	Transform_set_localScale_Injected_m9BF22FF0CD55A5008834951B58BB8E70D6982AB2,
	Transform_get_worldToLocalMatrix_Injected_mFEC701DE6F97A22DF1718EB82FBE3C3E62447936,
	Transform_get_localToWorldMatrix_Injected_mF5629FA21895EB6851367E1636283C7FB70333A9,
	Transform_SetPositionAndRotation_Injected_mD8DC359CE79CE34899FF76F73469884818AC299A,
	Transform_TransformDirection_Injected_m5E7C9D4E879820DF32F1CB1DE1504C59B8E98943,
	Transform_TransformPoint_Injected_mB697D04DF989E68C8AAFAE6BFBBE718B68CB477D,
	Transform_InverseTransformPoint_Injected_m320ED08EABA9713FDF7BDAD425630D567D39AB1D,
	Enumerator__ctor_mBF5A46090D26A1DD98484C00389566FD8CB80770,
	Enumerator_get_Current_mD91FA41B0959224F24BF83051D46FCF3AF82F773,
	Enumerator_MoveNext_mF27E895DC4BB3826D2F00E9484A9ECC635770031,
	Enumerator_Reset_mA4AD59858E0D61FE247C0E158737A4C02FCE244F,
	Sprite__ctor_m8559FBC54BD7CDA181B190797CC8AC6FB1310F9E,
	Sprite_GetPackingMode_mF0507D88752CDA45A9283445067070092E524317,
	Sprite_GetPacked_mBDE07283B07E7FB8892D309C5EDC81584C849BCC,
	Sprite_GetTextureRect_mE506ABF33181E32E82B75479EE4A0910350B1BF9,
	Sprite_GetInnerUVs_m273E051E7DF38ED3D6077781D75A1C1019CABA25,
	Sprite_GetOuterUVs_mD78E47470B4D8AD231F194E256136B0094ECEBC5,
	Sprite_GetPadding_m5781452D40FAE3B7D0CE78BF8808637FBFE78105,
	Sprite_CreateSprite_m1F676037B8C5EB3E216F70EE4630662FF144AFC5,
	Sprite_get_bounds_mD440465B889CCD2D80D118F9174FD5EAB19AE874,
	Sprite_get_rect_mF1D59ED35D077D9B5075E2114605FDEB728D3AFF,
	Sprite_get_border_m940E803CAD380B3B1B88371D7A4E74DF9A48604F,
	Sprite_get_texture_mA1FF8462BBB398DC8B3F0F92B2AB41BDA6AF69A5,
	Sprite_get_pixelsPerUnit_m54E3B43BD3D255D18CAE3DC8D963A81846983030,
	Sprite_get_associatedAlphaSplitTexture_m2EF38CF62616FBBBBAE7876ECBCC596DB3F42156,
	Sprite_get_pivot_m8E3D24C208E01EC8464B0E63FBF3FB9429E4C1D9,
	Sprite_get_packed_m501A9E7D2C44867665FB579FD1A8C5D397C872C3,
	Sprite_get_packingMode_m1B5AA0F5476DAEADFF14F65E99944B54940D869F,
	Sprite_get_textureRect_m8CDA38796589CB967909F78076E7138907814DCD,
	Sprite_get_vertices_mD858385A07239A56691D1559728B1B5765C32722,
	Sprite_get_triangles_m3B0A097930B40C800E0591E5B095D118D2A33D2E,
	Sprite_get_uv_mBD484CDCD2DF54AAE452ADBA927806193CB0FE84,
	Sprite_Create_mE9E237E1E936F7A7398361253D1D7C7B7ECD622F,
	Sprite_Create_m4BF8E8E0F77846FA88502FD896E3AFB6D2AB2E0A,
	Sprite_Create_mBF0676DF6C3CB8554451DC01E0713CF73C84DB4A,
	Sprite_Create_mE9C9B96A1D1EC541FF41148E2001223C2030F803,
	Sprite_Create_m84A724DB0F0D73AEBE5296B4324D61EBCA72A843,
	Sprite_Create_m9ED36DA8DA0637F93BA2753A16405EB0F7B17A3C,
	Sprite_GetTextureRect_Injected_m3D0143FD7E689267FAE3164F7C149DB5FF3384C2,
	Sprite_GetInnerUVs_Injected_m19AF3A32647EE2153374B4B58CB248A5E3715F6B,
	Sprite_GetOuterUVs_Injected_m57E56A2D7686D47E6948511F102AF8135E98B2B0,
	Sprite_GetPadding_Injected_m843873F288F8CBC4BDDF1BBE20211405039ABBDC,
	Sprite_CreateSprite_Injected_m5393FA2042C8AF5D7E9CC32A2255270EE3DA702D,
	Sprite_get_bounds_Injected_m6422C2DBFD84A7B7F921DCA14BDFF2157738194B,
	Sprite_get_rect_Injected_mABF4FCC2AEDD9EE874797E35EDEFF023A52F5830,
	Sprite_get_border_Injected_mA56DD9A38B61783341DF35C808FBFE93A1BD4BB6,
	Sprite_get_pivot_Injected_m526201DCD812D7AB10AACE35E4195F7E53B633EC,
	APIUpdaterRuntimeHelpers_GetMovedFromAttributeDataForType_m2574674719979232087612C3C17A760E439BCA45,
	APIUpdaterRuntimeHelpers_GetObsoleteTypeRedirection_m43E0605422153F402426F8959BC2E8C65A69F597,
	DataUtility_GetInnerUV_m19FC4FF27A6733C9595B63F265EFBEC3BC183732,
	DataUtility_GetOuterUV_mB7DEA861925EECF861EEB643145C54E8BF449213,
	DataUtility_GetPadding_mE967167C8AB44F752F7C3A7B9D0A2789F5BD7034,
	DataUtility_GetMinSize_m8031F50000ACDDD00E1CE4C765FA4B0A2E9255AD,
	PixelPerfectRendering_set_pixelSnapSpacing_mDBC4671A1F9226F5082533483F64B9B2E65DFC32,
	SpriteAtlasManager_RequestAtlas_m792F61C44C634D9E8F1E15401C8CECB7A12F5DDE,
	SpriteAtlasManager_add_atlasRegistered_m6742D91F217B69CC2A65D80B5F25CFA372A1E2DA,
	SpriteAtlasManager_remove_atlasRegistered_m55564CC2797E687E4B966DC1797D059ABBB04051,
	SpriteAtlasManager_PostRegisteredAtlas_m2FCA85EDC754279C0A90CC3AF5E12C3E8F6A61CB,
	SpriteAtlasManager_Register_m2C324F6E122AF09D44E4EE3F8F024323663670D2,
	SpriteAtlasManager__cctor_m826C9096AB53C9C6CFCF342FA9FDC345A726B6C6,
	SpriteAtlas_CanBindTo_m6CE0E011A4C5F489F9A62317380FB35F20DF7016,
	Sampler__ctor_mEDF95F36C69BA3C699F942DE455131B3B74A772A,
	Sampler__cctor_mF1262C0B147581D48C65976480293BA7E4CE816F,
	CustomSampler__ctor_m6AF8A65CE6483316530AC812D0A3904DD30BE426,
	CustomSampler__ctor_m3C1E95E5355AE3C5C736F6DAFCBF5EB92E5E4771,
	CustomSampler_Create_m454B8B69BB1085AAC8AFC39B1EB311474080C0BA,
	CustomSampler_CreateInternal_mDD89E974215C157E5BCD54ABCFCB56CF6BAB3B8F,
	CustomSampler__cctor_mB5B9C73DFC279A84D57351F6AE105779B94ABDED,
	DebugScreenCapture_set_rawImageDataReference_mE09725CEBC8D7A846033531E33C8E9B8DA60DFDE_AdjustorThunk,
	DebugScreenCapture_set_imageFormat_m779E16070B55AACD76279BFDDAE5CC470667D3FB_AdjustorThunk,
	DebugScreenCapture_set_width_mD8B3C521091CD0049D323410FFD201D47B629127_AdjustorThunk,
	DebugScreenCapture_set_height_mD7E3596B40E77F906A3E9517BC6CE795C0609442_AdjustorThunk,
	MetaData__ctor_m1852CAF4EDFB43F1ABCE37819D9963CEE959A620,
	MemoryProfiler_PrepareMetadata_mDFBA7A9960E5B4DF4500092638CD59EB558DD42C,
	MemoryProfiler_WriteIntToByteArray_mBC872709F6A09ADFE716F41C459C1FCC1EFF25A0,
	MemoryProfiler_WriteStringToByteArray_mCAC0D283F16F612E4796C539994FDB487A048332,
	MemoryProfiler_FinalizeSnapshot_m48FD62744888BBF0A9B13826622041226C8B9AD7,
	MemoryProfiler_SaveScreenshotToDisk_mCA2AE332D689BEDE49DECACD92FDA366EB80047F,
	PhraseRecognitionSystem_PhraseRecognitionSystem_InvokeErrorEvent_m9FF196C06264F6035686945A734E1AC01A0E2E33,
	PhraseRecognitionSystem_PhraseRecognitionSystem_InvokeStatusChangedEvent_mF25930BC6443439CCBAF346B89799358451239D8,
	ErrorDelegate__ctor_mE77BF50AF1FD2FE54199276141F6B3CB17D2E1B1,
	ErrorDelegate_Invoke_m448BAD63228E49AEB609A60052F1E05C93853B17,
	ErrorDelegate_BeginInvoke_m3A859400873FD62B71B597C2771E50F94B344E09,
	ErrorDelegate_EndInvoke_m140002C504FD22C3B6C0F150576D37EE4A921189,
	StatusDelegate__ctor_mA3683647B7522FDFCC92DBE0161D7F585741477E,
	StatusDelegate_Invoke_mBA807D0015000ABE36C5B9B6F847D2882D3B26ED,
	StatusDelegate_BeginInvoke_m814D9105249F941053622B079479E04A4FB6D227,
	StatusDelegate_EndInvoke_mF6B9A0C43A10A4CA34F56684DD4FB842FFB5D1FF,
	PhraseRecognizer_InvokePhraseRecognizedEvent_mDBD38FADAC58DF9B960342AC84EE32CF221B0F02,
	PhraseRecognizer_MarshalSemanticMeaning_m444804CA07F778FD0E23E78432EE0E377579C26A,
	PhraseRecognizedDelegate__ctor_m0D7CFE194591D6DEE1120B7E23917C77ED5027F1,
	PhraseRecognizedDelegate_Invoke_m6136E32699B51A86EA0C594D338C7EC29F493478,
	PhraseRecognizedDelegate_BeginInvoke_m262B7DABBDF14FCBFF43293BF2FB06AC676CB962,
	PhraseRecognizedDelegate_EndInvoke_m53944ABF37F32936C799FBBD922F7ECD9B0235D4,
	DictationRecognizer_DictationRecognizer_InvokeHypothesisGeneratedEvent_mD5D8576CD4D2BC21FFBBFACAE879D9E35BFD4BED,
	DictationRecognizer_DictationRecognizer_InvokeResultGeneratedEvent_m144DE6D67869D7308AA407D42D068B17410916EA,
	DictationRecognizer_DictationRecognizer_InvokeCompletedEvent_mCB00EBDBFA1E43EEEFEF8A98BC681350ED071479,
	DictationRecognizer_DictationRecognizer_InvokeErrorEvent_mF72B166A7D7F1D73E508FD4350DD6B4A147D047F,
	DictationHypothesisDelegate__ctor_mFB606F04C9375D67CD8701F116EA58381924D3A1,
	DictationHypothesisDelegate_Invoke_m13B00B4DADC3F35EF3655EFEA69A68917609CD53,
	DictationHypothesisDelegate_BeginInvoke_mFCA96ECCE23AB50C58CA8DA154B73C7E20C618F1,
	DictationHypothesisDelegate_EndInvoke_mD3BED2D554BE05C00F5393F48BD66E3B8AFF283C,
	DictationResultDelegate__ctor_mDECF2707DE7D125C6DE6BE8EC8E1BCD1539CF40C,
	DictationResultDelegate_Invoke_mC2BCB095B651CD4DE23FED7A0A0C92A6684A5C91,
	DictationResultDelegate_BeginInvoke_mB1DAE084A144180C6B6C3FBB95FC11C953E51872,
	DictationResultDelegate_EndInvoke_m9F81B0B190A0455B077CDC0222059CEA973B83C3,
	DictationCompletedDelegate__ctor_m5B703B2796175B619EDBD28F7B6EB86294678369,
	DictationCompletedDelegate_Invoke_m393D08D4E4C4BDC07D2C1086678A3BC34ADD5C37,
	DictationCompletedDelegate_BeginInvoke_m86D73A3A2CE70124C65709ADABB270C4F4A981F1,
	DictationCompletedDelegate_EndInvoke_m76C332FC975E3C94B71ED70F0CC1F04DE52BA964,
	DictationErrorHandler__ctor_m13B3D1B66DB5DB3FA513E70E2DBEEBA1FDC6D0D6,
	DictationErrorHandler_Invoke_mC67E23094C88F1042656F92133FE2C9E32FFA52F,
	DictationErrorHandler_BeginInvoke_mD24E9C40E56521AC36B8D32518198DFB89D9827C,
	DictationErrorHandler_EndInvoke_mD1499F5B20B970B36944DFE8111CE94171656798,
	PhraseRecognizedEventArgs__ctor_m362E97ADA890AE34C5E062B0FEED70E46E110ECE_AdjustorThunk,
	PhotoCapture_MakeCaptureResult_m30A1524DDA706A094516C9C1E191367B8194B2AA,
	PhotoCapture_InvokeOnCreatedResourceDelegate_mAEC319E9811B816A642DA8A135CCEC3CB91C75DA,
	PhotoCapture__ctor_mD7209B9F37CC0D345E634824E5792EB186EED544,
	PhotoCapture_InvokeOnPhotoModeStartedDelegate_m8C4172E50A49CDC9F2895BCE031428B4EE931CC2,
	PhotoCapture_InvokeOnPhotoModeStoppedDelegate_m17CFB212EE2F2E765241E0E6DD8F2B17E03B6F94,
	PhotoCapture_InvokeOnCapturedPhotoToDiskDelegate_mB6AEB939C6D1ACC29FA6E711E92924319674E604,
	PhotoCapture_InvokeOnCapturedPhotoToMemoryDelegate_m81F2206975AEBC72CBE1238EDA770DCE7F9A9ED8,
	PhotoCapture_Dispose_mAC295018942A4ACBBC627647FE0F463C21F94CE0,
	PhotoCapture_Dispose_Internal_m88BD45BC25F5336BF81ECF697CC14F5FC04D8234,
	PhotoCapture_Finalize_m8F5ABCCAA23CFF5949D6DC26EE6A164C2B952A42,
	PhotoCapture_DisposeThreaded_Internal_m2ECAF91B1E62B4B392A1CAA7953C5A599C6115B9,
	PhotoCapture__cctor_mB6B5B17F07B739073CCE8934A6AF65A74DD53259,
	OnCaptureResourceCreatedCallback__ctor_mAAD465DAB1EA7C5EAEEF4D99E58E790A84523131,
	OnCaptureResourceCreatedCallback_Invoke_m787BA10D9B4F55B5015FF0790E904D3822357A1A,
	OnCaptureResourceCreatedCallback_BeginInvoke_mDC83388D4F69C259D3E383BB43257060AC0B9949,
	OnCaptureResourceCreatedCallback_EndInvoke_mB7FDC61A9CC48C49932893AC1FF1B48EBCAA4CF0,
	OnPhotoModeStartedCallback__ctor_m990C6B308C927E3A4CF7B9F6B5C8E100990F4030,
	OnPhotoModeStartedCallback_Invoke_m55517FF76661702C2833E956934524EDBBF5A7C1,
	OnPhotoModeStartedCallback_BeginInvoke_mBCCD40B907D5289FBD9F4E306E68BED5E74D7E4E,
	OnPhotoModeStartedCallback_EndInvoke_m1302B87CE9EB9432AA4DB74D5DFDBD1823E5FD0C,
	OnPhotoModeStoppedCallback__ctor_m8A90D66450A8C11352A39C2A61ECA8B4AE482933,
	OnPhotoModeStoppedCallback_Invoke_m48D94A324C05FC097090E2C876AF6B4BC8EE13EE,
	OnPhotoModeStoppedCallback_BeginInvoke_m21A3D9F9B428F00D754B8C4DFAFC6E5C594E5B35,
	OnPhotoModeStoppedCallback_EndInvoke_m32021025A8CCD26030D859237B8304EC0CAF06AD,
	OnCapturedToDiskCallback__ctor_m422F63D53BEB921A7685600FBE41069C79959EE3,
	OnCapturedToDiskCallback_Invoke_m9117393C833DA86181047DD79B92317B940AEB06,
	OnCapturedToDiskCallback_BeginInvoke_mBFF762F91DF363C1BC015BDEF93B1242A02FF9F6,
	OnCapturedToDiskCallback_EndInvoke_mC2E3EC1D4522A7910110D94DECC7CCD0B21123D1,
	OnCapturedToMemoryCallback__ctor_m377769F37D6EA6AD73ED08D5A14564FCDFBFDACE,
	OnCapturedToMemoryCallback_Invoke_m2382646696D4D08D880B9621E40F4E7CD969498E,
	OnCapturedToMemoryCallback_BeginInvoke_mD05157F78B546F75A987887C683FAC6A922A49B7,
	OnCapturedToMemoryCallback_EndInvoke_mE06069F070AC6C019F5C56BD3CEF38D43BDCF550,
	PhotoCaptureFrame_get_dataLength_m2169CBC908EF8673C1876952BCB9C1642706849C,
	PhotoCaptureFrame_set_dataLength_m708C3983B97B7470A4E7A4692A590E5338465A5B,
	PhotoCaptureFrame_set_hasLocationData_mA2E608666F3D923EEBCFFD1F2A8534BFAC938CD9,
	PhotoCaptureFrame_set_pixelFormat_m956028BE24FB4646618B56A24CDB9559026B78D4,
	PhotoCaptureFrame_GetDataLength_m2D4FC19B5BEED3478C681DD941F7018F142788DB,
	PhotoCaptureFrame_GetHasLocationData_m01BDCAD79360F3BAF759FF2A9EB2963C480BEF42,
	PhotoCaptureFrame_GetCapturePixelFormat_mD1DED87FE85284782AE1533390314119BD1B5C6E,
	PhotoCaptureFrame__ctor_m2200B47E027A635C22A6822CE3548BBFD38CFF01,
	PhotoCaptureFrame_Cleanup_m4F7B4E31415ABD61458F394F09597B9CE31C9E0C,
	PhotoCaptureFrame_Dispose_Internal_m24C9E95622D5362B90B3B9231F3E773E4C8B5ECB,
	PhotoCaptureFrame_Dispose_mA569A16F2EE402B143C252D57B6C93040B81BABD,
	PhotoCaptureFrame_Finalize_m597A19661FD4FDF0B20C50E16891C559B3826EAA,
	VideoCapture_MakeCaptureResult_m8E3FDAF1FB4B3F56197D02ECB1E94BA16ED01524,
	VideoCapture_InvokeOnCreatedVideoCaptureResourceDelegate_mF9883CC0DE032FC32261999B5DBA0FA3B97BEA12,
	VideoCapture__ctor_m0FE3A72AA0BE57264435FD94F28228F5A82E15FB,
	VideoCapture_InvokeOnVideoModeStartedDelegate_m26310208BD52CAC57B4F7581FBAFC7EEF491EA98,
	VideoCapture_InvokeOnVideoModeStoppedDelegate_mD5BD41E17DC995244E5466CBAA9C370168EE12C2,
	VideoCapture_InvokeOnStartedRecordingVideoToDiskDelegate_m6D5AEC9ACC849B33AA27AEC954FF67C8333505F2,
	VideoCapture_InvokeOnStoppedRecordingVideoToDiskDelegate_m2F132EE579D852F77A5F70639EDEE85E7AE13739,
	VideoCapture_Dispose_m05A80B67D93D420B5FFA350028C62AC7C3A2791F,
	VideoCapture_Dispose_Internal_m544E2E76F43A934DA00C58277E89C27E96A6F952,
	VideoCapture_Finalize_m7B97B93616E65E61B55F4D9B6784E65C4916C2F2,
	VideoCapture_DisposeThreaded_Internal_m731C1AD152F8A05604EC9B286FA69C1591A71068,
	VideoCapture__cctor_m575F77433389795AB691B84D88DD79C1D2CFBD06,
	OnVideoCaptureResourceCreatedCallback__ctor_m8126E742A34950E1A69239EA771F99FB4BF0C751,
	OnVideoCaptureResourceCreatedCallback_Invoke_mCBAB47A08804FC4A040E3E6D0DB626A3C3471182,
	OnVideoCaptureResourceCreatedCallback_BeginInvoke_m6EE12058C9073F8075C6104E3793156BC232A0F1,
	OnVideoCaptureResourceCreatedCallback_EndInvoke_m991BC133674B0CC5BD3DFA0114DB7612B1A5297A,
	OnVideoModeStartedCallback__ctor_m1753A0D7909741085AEC31818DDFB57D59EBE539,
	OnVideoModeStartedCallback_Invoke_mB9A2828F520201F753009139BDB2C193A38687A0,
	OnVideoModeStartedCallback_BeginInvoke_m95E5682FF37266B911974288C4E9090187B416C0,
	OnVideoModeStartedCallback_EndInvoke_mFF236A689DD47097F9CACB33E48B8D8410B8507D,
	OnVideoModeStoppedCallback__ctor_mDAB9D65B5DCFFF1D4BF5C3109D7C95051818A6C8,
	OnVideoModeStoppedCallback_Invoke_m2CFBF6763FCED9C9201834019A962EACF2F1D088,
	OnVideoModeStoppedCallback_BeginInvoke_m21579FF978236D09DEB3AC1F508A4EF4A04A8FAB,
	OnVideoModeStoppedCallback_EndInvoke_mB36D35F04396E8787C3053B300DBDA24E2562DE2,
	OnStartedRecordingVideoCallback__ctor_m5303F5AED4F0183EB22E5108148404E8B1DF7ECD,
	OnStartedRecordingVideoCallback_Invoke_mE31381DAE5B30D92A9186FA747C5AC023048114D,
	OnStartedRecordingVideoCallback_BeginInvoke_m64CB638B651C771C976BC6251A897DBC33F9FFE7,
	OnStartedRecordingVideoCallback_EndInvoke_mD9413A65A1749390BD613712A3DD510650A1D267,
	OnStoppedRecordingVideoCallback__ctor_m87A4D9B5EEF3E3C1C32B7A56D5D60FDAE77890A3,
	OnStoppedRecordingVideoCallback_Invoke_mA23DA19077DFC878FC21A80106550E09E514EDF4,
	OnStoppedRecordingVideoCallback_BeginInvoke_mA96640AB5DA79F3C8C07367769094492D30056BB,
	OnStoppedRecordingVideoCallback_EndInvoke_mF7901932350D8462A33A68A8ACD4FCFE21AF383D,
	ArgumentCache_get_unityObjectArgument_m89597514712FB91B443B9FB1A44D099F021DCFA5,
	ArgumentCache_get_unityObjectArgumentAssemblyTypeName_mD54EA1424879A2E07B179AE93D374100259FF534,
	ArgumentCache_get_intArgument_mD9D072A7856D998847F159350EAD0D9AA552F76B,
	ArgumentCache_get_floatArgument_mDDAD91A992319CF1FFFDD4F0F87C5D162BFF187A,
	ArgumentCache_get_stringArgument_mCD1D05766E21EEFDFD03D4DE66C088CF29F84D00,
	ArgumentCache_get_boolArgument_mCCAB5FB41B0F1C8C8A2C31FB3D46DF99A7A71BE2,
	ArgumentCache_TidyAssemblyTypeName_m2D4AFE74BEB5F32B14165BB52F6AB29A75306936,
	ArgumentCache_OnBeforeSerialize_mCBE8301FE0DDE2E516A18051BBE3DC983BC80FBC,
	ArgumentCache_OnAfterDeserialize_m59072D771A42C518FECECBE2CE7EE9E15F4BE55F,
	ArgumentCache__ctor_m9618D660E40F991782873643F0FDCACA32A63541,
	BaseInvokableCall__ctor_m232CE2068209113988BB35B50A2965FC03FC4A58,
	BaseInvokableCall__ctor_m71AC21A8840CE45C2600FF784E8B0B556D7B2BA5,
	NULL,
	NULL,
	BaseInvokableCall_AllowInvoke_m0B193EBF1EF138FC5354933974DD702D3D9FF091,
	NULL,
	InvokableCall_add_Delegate_mCE91CE04CF7A8B962FF566B018C8C516351AD0F3,
	InvokableCall_remove_Delegate_m0CFD9A25842A757309236C500089752BF544E3C7,
	InvokableCall__ctor_m2F9F0CD09FCFFEBCBBA87EC75D9BA50058C5B873,
	InvokableCall__ctor_m77F593E751D2119119A5F3FD39F8F5D3B653102B,
	InvokableCall_Invoke_mDB8C26B441658DDA48AC3AF259F4A0EBCF673FD0,
	InvokableCall_Invoke_m0B9E7F14A2C67AB51F01745BD2C6C423114C9394,
	InvokableCall_Find_mDC13296B10EFCD0A92E486CD5787E07890C7B8CC,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PersistentCall_get_target_mCAD7D486F28743D49DCF268B791721313A7FC8C5,
	PersistentCall_get_methodName_m164BE545C327516CABE9464D88A417B7F00010E1,
	PersistentCall_get_mode_mC88324F8D18B5E4E79045AE1F99DF3EB36CEE644,
	PersistentCall_get_arguments_m53AFE12B586F0C8948D60852866EC71F38B3BAE1,
	PersistentCall_IsValid_mF3E3A11AF1547E84B2AC78AFAF6B2907C9B159AE,
	PersistentCall_GetRuntimeCall_m68F27109F868C451A47DAC3863B27839C515C3A6,
	PersistentCall_GetObjectCall_m895EBE1B8E2A4FB297A8C268371CA4CD320F72C9,
	PersistentCall__ctor_mBF65325BE6B4EBC6B3E8ADAD3C6FA77EF5BBEFA8,
	PersistentCallGroup__ctor_m46B7802855B55149B9C1ECD9C9C97B8025BF2D7A,
	PersistentCallGroup_Initialize_m9F47B3D16F78FD424D50E9AE41EB066BA9C681A3,
	InvokableCallList_AddPersistentInvokableCall_m62BDD6521FB7B68B58673D5C5B1117FCE4826CAD,
	InvokableCallList_AddListener_mE4069F40E8762EF21140D688175D7A4E46FD2E83,
	InvokableCallList_RemoveListener_mC886122D45A6682A85066E48637339065085D6DE,
	InvokableCallList_ClearPersistent_m4038DB499DCD84B79C0F1A698AAA7B9519553D49,
	InvokableCallList_PrepareInvoke_m5BB28A5FBF10C84ECF5B52EBC52F9FCCDC840DC1,
	InvokableCallList__ctor_m8A5D49D58DCCC3D962D84C6DAD703DCABE74EC2D,
	UnityEventBase__ctor_m57AF08DAFA9C1B4F4C8DA855116900BAE8DF9595,
	UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m147F610873545A23E9005CCB35CA6A05887E7599,
	UnityEventBase_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_m3A87E89948C5FF32BD5BA1BDD1A4D791738A141E,
	NULL,
	NULL,
	UnityEventBase_FindMethod_m4E838DE0D107C86C7CAA5B05D4683066E9EB9C32,
	UnityEventBase_FindMethod_m82A135403D677ECE42CEE42A322E15EB2EA53797,
	UnityEventBase_DirtyPersistentCalls_m31D9B2D3B265718318F4D7E87373E53F249E65EB,
	UnityEventBase_RebuildPersistentCallsIfNeeded_mFC89AED628B42E5B1CBCC702222A6DF97605234F,
	UnityEventBase_AddCall_mD45F68C1A40E2BD9B0754490B7709846B84E8075,
	UnityEventBase_RemoveListener_mE7EBC544115373D2357599AC07F41F13A8C5A49E,
	UnityEventBase_PrepareInvoke_mFA3E2C97DB776A1089DCC85C9F1DA75C295032AE,
	UnityEventBase_ToString_m7672D78CA070AC49FFF04E645523864C300DD66D,
	UnityEventBase_GetValidMethodInfo_m4521621AB72C7265A2C0EC6911BE4DC42A99B6A5,
	UnityAction__ctor_mEFC4B92529CE83DF72501F92E07EC5598C54BDAC,
	UnityAction_Invoke_mC9FF5AA1F82FDE635B3B6644CE71C94C31C3E71A,
	UnityAction_BeginInvoke_m6819B1057D192033B17EB15C9E34305720F0401C,
	UnityAction_EndInvoke_m9C465516D5977EF185DCEB6CA81D0B90EDAD7370,
	UnityEvent__ctor_m2F8C02F28E289CA65598FF4FA8EAB84D955FF028,
	UnityEvent_AddListener_m31973FDDC5BB0B2828AB6EF519EC4FD6563499C9,
	UnityEvent_FindMethod_Impl_mC96F40A83BB4D1430E254DAE9B091E27E42E8796,
	UnityEvent_GetDelegate_m8D277E2D713BB3605B3D46E5A3DB708B6A338EB0,
	UnityEvent_GetDelegate_mDFBD636D71E24D75D0851959256A3B97BA842865,
	UnityEvent_Invoke_mB2FA1C76256FE34D5E7F84ABE528AC61CE8A0325,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	FormerlySerializedAsAttribute__ctor_m770651B828F499F804DB06A777E8A4103A3ED2BD,
	PreserveAttribute__ctor_mD842EE86496947B39FE0FBC67393CE4401AC53AA,
	MovedFromAttributeData_Set_m244D6454BEA753FA4C7C3F2393A5DADCB3166B1C_AdjustorThunk,
	MovedFromAttribute__ctor_mF87685F9D527910B31D3EF58F0EAA297E1944B42,
	Scene_get_handle_mFAB5C41D41B90B9CEBB3918A6F3638BD41E980C9_AdjustorThunk,
	Scene_GetHashCode_m65BBB604A5496CF1F2C129860F45D0E437499E34_AdjustorThunk,
	Scene_Equals_mD5738AF0B92757DED12A90F136716A5E2DDE3F54_AdjustorThunk,
	SceneManager_Internal_SceneLoaded_m800F5F7F7B30D5206913EF65548FD7F8DE9EF718,
	SceneManager_Internal_SceneUnloaded_m32721E87A02DAC634DD4B9857092CC172EE8CB98,
	SceneManager_Internal_ActiveSceneChanged_mE9AB93D6979594CFCED5B3696F727B7D5E6B25F5,
	SceneManager__cctor_m36C7C4EECB3F22A383FA829341F6A4EA0B2D3377,
	UpdateFunction__ctor_m203C45C9226ED025C1369B78B759C952ABDA630A,
	UpdateFunction_Invoke_m6C0E9E5082FCEEF018602FD40A43E613360D410D,
	UpdateFunction_BeginInvoke_m7261B0AA3E858CC7A24FF343DE292DB5A34DAC0C,
	UpdateFunction_EndInvoke_m49FBADEA0EED0F50341E2E1F5F21349C2059EA55,
	MessageEventArgs__ctor_m436B854CFEEDB949F4D9ACAEA2E512BDAEDC6E1B,
	PlayerConnection_get_instance_mF51FB76C702C7CDD0BAEAD466060E3BDF23D390F,
	PlayerConnection_get_isConnected_mB902603E2C8CA93299FF0B28E13A9D594CBFE14E,
	PlayerConnection_CreateInstance_m6325767D9D05B530116767E164CDCBE613A5787F,
	PlayerConnection_OnEnable_m9D8136CEB952BC0F44A46A212BF2E91E5A769954,
	PlayerConnection_GetConnectionNativeApi_mC88D9972FDF9D4FF15CC8C4BB6CA633FB114D918,
	PlayerConnection_Register_m9B203230984995ADF5E19E50C3D7DF7E21036FF2,
	PlayerConnection_Unregister_m8EB88437DF970AA6627BC301C54A859DAED70534,
	PlayerConnection_RegisterConnection_m7E54302209A4F3FB3E27A0E7FEB8ADE32C100F1B,
	PlayerConnection_RegisterDisconnection_m556075060F55D3FA7F44DEB4B34CE1070ECBF823,
	PlayerConnection_UnregisterConnection_mC6A080D398CD6C267C1638D98F7485E2B837D029,
	PlayerConnection_UnregisterDisconnection_m148453805654D809DB02F377D0FBC4524F63EBF6,
	PlayerConnection_Send_m1CDF41319A60A5940B487D08ECE14D0B61EDE6AC,
	PlayerConnection_TrySend_m3C0D0208A6A8A7F7FF93AF155A71B726ABE8D662,
	PlayerConnection_BlockUntilRecvMsg_mFCF2DB02D6F07C0A69C0412D8A3F596AF4AC54A2,
	PlayerConnection_DisconnectAll_m278A4B90D90892338D1B41F5A59CD7C519F1C8D2,
	PlayerConnection_MessageCallbackInternal_m3E9A847ED82FDA9ABB680F81595A876450EFB166,
	PlayerConnection_ConnectedCallbackInternal_mFEC88D604DE3923849942994ED873B26CEEDDA3D,
	PlayerConnection_DisconnectedCallback_m2A12A748DDACDD3877D01D7F38ABBC55DEE26A56,
	PlayerConnection__ctor_m3E1248C28C3082C592C2E5F69778F31F6610D93D,
	U3CU3Ec__DisplayClass12_0__ctor_m2685C903220EF0EFCFABCCCCE85520064EEB9BCE,
	U3CU3Ec__DisplayClass12_0_U3CRegisterU3Eb__0_m1979ADC0BD33A692CDFDD59354B756C347611773,
	U3CU3Ec__DisplayClass13_0__ctor_m75A34D41161C0967E4A336B2713ACAE2BD5F5F46,
	U3CU3Ec__DisplayClass13_0_U3CUnregisterU3Eb__0_m8C6607EC9FE0F26B57047ED3642837003A532C79,
	U3CU3Ec__DisplayClass20_0__ctor_m3E72979DC019A7C47E2AB71E1F17B9056A7D068B,
	U3CU3Ec__DisplayClass20_0_U3CBlockUntilRecvMsgU3Eb__0_m89ABCD175D2DA1D535B2645459C38003ECBC896C,
	PlayerEditorConnectionEvents_InvokeMessageIdSubscribers_mFA28BDF3B52AEF86161F33B52699253181800926,
	PlayerEditorConnectionEvents_AddAndCreate_mB5A51595E4A5DA3B9F353AC72F7B0484C675B7D3,
	PlayerEditorConnectionEvents_UnregisterManagedCallback_mFD3A444E636B079C03739DC96BAFFD5FD55C574A,
	PlayerEditorConnectionEvents__ctor_m9BE616B901BCACAABEC9063A838BB803AB7EC2A7,
	MessageEvent__ctor_m700B679037ED52893F092843EE603DBCD6EB8386,
	ConnectionChangeEvent__ctor_m3F04C39FD710BF0F25416A61F479CBA1B9021F18,
	MessageTypeSubscribers_get_MessageTypeId_mE7DD7E800436C92A325A1080AF60663AE1100D25,
	MessageTypeSubscribers_set_MessageTypeId_m294A7B621AAF1984D886D2569CF1206E4F469115,
	MessageTypeSubscribers__ctor_mD26A2485EA3ECACFA2CB35D08A48256CE9DFE825,
	U3CU3Ec__DisplayClass6_0__ctor_mC65CF56D3417BA36ED321886F1E7A1AF8D443966,
	U3CU3Ec__DisplayClass6_0_U3CInvokeMessageIdSubscribersU3Eb__0_m7208417727D24E769D2C1CF90D6E4CC1AE1F2556,
	U3CU3Ec__DisplayClass7_0__ctor_m59072FF40A09DA582550D3DED10DA2A93FBEAFEF,
	U3CU3Ec__DisplayClass7_0_U3CAddAndCreateU3Eb__0_m24A60437D2E527CE675AC4AFAC8152BCA69B033B,
	U3CU3Ec__DisplayClass8_0__ctor_mE25781AE393CFFE6170E4D655A751918973393AB,
	U3CU3Ec__DisplayClass8_0_U3CUnregisterManagedCallbackU3Eb__0_m11D9A0AFB947855B548E99416A058C4AAA2E2B26,
	DefaultValueAttribute__ctor_m2E914CFCFD82ACAB447480971570E5763C42DAAD,
	DefaultValueAttribute_get_Value_m1E1505D5F1838C28CA4C52DED4A20E81F81BFCC3,
	DefaultValueAttribute_Equals_mD9073A5C537D4DBDFBD5E3616BC5A05B5D0C51B2,
	DefaultValueAttribute_GetHashCode_m4782E2C5A005991FA7E705110A690DD5E0E52D50,
	ExcludeFromDocsAttribute__ctor_m01F11706D334D5D31B0C59630DB1674ECFBFAF04,
	RenderTargetIdentifier__ctor_mC9F9E7E9E601C54067BD503DD592A2212594BD16_AdjustorThunk,
	RenderTargetIdentifier__ctor_m055D23CB6BA657306005CBD53F58FC995B4DA977_AdjustorThunk,
	RenderTargetIdentifier__ctor_mB2D86972876305C456360182A9315B82FEFF8626_AdjustorThunk,
	RenderTargetIdentifier__ctor_m52105EEE0684E42DC890D059B45A22FCA5FBEA64_AdjustorThunk,
	RenderTargetIdentifier__ctor_m51C7EDAEACCD0E210235DDA5769507BA62D290E3_AdjustorThunk,
	RenderTargetIdentifier_op_Implicit_m080A48CE8A898732E2554818DD3BF66004369D1B,
	RenderTargetIdentifier_op_Implicit_mC840E0D824C89F1B45CF6484764C33FFF0160E1D,
	RenderTargetIdentifier_op_Implicit_mC09883E389EF054E8DDB5F3CFAD57AAE6EB9F222,
	RenderTargetIdentifier_ToString_mCFDB39041DD38EB31806B9DFE0A617E2F4034623_AdjustorThunk,
	RenderTargetIdentifier_GetHashCode_m2B944611B172983A1960899C5D50D2963CCFC0A0_AdjustorThunk,
	RenderTargetIdentifier_Equals_m00E3CCDBDEBC15F4ADEEF48412F283B001EFB6E8_AdjustorThunk,
	RenderTargetIdentifier_Equals_mB5F0CAF9B997DC7AE33D33CB48F434534326E9CD_AdjustorThunk,
	RenderTargetIdentifier_op_Equality_mAB9168185A74088E10E2AC74603FA4C8C14FB8DC,
	RenderTargetIdentifier_op_Inequality_m437F3C325DBD8A46ED251E297B0714B15DE3B174,
	GraphicsSettings_get_lightsUseLinearIntensity_mED8D75F87016FCF600955146863696AB214BA29A,
	GraphicsSettings_set_lightsUseLinearIntensity_mC6F381972C7D65C767AE062D66F96F9C59C3A3AB,
	GraphicsSettings_set_useScriptableRenderPipelineBatching_mB8156F563763E71E21B4367A3B04242A4E27E513,
	GraphicsSettings_AllowEnlightenSupportForUpgradedProject_m00E568FAA4C9D08BEE0944042CF817BC242F2BEF,
	GraphicsSettings_HasShaderDefine_mA450B4FB841C35E87047EABACF23EBB946338DA0,
	GraphicsSettings_get_INTERNAL_currentRenderPipeline_m0671B600425EBD6A0E9314CCDD23E4423F4958E8,
	GraphicsSettings_get_currentRenderPipeline_mAF5358722E9516C78CFDCE7653F95C199A08B22E,
	GraphicsSettings_set_renderPipelineAsset_mE2F18FA93835AAE00130EFADA71084D2638BEFB2,
	GraphicsSettings_set_INTERNAL_defaultRenderPipeline_m762F3819352D0E42CCD2D281942787ECE10B4DF5,
	GraphicsSettings_set_defaultRenderPipeline_mDCDB1E887380471F046566C549392954C3BAC4CC,
	OnDemandRendering_get_renderFrameInterval_m5A12FB459D93296FBACCD6FD59EA27CD092A0132,
	OnDemandRendering_GetRenderFrameInterval_m2A6D3ADB578BA19E153C6B049FC668975155EB27,
	OnDemandRendering__cctor_m00887F122A90C963B1B120117276E3BE3A0D258F,
	CommandBuffer_InitBuffer_m4C92D488CE3F9B4F32ECF52DBCE84C7FC4E9169F,
	CommandBuffer_ReleaseBuffer_m330F9401528CDD7D9A7AB6D87719B3740B15977E,
	CommandBuffer_Internal_SetComputeTextureParam_m96D5BA0A59E7EC8B1650F4BF3B46AA80841996C6,
	CommandBuffer_Internal_DispatchCompute_m1DEED4C414F5F4D2926E6E0491A2AE9407553246,
	CommandBuffer_set_name_m30052DF9C74868F27260E3A114E02497972C4503,
	CommandBuffer_Clear_mCE65F50CF8DBEE5543EFE80CA9FEDA780F76F430,
	CommandBuffer_Internal_DrawMesh_m4B07D0CEEC6669401C9A6184F347578430D33405,
	CommandBuffer_Internal_DrawRenderer_m3DE8FFA9BA7631AEB8DB855ADEF463A0EC03618A,
	CommandBuffer_Internal_DrawProcedural_m83E79E951F1C3074932C86FC7CDB69A8991F1029,
	CommandBuffer_Internal_DrawOcclusionMesh_mC9E401F7B969786E6E4BFCAE49AC8A58E0816B36,
	CommandBuffer_SetViewport_mB4381F35791CB3E1EBF12EB56E50B258CC56AC73,
	CommandBuffer_EnableScissorRect_m93E69383D1B88B4DD095F9C84FA41C74A5F11446,
	CommandBuffer_DisableScissorRect_m7E9FF8FCCB245074C01985F8BAB3CBC4A09731B2,
	CommandBuffer_Blit_Identifier_m2A46C7B22C0C912DE5E5E479227829C4C9DF547C,
	CommandBuffer_GetTemporaryRTWithDescriptor_mA812D41F50EF532AD70F7539734F6219650CCCC6,
	CommandBuffer_GetTemporaryRT_m2D1ED99658CAE81F879AA985FD2D17082E4EAF11,
	CommandBuffer_ReleaseTemporaryRT_m3267E003250DF8263AA098E0DEE1868B894312D1,
	CommandBuffer_ClearRenderTarget_m269F6929B8F37BFEA0DDBEAE30C1E0406612468B,
	CommandBuffer_ClearRenderTarget_mFC9852EE8E501998CFFC2B6311FBD20D9150B79B,
	CommandBuffer_SetGlobalFloat_m403119507077C95E321EE6403ED3E15E3844EDAA,
	CommandBuffer_SetGlobalVector_mC6C9D66DA11EFEFAF580FE1411D32E8A61EC6B3C,
	CommandBuffer_SetGlobalColor_mCE5542EEC3DA5CB363DCF34213D748F213420BD5,
	CommandBuffer_SetGlobalMatrix_m5F602FC5014073C65BC9C0CA67CA12EE4FCE27F4,
	CommandBuffer_EnableShaderKeyword_m026A67186DDDE920448D9C3C45A1C4B9498A9CA2,
	CommandBuffer_DisableShaderKeyword_mEC93D09CFC43C5AA7B465E5B49C5ACD617BEFE6E,
	CommandBuffer_SetViewProjectionMatrices_m4244BA279DA833E02F12838CF56B8D62BB210385,
	CommandBuffer_ValidateAgainstExecutionFlags_mFE1D4E7FDB70EA8C5D819FBFDA6A33C3698F247C,
	CommandBuffer_SetGlobalVectorArray_mDAA1401184E0A4E83A7F14FF2C8D02BC90C91FDE,
	CommandBuffer_SetGlobalMatrixArray_m93A4C4959543348B9781CC5C3188F30A894B3CAB,
	CommandBuffer_SetGlobalTexture_Impl_m0C6C71E266DD5BFFA7B3E031153C7D12A6AF51E4,
	CommandBuffer_SetGlobalBuffer_m156A3B6BD9DE675918639BA72F8AB6A6B2F740C1,
	CommandBuffer_BeginSample_m3CA1DF7A40CAD00ADB4D65DABD9BBAD85270C94B,
	CommandBuffer_EndSample_m95CE1316AB5FC819FAD6EC713C8761AA08E2D759,
	CommandBuffer_SetRenderTarget_m4A6843B28AE9DCDC2AB8B346ACD9EEE87624C350,
	CommandBuffer_SetRenderTarget_m68ACC8D2AE163D56A0540F9C86BB6DC2F7BCE34B,
	CommandBuffer_SetRenderTarget_m0B46C3DA20A687C5342ADCA092428D06285E6799,
	CommandBuffer_SetRenderTarget_m55B90D47B8E5114F44265CE5A9B4006C7AE0ADF3,
	CommandBuffer_SetRenderTarget_m92DD2D65157954D6A495FEC5C9F1C90E9E36C56C,
	CommandBuffer_SetRenderTarget_m98CE2A15CE8C7B8B1BDAF6BE95FA170843A43794,
	CommandBuffer_SetRenderTarget_mA7F010252636777AF2664CDD0413088D40B8426D,
	CommandBuffer_SetRenderTargetSingle_Internal_m644F8B20A5387FCF5EAE8F7878B65235E06F80BC,
	CommandBuffer_SetRenderTargetColorDepth_Internal_mEB22B7C89467D5A0C82C3C307C75690AE5E79F6D,
	CommandBuffer_SetRenderTargetMultiSubtarget_m040DAB3E7EDC6C8EFA4F5F53CF87D9ED3600E924,
	CommandBuffer_Finalize_mD3311714DC6ECA1FDA3A784A543BB475C6D35C0E,
	CommandBuffer_Dispose_m8DC3E2F8552CCCFE67C139585E88F5BC1735BF1C,
	CommandBuffer_Dispose_m960A52C79A8B46920A321C0636F4EBED21E8AF68,
	CommandBuffer__ctor_m4394F7E41C9BB751E382A8CAFA38B19F69E03890,
	CommandBuffer_SetComputeTextureParam_m5296CBD113C2D672F20A0151812BCCF72AA5C350,
	CommandBuffer_DispatchCompute_mDC3B6B6A63C8583EA623A214629EC6F7E4AEEC7A,
	CommandBuffer_DrawMesh_mEA36EB7C577DE37F8748E5C05A93D4E041856831,
	CommandBuffer_DrawMesh_m1C8D2B41AD8B7A900983B46AB125C2496B569AAE,
	CommandBuffer_DrawMesh_m5516835A54715967C66C40BD0C473D5E82AF4E78,
	CommandBuffer_DrawMesh_m99BD39FFA05B90C9C2464095D351A7316B276A3B,
	CommandBuffer_DrawRenderer_mEED261111FF54C15DCA12EBCCE5917C79CFC0918,
	CommandBuffer_DrawRenderer_m945F95EA6511B5C707B1B6B35A9608C4EB90B83C,
	CommandBuffer_DrawRenderer_mFEBC0E774BB41C84909B49BDF610D84067DA40B4,
	CommandBuffer_DrawProcedural_m0CCC835D8D69536F516EF9C71EF311FCCB386D50,
	CommandBuffer_DrawOcclusionMesh_m9CD6F32EC9020F4329A3E9C909BD4ED4C849286D,
	CommandBuffer_Blit_mAB18B4FAB53E131FE17ABB00B8891664803B1A58,
	CommandBuffer_Blit_m2EC19CD9B2A14AD0674980C17210315BA050FE54,
	CommandBuffer_SetGlobalFloat_m531DDFDE18FE436DA735D58F2271F4DD1624F679,
	CommandBuffer_SetGlobalVector_m8FDF51D3D5336EFDA2B93252742D339BD61F8FC2,
	CommandBuffer_SetGlobalColor_m2E1ABCC34C55ECF89E2E70AA6265B22833BF1658,
	CommandBuffer_SetGlobalMatrix_m5E91602C3778640EA7D0587BF08F80DC6E9EE2C2,
	CommandBuffer_SetGlobalTexture_mB8A5225451E1E43048503A268E5F8737F5F80437,
	CommandBuffer_SetGlobalTexture_m8001F4E6981084B9E53FFFBF3ADA29AA080A7496,
	CommandBuffer_SetGlobalTexture_mEC04BECCC16812161235D47483E5E2BF0F70233F,
	CommandBuffer_Internal_DrawMesh_Injected_m03A7D079E2C3C87D9774BF3D5FCF56F30C5D0AEA,
	CommandBuffer_Internal_DrawProcedural_Injected_m2B1DD80639018659DA66B4502EBDE38AC72BCD21,
	CommandBuffer_Internal_DrawOcclusionMesh_Injected_mC0E2824DFD6ACBBB9CDF7B2357D9C0FA0F6696E6,
	CommandBuffer_SetViewport_Injected_m1BAF7CF8FC8C2EA01B480F202AE04C90BAC768EE,
	CommandBuffer_EnableScissorRect_Injected_m2EFF33BE41BF2C0F03AD9E1DD1337219ECB7FD88,
	CommandBuffer_Blit_Identifier_Injected_mD466A36D8110C0D8D458FCE4B2A4545A30207F03,
	CommandBuffer_GetTemporaryRTWithDescriptor_Injected_m1E919DF93296D82BA0A17AF4B6CB03DE15C3F822,
	CommandBuffer_ClearRenderTarget_Injected_m33BD666160A5331D0B164F36D4222ACD2D629355,
	CommandBuffer_SetGlobalVector_Injected_mBA68058B2D3C0E6A7C32EFF9356489ED5A65E74A,
	CommandBuffer_SetGlobalColor_Injected_m542893E3ED6D761D188252EFC447E0577E79415C,
	CommandBuffer_SetGlobalMatrix_Injected_m6B89FBA274BC550DE264027C40CB603541866C0C,
	CommandBuffer_SetViewProjectionMatrices_Injected_m733213BCC938EDED6595BDCA26A5F6065DAEB71D,
	CommandBuffer_SetRenderTargetSingle_Internal_Injected_mBC700D63DEB5998C857DA9694837AA65387A4C7C,
	CommandBuffer_SetRenderTargetColorDepth_Internal_Injected_m90FAA369BC20773B54F298636A780D722741094D,
	CommandBuffer_SetRenderTargetMultiSubtarget_Injected_m0D92DFDC0BD84730CF35D815F107C068520A5C3D,
	SphericalHarmonicsL2_get_Item_m82A8676E14B978464C341AD2FA510C6332DEB690_AdjustorThunk,
	SphericalHarmonicsL2_GetHashCode_mDE2A1FBF5564831948DB2A1D4C30069B3D1F1F0F_AdjustorThunk,
	SphericalHarmonicsL2_Equals_mD5CEC114E1C53B65C9F7AD47BC625E5D817707CB_AdjustorThunk,
	SphericalHarmonicsL2_Equals_mF10B8F6B3BAC7AF361CF908C6135A07A6C18E431_AdjustorThunk,
	SphericalHarmonicsL2_op_Equality_mE15995C406879B7A0B606C4535F2E3EC20DA00DC,
	BatchCullingContext__ctor_m5BB85EDAC0F7C5AFFABF7AD30F18AD272EA23E32_AdjustorThunk,
	BatchRendererGroup_InvokeOnPerformCulling_mE7F3139F1032B8B6160F5601BB55410609D0EF6E,
	OnPerformCulling__ctor_mC901B41F5C6F0A0A144862B9014047CAE3702E2F,
	OnPerformCulling_Invoke_m91277025DBB74E928F6C98E7A6745B07F5B2FD59,
	OnPerformCulling_BeginInvoke_m8179E1CC4FD6B2858D0333578FCB43594551DAAD,
	OnPerformCulling_EndInvoke_m3EB7184DC9175B0F722CE41E1CE6507887CA55DB,
	BlendState_get_defaultValue_mD779BFF820CEFD4DC3E9D9ED6745B29BCA989FC9,
	BlendState__ctor_m74AE96850682F048EB45745E8081C78573072117_AdjustorThunk,
	BlendState_Equals_mA8EDACDA477AAB9E60C1C2A7FC568F8DB9707F9D_AdjustorThunk,
	BlendState_Equals_m4432F73926DDA5349F3EBC402F0E74C0DDC096F5_AdjustorThunk,
	BlendState_GetHashCode_mEBF901015C36A6618A26E0EEBDB8E576B68BEF78_AdjustorThunk,
	CoreCameraValues_Equals_mCF002AD7C14B85902AF18F2ED870B767E442E092_AdjustorThunk,
	CoreCameraValues_Equals_m63B9697F5C101FB73ADE5D36A768CD53D9EB0B51_AdjustorThunk,
	CoreCameraValues_GetHashCode_m6CF09BCD18D9C423387247346F275E1EA8677E65_AdjustorThunk,
	CameraProperties_GetShadowCullingPlane_m59D2AD18CC32DFD00035BCAC76066B580C4ED1F8_AdjustorThunk,
	CameraProperties_GetCameraCullingPlane_mF12B28E5D0DED39216717B26BAFA3A204CD98235_AdjustorThunk,
	CameraProperties_Equals_mB337807818FA5B1186271C11ED6BED966E5DFED2_AdjustorThunk,
	CameraProperties_Equals_mD757026849E7166ED35F025EAF3ECF8AFEA01D09_AdjustorThunk,
	CameraProperties_GetHashCode_mC57BC84CD0C4C0FF93E501CFEC78F0DB1FF39AFA_AdjustorThunk,
	ScriptableCullingParameters_get_cullingPlaneCount_m67039C9499D1E2704DCFA130B74CBCF200331B1F_AdjustorThunk,
	ScriptableCullingParameters_set_isOrthographic_mEF6A28AEF683251F51167816FE4C07F17378DCCB_AdjustorThunk,
	ScriptableCullingParameters_set_shadowDistance_mDF1E31636326E2A29BF66D54D764D2E42E7F2D9D_AdjustorThunk,
	ScriptableCullingParameters_get_cullingOptions_m2FEA92265EF0460E8B42A767370CBDE6C95B9FF7_AdjustorThunk,
	ScriptableCullingParameters_set_cullingOptions_m3743C1B77E7404612AD43ACEF8E4395F9C73A947_AdjustorThunk,
	ScriptableCullingParameters_GetLayerCullingDistance_m921444B2ED20478C6A4F79BCA88289EA97A53852_AdjustorThunk,
	ScriptableCullingParameters_GetCullingPlane_mA18B64C14443CAFD24A58060A76AFE55BB5DA146_AdjustorThunk,
	ScriptableCullingParameters_Equals_mFB5D9CE0FB089EC44A8487285EB4748522D60898_AdjustorThunk,
	ScriptableCullingParameters_Equals_mA9D6FDE1D691E461989197858871686AA0BFB739_AdjustorThunk,
	ScriptableCullingParameters_GetHashCode_mFB94E70582ACC5C30BC172C9190F9F58E57869B2_AdjustorThunk,
	ScriptableCullingParameters__cctor_m3D1DDA0E0FACF810E53B8D17043970F1110890D3,
	CullingResults_GetLightIndexCount_m6CB083E56D9DD7F2BCCC7896C857656C2F3CEC31,
	CullingResults_GetReflectionProbeIndexCount_m2AC7AA1AB45D57D01723DB0013628178F6B7F831,
	CullingResults_FillLightAndReflectionProbeIndices_mB0C3A11B23CFC3530435CA821739C2035895A3D0,
	CullingResults_GetLightIndexMapSize_mC52FA8F1CAD2C5389BD3388C90D6F8C63D25B839,
	CullingResults_FillLightIndexMap_m225AF3BCBA56D56FE998A18816D116F8E3DFF3C1,
	CullingResults_SetLightIndexMap_m2A22BD3FDE332141F3F1F9DCF41B92983739699C,
	CullingResults_GetShadowCasterBounds_m74D9F506D439462ACE12B68EE448E7B7F6529F79,
	CullingResults_ComputeSpotShadowMatricesAndCullingPrimitives_m69822200F58EB7952BC26EE5FC30F2B4EDB09FAF,
	CullingResults_ComputeDirectionalShadowMatricesAndCullingPrimitives_mC2C3CE3FB7E8B2CF7DCB60361D2ECF0BF8B2F709,
	CullingResults_get_visibleLights_mF7FE02023976E76F78058AB97D61BA7AC1491E2C_AdjustorThunk,
	NULL,
	CullingResults_get_lightAndReflectionProbeIndexCount_m9B77AC9C4F955AA82C3C3FB50D0C849FFABAEB63_AdjustorThunk,
	CullingResults_FillLightAndReflectionProbeIndices_mCC188839E66568E445A2271C91D533770681910C_AdjustorThunk,
	CullingResults_GetLightIndexMap_m3685972D6DB3D1D473A6DCA50676A6BF60C0BC6F_AdjustorThunk,
	CullingResults_SetLightIndexMap_mA274F23D6A03E0C537912F8803245C5BC3A8E804_AdjustorThunk,
	CullingResults_GetShadowCasterBounds_m4550764F8697432A7C523FC3B0BCEACD0B44DF60_AdjustorThunk,
	CullingResults_ComputeSpotShadowMatricesAndCullingPrimitives_m34C7A7431179181F5CD5CE677414E51B14B7F5CA_AdjustorThunk,
	CullingResults_ComputeDirectionalShadowMatricesAndCullingPrimitives_m75000CD6EEE423308C50720E2609A594BD7D089D_AdjustorThunk,
	CullingResults_Equals_mA31A3924C0B0E10C6FE07CEBF8DF48D52B040460_AdjustorThunk,
	CullingResults_Equals_m37650670C974A08FAED2DF2E028FFE173E3FC19C_AdjustorThunk,
	CullingResults_GetHashCode_m092C0888338AF8B1D3B25A23477B00FD71A685B3_AdjustorThunk,
	CullingResults_ComputeDirectionalShadowMatricesAndCullingPrimitives_Injected_m722BE0A4A0FE97DC4EF58CD86946E1977163A812,
	DepthState_get_defaultValue_m7ABBFF624BB587EA1BA5244A06C0E433AF53F7A4,
	DepthState__ctor_m296B75647D432FB7A06CAB944CECBE8A54D1E4A0_AdjustorThunk,
	DepthState_Equals_mBAB748FD4F8C461C9AFB3D622AD46D366232E873_AdjustorThunk,
	DepthState_Equals_mAB22C1750F2B575266075D84C253CF9F9C98F4CF_AdjustorThunk,
	DepthState_GetHashCode_m8FB208CD53B72DD0FB3742059CEE9F298B7B3F9E_AdjustorThunk,
	DrawingSettings__ctor_m2F119B3CF65B1FFA436A7B4A991C9A689C4C8FBB_AdjustorThunk,
	DrawingSettings_get_sortingSettings_mA64046907F290D8F3D317ED8F4BB1D8A9E4D8875_AdjustorThunk,
	DrawingSettings_set_sortingSettings_mFD4C60DFFA5C123A2DEC30C7DC960D92FC019A2E_AdjustorThunk,
	DrawingSettings_set_perObjectData_m6A4F6E34388D3FFE3494206B463B595948FFB321_AdjustorThunk,
	DrawingSettings_set_enableDynamicBatching_mAA13C7A89709FDB2CA882E078238A0F73AAA4A44_AdjustorThunk,
	DrawingSettings_set_enableInstancing_m8994A09CDD7A03F7612A7B5CE527888214559BFC_AdjustorThunk,
	DrawingSettings_set_overrideMaterial_mD4B5D818602EA17036A0C98F28530770A8C9627A_AdjustorThunk,
	DrawingSettings_set_overrideMaterialPassIndex_mD20615AE6699346E72D20695A9E54C5447C7081A_AdjustorThunk,
	DrawingSettings_set_mainLightIndex_m59B22E23577931C5348546E297C2FDB5B3B6FD72_AdjustorThunk,
	DrawingSettings_GetShaderPassName_mC19E60468AD2B769FFC9F299E13E46458CF23037_AdjustorThunk,
	DrawingSettings_SetShaderPassName_mC570D206B1D6158491BB5AE5B9669AF54764F9AD_AdjustorThunk,
	DrawingSettings_Equals_mE7BD5DAFE2A9BCFA04ED43D264A667D4859B071C_AdjustorThunk,
	DrawingSettings_Equals_m20C6C79F7A33E55521B546A634CB59967B23B157_AdjustorThunk,
	DrawingSettings_GetHashCode_m10BFA80936AFD9587C09E7BE2F7701389781765D_AdjustorThunk,
	DrawingSettings__cctor_mF0435125E65C97D927E644D6786A7829E665EC1D,
	FilteringSettings__ctor_m17296E7A507C13F758B3CCCD00C4B364364540FE_AdjustorThunk,
	FilteringSettings_set_renderQueueRange_mEBA3759ADFB8D437DBDF285AE7CAC6116358D396_AdjustorThunk,
	FilteringSettings_set_layerMask_m6DE0420680D7D053384BE02989AC1DC1C541AC62_AdjustorThunk,
	FilteringSettings_set_renderingLayerMask_m71841C84FBD32A0B097B649A6EA035C0A706A2F9_AdjustorThunk,
	FilteringSettings_set_excludeMotionVectorObjects_mC15F14289E6CA27DCF2D2D4C4A6729A426E4C1AF_AdjustorThunk,
	FilteringSettings_set_sortingLayerRange_m71CBCB0A643F3A00347C111F1C7DFCB49873C32A_AdjustorThunk,
	FilteringSettings_Equals_mAB7A18838983321A60F7D010BE81DEA3811C2D03_AdjustorThunk,
	FilteringSettings_Equals_mB9F939984F1C93ACA9BA6BFAAB7C00376278FFD4_AdjustorThunk,
	FilteringSettings_GetHashCode_m1FB9EEA742BE8D7429785DD1D5B20E6071C6B789_AdjustorThunk,
	LODParameters_Equals_mA7C4CFD75190B341999074C56E1BAD9E5136CF61_AdjustorThunk,
	LODParameters_Equals_m03754D13F85184E596AFBBCF6DA1EDB06CA58F6B_AdjustorThunk,
	LODParameters_GetHashCode_m532D8960CCF3340F7CDF6B757D33BAE13B152716_AdjustorThunk,
	RasterState__ctor_m406D67E2352F073428C9B11A06B7D5737913B316_AdjustorThunk,
	RasterState_Equals_m29A194E6B6731C4651E5404F5237FA90777E02B7_AdjustorThunk,
	RasterState_Equals_mF19AC1C01B6E65D8CB13832FA625ACC2C1FE9C17_AdjustorThunk,
	RasterState_GetHashCode_m68F131D584F611BD2573BE33616A89388ADD3D18_AdjustorThunk,
	RasterState__cctor_mD45EB6E6F1529D4067EBD7C58425DB6DD6CF74AB,
	NULL,
	RenderPipeline_BeginFrameRendering_mA1E6462B6473351723C6AF121834824C1E5DAFFE,
	RenderPipeline_BeginCameraRendering_mBDA378BECAF708F3006B3AB94352F54ABD698F86,
	RenderPipeline_EndFrameRendering_m4EAF314449AA5B74B43B135E3F45230C31849902,
	RenderPipeline_EndCameraRendering_m8BC96F3C24F010AD2665EBCED0BE21B62531DB66,
	RenderPipeline_InternalRender_m3601304F718BEEDCC63FAC61AF865392A1B97159,
	RenderPipeline_get_disposed_mA11FE959A1C7309A86F26893DA04D00DD5D61149,
	RenderPipeline_set_disposed_m6319C7F5991E861B961370FF374CF87E9F0DA691,
	RenderPipeline_Dispose_mFFDBE5963DA828BA99417035F8F6228535E0EAAB,
	RenderPipeline_Dispose_m256C636C8C66B12ED0E67F4C6F6470A79CBAA49B,
	RenderPipeline__ctor_m951F82954ED852CE97F36C8D0B906EC20509F5A5,
	RenderPipelineAsset_InternalCreatePipeline_m7FC3209A9640269E6E01FCBCC879E3FC36B23264,
	RenderPipelineAsset_get_renderingLayerMaskNames_mD9D46ECB8CB3AA207307DF715AB738EBE9774D4C,
	RenderPipelineAsset_get_defaultMaterial_mB049EB56C99330E8392028148336A9329A1F6BEF,
	RenderPipelineAsset_get_autodeskInteractiveShader_mACEA652B47468186F0B74AAE63A5625A70E500A4,
	RenderPipelineAsset_get_autodeskInteractiveTransparentShader_mBC027215A56E8FD6C3B3CC5008B69540BBEBD1FD,
	RenderPipelineAsset_get_autodeskInteractiveMaskedShader_m5342E858293BCAB426D1A6E84242CD7D26EE5BC7,
	RenderPipelineAsset_get_terrainDetailLitShader_mE16DBCD806DD77447A89F3C1109E35CD24FEA7CF,
	RenderPipelineAsset_get_terrainDetailGrassShader_mAF8F368B3B67F7E6C71A70A93696122E73ED6C47,
	RenderPipelineAsset_get_terrainDetailGrassBillboardShader_m2DAE45A6FF177CB2996EC95EDF1AC05F59A7470B,
	RenderPipelineAsset_get_defaultParticleMaterial_m131DA69D30E5A400B227B98B8877C94A118E9F49,
	RenderPipelineAsset_get_defaultLineMaterial_m9FF591F569273D367C4020C1AC3A30AA161CE6BC,
	RenderPipelineAsset_get_defaultTerrainMaterial_mA6D10A07A29A577D83AF711CDE2E70B28D51A91A,
	RenderPipelineAsset_get_defaultUIMaterial_m39BD27EC73AE39354158451661A0112FC4E4F7F6,
	RenderPipelineAsset_get_defaultUIOverdrawMaterial_m0FE02710211BE1CF77728A1086BDC5EDCE106D35,
	RenderPipelineAsset_get_defaultUIETC1SupportedMaterial_mB8E2388C7F45E6D1B4EC728EC2335B527A741470,
	RenderPipelineAsset_get_default2DMaterial_mF68C0199E16004C348D11AD0BA4C9482CCFC9762,
	RenderPipelineAsset_get_defaultShader_m8F4DD3FBD2EA1A55DE3EB45EF41C3FD502141A40,
	RenderPipelineAsset_get_defaultSpeedTree7Shader_mE81955ABC171A01E496BD2E6166CC0BCDCC12E39,
	RenderPipelineAsset_get_defaultSpeedTree8Shader_mF5025B6116D23E28B7A872C3694ADED33A6DE9B0,
	NULL,
	RenderPipelineAsset_OnValidate_m232856172D71149CC85645BE94902D01628A1A8E,
	RenderPipelineAsset_OnDisable_m6DB5D6EE17E7CAEC1254135C61F4EB3E249FDD52,
	RenderPipelineAsset__ctor_mCB26E546B9DC1F2518E0F0F4A7E6CFF519D852F2,
	RenderPipelineManager_get_currentPipeline_m07358604B9829E6C1EEDE94064729109D9259852,
	RenderPipelineManager_set_currentPipeline_mDCF377780787BD6CAB3BC9F4A04B01B478293B88,
	RenderPipelineManager_add_beginCameraRendering_m49A42A94633EDC2DDE0B2326AFB16648F3EA4655,
	RenderPipelineManager_remove_beginCameraRendering_m1E9FF5693BD4A7CFF90A2F76F0E36F54857DC757,
	RenderPipelineManager_add_endCameraRendering_mAAB014A733DF153D0B535C34827A626B838A24D5,
	RenderPipelineManager_remove_endCameraRendering_m71A598F738E2D4DED262A2DF7DAAD1EE85E92860,
	RenderPipelineManager_BeginFrameRendering_m73DFC13D37084610A3320A3087C45FF96100AC90,
	RenderPipelineManager_BeginCameraRendering_m2074DD98F47E3C5EF42CEB0B6FC4598AE207231A,
	RenderPipelineManager_EndFrameRendering_mB39C68E3EBB09CAC4EBD5235B1ED7B0B0EC19DA3,
	RenderPipelineManager_EndCameraRendering_m4E62F4F4D17A5E3FAF35BEC5830AC6D433AEA4C5,
	RenderPipelineManager_CleanupRenderPipeline_m82AC5DAD81AE3B10147198B7C7CFAAD8AE528010,
	RenderPipelineManager_GetCameras_m53602210E7576F801085A741B2068BEA0995433F,
	RenderPipelineManager_DoRenderLoop_Internal_mF16D72874EE44C297C2D0623933207B448BFCD32,
	RenderPipelineManager_PrepareRenderPipeline_m4A4D5CD3B9803F6D92DBD7D245A3D925F9028CC7,
	RenderPipelineManager__cctor_m7B3FA781696A3B82639DA7705E02A4E0BD418421,
	RenderQueueRange_get_all_mA3F6A2BCFDD1C70DCF6C5FB39A66A21764341447,
	RenderQueueRange_get_opaque_mE172B321960F4D55A56B287E39CCB50927107B7C,
	RenderQueueRange_get_transparent_m1CF8E0923DA509879885DB20FEA78CCE027255B9,
	RenderQueueRange_Equals_m4C359E94CCFE49E8989B8B8844E26848BF9FC265_AdjustorThunk,
	RenderQueueRange_Equals_mBFB376C90D44224911F400ABBAC181A0AB5A1592_AdjustorThunk,
	RenderQueueRange_GetHashCode_m1DFED684DB51CE12FE84A5AB54050C8630E82274_AdjustorThunk,
	RenderQueueRange__cctor_mEA846D826B022C1E26E9562DD45680625F6112A3,
	RenderStateBlock__ctor_m48003DB81752663592D20E4697643A9320D82EFB_AdjustorThunk,
	RenderStateBlock_set_depthState_m85E6842AFBAEB4179ABFA8F3C81533EC51829758_AdjustorThunk,
	RenderStateBlock_set_stencilState_m814032B71A44F9A14DF1677E6BDA0F02842491E3_AdjustorThunk,
	RenderStateBlock_set_stencilReference_mAE73008443F7445B0277B8E6376DC2D00382B590_AdjustorThunk,
	RenderStateBlock_get_mask_mE690A0C5AA9506C9DDFFCF11B2BCC20FADD495E9_AdjustorThunk,
	RenderStateBlock_set_mask_m1829425552BFD051A106DA12F367104EFE2CB0FE_AdjustorThunk,
	RenderStateBlock_Equals_m16021C56F492DF3F064C9316A7C6A352F180B798_AdjustorThunk,
	RenderStateBlock_Equals_m0E8A2D2F56D621408EF5962FAA5BE280DE8C0BD4_AdjustorThunk,
	RenderStateBlock_GetHashCode_m1F7F40E3B1CF65CC83FC569C413F06BCEFF5C71C_AdjustorThunk,
	RenderTargetBlendState_get_defaultValue_m3444F0C0CD14104F3A75355CAE4C0EA2D20FE505,
	RenderTargetBlendState__ctor_m9867E3C16C73C883A83BA0D7A8082942E6B2AD85_AdjustorThunk,
	RenderTargetBlendState_Equals_m765987071D3AD0B98F2B5ADB8981128052E57B68_AdjustorThunk,
	RenderTargetBlendState_Equals_mA207F23FCA550F6C5BFC77D513ECE1C5CCD2F4DB_AdjustorThunk,
	RenderTargetBlendState_GetHashCode_m056162E23B1AD394477E05F4B4B48747159166AF_AdjustorThunk,
	ScriptableRenderContext_Internal_Cull_mFD76253744E69C86617B1CB320C206A0347269A2,
	ScriptableRenderContext_InitializeSortSettings_m28764ABF60F041BFB2634D0F5D105F3ABDA6DB5F,
	ScriptableRenderContext_Submit_Internal_mAAE0CC08056C1DDE85A89A19BBE8E7EED87C515F_AdjustorThunk,
	ScriptableRenderContext_GetNumberOfCameras_Internal_m58DE22F11E08F3B9C7E4B1D9788711101EBD2395_AdjustorThunk,
	ScriptableRenderContext_GetCamera_Internal_m1E56C9D9782F0E99A7ED3C64C15F3A06A8A0B917_AdjustorThunk,
	ScriptableRenderContext_DrawRenderers_Internal_m42B37848BB342A4E5842AC899121624B49112F03_AdjustorThunk,
	ScriptableRenderContext_DrawShadows_Internal_m26D9998BA2D211BF6413294423AFD43438E55D30_AdjustorThunk,
	ScriptableRenderContext_ExecuteCommandBuffer_Internal_m6BDE1A07FB715DC99F1126AF36DBDDE8C73019D4_AdjustorThunk,
	ScriptableRenderContext_SetupCameraProperties_Internal_mED05BC7D41C7B3E1FBA2A7C4EF5269275848B5AF_AdjustorThunk,
	ScriptableRenderContext_StereoEndRender_Internal_m3C8BD0BCE398DC4253B9D94F9BBACFAB5BEA49A7_AdjustorThunk,
	ScriptableRenderContext_StartMultiEye_Internal_m161C0DC08488F76505BAF21C66E84EF72EDEC53E_AdjustorThunk,
	ScriptableRenderContext_StopMultiEye_Internal_mA80FA0BF5222B49BF6F9E16A04CC30B9D0AD6442_AdjustorThunk,
	ScriptableRenderContext_DrawSkybox_Internal_mF0A6A4B91FCB1185A275E55926D860F3C50B4520_AdjustorThunk,
	ScriptableRenderContext_InvokeOnRenderObjectCallback_Internal_m1BD2722EF4155A2EAE724492A66BCF51C79560CE_AdjustorThunk,
	ScriptableRenderContext__ctor_m554E9C4BB7F69601E65F71557914C6958D3181EE_AdjustorThunk,
	ScriptableRenderContext_Submit_m93F8AB4A95BAD8135BD19CA6ED07B1A14F2CC87C_AdjustorThunk,
	ScriptableRenderContext_GetNumberOfCameras_mF14CD21DA4E8A43DCE5811735E48748313F71CBA_AdjustorThunk,
	ScriptableRenderContext_GetCamera_mCC4F389E3EB259D9FF01E7F7801D39137BC0E41C_AdjustorThunk,
	ScriptableRenderContext_DrawRenderers_mBD9F5C26FEF615D84B4657B6FDE0854B629DD8B0_AdjustorThunk,
	ScriptableRenderContext_DrawRenderers_m67847BB31C9F8792D016A3BE4B0F5BD4C10AFD39_AdjustorThunk,
	ScriptableRenderContext_DrawShadows_m87B0FF3E8B7050791A2DBA3516C6BF0525DF9244_AdjustorThunk,
	ScriptableRenderContext_ExecuteCommandBuffer_m7564285E9D694FADA319BF5BB0A864B2EBF313AF_AdjustorThunk,
	ScriptableRenderContext_SetupCameraProperties_mA0648392A1F6B5A0F8B11C73E0A337DA0A6644CC_AdjustorThunk,
	ScriptableRenderContext_StereoEndRender_m3EDDC1DE013EB3B3AEF0EBC181E1FF4DBBCD40BA_AdjustorThunk,
	ScriptableRenderContext_StartMultiEye_m763B41DFA957DEE5B4D226E2D0E6363E20EFA87D_AdjustorThunk,
	ScriptableRenderContext_StopMultiEye_m6B68D7362BAD3C2EF68E814F983B8436079C33C6_AdjustorThunk,
	ScriptableRenderContext_DrawSkybox_m34BF2168F50F04A51CFDB5EEFA9F837880CD03BF_AdjustorThunk,
	ScriptableRenderContext_InvokeOnRenderObjectCallback_mED67F10A990A965345F95633FA51AE83D2FDD441_AdjustorThunk,
	ScriptableRenderContext_Cull_m193842B732EFDA3A6B462A06D4B656C0551F4889_AdjustorThunk,
	ScriptableRenderContext_Equals_m0612225D9DC8BE5574C67738B9B185A05B306803_AdjustorThunk,
	ScriptableRenderContext_Equals_m239EBA23E760DDF7CC7112D3299D9B4CEA449683_AdjustorThunk,
	ScriptableRenderContext_GetHashCode_m2A894A66C98DF28B51758A3579EE04B87D2AC6D6_AdjustorThunk,
	ScriptableRenderContext_Internal_Cull_Injected_mBF4FAD3354E079A2BE20FE65B3D510EE33398B60,
	ScriptableRenderContext_Submit_Internal_Injected_m0873AB61AF51418408CB683059B99385DCC8B2DE,
	ScriptableRenderContext_GetNumberOfCameras_Internal_Injected_m70F9C34BAA4E5548D1B5848EFFBA6ACDC1B9781B,
	ScriptableRenderContext_GetCamera_Internal_Injected_m43E535C1F7FC90BF7254A0D043E624D45B70E459,
	ScriptableRenderContext_DrawRenderers_Internal_Injected_mDB5C687C0C9F7930B25631107134AEF8A1F7571A,
	ScriptableRenderContext_DrawShadows_Internal_Injected_mBD7A5802D4D4D9B0E8C97571F94C94153683E630,
	ScriptableRenderContext_ExecuteCommandBuffer_Internal_Injected_m93612BE8FA6714852C3CFF474B2699F369DE7C22,
	ScriptableRenderContext_SetupCameraProperties_Internal_Injected_m1A38D96372E32AFF7535AC1F8C18DE08676E8FEE,
	ScriptableRenderContext_StereoEndRender_Internal_Injected_m3223FBF747D4D32801BF5F9D351F6A97EC289E1D,
	ScriptableRenderContext_StartMultiEye_Internal_Injected_m8BC7A82B98E30DEF798D9A0CAB31DA4357510C0D,
	ScriptableRenderContext_StopMultiEye_Internal_Injected_mB59DC2073C99657D74DE96E4B9B26AE1126EB645,
	ScriptableRenderContext_DrawSkybox_Internal_Injected_mE7C766A1E68506A171066B9AA74B7C9AEC7F7A5E,
	ScriptableRenderContext_InvokeOnRenderObjectCallback_Internal_Injected_m563B766BE42287E25E697BFC50616BF662932D0E,
	ShaderTagId__ctor_m12711C3099F1BBDED9B114567F6A6C382A6C1F5E_AdjustorThunk,
	ShaderTagId_get_id_mB1AB67FC09D015D245DAB1F6C491F2D59558C5D5_AdjustorThunk,
	ShaderTagId_set_id_m47A84B8D0203D1BAE247CF591D1E2B43A1FFEF1E_AdjustorThunk,
	ShaderTagId_Equals_m7C6B4B00D502970BEDA5032CC9F791795B8C44EE_AdjustorThunk,
	ShaderTagId_Equals_mC8A45F721611717B4CB12DBD73E23200C67AA7AF_AdjustorThunk,
	ShaderTagId_GetHashCode_m51C1D9E4417AD43F0A5E9CCF7FF88C10BCDB2905_AdjustorThunk,
	ShaderTagId_op_Equality_mBCF8FA710D713780FC23AC5D982A7F95C9179927,
	ShaderTagId_op_Inequality_m402802CD41D679E07675D4178CF8A05084A2B31E,
	ShaderTagId__cctor_mC73D6F5DE8D099CE53149E383ADF6B64F3EA763D,
	ShadowDrawingSettings_get_splitData_m181634A672466BB78C5D07AC459C7D03BED52B21_AdjustorThunk,
	ShadowDrawingSettings_set_splitData_mFD018747362F76EA0A2AFAEB0AEF16FFA385E9CD_AdjustorThunk,
	ShadowDrawingSettings__ctor_mB16160F768301351FCB350175F9D4CAA6933F06E_AdjustorThunk,
	ShadowDrawingSettings_Equals_m835B1C914090FC8971F7C06091F6378B2802ED4C_AdjustorThunk,
	ShadowDrawingSettings_Equals_m3F42D86A4397FEAC349A8DF247474441FAE37BEA_AdjustorThunk,
	ShadowDrawingSettings_GetHashCode_m173F0560EBC60E94F2AF816DBD77673486883B2A_AdjustorThunk,
	ShadowSplitData_get_cullingPlaneCount_m50740AF255ABF29DAFF5C1AC466DC32DF2AF1ABF_AdjustorThunk,
	ShadowSplitData_get_cullingSphere_mD8D0343483420281198C1ADDB980D9D12EEB2B12_AdjustorThunk,
	ShadowSplitData_set_cullingSphere_mFF499B760D7ED1FA7FBCAF97FD0DA010AF24CC94_AdjustorThunk,
	ShadowSplitData_set_shadowCascadeBlendCullingFactor_m8505213D2AA1742B31E47194E138C4CD6C3C408F_AdjustorThunk,
	ShadowSplitData_GetCullingPlane_mAAD500FB0AE82378EC6A749DB8259011075463CB_AdjustorThunk,
	ShadowSplitData_Equals_mB8782F941169D85E024BB62257CADFCA3C903438_AdjustorThunk,
	ShadowSplitData_Equals_m5149323E2B11FDDF90F8B1A20EF6EE7F4040338A_AdjustorThunk,
	ShadowSplitData_GetHashCode_mA15BCD7F6B7FC695DA294B34EEF5CE92D1396AA7_AdjustorThunk,
	ShadowSplitData__cctor_mEE17BC8B51CA98ABF4A4B66B94AA7F6ABEB8F2FB,
	SortingLayerRange__ctor_m634A50CF97DED78D9EE04F59089ADFC8404CC108_AdjustorThunk,
	SortingLayerRange_get_all_m796E1D9B448FE441F810C7B1637C829584792914,
	SortingLayerRange_Equals_mAEE1B3D2ABDAF056DA9C9E259C152679A37DBA6D_AdjustorThunk,
	SortingLayerRange_Equals_mC9CABA22A3A3D3EFFCFED34D136B137A27FA2FC5_AdjustorThunk,
	SortingLayerRange_GetHashCode_m6EB3305DF1B44508D1A888DEF8192BCD74F6F1DF_AdjustorThunk,
	SortingSettings__ctor_m05CC25CC8BCE175ABD0B67393C11B25616C93BE9_AdjustorThunk,
	SortingSettings_set_customAxis_m201EA863932FC631A79B9042C589EFD20B0D710A_AdjustorThunk,
	SortingSettings_get_criteria_mC4A5DED8DD361A05446351B680526AC2D2B9E390_AdjustorThunk,
	SortingSettings_set_criteria_m6D617C21387E5FB780193B122EC6E99F53694BA6_AdjustorThunk,
	SortingSettings_set_distanceMetric_mC1BC65D6F352F56C11FCFE66084626AF6DD5E894_AdjustorThunk,
	SortingSettings_Equals_m592EFC54F954B3ECACCBC2F74C066BB14B151144_AdjustorThunk,
	SortingSettings_Equals_m9BB6F63E8A0C4F1B32229B6AE40A1CA149CD7DE1_AdjustorThunk,
	SortingSettings_GetHashCode_m2A5DE15F0AE8B86F4F7862F316C2C7579EC1DB5C_AdjustorThunk,
	StencilState_get_defaultValue_m23346895118822B73BE908CD6BA45D80DA044DD6,
	StencilState__ctor_mE63E73C425D1B93B7761FE3847715904A5ED7778_AdjustorThunk,
	StencilState__ctor_m9D74151811E5B6EB01FEA9738FE99D2B938B41EE_AdjustorThunk,
	StencilState_get_enabled_m64131ECAE790CCB31DD756158547B7C86E1F12D4_AdjustorThunk,
	StencilState_set_enabled_m74BFD7FEDD9520F20DD89CB19A71651758329954_AdjustorThunk,
	StencilState_SetCompareFunction_m8A6DF9ED845CA019FFAAEDE176C656CC26583FF4_AdjustorThunk,
	StencilState_SetPassOperation_mC31938C4783210A8C9FECFCA9E2601FDE677780F_AdjustorThunk,
	StencilState_SetFailOperation_m3C36F224A6CFAB101DD489D11BEA05D9B4CC8454_AdjustorThunk,
	StencilState_SetZFailOperation_mC2EA216433E31AB4DDEB6B09AD8B4EED19CEA834_AdjustorThunk,
	StencilState_set_compareFunctionFront_mBE9C600C33516DD7A41AF16414CE2B3677659F4F_AdjustorThunk,
	StencilState_set_passOperationFront_m8F4ECB3726CE0598ED1759D24A61ED7AD1F5CD7D_AdjustorThunk,
	StencilState_set_failOperationFront_mE764F5190ADFE5E00272DD8D22D728464A309DEF_AdjustorThunk,
	StencilState_set_zFailOperationFront_m5C98C971FFE0729FF3428BFEB3C874BA7E660049_AdjustorThunk,
	StencilState_set_compareFunctionBack_m1D9D4DEB9F190A5358FB5AB63E7B3E8276EE6F75_AdjustorThunk,
	StencilState_set_passOperationBack_mB5045FFA7058C6AB7616CAE7B0F00622E3041C5C_AdjustorThunk,
	StencilState_set_failOperationBack_m7147B6C2E7A2057BC1FF837E1424748784DAD304_AdjustorThunk,
	StencilState_set_zFailOperationBack_mA749E7E40D0EA8836ABF1DE10C3541BEC3C46D62_AdjustorThunk,
	StencilState_Equals_m1479C86015904B22C0B117F63A040915444EB870_AdjustorThunk,
	StencilState_Equals_mD71613CA8665973266A04A8CE01D1DDFE8809E4A_AdjustorThunk,
	StencilState_GetHashCode_mB1FD5BCCD93E54C1D525CEC275DBBB317E74B5A8_AdjustorThunk,
	SupportedRenderingFeatures_get_active_m2C2E65CE6B3B9197E71D6390B4CE3AF024EFC286,
	SupportedRenderingFeatures_set_active_m2E459FC4898691C6E729A5EC2D2B08A1733CDCC2,
	SupportedRenderingFeatures_get_defaultMixedLightingModes_m903DC0B0AB86F4C047E8930E0C59C4131DA600C9,
	SupportedRenderingFeatures_get_mixedLightingModes_m87742B8CBD950598883F391C22FF036BE774E2D9,
	SupportedRenderingFeatures_get_lightmapBakeTypes_m6B99531AE2EDEB49D54886E103AF12CFB1BC426A,
	SupportedRenderingFeatures_get_lightmapsModes_mAAAC00FB06849B233D053DB11B47E8DA8666583B,
	SupportedRenderingFeatures_get_enlighten_m493ED393C99DC9105CCC2D8D28D43D6AB0B96C78,
	SupportedRenderingFeatures_FallbackMixedLightingModeByRef_m91AC959EB7DD16F061466CF2123820AFA257BD76,
	SupportedRenderingFeatures_IsMixedLightingModeSupported_m22C3916FDD1308FCDD201651709ED3861DBC09AB,
	SupportedRenderingFeatures_IsMixedLightingModeSupportedByRef_mE77416221A79F75F9EF7FD062AF9674264D1E069,
	SupportedRenderingFeatures_IsLightmapBakeTypeSupported_mD21AC518EFAA0892131E4ADE0EBA1DA980937A61,
	SupportedRenderingFeatures_IsLightmapBakeTypeSupportedByRef_mE33A63BE6E3D6D4DF4B5584E4F451713DC776DB8,
	SupportedRenderingFeatures_IsLightmapsModeSupportedByRef_mAFD9EC8C77CF9874911FFC0C084FC161C27E9A13,
	SupportedRenderingFeatures_IsLightmapperSupportedByRef_m96E352A96F40887994AE8BA5F07BBB87D8A3E557,
	SupportedRenderingFeatures_FallbackLightmapperByRef_m04F1D58EF96BB1E1E20C72A562E86F17EEF3B1B9,
	SupportedRenderingFeatures__ctor_mFA6FBB0F889B8A9ECD5B77C0CE2EEF685C0310F5,
	SupportedRenderingFeatures__cctor_m0AAC399710A8663753C069DDC8CAE61039630C40,
	VisibleLight_get_light_mBFDEA0FA083D1606373637E8ABBB1DD65C9D25A7_AdjustorThunk,
	VisibleLight_get_lightType_mE1C9653B71D5C00C756CBFF0C8F5ACEC2B325F3C_AdjustorThunk,
	VisibleLight_get_finalColor_mCBE20D4E88F3FA1865B8E27817E4C18F4BDC4964_AdjustorThunk,
	VisibleLight_get_localToWorldMatrix_mE8EF56DEFDCE473A3C178B36C3E3FAB6966D53B1_AdjustorThunk,
	VisibleLight_get_range_m704917DFACCA204B15A2C8BF85186C5162006157_AdjustorThunk,
	VisibleLight_get_spotAngle_m7AC099D76961795FA55436FA4933C80BBA568596_AdjustorThunk,
	VisibleLight_Equals_m0BF2234DCEA6C61BF33864040A15F70A281BA66A_AdjustorThunk,
	VisibleLight_Equals_mBFFD5A8CFA341A4AFC0A6E2D45EBE341D076CDCA_AdjustorThunk,
	VisibleLight_GetHashCode_m11027F568A276C0B13F69B10C7A747DD0B778334_AdjustorThunk,
	VisibleReflectionProbe_Equals_mA3C9F4E406435B3C8D69882F7FC8E96C2C03AAB1_AdjustorThunk,
	VisibleReflectionProbe_Equals_mE7F229880369A006CC83B61BAB0B56EE26A08E1A_AdjustorThunk,
	VisibleReflectionProbe_GetHashCode_m0016B00F3A385A04BFF7BEBAF7CEBBE449BD8CCB_AdjustorThunk,
	ShaderKeyword_GetGlobalKeywordIndex_m2297A7E7248ECAB6D1BBD158F98D56A3F1DFE4C1,
	ShaderKeyword__ctor_m95799F6B14823F6C9C48A3975EC58B884A69C14B_AdjustorThunk,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Playable_get_Null_m1641F4B851ACAA6CBCC9BB400EC783EDEAF1A48D,
	Playable__ctor_m24C6ED455A921F585698BFFEC5CCED397205543E_AdjustorThunk,
	Playable_GetHandle_m952F17BACFC90BEACD3CB9880E65E69B3271108A_AdjustorThunk,
	Playable_Equals_m1EC7E8B579C862BA8C979BD616224EC1B3364DD1_AdjustorThunk,
	Playable__cctor_m5655D443F6D04230DB5D37BF7D5EDCA71FD85A32,
	NULL,
	PlayableAsset_get_duration_m58C1A4AC3A8CF2783815016BE58378D6E17D22D2,
	PlayableAsset_get_outputs_mD839CEB7A22543AC17FAE1C3C4BCD9A7B8DA82B1,
	PlayableAsset_Internal_CreatePlayable_mB36624F1FD210AAD53A848BF8F26912D47DFC09C,
	PlayableAsset_Internal_GetPlayableAssetDuration_m099C6F58730A818ACA8C837D3DDBFC4ACA75693F,
	PlayableAsset__ctor_m669F459CFACFE65873346E428F206C457B488167,
	PlayableBehaviour__ctor_mE96A877D927BEEC8C9368A0673FEAD77A78C35EE,
	PlayableBehaviour_OnGraphStart_m41537F7ED140E16D8666B4959D99EF9BC16FF622,
	PlayableBehaviour_OnGraphStop_m5B1C17F7DA22FFBF8BABB18CBA090AB64FD51740,
	PlayableBehaviour_OnPlayableCreate_m963F9A0600B2208400FE3F90647FBACE0B5FE0DD,
	PlayableBehaviour_OnPlayableDestroy_mC1C991442A5940826928EA321FC5EFBE68482A57,
	PlayableBehaviour_OnBehaviourPlay_m4B44CD41A9CB3EA391BCB142FA3B9A80AFAFF820,
	PlayableBehaviour_OnBehaviourPause_mBC9C4536B30B413E248C96294F53CDABA2C1490C,
	PlayableBehaviour_PrepareFrame_m0FC4368B39C1DBC6586E417C8505D1A8C49235E2,
	PlayableBehaviour_ProcessFrame_m32F9B265BB54D1A3A290E2709FDD0B873360B25A,
	PlayableBehaviour_Clone_m2BB70A16D658FD18307D084EFFFE4A7B1BB234FD,
	PlayableBinding__cctor_mF1C450FA8C820DA444D8AB9235958EC750AE60C8,
	CreateOutputMethod__ctor_m252187F08E76732D791C8458AF5629F29BDDB8F2,
	CreateOutputMethod_Invoke_m56F81543465C6F9C65319BEEEFC5AEEF6A0D7764,
	CreateOutputMethod_BeginInvoke_m4FC768B14DF77F9DB8847F3FAF1CBFD11048030D,
	CreateOutputMethod_EndInvoke_m61A9C47D6ED76402024C0C7139C4A6F1D58D4C47,
	NULL,
	PlayableHandle_get_Null_m09DE585EF795EFA2811950173C80F4FA24CBAAD1,
	PlayableHandle_op_Equality_mBA774AE123AF794A1EB55148206CDD52DAFA42DF,
	PlayableHandle_Equals_m7D3DC594EE8EE029E514FF9505C5E7A820D2435E_AdjustorThunk,
	PlayableHandle_Equals_mBCBD135BA1DBB6B5F8884A21EE55FDD5EADB555C_AdjustorThunk,
	PlayableHandle_GetHashCode_mFEF967B1397A1DC2EE05FC8DBB9C5E13161E3C45_AdjustorThunk,
	PlayableHandle_CompareVersion_m24BEA91E99FF5FD3472B1A71CB78296D99F808A9,
	PlayableHandle_IsValid_mDA0A998EA6E2442C5F3B6CDFAF07EBA9A6873059_AdjustorThunk,
	PlayableHandle_GetPlayableType_m962BE384C093FF07EAF156DA373806C2D6EF1AD1_AdjustorThunk,
	PlayableHandle__cctor_m6FA486FD9ECB91B10F04E59EFE993EC7663B6EA3,
	PlayableHandle_IsValid_Injected_mCCEEB80CD0855FD683299F6DBD4F9BA864C58C31,
	PlayableHandle_GetPlayableType_Injected_m65C3EB2DEC74C0A02707B6A61D25B3BFEC91DB66,
	PlayableOutput__ctor_m881EC9E4BAD358971373EE1D6BF9C37DDB7A4943_AdjustorThunk,
	PlayableOutput_GetHandle_m079ADC0139E95AA914CD7502F27EC79BB1A876F3_AdjustorThunk,
	PlayableOutput_Equals_m458689DD056559A7460CCE496BF6BEC45EB47C5B_AdjustorThunk,
	PlayableOutput__cctor_m833F06DD46347C62096CEF4E22DBC3EB9ECDACD5,
	PlayableOutputHandle_get_Null_mA462EF24F3B0CDD5B3C3F0C57073D49CED316FA4,
	PlayableOutputHandle_GetHashCode_mC35D44FD77BCA850B945C047C6E2913436B1DF1C_AdjustorThunk,
	PlayableOutputHandle_op_Equality_m9917DCF55902BB4984B830C4E3955F9C4E4CE0C0,
	PlayableOutputHandle_Equals_m42558FEC083CC424CB4BD715FC1A6561A2E47EB2_AdjustorThunk,
	PlayableOutputHandle_Equals_m1FCA747BC3F69DC784912A932557EB3B24DC3F18_AdjustorThunk,
	PlayableOutputHandle_CompareVersion_m4DD52E80EDD984F824FE235F35B849C5BA9B4964,
	PlayableOutputHandle__cctor_mD1C850FF555697A09A580322C66357B593C9294E,
	LinearColor_Convert_m34C66A797B11DE3EE19A9ED913B286C5C76F3B4E,
	LinearColor_Black_m0C3B7331D5DEBB72F85BAFC175BC785D964D30D8,
	LightDataGI_Init_m93EBCF45B2A5F8A0C9879FD2CF1B853514837F4B_AdjustorThunk,
	LightDataGI_Init_m236C2DEE096CDCF4B4489B9A5630E231531DF022_AdjustorThunk,
	LightDataGI_Init_mBCCAA12227CF3845C831463F7B8572F00CB17CF3_AdjustorThunk,
	LightDataGI_Init_m24775B5AF758CAE25BA180BC17D9E032064B52B9_AdjustorThunk,
	LightDataGI_Init_m00F56356E1220B292978ABE384B6500A1F1C9291_AdjustorThunk,
	LightDataGI_InitNoBake_m660C58A4878A0DB9E842F642AA6D2800D30F0C48_AdjustorThunk,
	LightmapperUtils_ExtractIndirect_m1BA4D17B92F68DE86B8696BCA09901CB9F70E352,
	LightmapperUtils_ExtractInnerCone_mAB6BC006F6841F7881DAC60077A61BA525E09C48,
	LightmapperUtils_Extract_mA213675C1DD2F46927D6B0D02619CD0F2247E98D,
	LightmapperUtils_Extract_mC23121E46C67B16DA74D2B74AA96BC9B734B4A86,
	LightmapperUtils_Extract_mC6A2DEE19D89B532926E1E1EF0F6815E069F27C2,
	LightmapperUtils_Extract_mFF46D8454835FF7AC4B35A807B1F29222425B594,
	LightmapperUtils_Extract_mF66211092ADB3241E3E1902CB84FF8E1A84A301F,
	Lightmapping_SetDelegate_mEA4A2549370F078869895AAC4E01EB916BB49A01,
	Lightmapping_GetDelegate_mCFE706531D3E5A96E71ED963AF8CB4B93A1C0AEE,
	Lightmapping_ResetDelegate_m25E3082200DFB9F101AEE07039FC4A33C4183738,
	Lightmapping_RequestLights_m572FA5D5ADA94FF109696431E2EAE13B6D5C9AB6,
	Lightmapping__cctor_m542D9D32613B348F62541FB1F0AF70EBF7EBB93A,
	RequestLightsDelegate__ctor_m32E80A59669219265627BAF616170C5BA130CA77,
	RequestLightsDelegate_Invoke_m2B97E4D1ED4DC45416B5EC472FC12B581373E403,
	RequestLightsDelegate_BeginInvoke_m842A0B872EE1BDC505161CC083CA189F222784A8,
	RequestLightsDelegate_EndInvoke_mB5DE6574659D68281BC3D8179211DA892A481333,
	U3CU3Ec__cctor_mB5E5B471CF113C81A1D2CF2C4245C2181590DB0C,
	U3CU3Ec__ctor_m9919FB3B009FEC46DBE2AAB63233F08B8B8D798D,
	U3CU3Ec_U3C_cctorU3Eb__7_0_m2D9D2C1DEA68EC9BC1F47CA41F462BB9EF72CF7B,
	CameraPlayable_GetHandle_mC710651CAEE2596697CFFC01014BEB041C67E2B4_AdjustorThunk,
	CameraPlayable_Equals_mBA0325A3187672B8FDE237D2D5229474C19E3A52_AdjustorThunk,
	MaterialEffectPlayable_GetHandle_mB0F6F324656489CE4DE4EFA8ACCE37458D292439_AdjustorThunk,
	MaterialEffectPlayable_Equals_m9C2DB0EB37CFB9679961D667B61E2360384C71DA_AdjustorThunk,
	TextureMixerPlayable_GetHandle_mBC5D38A23834675B7A8D5314DCF4655C83AE649C_AdjustorThunk,
	TextureMixerPlayable_Equals_mEDE18FD43C9501F04871D2357DC66BABE43F397B_AdjustorThunk,
	BuiltinRuntimeReflectionSystem_TickRealtimeProbes_m7100EF316D04C407A21C27A35752826E463603EB,
	BuiltinRuntimeReflectionSystem_Dispose_m60454D78E8492E739E2537F0B80FC76AC5DA1FCC,
	BuiltinRuntimeReflectionSystem_Dispose_m46A331A4A718F67B97CC07E98D419C0BBF38A8B0,
	BuiltinRuntimeReflectionSystem_BuiltinUpdate_mE62DD3456554487F133F6CCF3D07E0CE6B7A07AB,
	BuiltinRuntimeReflectionSystem_Internal_BuiltinRuntimeReflectionSystem_New_m1B6EE7816B71869B7F874488A51FF0093F1FF8CB,
	BuiltinRuntimeReflectionSystem__ctor_mB95177E1C8083A75B0980623778F2B6F3A80FE52,
	NULL,
	ScriptableRuntimeReflectionSystemSettings_set_Internal_ScriptableRuntimeReflectionSystemSettings_system_m9D4C5A04E52667F4A9C15144B854A9D84D089590,
	ScriptableRuntimeReflectionSystemSettings_get_Internal_ScriptableRuntimeReflectionSystemSettings_instance_m67BF9AE5DFB70144A8114705C51C96FFB497AA3E,
	ScriptableRuntimeReflectionSystemSettings_ScriptingDirtyReflectionSystemInstance_m02B2FCD9BBCFA4ECC1D91A0B5B8B83856AC55718,
	ScriptableRuntimeReflectionSystemSettings__cctor_m9CC42ECA95CACFFF874575B63D1FA461667D194C,
	ScriptableRuntimeReflectionSystemWrapper_get_implementation_mABDBD524BA9D869BCC02159B00C3B5F6DEE21895,
	ScriptableRuntimeReflectionSystemWrapper_set_implementation_m7866062401FA10180983AFE19BA672AE63CED29B,
	ScriptableRuntimeReflectionSystemWrapper_Internal_ScriptableRuntimeReflectionSystemWrapper_TickRealtimeProbes_m65564441C57A8D5D3BA116C171ECE95B91F734A2,
	ScriptableRuntimeReflectionSystemWrapper__ctor_mB936D4EA457BCCBEB0413F3F5B216164D88C4A3F,
	GraphicsFormatUtility_GetFormat_m8DDA73529B51539BEE2A75451CBFA60186888589,
	GraphicsFormatUtility_GetGraphicsFormat_mBA4E395B8A78B67B0969356DE19F6F1E73D284E0,
	GraphicsFormatUtility_GetGraphicsFormat_Native_TextureFormat_mAB77B8E00F9BE01455C0E011CF426FFBC53FA533,
	GraphicsFormatUtility_GetGraphicsFormat_mA94B78BFCA8AFEBB85150D361A9A20C83FC5277E,
	GraphicsFormatUtility_GetGraphicsFormat_Native_RenderTextureFormat_m36427FF5F0909DFE7AB6849EAC2D01A4E8D5ECF8,
	GraphicsFormatUtility_GetGraphicsFormat_m4527266E37A786CC45C6BDD520A793C3B5A3A09E,
	GraphicsFormatUtility_IsSRGBFormat_mBF49E7451A3960BD67B1F13745BCA3AC5C8AC66E,
	GraphicsFormatUtility_GetRenderTextureFormat_m4A8B97E7A7BD031B38EE1C5DA0C93B0F65016468,
	GraphicsFormatUtility_IsCompressedTextureFormat_m456D7B059F25F7378E05E3346CB1670517A46C71,
	GraphicsFormatUtility_IsCrunchFormat_m97E8A6551AAEE6B1E4E92F92167FC97CC7D73DB1,
	Assert_Fail_m9A3A2A08A2E1D18D0BB7D0C635055839EAA2EF02,
	NULL,
	NULL,
	Assert_AreEqual_mFD46F687B9319093BA13D285D19999C801DC0A60,
	Assert_AreEqual_mF4EDACE982A071478F520E76D1901B840411A91E,
	Assert__cctor_mB34E1F44EB37A40F434BDB787B5E55F2B4033AF5,
	AssertionException__ctor_mDB97D95CF48EE1F6C184D30F6C3E099E1C4DA7FD,
	AssertionException_get_Message_m857FDA8060518415B2FFFCCA4A6BEE7B9BF66ECE,
	AssertionMessageUtil_GetMessage_mA6DC7467BAF09543EA091FC63587C9011E1CA261,
	AssertionMessageUtil_GetMessage_m97506B9B19E9F75E8FE164BF64085466FC96EA18,
	AssertionMessageUtil_GetEqualityMessage_mDBD27DDE3A03418E4A2F8DB377AE866F656C812A,
};
static const int32_t s_InvokerIndices[2284] = 
{
	3,
	32,
	26,
	14,
	23,
	26,
	1092,
	1093,
	25,
	25,
	7,
	23,
	3,
	3,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	23,
	23,
	23,
	23,
	23,
	23,
	-1,
	-1,
	-1,
	-1,
	1094,
	308,
	1095,
	1096,
	200,
	94,
	94,
	1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	10,
	10,
	4,
	4,
	21,
	43,
	1097,
	684,
	296,
	25,
	24,
	1098,
	23,
	1099,
	14,
	26,
	1100,
	1101,
	1101,
	1102,
	32,
	1103,
	10,
	26,
	1103,
	14,
	931,
	26,
	23,
	9,
	9,
	10,
	1104,
	1105,
	774,
	133,
	3,
	49,
	131,
	49,
	3,
	682,
	49,
	3,
	3,
	799,
	122,
	49,
	102,
	23,
	113,
	26,
	102,
	605,
	1106,
	26,
	18,
	7,
	684,
	684,
	684,
	114,
	114,
	114,
	684,
	296,
	114,
	10,
	10,
	684,
	10,
	10,
	10,
	1107,
	10,
	1108,
	1109,
	1108,
	1109,
	10,
	10,
	14,
	10,
	1110,
	1111,
	1110,
	1110,
	23,
	1112,
	1113,
	1113,
	1114,
	1115,
	1116,
	4,
	114,
	10,
	131,
	95,
	131,
	95,
	122,
	122,
	122,
	1117,
	1118,
	23,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	1119,
	525,
	1119,
	102,
	26,
	179,
	26,
	23,
	23,
	23,
	23,
	26,
	26,
	32,
	30,
	1120,
	24,
	23,
	102,
	1121,
	1122,
	26,
	330,
	122,
	1123,
	134,
	40,
	27,
	23,
	4,
	122,
	122,
	134,
	134,
	159,
	122,
	134,
	122,
	134,
	159,
	799,
	720,
	122,
	49,
	111,
	3,
	1124,
	10,
	9,
	1125,
	1126,
	1127,
	1126,
	1127,
	1126,
	1127,
	1126,
	1127,
	1126,
	1127,
	1128,
	1128,
	1124,
	1127,
	14,
	1124,
	1129,
	14,
	1124,
	1126,
	1126,
	1130,
	14,
	1097,
	1131,
	1132,
	1133,
	684,
	296,
	684,
	296,
	1134,
	1135,
	1134,
	1134,
	1134,
	684,
	296,
	684,
	296,
	1134,
	1135,
	684,
	296,
	684,
	296,
	684,
	296,
	684,
	296,
	1136,
	1137,
	1138,
	1139,
	1140,
	1141,
	1141,
	10,
	9,
	1139,
	14,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	300,
	14,
	1142,
	23,
	102,
	23,
	14,
	23,
	717,
	25,
	10,
	10,
	10,
	10,
	10,
	10,
	1143,
	1144,
	3,
	3,
	23,
	7,
	10,
	10,
	10,
	10,
	114,
	114,
	1145,
	4,
	122,
	3,
	1146,
	1146,
	1147,
	547,
	547,
	3,
	102,
	23,
	113,
	26,
	131,
	131,
	1148,
	131,
	131,
	131,
	49,
	49,
	1149,
	1149,
	3,
	1150,
	1151,
	1148,
	1148,
	1152,
	14,
	131,
	133,
	131,
	23,
	717,
	25,
	31,
	23,
	23,
	23,
	23,
	1153,
	10,
	10,
	6,
	1154,
	4,
	4,
	1155,
	1148,
	17,
	17,
	0,
	114,
	122,
	122,
	122,
	95,
	95,
	1156,
	1157,
	1156,
	1157,
	23,
	1158,
	1158,
	134,
	134,
	122,
	26,
	26,
	26,
	14,
	37,
	30,
	9,
	26,
	26,
	26,
	26,
	931,
	1159,
	1160,
	62,
	34,
	861,
	931,
	140,
	172,
	1161,
	1162,
	62,
	28,
	34,
	774,
	774,
	10,
	684,
	684,
	1107,
	684,
	684,
	684,
	684,
	684,
	684,
	1163,
	10,
	684,
	23,
	6,
	6,
	23,
	23,
	122,
	23,
	1164,
	1165,
	32,
	30,
	1166,
	164,
	114,
	10,
	31,
	23,
	31,
	37,
	21,
	-1,
	-1,
	1166,
	-1,
	-1,
	-1,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	14,
	14,
	26,
	14,
	26,
	35,
	26,
	35,
	26,
	35,
	26,
	35,
	-1,
	62,
	442,
	23,
	800,
	30,
	30,
	26,
	34,
	1164,
	38,
	1167,
	140,
	1168,
	1169,
	35,
	943,
	1170,
	705,
	23,
	23,
	31,
	23,
	10,
	10,
	10,
	10,
	10,
	32,
	10,
	32,
	10,
	32,
	114,
	10,
	32,
	32,
	32,
	296,
	1134,
	30,
	52,
	28,
	3,
	6,
	10,
	4,
	4,
	1171,
	1172,
	114,
	42,
	1173,
	1174,
	1175,
	1176,
	298,
	39,
	1177,
	1178,
	26,
	1179,
	42,
	23,
	1180,
	1181,
	1182,
	1183,
	42,
	114,
	1173,
	38,
	38,
	38,
	300,
	1184,
	1185,
	1086,
	1173,
	42,
	23,
	1180,
	114,
	1186,
	1187,
	42,
	140,
	472,
	472,
	1188,
	472,
	1189,
	42,
	23,
	131,
	114,
	1186,
	1187,
	472,
	472,
	1188,
	1190,
	1191,
	1189,
	114,
	1192,
	1193,
	42,
	165,
	35,
	300,
	300,
	472,
	1189,
	298,
	39,
	42,
	23,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	114,
	31,
	114,
	32,
	10,
	32,
	31,
	10,
	32,
	10,
	32,
	31,
	31,
	31,
	114,
	23,
	31,
	122,
	1194,
	1195,
	1196,
	122,
	32,
	23,
	1194,
	26,
	300,
	300,
	472,
	472,
	300,
	38,
	472,
	1195,
	1194,
	1197,
	138,
	1196,
	1198,
	1199,
	6,
	6,
	88,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	32,
	10,
	32,
	10,
	32,
	114,
	31,
	10,
	32,
	10,
	32,
	32,
	32,
	32,
	172,
	300,
	472,
	769,
	31,
	31,
	31,
	31,
	31,
	31,
	3,
	904,
	145,
	145,
	1200,
	14,
	1201,
	9,
	1202,
	10,
	116,
	1203,
	1203,
	1203,
	88,
	348,
	1204,
	1205,
	49,
	1204,
	1206,
	1207,
	308,
	1204,
	1208,
	1208,
	1206,
	1209,
	3,
	6,
	799,
	131,
	133,
	14,
	62,
	325,
	325,
	40,
	27,
	26,
	14,
	26,
	114,
	31,
	10,
	32,
	30,
	0,
	62,
	325,
	325,
	40,
	27,
	122,
	122,
	3,
	560,
	26,
	35,
	23,
	1097,
	1210,
	14,
	10,
	9,
	1211,
	1212,
	1213,
	1214,
	1214,
	1215,
	1216,
	1154,
	1154,
	1154,
	1154,
	1154,
	1154,
	1107,
	1107,
	684,
	1217,
	1218,
	85,
	1219,
	1220,
	14,
	717,
	23,
	1098,
	23,
	23,
	9,
	9,
	10,
	1221,
	1222,
	1110,
	1223,
	1224,
	1225,
	931,
	10,
	9,
	1226,
	1227,
	1228,
	1161,
	1113,
	1113,
	1113,
	1229,
	1230,
	1230,
	14,
	3,
	1208,
	348,
	1231,
	1232,
	1233,
	931,
	1210,
	1234,
	1235,
	10,
	9,
	1137,
	1145,
	23,
	1126,
	1236,
	1236,
	1237,
	684,
	684,
	1235,
	1235,
	1238,
	1238,
	1238,
	1238,
	1238,
	1238,
	1238,
	1238,
	1235,
	1235,
	1145,
	1239,
	1240,
	1239,
	1241,
	1241,
	14,
	3,
	1242,
	1243,
	1244,
	1245,
	1097,
	1246,
	1247,
	221,
	1248,
	1248,
	1249,
	1124,
	1145,
	1126,
	1250,
	1243,
	10,
	9,
	1251,
	14,
	3,
	348,
	348,
	348,
	1252,
	391,
	391,
	391,
	391,
	391,
	391,
	391,
	391,
	391,
	392,
	138,
	392,
	138,
	392,
	391,
	392,
	391,
	391,
	391,
	391,
	231,
	231,
	231,
	391,
	1253,
	139,
	391,
	1253,
	1254,
	1255,
	392,
	1253,
	3,
	1233,
	931,
	1234,
	1256,
	23,
	1134,
	14,
	10,
	9,
	1136,
	1257,
	684,
	684,
	1257,
	1256,
	1256,
	1256,
	1256,
	1258,
	1259,
	1259,
	1260,
	1260,
	1261,
	1262,
	1263,
	1263,
	1263,
	1263,
	1263,
	1263,
	3,
	10,
	32,
	10,
	32,
	172,
	1264,
	1265,
	1266,
	1266,
	9,
	1267,
	10,
	14,
	1268,
	1268,
	3,
	10,
	10,
	10,
	38,
	1269,
	9,
	1270,
	10,
	14,
	3,
	1233,
	931,
	1097,
	1234,
	10,
	9,
	1271,
	1272,
	684,
	1273,
	1274,
	1275,
	1276,
	1277,
	1278,
	1279,
	1280,
	1281,
	14,
	3,
	23,
	23,
	1282,
	1283,
	23,
	947,
	947,
	114,
	1282,
	1283,
	23,
	947,
	947,
	23,
	114,
	23,
	49,
	3,
	122,
	122,
	169,
	441,
	3,
	3,
	23,
	23,
	26,
	23,
	296,
	26,
	1234,
	172,
	31,
	1284,
	351,
	26,
	1285,
	1286,
	10,
	9,
	1287,
	14,
	1148,
	-1,
	1,
	1,
	-1,
	23,
	0,
	0,
	95,
	95,
	95,
	-1,
	3,
	23,
	26,
	26,
	140,
	23,
	23,
	23,
	26,
	10,
	23,
	114,
	31,
	114,
	23,
	3,
	14,
	14,
	28,
	102,
	-1,
	-1,
	112,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	28,
	-1,
	-1,
	-1,
	-1,
	27,
	27,
	-1,
	-1,
	23,
	23,
	23,
	25,
	919,
	2,
	114,
	14,
	114,
	23,
	23,
	23,
	23,
	-1,
	28,
	102,
	112,
	-1,
	-1,
	28,
	1288,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	102,
	28,
	28,
	-1,
	14,
	10,
	32,
	31,
	114,
	114,
	605,
	26,
	23,
	27,
	134,
	1289,
	1290,
	10,
	122,
	1291,
	1292,
	919,
	114,
	23,
	861,
	1293,
	26,
	9,
	28,
	113,
	28,
	28,
	26,
	26,
	26,
	23,
	114,
	31,
	122,
	122,
	94,
	1294,
	134,
	111,
	94,
	113,
	28,
	26,
	26,
	14,
	23,
	95,
	-1,
	0,
	10,
	172,
	23,
	32,
	32,
	23,
	0,
	-1,
	122,
	121,
	49,
	23,
	122,
	4,
	411,
	0,
	3,
	23,
	26,
	173,
	14,
	14,
	3,
	3,
	23,
	27,
	10,
	10,
	9,
	94,
	111,
	94,
	15,
	14,
	26,
	0,
	180,
	-1,
	-1,
	-1,
	1295,
	122,
	568,
	122,
	0,
	122,
	32,
	-1,
	134,
	0,
	14,
	111,
	111,
	131,
	0,
	180,
	0,
	0,
	134,
	43,
	23,
	3,
	32,
	140,
	27,
	27,
	14,
	23,
	114,
	3,
	3,
	220,
	171,
	23,
	23,
	684,
	296,
	114,
	296,
	23,
	23,
	23,
	23,
	23,
	23,
	31,
	1296,
	122,
	172,
	472,
	23,
	10,
	-1,
	-1,
	1297,
	702,
	116,
	23,
	23,
	131,
	4,
	131,
	131,
	131,
	49,
	49,
	131,
	131,
	131,
	49,
	49,
	94,
	46,
	46,
	131,
	4,
	131,
	131,
	131,
	49,
	49,
	131,
	131,
	131,
	49,
	49,
	46,
	46,
	53,
	138,
	21,
	1148,
	1148,
	1148,
	1148,
	1148,
	1148,
	25,
	23,
	23,
	1298,
	1299,
	49,
	49,
	1300,
	14,
	26,
	799,
	114,
	31,
	10,
	32,
	114,
	114,
	1301,
	1302,
	348,
	135,
	605,
	23,
	122,
	122,
	1108,
	1134,
	1135,
	1134,
	1135,
	1134,
	1135,
	1134,
	1135,
	1134,
	1135,
	1135,
	1135,
	26,
	26,
	931,
	122,
	1134,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	102,
	26,
	179,
	26,
	23,
	1126,
	1127,
	1126,
	1127,
	1126,
	1127,
	1126,
	1127,
	1126,
	1126,
	1303,
	1304,
	1303,
	1304,
	1126,
	1127,
	14,
	26,
	14,
	26,
	14,
	26,
	406,
	1110,
	1110,
	1305,
	1113,
	1113,
	1113,
	10,
	23,
	9,
	14,
	34,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	6,
	525,
	525,
	525,
	525,
	26,
	14,
	114,
	23,
	23,
	10,
	10,
	1108,
	1306,
	1306,
	1306,
	1307,
	1153,
	1108,
	1306,
	14,
	684,
	14,
	1134,
	114,
	10,
	1108,
	14,
	14,
	14,
	1307,
	1308,
	1309,
	1310,
	1311,
	1312,
	6,
	6,
	6,
	6,
	1313,
	6,
	6,
	6,
	6,
	967,
	967,
	1314,
	1314,
	1314,
	1315,
	1316,
	94,
	122,
	122,
	122,
	122,
	3,
	9,
	23,
	3,
	23,
	7,
	0,
	24,
	3,
	1317,
	32,
	32,
	32,
	23,
	4,
	537,
	334,
	568,
	1318,
	133,
	133,
	102,
	32,
	546,
	26,
	102,
	32,
	546,
	26,
	1319,
	1320,
	102,
	1321,
	1322,
	26,
	26,
	140,
	32,
	140,
	102,
	26,
	179,
	26,
	102,
	140,
	1323,
	26,
	102,
	32,
	546,
	26,
	102,
	140,
	1323,
	26,
	1324,
	1325,
	919,
	7,
	120,
	120,
	120,
	1326,
	23,
	23,
	23,
	23,
	3,
	102,
	26,
	179,
	26,
	102,
	1327,
	1328,
	26,
	102,
	1327,
	1328,
	26,
	102,
	1327,
	1328,
	26,
	102,
	1329,
	1330,
	26,
	10,
	32,
	31,
	32,
	10,
	114,
	10,
	7,
	23,
	23,
	23,
	23,
	1331,
	919,
	7,
	120,
	120,
	120,
	120,
	23,
	23,
	23,
	23,
	3,
	102,
	26,
	179,
	26,
	102,
	1332,
	1333,
	26,
	102,
	1332,
	1333,
	26,
	102,
	1332,
	1333,
	26,
	102,
	1332,
	1333,
	26,
	14,
	14,
	10,
	684,
	14,
	114,
	23,
	23,
	23,
	23,
	23,
	27,
	26,
	-1,
	94,
	115,
	26,
	26,
	27,
	26,
	26,
	23,
	115,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	14,
	14,
	10,
	14,
	114,
	28,
	2,
	23,
	23,
	27,
	26,
	26,
	27,
	23,
	14,
	23,
	23,
	23,
	23,
	113,
	113,
	28,
	905,
	23,
	23,
	26,
	27,
	14,
	14,
	2,
	102,
	23,
	113,
	26,
	23,
	26,
	113,
	113,
	0,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	26,
	23,
	1066,
	26,
	10,
	10,
	9,
	1334,
	1335,
	1336,
	3,
	102,
	23,
	113,
	26,
	23,
	4,
	114,
	4,
	23,
	14,
	1337,
	1337,
	26,
	26,
	26,
	26,
	1337,
	1338,
	1339,
	23,
	1340,
	133,
	133,
	23,
	23,
	9,
	23,
	9,
	23,
	26,
	1282,
	996,
	1337,
	23,
	23,
	23,
	673,
	947,
	23,
	23,
	9,
	23,
	9,
	23,
	9,
	26,
	14,
	9,
	10,
	23,
	32,
	32,
	300,
	1341,
	26,
	1342,
	1342,
	1343,
	14,
	10,
	1344,
	9,
	1345,
	1345,
	49,
	799,
	799,
	49,
	53,
	4,
	4,
	122,
	122,
	122,
	131,
	17,
	3,
	717,
	23,
	1346,
	702,
	26,
	23,
	1347,
	36,
	1348,
	1349,
	1109,
	1109,
	23,
	1350,
	1351,
	1351,
	32,
	1352,
	1353,
	931,
	1161,
	1159,
	1160,
	26,
	26,
	1354,
	52,
	62,
	62,
	622,
	62,
	26,
	26,
	1355,
	1356,
	1357,
	1341,
	1358,
	1359,
	1360,
	1357,
	1361,
	1362,
	23,
	23,
	31,
	23,
	1363,
	702,
	1347,
	1364,
	1365,
	1366,
	36,
	605,
	27,
	1348,
	1349,
	1367,
	1368,
	861,
	1369,
	1370,
	1162,
	1371,
	1372,
	1373,
	1374,
	1375,
	6,
	6,
	6,
	1376,
	622,
	1377,
	774,
	774,
	774,
	525,
	1378,
	1379,
	1380,
	1381,
	10,
	9,
	1382,
	1383,
	1384,
	411,
	102,
	1385,
	1386,
	1387,
	1388,
	42,
	1389,
	9,
	10,
	1390,
	9,
	10,
	1391,
	1391,
	1392,
	9,
	10,
	10,
	31,
	296,
	10,
	32,
	1233,
	1391,
	1393,
	9,
	10,
	3,
	123,
	123,
	1394,
	123,
	1395,
	1395,
	1396,
	1397,
	1398,
	1399,
	-1,
	10,
	26,
	1400,
	1401,
	1402,
	730,
	1403,
	1404,
	9,
	10,
	1405,
	1406,
	769,
	1407,
	9,
	10,
	1408,
	1409,
	1410,
	32,
	31,
	31,
	26,
	32,
	32,
	1411,
	1412,
	1413,
	9,
	10,
	3,
	1414,
	1415,
	32,
	32,
	31,
	1416,
	1417,
	9,
	10,
	1418,
	9,
	10,
	1419,
	1420,
	9,
	10,
	3,
	1421,
	1422,
	1422,
	1422,
	1422,
	1421,
	114,
	31,
	23,
	31,
	23,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	14,
	23,
	23,
	23,
	4,
	122,
	122,
	122,
	122,
	122,
	1422,
	1422,
	1422,
	1422,
	3,
	1423,
	919,
	122,
	3,
	1424,
	1424,
	1424,
	1425,
	9,
	10,
	3,
	32,
	1426,
	1427,
	32,
	10,
	32,
	1428,
	9,
	10,
	1429,
	273,
	1430,
	9,
	10,
	1431,
	351,
	23,
	10,
	34,
	1432,
	7,
	26,
	1036,
	316,
	140,
	26,
	26,
	23,
	7,
	23,
	10,
	34,
	1433,
	1434,
	6,
	26,
	1036,
	316,
	140,
	26,
	26,
	23,
	1435,
	1436,
	9,
	10,
	1437,
	17,
	449,
	269,
	1438,
	1439,
	992,
	1440,
	1441,
	91,
	992,
	992,
	17,
	26,
	10,
	32,
	9,
	1442,
	10,
	1443,
	1443,
	3,
	1444,
	1445,
	1446,
	1447,
	9,
	10,
	10,
	1306,
	1448,
	296,
	1391,
	1449,
	9,
	10,
	3,
	1067,
	1450,
	1451,
	9,
	10,
	26,
	1127,
	10,
	32,
	32,
	1452,
	9,
	10,
	1453,
	1454,
	1455,
	114,
	31,
	32,
	32,
	32,
	32,
	32,
	32,
	32,
	32,
	32,
	32,
	32,
	32,
	1456,
	9,
	10,
	4,
	122,
	10,
	10,
	10,
	10,
	114,
	25,
	46,
	1457,
	46,
	1457,
	1457,
	1457,
	25,
	23,
	3,
	14,
	10,
	1107,
	1110,
	684,
	684,
	1458,
	9,
	10,
	1459,
	9,
	10,
	95,
	26,
	1460,
	1461,
	1461,
	1461,
	1461,
	1462,
	1462,
	1462,
	1463,
	1464,
	1465,
	1466,
	1467,
	3,
	1468,
	410,
	14,
	1469,
	919,
	23,
	23,
	1461,
	1461,
	1461,
	1461,
	1462,
	1462,
	1462,
	1463,
	14,
	3,
	102,
	1470,
	1471,
	1472,
	-1,
	1473,
	1474,
	9,
	1475,
	10,
	1474,
	114,
	14,
	3,
	344,
	88,
	1476,
	1477,
	1478,
	3,
	1479,
	10,
	1480,
	9,
	1481,
	1480,
	3,
	1482,
	1483,
	6,
	6,
	6,
	6,
	6,
	32,
	1484,
	1485,
	351,
	351,
	351,
	351,
	351,
	122,
	4,
	3,
	1120,
	3,
	102,
	1486,
	1487,
	26,
	3,
	23,
	1486,
	1466,
	1488,
	1466,
	1489,
	1466,
	1490,
	114,
	23,
	31,
	49,
	4,
	23,
	114,
	122,
	4,
	3,
	3,
	14,
	26,
	6,
	23,
	95,
	268,
	268,
	268,
	268,
	138,
	46,
	21,
	46,
	46,
	134,
	-1,
	-1,
	159,
	135,
	3,
	27,
	14,
	0,
	1,
	180,
};
static const Il2CppTokenRangePair s_rgctxIndices[65] = 
{
	{ 0x02000012, { 0, 13 } },
	{ 0x02000013, { 13, 4 } },
	{ 0x0200011B, { 89, 7 } },
	{ 0x0200011C, { 96, 7 } },
	{ 0x0200011D, { 103, 9 } },
	{ 0x0200011E, { 112, 11 } },
	{ 0x0200011F, { 123, 3 } },
	{ 0x02000128, { 126, 8 } },
	{ 0x0200012A, { 134, 4 } },
	{ 0x0200012C, { 138, 5 } },
	{ 0x0200012E, { 143, 6 } },
	{ 0x0600002B, { 17, 1 } },
	{ 0x06000034, { 18, 1 } },
	{ 0x06000035, { 19, 1 } },
	{ 0x06000036, { 20, 2 } },
	{ 0x06000037, { 22, 1 } },
	{ 0x06000038, { 23, 1 } },
	{ 0x06000039, { 24, 1 } },
	{ 0x0600003A, { 25, 1 } },
	{ 0x060001C5, { 26, 2 } },
	{ 0x060001C6, { 28, 1 } },
	{ 0x060001C9, { 29, 1 } },
	{ 0x060001CA, { 30, 1 } },
	{ 0x060001E0, { 31, 1 } },
	{ 0x060003F8, { 32, 2 } },
	{ 0x060003FB, { 34, 2 } },
	{ 0x06000402, { 36, 2 } },
	{ 0x06000417, { 38, 1 } },
	{ 0x06000418, { 39, 1 } },
	{ 0x0600041A, { 40, 2 } },
	{ 0x0600041B, { 42, 2 } },
	{ 0x0600041C, { 44, 1 } },
	{ 0x0600041D, { 45, 1 } },
	{ 0x0600041E, { 46, 1 } },
	{ 0x0600041F, { 47, 1 } },
	{ 0x06000421, { 48, 2 } },
	{ 0x06000422, { 50, 1 } },
	{ 0x06000423, { 51, 1 } },
	{ 0x06000424, { 52, 1 } },
	{ 0x06000427, { 53, 1 } },
	{ 0x06000428, { 54, 1 } },
	{ 0x06000436, { 55, 1 } },
	{ 0x0600043A, { 56, 1 } },
	{ 0x0600043B, { 57, 2 } },
	{ 0x0600043E, { 59, 2 } },
	{ 0x0600043F, { 61, 1 } },
	{ 0x06000440, { 62, 2 } },
	{ 0x06000441, { 64, 1 } },
	{ 0x06000442, { 65, 1 } },
	{ 0x06000443, { 66, 2 } },
	{ 0x06000444, { 68, 2 } },
	{ 0x06000448, { 70, 2 } },
	{ 0x06000479, { 72, 1 } },
	{ 0x06000482, { 73, 2 } },
	{ 0x060004A0, { 75, 1 } },
	{ 0x060004A1, { 76, 1 } },
	{ 0x060004A2, { 77, 1 } },
	{ 0x060004AA, { 78, 2 } },
	{ 0x060004D7, { 80, 3 } },
	{ 0x060004D8, { 83, 4 } },
	{ 0x06000636, { 87, 2 } },
	{ 0x06000772, { 149, 1 } },
	{ 0x06000891, { 150, 1 } },
	{ 0x060008E3, { 151, 3 } },
	{ 0x060008E4, { 154, 3 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[157] = 
{
	{ (Il2CppRGCTXDataType)3, 16548 },
	{ (Il2CppRGCTXDataType)2, 16118 },
	{ (Il2CppRGCTXDataType)3, 16549 },
	{ (Il2CppRGCTXDataType)3, 16550 },
	{ (Il2CppRGCTXDataType)3, 16551 },
	{ (Il2CppRGCTXDataType)3, 16552 },
	{ (Il2CppRGCTXDataType)3, 16553 },
	{ (Il2CppRGCTXDataType)3, 16554 },
	{ (Il2CppRGCTXDataType)2, 16120 },
	{ (Il2CppRGCTXDataType)3, 16555 },
	{ (Il2CppRGCTXDataType)3, 16556 },
	{ (Il2CppRGCTXDataType)2, 16118 },
	{ (Il2CppRGCTXDataType)3, 16557 },
	{ (Il2CppRGCTXDataType)3, 16558 },
	{ (Il2CppRGCTXDataType)3, 16559 },
	{ (Il2CppRGCTXDataType)3, 16560 },
	{ (Il2CppRGCTXDataType)2, 16128 },
	{ (Il2CppRGCTXDataType)1, 21075 },
	{ (Il2CppRGCTXDataType)3, 16561 },
	{ (Il2CppRGCTXDataType)1, 21077 },
	{ (Il2CppRGCTXDataType)3, 16562 },
	{ (Il2CppRGCTXDataType)3, 16563 },
	{ (Il2CppRGCTXDataType)2, 16169 },
	{ (Il2CppRGCTXDataType)2, 16170 },
	{ (Il2CppRGCTXDataType)2, 21080 },
	{ (Il2CppRGCTXDataType)3, 16564 },
	{ (Il2CppRGCTXDataType)2, 16384 },
	{ (Il2CppRGCTXDataType)2, 16384 },
	{ (Il2CppRGCTXDataType)3, 16565 },
	{ (Il2CppRGCTXDataType)3, 16566 },
	{ (Il2CppRGCTXDataType)3, 16567 },
	{ (Il2CppRGCTXDataType)3, 16568 },
	{ (Il2CppRGCTXDataType)1, 16505 },
	{ (Il2CppRGCTXDataType)2, 16505 },
	{ (Il2CppRGCTXDataType)1, 16506 },
	{ (Il2CppRGCTXDataType)2, 16506 },
	{ (Il2CppRGCTXDataType)1, 16512 },
	{ (Il2CppRGCTXDataType)2, 16512 },
	{ (Il2CppRGCTXDataType)1, 16540 },
	{ (Il2CppRGCTXDataType)3, 16569 },
	{ (Il2CppRGCTXDataType)1, 16543 },
	{ (Il2CppRGCTXDataType)2, 16543 },
	{ (Il2CppRGCTXDataType)1, 16544 },
	{ (Il2CppRGCTXDataType)2, 16544 },
	{ (Il2CppRGCTXDataType)3, 16570 },
	{ (Il2CppRGCTXDataType)3, 16571 },
	{ (Il2CppRGCTXDataType)3, 16572 },
	{ (Il2CppRGCTXDataType)3, 16573 },
	{ (Il2CppRGCTXDataType)1, 16553 },
	{ (Il2CppRGCTXDataType)2, 16553 },
	{ (Il2CppRGCTXDataType)3, 16574 },
	{ (Il2CppRGCTXDataType)3, 16575 },
	{ (Il2CppRGCTXDataType)3, 16576 },
	{ (Il2CppRGCTXDataType)1, 16561 },
	{ (Il2CppRGCTXDataType)3, 16577 },
	{ (Il2CppRGCTXDataType)1, 16577 },
	{ (Il2CppRGCTXDataType)3, 16578 },
	{ (Il2CppRGCTXDataType)1, 16579 },
	{ (Il2CppRGCTXDataType)2, 16579 },
	{ (Il2CppRGCTXDataType)1, 16581 },
	{ (Il2CppRGCTXDataType)2, 16580 },
	{ (Il2CppRGCTXDataType)1, 16583 },
	{ (Il2CppRGCTXDataType)1, 16585 },
	{ (Il2CppRGCTXDataType)2, 16584 },
	{ (Il2CppRGCTXDataType)1, 16587 },
	{ (Il2CppRGCTXDataType)1, 16589 },
	{ (Il2CppRGCTXDataType)1, 16591 },
	{ (Il2CppRGCTXDataType)2, 16590 },
	{ (Il2CppRGCTXDataType)1, 16593 },
	{ (Il2CppRGCTXDataType)2, 16593 },
	{ (Il2CppRGCTXDataType)1, 16594 },
	{ (Il2CppRGCTXDataType)2, 16594 },
	{ (Il2CppRGCTXDataType)3, 16579 },
	{ (Il2CppRGCTXDataType)1, 16613 },
	{ (Il2CppRGCTXDataType)2, 16613 },
	{ (Il2CppRGCTXDataType)2, 16637 },
	{ (Il2CppRGCTXDataType)3, 16580 },
	{ (Il2CppRGCTXDataType)2, 16639 },
	{ (Il2CppRGCTXDataType)1, 16641 },
	{ (Il2CppRGCTXDataType)2, 16641 },
	{ (Il2CppRGCTXDataType)3, 16581 },
	{ (Il2CppRGCTXDataType)3, 16582 },
	{ (Il2CppRGCTXDataType)3, 16583 },
	{ (Il2CppRGCTXDataType)3, 16584 },
	{ (Il2CppRGCTXDataType)1, 16672 },
	{ (Il2CppRGCTXDataType)3, 16585 },
	{ (Il2CppRGCTXDataType)3, 16586 },
	{ (Il2CppRGCTXDataType)2, 21081 },
	{ (Il2CppRGCTXDataType)1, 21081 },
	{ (Il2CppRGCTXDataType)2, 16857 },
	{ (Il2CppRGCTXDataType)3, 16587 },
	{ (Il2CppRGCTXDataType)1, 16857 },
	{ (Il2CppRGCTXDataType)3, 16588 },
	{ (Il2CppRGCTXDataType)3, 16589 },
	{ (Il2CppRGCTXDataType)2, 16858 },
	{ (Il2CppRGCTXDataType)3, 16590 },
	{ (Il2CppRGCTXDataType)1, 21082 },
	{ (Il2CppRGCTXDataType)2, 21082 },
	{ (Il2CppRGCTXDataType)3, 16591 },
	{ (Il2CppRGCTXDataType)3, 16592 },
	{ (Il2CppRGCTXDataType)2, 16863 },
	{ (Il2CppRGCTXDataType)2, 16864 },
	{ (Il2CppRGCTXDataType)3, 16593 },
	{ (Il2CppRGCTXDataType)1, 21083 },
	{ (Il2CppRGCTXDataType)2, 21083 },
	{ (Il2CppRGCTXDataType)3, 16594 },
	{ (Il2CppRGCTXDataType)3, 16595 },
	{ (Il2CppRGCTXDataType)3, 16596 },
	{ (Il2CppRGCTXDataType)2, 16868 },
	{ (Il2CppRGCTXDataType)2, 16869 },
	{ (Il2CppRGCTXDataType)2, 16870 },
	{ (Il2CppRGCTXDataType)3, 16597 },
	{ (Il2CppRGCTXDataType)1, 21084 },
	{ (Il2CppRGCTXDataType)2, 21084 },
	{ (Il2CppRGCTXDataType)3, 16598 },
	{ (Il2CppRGCTXDataType)3, 16599 },
	{ (Il2CppRGCTXDataType)3, 16600 },
	{ (Il2CppRGCTXDataType)3, 16601 },
	{ (Il2CppRGCTXDataType)2, 16874 },
	{ (Il2CppRGCTXDataType)2, 16875 },
	{ (Il2CppRGCTXDataType)2, 16876 },
	{ (Il2CppRGCTXDataType)2, 16877 },
	{ (Il2CppRGCTXDataType)3, 16602 },
	{ (Il2CppRGCTXDataType)3, 16603 },
	{ (Il2CppRGCTXDataType)2, 16879 },
	{ (Il2CppRGCTXDataType)3, 16604 },
	{ (Il2CppRGCTXDataType)3, 16605 },
	{ (Il2CppRGCTXDataType)2, 21085 },
	{ (Il2CppRGCTXDataType)1, 16908 },
	{ (Il2CppRGCTXDataType)2, 21086 },
	{ (Il2CppRGCTXDataType)3, 16606 },
	{ (Il2CppRGCTXDataType)3, 16607 },
	{ (Il2CppRGCTXDataType)3, 16608 },
	{ (Il2CppRGCTXDataType)2, 16908 },
	{ (Il2CppRGCTXDataType)1, 21087 },
	{ (Il2CppRGCTXDataType)1, 21088 },
	{ (Il2CppRGCTXDataType)2, 21089 },
	{ (Il2CppRGCTXDataType)3, 16609 },
	{ (Il2CppRGCTXDataType)1, 21090 },
	{ (Il2CppRGCTXDataType)1, 21091 },
	{ (Il2CppRGCTXDataType)1, 21092 },
	{ (Il2CppRGCTXDataType)2, 21093 },
	{ (Il2CppRGCTXDataType)3, 16610 },
	{ (Il2CppRGCTXDataType)1, 21094 },
	{ (Il2CppRGCTXDataType)1, 21095 },
	{ (Il2CppRGCTXDataType)1, 21096 },
	{ (Il2CppRGCTXDataType)1, 21097 },
	{ (Il2CppRGCTXDataType)2, 21098 },
	{ (Il2CppRGCTXDataType)3, 16611 },
	{ (Il2CppRGCTXDataType)3, 16612 },
	{ (Il2CppRGCTXDataType)1, 21099 },
	{ (Il2CppRGCTXDataType)3, 16613 },
	{ (Il2CppRGCTXDataType)2, 21100 },
	{ (Il2CppRGCTXDataType)3, 16614 },
	{ (Il2CppRGCTXDataType)1, 17575 },
	{ (Il2CppRGCTXDataType)2, 17575 },
	{ (Il2CppRGCTXDataType)2, 17576 },
};
extern const Il2CppCodeGenModule g_UnityEngine_CoreModuleCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_CoreModuleCodeGenModule = 
{
	"UnityEngine.CoreModule.dll",
	2284,
	s_methodPointers,
	s_InvokerIndices,
	0,
	NULL,
	65,
	s_rgctxIndices,
	157,
	s_rgctxValues,
	NULL,
};
